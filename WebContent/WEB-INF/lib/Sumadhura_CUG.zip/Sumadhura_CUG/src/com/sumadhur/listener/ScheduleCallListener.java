package com.sumadhur.listener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.sumadhura.service.EmailFunction;
import com.sumadhura.transdao.SchedulerDao;
import com.sumadhura.util.UIProperties;

/**
 * @author Madhu Tokala
 * @Company Veeranki's Pvt Ltd.
 * @Date Aug 21, 2017 10:30:39 PM
 */

public class ScheduleCallListener extends UIProperties implements ServletContextListener {

	ServletContext context;
	@SuppressWarnings("deprecation")
	public void contextInitialized(ServletContextEvent contextEvent) {

		context = contextEvent.getServletContext();
		System.out.println("contex" +context);
		final int hour=Integer.valueOf(validateParams.getProperty("PMR_TXN_SCHDTIME"));
		final int minutes=Integer.valueOf(validateParams.getProperty("PMR_TXN_SCHDMINUTS"));


		logger.info("time     :"+hour);
		logger.info("minutes  :"+minutes);
		logger.info("********* Sumadhura Recive and Issue Transactions ServletContextListener Start *********");
		int delay = 1000;
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			public void run() {

				Date now = new Date();
				SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				logger.info("Formatted date :   " + dateFormatter.format(now) + "current time : " + now.getHours() + " minute : " + now.getMinutes());

				String addMinZeroDigit = String.valueOf(now.getMinutes()).length() == 1 ? "0" : "";
				String addHourZeroDigit = String.valueOf(now.getHours()).length() == 1 ? "0" : "";
				if (now.getHours() == hour && now.getMinutes() == minutes) {

					logger.info("Notification Time:" + addHourZeroDigit + now.getHours() + ":" + addMinZeroDigit + now.getMinutes());

					try {
						
						
						
						
						ApplicationContext context = new FileSystemXmlApplicationContext
						//("E:/pavan/Sumadhura UAT/Sumadhura/WebContent/WEB-INF/applicationContext.xml");
						("F:/Sumadhara/Sumadhura/WebContent/WEB-INF/applicationContext.xml");

						SchedulerDao obj = (SchedulerDao) context.getBean("schedularDao");
						 obj.statScheduler();

						
						//new SchedulerDao().statScheduler();
						logger.info("Scheduler Running Successfully....");
					} catch (Exception ex) {
						try {

							String emailBodyMsgTxt = "Closing balance Schedular is running failed, Please contact with support team on urgent basis";
							String emailSubjectTxt = "Closing balance schedular running failed";
							String emailFromAddress = "sumadhura5949@gmail.com";
							String[] sendTo = { "pavan45662@gmail.com", "sumadhura5949@gmail.com","vericherlav@gmail.com" };
							
							EmailFunction objEmailFunction = new EmailFunction();
							objEmailFunction.sendEmail(emailBodyMsgTxt,emailSubjectTxt,emailFromAddress,sendTo, new String[0],"");
						} catch (Exception e) {
							e.printStackTrace();
						}
						ex.printStackTrace();
						logger.info("Exception while running Scheduler class :" + ex.getMessage());
					}
				}
				
				/*if (now.getDate() == 10 && now.getMonth() == 10 && now.getYear() == 117 && now.getHours() == hour && now.getMinutes() == minutes ) {

					logger.info("Notification Time:" + addHourZeroDigit + now.getHours() + ":" + addMinZeroDigit + now.getMinutes());

					try {
						ApplicationContext context = new FileSystemXmlApplicationContext
						("F:/Sumadhara/Sumadhura/WebContent/WEB-INF/applicationContext.xml");

						SchedulerDao obj = (SchedulerDao) context.getBean("schedularDao");
						// obj.statScheduler();

						obj.startReadExcelData();
						
						//obj.startReadExcelDataForProducts();
						
						//new SchedulerDao().statScheduler();
						logger.info("Scheduler Running Successfully....");
					} catch (Exception ex) {
						try {
							new TestEmailFunction().main();
						} catch (Exception e) {
							e.printStackTrace();
						}
						ex.printStackTrace();
						logger.info("Exception while running Scheduler class :" + ex.getMessage());
					}
				}*/
				
			} // End of Run
		}, delay, 60000);
		context.setAttribute("timer", timer);

		logger.info("********* PMR Transactions ServletContextListener End *********");
	}

	public void contextDestroyed(ServletContextEvent contextEvent) {

		Timer timer = (Timer) context.getAttribute("timer");

		// cancel all pending tasks in the timers queue
		if (timer != null)
			timer.cancel();

		// remove the timer from the servlet context
		context.removeAttribute("timer");
		logger.info("********* Sumadhura Recive and Issue Transactions ServletContextListener End *********");
	}




}
