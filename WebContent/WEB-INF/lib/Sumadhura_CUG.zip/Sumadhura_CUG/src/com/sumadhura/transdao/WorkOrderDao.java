package com.sumadhura.transdao;

import java.util.List;
import java.util.Map;

public interface WorkOrderDao {

	List<Map<String, Object>> loadChildProduct(String prodId, String prodName);

	Map<String, String> loadQSProducts();

	String loadWOSubProds(String mainProductId);

	String loadWOChildProds(String subProductId);

	String loadWorkOrderMeasurements(String childProductId);

	List<String> getVendorInfo(String vendorName, boolean flag);

	List<Map<String, Object>> loadWOAreaMapping(String siteId);

	int getQS_WO_Temp_Issue_Dtls();

}
