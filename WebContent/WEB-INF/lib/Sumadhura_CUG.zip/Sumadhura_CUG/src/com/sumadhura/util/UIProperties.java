package com.sumadhura.util;
public class UIProperties {

	 public static ValidateParams validateParams = ValidateParams.validateParamsObj(); // This will Return the Only One Instance of Class ; SingleTon
	 public ReadProperties properties = ReadProperties.readPropertiesObj(); // This will Return the Only One Instance of Class ; SingleTon
	 //public final  TimeOutProperties timeout = TimeOutProperties.timeOutPropertiesObj();
	 public AppLogger logger = AppLogger.loggerObj();
	
	 public static String  evocherm="00170";

}
