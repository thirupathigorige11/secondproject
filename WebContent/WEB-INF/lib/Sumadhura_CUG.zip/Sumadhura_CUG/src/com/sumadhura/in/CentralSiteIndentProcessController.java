package com.sumadhura.in;

import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.service.CentralSiteIndentrocessService;
import com.sumadhura.service.IndentCreationService;
import com.sumadhura.service.IndentIssueService;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;


@Controller
public class CentralSiteIndentProcessController extends UIProperties{
	
	@Autowired
	@Qualifier("cntlIndentprocess")
	CentralSiteIndentrocessService csips;
	
	@Autowired
	@Qualifier("iisClass")
	IndentIssueService iis;
	
	
	@RequestMapping(value = "/sendCentralIndentToPD.spring", method = RequestMethod.POST)
	public String sendCentralIndentToPD(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			
			response = csips.sendToPD(model, request, site_id, user_id);
			if(response=="Indent Sent To Purchase Dept Successfully"){
			model.addAttribute("responseMessage",response);
			}
			else
				
			model.addAttribute("responseMessage1",response);	
			List<IndentCreationBean> listofCentralIndents = null;
			listofCentralIndents = csips.getAllCentralIndents();
			model.addAttribute("listofCentralIndents",listofCentralIndents);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String strAuditResponse = request.getAttribute("AuditResponse") == null ? "" : request.getAttribute("AuditResponse").toString();
		SaveAuditLogDetails.auditLog("0",user_id,"Sending Cntl To Purchase Dept",strAuditResponse,String.valueOf(site_id));
		return "ViewAllCentralIndents";
	}
	
	@RequestMapping(value = "/viewIndent.spring", method = RequestMethod.GET)
	public String viewIndent(Model model, HttpServletRequest request,HttpSession session) {
		String strSiteId = "";
		String user_id = "";
		IndentCreationBean icb = new IndentCreationBean();
		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			int indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			String reqSiteName = request.getParameter("siteName");
			
			model.addAttribute("indentCreationModelForm", icb);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
			icb.setIndentNumber(indentNumber);	
			icb.setSiteName(reqSiteName);	
			
			//iib.setProjectName(iis.getProjectName(session));
			List<IndentCreationBean> IndentDetails = null;
			List<IndentCreationBean> IndentDtls = null;
			IndentDtls = csips.getIndentCreationLists(indentNumber);
			model.addAttribute("IndentDtls",IndentDtls);
			IndentDetails = csips.getCentralIndentDetailsLists(indentNumber);
			model.addAttribute("IndentDetails",IndentDetails);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Showing Central Indent","Success",strSiteId);
		return "CentralIndent";
	}
	
	@RequestMapping(value = "/requestCentralIndentToOtherSite.spring", method = RequestMethod.POST)
	public String requestCentralIndentToOtherSite(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			
			response = csips.requestToOtherSite(model, request, site_id, user_id);
			model.addAttribute("responseMessage",response);
			List<IndentCreationBean> listofCentralIndents = null;
			listofCentralIndents = csips.getAllCentralIndents();
			model.addAttribute("listofCentralIndents",listofCentralIndents);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Requesting To Other Site From Central",response,String.valueOf(site_id));
		return "ViewAllCentralIndents";
	}
	
}
