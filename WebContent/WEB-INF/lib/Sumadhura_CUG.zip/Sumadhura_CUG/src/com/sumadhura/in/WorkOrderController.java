package com.sumadhura.in;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sumadhura.bean.IndentIssueBean;
import com.sumadhura.bean.WorkOrderBean;
import com.sumadhura.service.IndentIssueService;
import com.sumadhura.service.WorkOrderService;
import com.sumadhura.util.CheckSessionValidation;
import com.sumadhura.util.SaveAuditLogDetails;

@Controller
public class WorkOrderController {

	@Autowired
	@Qualifier("workControllerService")
	WorkOrderService workControllerService;
	@Autowired
	@Qualifier("iisClass")
	IndentIssueService iis;

	@RequestMapping(value = "/loadChildProductList.spring", method = RequestMethod.GET)
	public @ResponseBody List<Map<String, Object>> loadChildProductList(String prodId, String prodName) {
		System.out.println("WorkController.loadChildProductList()" + prodName);
		try {
			List<Map<String, Object>> list = workControllerService.loadChildProduct(prodId, "112");
			Gson gson = new Gson();
			String data = gson.toJson(list);
			System.err.println(data);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/certificateOfPayment.spring", method = RequestMethod.GET)
	public ModelAndView workOrder() {
		System.out.println("WorkController.work()");
		ModelAndView model = new ModelAndView();
		try {

			Map<String, String> productsList = iis.loadProds();
			model.addObject("productsList", productsList);
			model.addObject("increment", 0);
			System.out.println(productsList);
		} catch (Exception e) {
			e.printStackTrace();
			model.addObject("succMessage", "exception occured..");
		} finally {
			model.setViewName("WorkOrder/WorkOrder");
		}

		return model;
	}

	@RequestMapping(value = "/samplePage.spring", method = RequestMethod.GET)
	public String launchLogInPage(Model model, HttpServletRequest request, HttpSession session) {
		WorkOrderBean iib = new WorkOrderBean();

		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

		Map<String, String> list = workControllerService.loadQSProducts();
		int qsSequenceNumer = workControllerService.getQS_WO_Temp_Issue_Dtls();
		model.addAttribute("WorkOrderBean", iib);
		model.addAttribute("workMajorHead", list);//productsMap
		model.addAttribute("qsSequenceNumer", qsSequenceNumer);
		model.addAttribute("columnHeadersMap",ResourceBundle.getBundle("validationproperties"));
		//model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));

		// iib.setReqId(indentEntrySeqNum);
		//iib.setProjectName(iis.getProjectName(session));

		SaveAuditLogDetails audit = new SaveAuditLogDetails();
		// String
		// indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id = String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("", user_id, "New Issue View", "success", site_id1);
		return "WorkOrder/samplePage";
	}

	@RequestMapping(value = "/workOrderSubProducts", method = RequestMethod.POST)
	@ResponseBody
	public String workOrderSubProducts(@RequestParam("mainProductId") String mainProductId) {
		//System.out.println("WorkOrderController.workOrderSubProducts()");
		return workControllerService.loadWOSubProds(mainProductId);
	}

	@RequestMapping(value = "/workOrderChildProducts", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueChildProducts(@RequestParam("subProductId") String subProductId) {
		return workControllerService.loadWOChildProds(subProductId);
	}

	@RequestMapping(value = "/listOfWOmesurment", method = RequestMethod.POST)
	@ResponseBody
	public String listUnitsOfSubProducts(@RequestParam("childProductId") String childProductId) {
		return workControllerService.loadWorkOrderMeasurements(childProductId);
	}

	@RequestMapping(value = "/loadAndSetVendorInfoForWO", method = RequestMethod.GET)
	@ResponseBody
	public List<String> loadAndSetEmployerInfo(@RequestParam("vendorName") String vendorName,
			@RequestParam("loadVendorData") String loadVendorData) {

		List<String> vendorData = workControllerService.getVendorInfo(vendorName, loadVendorData);
		/*
		 * if(vendorData.isEmpty()){ vendorData.add("No Data Found"); }
		 */
		return vendorData;
	}

	@RequestMapping(value = "/loadWOAreaMapping.spring", method = RequestMethod.GET)
	@ResponseBody
	public List<Map<String, Object>> loadWOAreaMapping(HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		//System.out.println("WorkOrderController.loadWOAreaMapping()");
		String siteId = (String) CheckSessionValidation.validateUserSession(mav,
				session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));
		List<Map<String, Object>> qsAreaMapping = workControllerService.loadWOAreaMapping(siteId);
		System.out.println(qsAreaMapping);
		return qsAreaMapping;

	}

}
