package com.sumadhura.in;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.transdao.ProductDao;
import com.sumadhura.transdao.SchedulerDao;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.util.SaveAuditLogDetails;

@Controller
public class MastersController {
	@Autowired
	private ProductDao dao;

	@Autowired
	private UtilDao utilDao;
	
	
	@Autowired
	private SchedulerDao schDao;

	@RequestMapping("/AddProduct.spring")
	public  ModelAndView addform(HttpServletRequest request,HttpSession session){  
		ModelAndView mav = new ModelAndView();

		//List<ProductDetails> listProductsList = new ArrayList<ProductDetails>();
		try{

			List<Map<String,Object>> totalProductList = utilDao.getTotalProducts();
			System.out.println("ADD PRODUCT "+totalProductList.size());
			request.setAttribute("totalProductsList",totalProductList);

		}catch(Exception e){
			e.printStackTrace();
		}
		mav.setViewName("AddProduct");
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Product Master Viewed","success",site_id1);
			
		
		
		
		
		return mav;  
	}  
	
	
	
	@RequestMapping(value = "/saveproduct.spring", method = RequestMethod.POST)
	public ModelAndView saveproduct(HttpServletRequest request,HttpSession session) throws Exception {

		System.out.println("product controler");
		String strServiceType = "";
		String strProductName = "";
		ModelAndView model = new ModelAndView();
		List<Map<String, Object>> totalProductList = null;
		
		try {
			
			strServiceType = request.getParameter("ServiceType");
			int intProductId = dao.getSeqNo("combobox_Product");
			String strProductId = "PRD" + intProductId;

			System.out.println("strProduct name " + strProductName);
			System.out.println("strProduct name " + strProductId);
			int intCount = 0;
			if (strServiceType.equals("add")) {

				strProductName = request.getParameter("product") == null ? "" : request.getParameter("product").toString();
				int res = dao.checkProductNameAvailableOrNot(strProductName);
				if (res == 0) {
					intCount = dao.saveproduct(strProductName, strProductId);
					request.setAttribute("succMessage", "Product Name has been added successfully");
				} else {
					request.setAttribute("errMessage", "Product Name was already Added, Please try with Another Product Name");
				}
			} else if (strServiceType.equals("delete")) {

				String strProduct = request.getParameter("product_delete") == null ? "" : request.getParameter("product_delete").toString();
				if (strProduct.contains("@@")) {
					String productArr[] = strProduct.split("@@");
					if (productArr != null && productArr.length >= 1) {
						strProductId = productArr[0].trim();
						strProductName = productArr[1].trim();
					}
				}

				intCount = dao.deleteproduct(strProductId);
				if (intCount > 0) {

					request.setAttribute("succMessage", "Product deleted successfully");
				} else {
					request.setAttribute("errMessage", "Product not deleted");
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("AddProduct");
			totalProductList = utilDao.getTotalProducts();
			request.setAttribute("totalProductsList", totalProductList);
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Product Master clicked submit","success",site_id1);
			
		
		
		
		return model;
	}
	
	
	
	
	
	@RequestMapping("/viewaddedproduct.spring")
	public  @ResponseBody List<ProductDetails> getproductList(HttpSession session){

		System.out.println("get Total Products...");
		List<ProductDetails> listProductsList = new ArrayList<ProductDetails>();
		try{
			listProductsList = dao.getTotalProducts();
			System.out.println("get Total Products..." + listProductsList.size()); 
		}catch(Exception e){
			e.printStackTrace();
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id," Product Master Viewed All details","success",site_id1);
			
		
		
		
		
		
		return listProductsList;
	}



	@RequestMapping(value="/AddSubProduct.spring")  
	public  ModelAndView addsubform(HttpServletRequest request,HttpSession session){  
		ModelAndView mav = new ModelAndView();

		List<Map<String,Object>> totalProductList = utilDao.getTotalProducts();
		request.setAttribute("totalProductsList",totalProductList);

		/*List<Map<String,Object>> totalSubProductList = utilDao.getTotalSubProducts();
		request.setAttribute("totalSubProductsList", totalSubProductList);*/

		mav.setViewName("AddSubProduct");
	SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Sub Product Master Viewed","success",site_id1);
			
		
		return mav;  
	} 
	
	
	@RequestMapping(value = "/savesubproduct.spring", method = RequestMethod.POST)
	public ModelAndView savesubproduct(HttpServletRequest request,HttpSession session) throws Exception {

		int intCount = 0;
		String strProdId = "";
		System.out.println("Master controler for save subproduct");
		String strProduct = "";
		String strProductId = "";
		String strSubProdId = "";
		String strSubProduct = "";
		String strServiceType = "";
		String strSubProductName = "";
		ModelAndView model = new ModelAndView();
		List<Map<String, Object>> totalProductList = null;

		try {

			strServiceType = request.getParameter("ServiceType");

			if (strServiceType.equals("add")) {

				strProduct = request.getParameter("combobox_Product") == null ? "" : request.getParameter("combobox_Product").toString();
				strSubProductName = request.getParameter("subproduct") == null ? "" : request.getParameter("subproduct").toString();

				if (strProduct.contains("@@")) {

					String productArr[] = strProduct.split("@@");

					if (productArr != null && productArr.length >= 1) {
						strProductId = productArr[0].trim();
					}
				}

				int coount = dao.checkSubProductNameAvailableOrNot(strProductId, strSubProductName);
				if (coount == 0) {
					int getSubProductId = dao.getSeqNo("delete_SubProd");
					String strSubProductId = "SUB" + getSubProductId;
					intCount = dao.savesubproduct(strProductId, strSubProductId, strSubProductName);
					if (intCount > 0) {
						request.setAttribute("succMessage", "Sub Product Name has been added successfully");
					} else {
						request.setAttribute("errMessage", "Sub Product Name Not added.");
					}
				} else {
					request.setAttribute("errMessage", "Sub Product Name was already Added, Please try with Another Sub Product Name.");
				}

			} else if (strServiceType.equals("delete")) {

				strProduct = request.getParameter("combobox_Delete_Product") == null ? "": request.getParameter("combobox_Delete_Product").toString();
				strSubProduct = request.getParameter("combobox_delete_SubProd") == null ? "" : request.getParameter("combobox_delete_SubProd").toString();
				if (strProduct.contains("@@")) {
					String productArr[] = strProduct.split("@@");
					if (productArr != null && productArr.length >= 1) {
						strProdId = productArr[0].trim();
					}
				}
				if (strSubProduct.contains("@@")) {
					String subProductArr[] = strSubProduct.split("@@");
					if (subProductArr != null && subProductArr.length >= 1) {
						strSubProdId = subProductArr[0].trim();
					}
				}
				intCount = dao.deletesubproduct(strProdId, strSubProdId);
				if (intCount == 1) {

					request.setAttribute("succMessage", "Sub Product Name deleted successfully");
				} else {
					request.setAttribute("errMessage", "Sub Product deletion failed");
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Inside Save Subproduct() in Master Controller class   "+ex.getMessage());
		} finally {
			totalProductList = utilDao.getTotalProducts();
			request.setAttribute("totalProductsList", totalProductList);
			model.setViewName("AddSubProduct");
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Sub Product Master clicked submit","success",site_id1);
			
		
		
		
		return model;
	}
	
	
	
	
	
	@RequestMapping("/ViewSubProduct.spring")
	public  @ResponseBody List<ProductDetails> getSubProductList(HttpSession session){

		System.out.println("get Total Products and sub products...");
		List<ProductDetails> listSubProductsList = new ArrayList<ProductDetails>();
		try{
			listSubProductsList = dao.getTotalSubProducts();
			System.out.println("get Total Products and sub products..." + listSubProductsList.size()); 
		}catch(Exception e){
			e.printStackTrace();
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"sub product Viewed All Details","success",site_id1);
		
		
		
		
		
		return listSubProductsList;
	}

	@RequestMapping(value="/AddChildProduct.spring")  
	public  ModelAndView showform(HttpServletRequest request,HttpSession session){  
		ModelAndView mav = new ModelAndView();

		List<Map<String,Object>> totalProductList = utilDao.getTotalProducts();
		request.setAttribute("totalProductsList",totalProductList);

		/*List<Map<String,Object>> allProductList = utilDao.getAllChildProducts();
		request.setAttribute("totalChildProductsList", allProductList);*/

		mav.setViewName("AddChildProduct");
		
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"child product Viewed","success",site_id1);
				
			return mav;  
	}  

	@RequestMapping(value = "/save.spring", method = RequestMethod.POST)
	public ModelAndView saveChildProduct(HttpServletRequest request,HttpSession session) throws Exception {

		int intCount = 0;
		String strsubproduct = "";
		String strServiceType = "";
		String strSubProductId = "";
		String strsubProductId = "";
		String strChildProduct = "";
		String strmeasurementId = "";
		String strChildProductId = "";
		String strmeasurementName = "";
		String strChildProductName = "";
		ModelAndView model = new ModelAndView();
		List<Map<String, Object>> totalProductList = null;

		try {

			strServiceType = request.getParameter("ServiceType");

			if (strServiceType.equals("add")) {

				strsubproduct = request.getParameter("combobox_SubProd") == null ? "" : request.getParameter("combobox_SubProd").toString();

				if (strsubproduct.contains("@@")) {

					String subproductArr[] = strsubproduct.split("@@");

					if (subproductArr != null && subproductArr.length >= 1) {
						strSubProductId = subproductArr[0].trim();
					}
				}
				strChildProductName = request.getParameter("childproduct");
				strmeasurementName = request.getParameter("measurement");
				int count = dao.checkChildProductNameAvailableOrNot(strSubProductId, strChildProductName);
				if (count == 0) {
					int getChildProductId = dao.getSeqNo("childproduct");
					strChildProductId = "CHP" + getChildProductId;

					int getmeasurementId = dao.getSeqNo("measurement");
					strmeasurementId = "MST" + getmeasurementId;

					System.out.println("strsubProduct name " + strSubProductId);
					intCount = dao.saveChildProduct(strChildProductName, strChildProductId, strSubProductId, strmeasurementName, strmeasurementId);
					if (intCount == 1) {
						request.setAttribute("succMessage", "Child Product Name has been Added successfully");
					} else {
						request.setAttribute("Message", "Child Product Name Not Added.");
					}
				} else {

					request.setAttribute("errMessage", "Child Product Name was already Added, Please try with Another Child Product Name.");
				}

			} else if (strServiceType.equals("delete")) {

				strChildProduct = request.getParameter("combobox_delete_ChildProd") == null ? "" : request.getParameter("combobox_delete_ChildProd").toString();
				strChildProductId = "";

				if (strChildProduct.contains("@@")) {

					String childProductArr[] = strChildProduct.split("@@");

					if (childProductArr != null && childProductArr.length >= 1) {
						strChildProductId = childProductArr[0].trim();
					}
				}
				 strsubproduct = request.getParameter("combobox_delete_SubProd") == null ? "" : request.getParameter("combobox_delete_SubProd").toString();

				if (strsubproduct.contains("@@")) {

					String subproductArr[] = strsubproduct.split("@@");

					if (subproductArr != null && subproductArr.length >= 1) {
						strsubProductId = subproductArr[0].trim();
					}
				}

				intCount = dao.deletechildproduct(strsubProductId, strChildProductId);
				if (intCount == 1) {

					request.setAttribute("succMessage", "child Product Name Deleted successfully");
				} else {
					request.setAttribute("errMessage", "child Product Name deletion Fail");
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			totalProductList = utilDao.getTotalProducts();
			request.setAttribute("totalProductsList", totalProductList);
			model.setViewName("AddChildProduct");
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Child Product Master cicked submit","success",site_id1);
				
		return model;
	}
	
	
	
	@RequestMapping("/ViewChildProduct.spring")
	public  @ResponseBody List<ProductDetails> getAllChildProductList(HttpSession session){

		System.out.println("get Total Products and sub products...");
		List<ProductDetails> listAllProductsList = new ArrayList<ProductDetails>();
		try{
			listAllProductsList = dao.getAllChildProducts();
			System.out.println("get All Products List..." + listAllProductsList.size()); 
		}catch(Exception e){
			e.printStackTrace();
		}
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Child Product Master viewed All details","success",site_id1);
				
		
		
		
		return listAllProductsList;
	}





	@RequestMapping("/autoSearchproduct.spring")
	public @ResponseBody String getAutoSearchproductNames(@RequestParam(value = "term") String term)  {
		System.out.println("get Total Products...");
		List<String> listProductsList = new ArrayList<String>();
		String searchproductList = "" ;
		try{
			System.out.println("Auto Search for Product Name "+term);
			listProductsList = utilDao.getProductsBySearch(term);
			System.out.println("Get Product Name List Size "+listProductsList.size());
			searchproductList = new Gson().toJson(listProductsList);
			System.out.println("get Products..." + searchproductList); 
		}catch(Exception e){
			e.printStackTrace();
		}
		return searchproductList;
	}

	@RequestMapping("/autoSearchSubProduct.spring")
	public @ResponseBody String getAutoSearchSubproductNames(@RequestParam(value = "term") String term)  {
		System.out.println("get Total subProducts...");
		List<String> listSubProductList = new ArrayList<String>();
		String searchsubproductList = "" ;
		try{
			listSubProductList = utilDao.getSubProductsBySearch(term);
			searchsubproductList = new Gson().toJson(listSubProductList);
			System.out.println("get subProducts..." + listSubProductList.size()); 
		}catch(Exception e){
			e.printStackTrace();
		}
		return searchsubproductList;
	}
	
	
	@RequestMapping("/autoSearchchildproduct.spring")
	public @ResponseBody String getAutoSearchNames(@RequestParam(value = "term") String term,@RequestParam(value = "subProductId") String subProductId)  {
		List<String> listAllProductsList = new ArrayList<String>();
		String searchList = "";
		String strSubProductId = "";
		try{
			
			if(subProductId.contains("@@")){
				String subProductIdArr [] = subProductId.split("@@");
				strSubProductId = subProductIdArr[0];
			}
			
			listAllProductsList = utilDao.getchildProductsBySearch(strSubProductId,term);
			searchList = new Gson().toJson(listAllProductsList);
			System.out.println("get vendor List..." + listAllProductsList.size()); 

		}catch(Exception e){
			e.printStackTrace();
		}
		return searchList;
	}
	
	
	
	@RequestMapping("/uploadExcel.spring")
	public  ModelAndView uploadExcelData(HttpServletRequest request){  
		ModelAndView mav = new ModelAndView();

		//List<ProductDetails> listProductsList = new ArrayList<ProductDetails>();
		try{

			//schDao.startReadExcelData();
			
			//schDao.updatePriceListIdInIndentEntryTable();
			schDao.updatePriceListIdInIndentEntryTable();

		}catch(Exception e){
			e.printStackTrace();
		}
		mav.setViewName("AddProduct");
		return mav;  
	}  

}
