package com.sumadhura.service;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.PaymentBean;
import com.sumadhura.bean.VendorDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.PaymentDto;
import com.sumadhura.transdao.PaymentProcessDao;
import com.sumadhura.util.DateUtil;
import com.sumadhura.util.UIProperties;


@Service
public class PaymentProcessServiceImpl extends UIProperties implements PaymentProcessService{

	@Autowired
	PaymentProcessDao objPaymentProcessDao;

	@Autowired
	PlatformTransactionManager transactionManager;

	@Override
	public List<String> savePaymentIntiateDetails( HttpServletRequest request,HttpSession session){
		boolean isDatabaseCommitted = false;
		final List<PaymentBean> SuccessDataListToMail = new ArrayList<PaymentBean>();
		ModelAndView model = null;
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		String strInvoiceNo = "";
		String strPaymentIntiateType = "";
		String strVendorId = "";
		String strVendorName = "";
		String strPaymentReqDate = "";
		double doubleAmountToBeReleased = 0.0;
		String strRemarks = "";
		String strInvoiceDate = "";
		String strResponse  = "";
		int paymentId = 0;
		int PaymentEntryDetailsSeqID = 0;
		double doubleInvoiceAmount = 0.0;
		double doublePOAmount = 0.0;
		String strSiteId = "";
		String dcNo = "";
		String poNo = "";
		String pendingEmpId = "";
		String strPODate = "";
		String strInvoiceReceivedDate = "";
		String strDCDate = "";
		String strInvoiceNoInAP = "";
		String paymentType = "";
		String indentEntryId = "";
		double doubleCreditTotalAmount = 0.0;
		String strCreditNoteNumber = "";
		double doubleAdjustAmountFromAdvance = 0.0;
		List<String> successList = new ArrayList<String>();
		String user_id="";
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PMIn_savPMI, ");
		try {
			
			user_id=String.valueOf(session.getAttribute("UserId"));
			pendingEmpId = objPaymentProcessDao.getPendingEmpId(user_id);
			
			model = new ModelAndView();
			int intTotalNoOfRecords = Integer.parseInt(request.getParameter("noOfRecords") == null ? "0" : request.getParameter("noOfRecords").toString());

			if(intTotalNoOfRecords > 0){
				PaymentDto  objPaymentDto = null;
				for(int i = 1;i<=intTotalNoOfRecords;i++){
					if(request.getParameter("checkboxname"+i)!=null){

						if(StringUtils.isBlank(request.getParameter("AmountToBeReleased"+i))||StringUtils.isBlank(request.getParameter("PaymentreqDateId"+i)))
							{
								successList.add("Failed. You not entered the Amount (or) Req.Date");
								continue;
							}

						objPaymentDto = new PaymentDto();




						paymentType = request.getParameter("paymentType"+i);
						doubleAmountToBeReleased = Double.valueOf(request.getParameter("AmountToBeReleased"+i) == null ? "0" : request.getParameter("AmountToBeReleased"+i));

						poNo = request.getParameter("poNo"+i);
						doubleAdjustAmountFromAdvance = Double.valueOf(request.getParameter("AdjustAmountFromAdvance"+i)==null ? "0" : request.getParameter("AdjustAmountFromAdvance"+i));
						String remainingAmountInAdvanceInDB = objPaymentProcessDao.getRemainingAmountInAdvance(poNo);
						if(doubleAdjustAmountFromAdvance>Double.valueOf(remainingAmountInAdvanceInDB)){
							successList.add("Failed");
							continue;
						}

						if(paymentType.equals("DIRECT")){
							double invoiceAmount = Double.valueOf(request.getParameter("invoiceAmount"+i) == null ? "0" : request.getParameter("invoiceAmount"+i));
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+doubleAmountToBeReleased+doubleAdjustAmountFromAdvance)>invoiceAmount){successList.add("Failed");continue;}
						}
						if(paymentType.equals("ADVANCE")){
							double poAmount = Double.valueOf(request.getParameter("poAmount"+i) == null ? "0" : request.getParameter("poAmount"+i));
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+doubleAmountToBeReleased+doubleAdjustAmountFromAdvance)>poAmount){successList.add("Failed");continue;}
						}


						strInvoiceDate = request.getParameter("invoiceDate"+i);
						strInvoiceNo = request.getParameter("invoiceNo"+i);
						strInvoiceNoInAP = request.getParameter("invoiceNoInAP"+i);
						strVendorId = request.getParameter("vendorId"+i);
						strVendorName =  request.getParameter("vendorName"+i);
						strPaymentReqDate = request.getParameter("PaymentreqDateId"+i);
						strRemarks = request.getParameter("remarks"+i);
						paymentId = Integer.parseInt(request.getParameter("paymentSeqId"+i) == null ? "0" : request.getParameter("paymentSeqId"+i));
						doubleInvoiceAmount = Double.valueOf(request.getParameter("invoiceAmount"+i));
						strSiteId = request.getParameter("siteId"+i);
						dcNo = request.getParameter("dcNo"+i);

						doublePOAmount = Double.valueOf(request.getParameter("poAmount"+i));
						strPODate = request.getParameter("poDate"+i);
						strInvoiceReceivedDate = request.getParameter("invoiceReceivedDate"+i);
						strDCDate = request.getParameter("dcDate"+i);
						indentEntryId = request.getParameter("indentEntryId"+i)==null ? "0" : request.getParameter("indentEntryId"+i);
						doubleCreditTotalAmount = Double.valueOf(request.getParameter("creditTotalAmount"+i)==null ? "0" : request.getParameter("creditTotalAmount"+i));
						strCreditNoteNumber = request.getParameter("creditNoteNumber"+i)==null ? "0" : request.getParameter("creditNoteNumber"+i);
						doubleAdjustAmountFromAdvance = Double.valueOf(request.getParameter("AdjustAmountFromAdvance"+i)==null ? "0" : request.getParameter("AdjustAmountFromAdvance"+i));

						WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , InvoiceNumber:"+strInvoiceNo+" , PONumber:"+poNo);

						


						objPaymentDto.setDoubleAmountToBeReleased(doubleAmountToBeReleased);
						objPaymentDto.setStrInvoiceNo(strInvoiceNo);
						objPaymentDto.setStrInvoiceNoInAP(strInvoiceNoInAP);
						objPaymentDto.setStrVendorId(strVendorId);
						objPaymentDto.setStrPaymentReqDate(strPaymentReqDate);
						objPaymentDto.setStrInvoiceDate(strInvoiceDate);
						objPaymentDto.setStrRemarks(strRemarks);
						objPaymentDto.setDoubleInvoiceAmount(doubleInvoiceAmount);
						objPaymentDto.setStrSiteId(strSiteId);
						objPaymentDto.setStrDCNo(dcNo);
						objPaymentDto.setStrPONo(poNo);
						objPaymentDto.setStrPendingEmpId(pendingEmpId);
						objPaymentDto.setIntPaymentId(paymentId);
						objPaymentDto.setDoublePOAmount(doublePOAmount);
						objPaymentDto.setStrPODate(strPODate);
						objPaymentDto.setStrInvoiceReceivedDate(strInvoiceReceivedDate);
						objPaymentDto.setStrDCDate(strDCDate);
						int intSiteWisePaymentNo = 0;
						intSiteWisePaymentNo = objPaymentProcessDao.getSiteWisePaymentNo(strSiteId);
						objPaymentDto.setIntSiteWisePaymentId(intSiteWisePaymentNo);
						objPaymentDto.setPaymentType(paymentType);
						objPaymentDto.setIntIndentEntryId(Integer.valueOf(indentEntryId));
						objPaymentDto.setDoubleCreditTotalAmount(doubleCreditTotalAmount);
						objPaymentDto.setStrCreditNoteNumber(strCreditNoteNumber);
						objPaymentDto.setDoubleAdjustAmountFromAdvance(doubleAdjustAmountFromAdvance);


						if(paymentId == 0){
							paymentId = objPaymentProcessDao.getPaymentId();
						}

						PaymentEntryDetailsSeqID = objPaymentProcessDao.getPaymentDetailsId();



						objPaymentProcessDao.saveOrUpdePaymentTable(objPaymentDto, paymentId);

						objPaymentProcessDao.savePaymentProcessDtlsTable(objPaymentDto, paymentId,PaymentEntryDetailsSeqID);



						objPaymentDto.setStrEmployeeId(user_id);
						objPaymentProcessDao.savePaymentApproveRejectTable(objPaymentDto, paymentId,PaymentEntryDetailsSeqID);

						//strResponse = "Success";
						successList.add("PaymentDetailsId: "+String.valueOf(PaymentEntryDetailsSeqID)+" ,"+(StringUtils.isNotBlank(strInvoiceNo)?("InvoiceNumber: "+strInvoiceNo):("PONumber: "+poNo))+"  => Success");
						PaymentBean objPB = new PaymentBean();
						objPB.setIntPaymentDetailsId(PaymentEntryDetailsSeqID);
						objPB.setStrInvoiceNo(strInvoiceNo);
						objPB.setStrPONo(poNo);
						objPB.setDoubleAmountToBeReleased(doubleAmountToBeReleased);
						objPB.setStrVendorName(strVendorName);
						SuccessDataListToMail.add(objPB);

					}
				}
			}else{
				model.setViewName("payment/payment");
			}
			transactionManager.commit(status);
			isDatabaseCommitted = true;
			WriteTrHistory.write("Tr_Completed");



		}catch(Exception e){
			successList.add("Failed");
			transactionManager.rollback(status);
			isDatabaseCommitted = false;
			WriteTrHistory.write("Tr_Completed");
			e.printStackTrace();
		}
		final String user_id_final=user_id;
		final String strSiteId_final=strSiteId;
		final String pendingEmpId_final=pendingEmpId;
		final int getLocalPort = request.getLocalPort();
		if(isDatabaseCommitted&&SuccessDataListToMail.size()!=0){

			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{


				executorService.execute(new Runnable() {
					public void run() {
						EmailFunction objEmailFunction = new EmailFunction();
						String [] emailToAddress = getPaymentApproverEmailId(user_id_final);
						objEmailFunction.sendPaymentInitiatedMail(SuccessDataListToMail,emailToAddress,getLocalPort,strSiteId_final,pendingEmpId_final);
					}
				});
				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}

		}

		return successList;
	}
	private String[] getPaymentApproverEmailId(String strUserId) {
		return objPaymentProcessDao.getPaymentApproverEmailId(strUserId);

	}

	@Override
	public List<PaymentBean> getInvoiceDetails(String fromDate, String toDate,String siteId,String vendorId,String invoiceNumber){

		List<PaymentBean> listPaymentBean =  null;
		try{
			listPaymentBean = objPaymentProcessDao.getInvoiceDetails(fromDate, toDate, siteId,vendorId,invoiceNumber);
		}catch(Exception e){
			e.printStackTrace();
		}

		return listPaymentBean;
	}
	@Override
	public List<PaymentBean> getPODetails(String fromDate, String toDate,String siteId,String vendorId,String poNumber){

		List<PaymentBean> listPaymentBean =  null;
		try{
			listPaymentBean = objPaymentProcessDao.getPODetails(fromDate, toDate, siteId, vendorId,poNumber);
		}catch(Exception e){
			e.printStackTrace();
		}

		return listPaymentBean;
	}
	public List<String> savePaymentApprovalAndRejectDetails( HttpServletRequest request,HttpSession session,String strUserId){
		PaymentBean  objPaymentBean = null;
		final List<PaymentBean> SuccessDataListToMail = new ArrayList<PaymentBean>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		//	TransactionStatus status = transactionManager.getTransaction(def);
		String actualRequestedAmount="";
		String actualRequestedDate="";
		String changedRequestedAmount="";
		String changedRequestedDate="";
		String comments="";
		//	String strStatus="";
		int intTotalNoOfRecords =0;
		String strPaymentIntiateType="";
		String paymentDetailsId="";
		String pendingEmpId="";
		String paymentId="";
		double tmpactualRequestedAmount=0.0;
		double tmpRequestedAmount=0.0;
		boolean isRowChanged = false;

		double amtAfterModified=0.0;
		double invoiceAmount=0.0;
		String response="success";
		String deptEmpId="";
		String receivedDate="";
		String remarks="";
		String reqSiteId="";
		double doubleAdjustAmountFromAdvance=0.0;
		double actualDoubleAdjustAmountFromAdvance=0.0;
		String poNo="";
		String paymentType="";
		double poAmount=0.0;
		String invoiceNo="";
		String strVendorName="";
		List<String> successList = new ArrayList<String>();

		String site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();	
		//	String accountsDeptId = validateParams.getProperty("ACCOUNTS_DEPT_ID") == null ? "" : validateParams.getProperty("ACCOUNTS_DEPT_ID").toString();

		try{

			pendingEmpId=objPaymentProcessDao.getPendingEmpId(strUserId);

			if(pendingEmpId.equals("-")){

				deptEmpId=objPaymentProcessDao.getDeptId(strUserId);
			}

			intTotalNoOfRecords = Integer.parseInt(request.getParameter("listTotalInvoices") == null ? "0" : request.getParameter("listTotalInvoices").toString());
			//	if(accountsDeptId.equals(deptEmpId)){

			if(intTotalNoOfRecords > 0){
				for(int i = 1;i<=intTotalNoOfRecords;i++){
					strPaymentIntiateType = request.getParameter("paymentIntiateType"+i);
					if(strPaymentIntiateType.equalsIgnoreCase("Approved")||strPaymentIntiateType.equalsIgnoreCase("Rejected")){
						objPaymentBean = new PaymentBean();
						changedRequestedAmount=request.getParameter("RequestedAmt"+i);

						changedRequestedDate=request.getParameter("RequestedDate"+i);
						comments=request.getParameter("comment"+i);
						paymentDetailsId=request.getParameter("paymentDetailsId"+i);
						paymentId=request.getParameter("PaymentId"+i);
						actualRequestedAmount=request.getParameter("actualRequestedAmt"+i);
						actualRequestedDate=request.getParameter("actualRequestedDate"+i);
						invoiceAmount = Double.valueOf(request.getParameter("invoiceAmount"+i) == null ? "0" : request.getParameter("invoiceAmount"+i));
						poAmount = Double.valueOf(request.getParameter("poAmount"+i) == null ? "0" : request.getParameter("poAmount"+i));
						receivedDate=request.getParameter("receivedDate"+i);
						remarks=request.getParameter("remarks"+i);
						reqSiteId=request.getParameter("siteId"+i);
						doubleAdjustAmountFromAdvance=Double.valueOf(request.getParameter("AdjustAmountFromAdvance"+i));
						actualDoubleAdjustAmountFromAdvance=Double.valueOf(request.getParameter("actualAdjustAmountFromAdvance"+i));
						poNo = request.getParameter("poNo"+i);
						invoiceNo = request.getParameter("invoiceNo"+i);
						paymentType = request.getParameter("paymentType"+i);
						strVendorName =  request.getParameter("vendorName"+i);

						if(remarks !=null && !remarks.equals("")){
							if(StringUtils.isNotBlank(comments)){
								remarks = remarks + "@@@" + comments;
							}
						}else{
							remarks = comments;
						}

						String remainingAmountInAdvanceInDB = objPaymentProcessDao.getRemainingAmountInAdvance(poNo);
						if((doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance)>Double.valueOf(remainingAmountInAdvanceInDB)){
							successList.add("Failed");
							continue;
						}

						if(paymentType.equals("DIRECT")){
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+(Double.valueOf(changedRequestedAmount)-Double.valueOf(actualRequestedAmount))+(doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance))>invoiceAmount){successList.add("Failed");continue;}
						}
						if(paymentType.equals("ADVANCE")){
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+(Double.valueOf(changedRequestedAmount)-Double.valueOf(actualRequestedAmount))+(doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance))>poAmount){successList.add("Failed");continue;}
						}


						tmpactualRequestedAmount=Double.parseDouble(actualRequestedAmount);
						tmpRequestedAmount=Double.parseDouble(changedRequestedAmount);
						objPaymentBean.setIntPaymentDetailsId(Integer.parseInt(paymentDetailsId));	
						objPaymentBean.setActualRequestedAmount(actualRequestedAmount);
						objPaymentBean.setActualRequestedDate(actualRequestedDate);
						objPaymentBean.setRequestedAmount(changedRequestedAmount);
						objPaymentBean.setRequestedDate(changedRequestedDate);
						objPaymentBean.setStrRemarks(comments);
						objPaymentBean.setStrEmployeeId(strUserId);
						objPaymentBean.setStrSiteId(reqSiteId);
						objPaymentBean.setDoubleAdjustAmountFromAdvance(doubleAdjustAmountFromAdvance);
						objPaymentBean.setActualDoubleAdjustAmountFromAdvance(actualDoubleAdjustAmountFromAdvance);


						SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
						SimpleDateFormat format1 = new SimpleDateFormat("dd-M-y");
						SimpleDateFormat requestDateFormat = new SimpleDateFormat("dd/MM/yyyy");

						java.util.Date d1 = null;
						java.util.Date d2 = null;

						d1 = format.parse(actualRequestedDate);
						d2 = requestDateFormat.parse(changedRequestedDate);

						//in milliseconds
						long diff = d2.getTime() - d1.getTime();
						long diffDays = diff / (24 * 60 * 60 * 1000);

						java.sql.Timestamp  timestamp = null;
						try {
							SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
							java.util.Date parsedDate = dateFormat.parse(changedRequestedDate);
							timestamp = new java.sql.Timestamp(parsedDate.getTime());
							System.out.println(timestamp);
						} catch(Exception e) { 
							e.printStackTrace();
						}

						if(StringUtils.isNotBlank(comments)){
							objPaymentProcessDao.UpDatePaymentDetailsRemarks(paymentDetailsId,remarks);
						}

						if(diffDays != 0){

							isRowChanged=true;	 
							objPaymentProcessDao.updatePaymentDetailsDate(paymentDetailsId,changedRequestedDate);


						} 


						if(strPaymentIntiateType.equalsIgnoreCase("Approved")){
							if(StringUtils.isNotBlank(pendingEmpId) && !pendingEmpId.equals("-")){
								int intResponse=0;

								intResponse=objPaymentProcessDao.updateRequestedPaymentEmpId(paymentDetailsId,pendingEmpId);	 


							} else if(StringUtils.isNotBlank(deptEmpId) && !deptEmpId.equals("-")){

								objPaymentProcessDao.updateRequestedPaymentDeptId(paymentDetailsId,deptEmpId);	 
								objPaymentProcessDao.saveAccountsDeptTable(objPaymentBean);

							}
							if(!actualRequestedAmount.equals(changedRequestedAmount))
							{
								isRowChanged=true;
								objPaymentProcessDao.UpDatePaymentDetails(paymentDetailsId,Double.valueOf(changedRequestedAmount));




							}
							if(doubleAdjustAmountFromAdvance!=actualDoubleAdjustAmountFromAdvance){
								isRowChanged=true;
								objPaymentProcessDao.updatePaymentDetailsAdjustAmount(paymentDetailsId,doubleAdjustAmountFromAdvance);
								objPaymentProcessDao.updateIntiateAmountInAdvancePaymentPO(poNo,actualDoubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance);
							}
							if((!actualRequestedAmount.equals(changedRequestedAmount))||(doubleAdjustAmountFromAdvance!=actualDoubleAdjustAmountFromAdvance)){

								objPaymentProcessDao.updateReqUptoInAccPayment(paymentId,actualRequestedAmount,changedRequestedAmount,actualDoubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance);

							}

							objPaymentProcessDao.saveApprovalDetails(paymentId,strUserId,comments,paymentDetailsId,site_id);
							if(isRowChanged){

								objPaymentProcessDao.saveChangedDetails(objPaymentBean,"M"); 


							}
						}
						else if(strPaymentIntiateType.equalsIgnoreCase("Rejected")){

							objPaymentProcessDao.saveRejectDetails(paymentId,strUserId,comments,paymentDetailsId,site_id);

							objPaymentProcessDao.updateReqUptoInAccPaymentOnReject(paymentId,actualRequestedAmount,actualDoubleAdjustAmountFromAdvance);

							objPaymentProcessDao.updateIntiateAmountInAdvancePaymentPOOnReject(poNo,actualDoubleAdjustAmountFromAdvance);


						}
						successList.add("PaymentDetailsId: "+String.valueOf(paymentDetailsId)+" ,"+(StringUtils.isNotBlank(invoiceNo)?("InvoiceNumber: "+invoiceNo):("PONumber: "+poNo))+"  => Success");

						if(strPaymentIntiateType.equalsIgnoreCase("Approved")){
							PaymentBean objPB = new PaymentBean();
							objPB.setIntPaymentDetailsId(Integer.parseInt(paymentDetailsId));
							objPB.setStrInvoiceNo(invoiceNo);
							objPB.setStrPONo(poNo);
							objPB.setDoubleAmountToBeReleased(Double.valueOf(changedRequestedAmount));
							objPB.setStrVendorName(strVendorName);
							SuccessDataListToMail.add(objPB);
						}
					}//if-approve OR reject
				}//for


			}

			/*	}else{

			int intResponse=0;
			for(int i = 1;i<=intTotalNoOfRecords;i++){

			paymentDetailsId=request.getParameter("paymentDetailsId"+i);

			intResponse=objPaymentProcessDao.updateRequestedPaymentEmpId(paymentDetailsId,pendingEmpId);

			}

			if(intResponse>0){
				response="success";
			}

		}*/



		}catch(Exception e){
			successList.add("Failed");
			response="failure";

			e.printStackTrace();
		}
		final String user_id_final=strUserId;
		
		final String strSiteId_final=reqSiteId;
		final String pendingEmpId_final=pendingEmpId;
		final int getLocalPort = request.getLocalPort();
		if(SuccessDataListToMail.size()!=0 && StringUtils.isNotBlank(pendingEmpId) && !pendingEmpId.equals("-")){

			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{


				executorService.execute(new Runnable() {
					public void run() {
						EmailFunction objEmailFunction = new EmailFunction();
						String [] emailToAddress = getPaymentApproverEmailId(user_id_final);
						objEmailFunction.sendPaymentInitiatedMail(SuccessDataListToMail,emailToAddress,getLocalPort,strSiteId_final,pendingEmpId_final);
						
					}
				});
				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}

		}

		return successList;


	}
	@Override
	public List<PaymentBean> getAccDeptPaymentPendingDetails(String strUserId) {
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		//String accDeptId = validateParams.getProperty("ACCOUNTS_DEPT_ID") == null ? "" : validateParams.getProperty("ACCOUNTS_DEPT_ID").toString();
		list = objPaymentProcessDao.getAccDeptPaymentPendingDetails(strUserId);
		return list;
	}

	@Override
	public List<String> createAccountDeptTransaction(HttpServletRequest request , String strEmpId) {

		final List<PaymentBean> SuccessDataListToMail = new ArrayList<PaymentBean>();
		final Map<String,List<PaymentBean>> PaymentRejectMapToMail = new HashMap<String,List<PaymentBean>>();
		String strResponse  = "";
		PaymentDto objPaymentDto = null;
		String requestedAmount="";
		String requestedDate="";
		int intTotalNoOfRecords =0;
		String paymentDetailsId="";
		String remarks="";
		int intAccDeptPaymentProcessId = 0;
		String strTransactionRefrenceno = "";
		String strSiteWisePaymentId = "";
		String paymentType = "";
		String poNo="";
		String invoiceNo="";
		double doubleAdjustAmountFromAdvance = 0.0;
		double actualDoubleAdjustAmountFromAdvance = 0.0;
		double invoiceAmount=0.0;
		double poAmount=0.0;
		String actualRequestedAmount="";
		String paymentId="";
		String siteId="";
		String requestReceiveFrom = "";
		String comments = "";
		String strVendorName = "";
		List<String> successList = new ArrayList<String>();
		try {
			intTotalNoOfRecords = Integer.parseInt(request.getParameter("noOfPendingPayments") == null ? "0" : request.getParameter("noOfPendingPayments").toString());
			if(intTotalNoOfRecords > 0){


				String strPendingEmpId = objPaymentProcessDao.getApproverEmpIdInAccounts(strEmpId);	

				for(int i = 1;i<=intTotalNoOfRecords;i++){
					String strPaymentIntiateType = request.getParameter("paymentIntiateType"+i);
					if(strPaymentIntiateType.equalsIgnoreCase("Approved")){

						String paymentMode = request.getParameter("paymentMode"+i);

						objPaymentDto = new PaymentDto();

						paymentType = request.getParameter("paymentType"+i);
						paymentDetailsId = request.getParameter("paymentDetailsId"+i);
						requestedDate = request.getParameter("paymentRequestDate"+i);
						requestedAmount = request.getParameter("requestAmount"+i);
						intAccDeptPaymentProcessId = Integer.parseInt(request.getParameter("accDeptPmtProcessId"+i));
						remarks = request.getParameter("remarks"+i);
						comments = request.getParameter("comments"+i);
						strTransactionRefrenceno = request.getParameter("utrOrChqNo"+i);
						strSiteWisePaymentId = request.getParameter("siteWisePaymetId"+i);
						doubleAdjustAmountFromAdvance = Double.valueOf(request.getParameter("AdjustAmountFromAdvance"+i));
						actualDoubleAdjustAmountFromAdvance=Double.valueOf(request.getParameter("actualAdjustAmountFromAdvance"+i));
						poNo = request.getParameter("poNo"+i);
						invoiceNo = request.getParameter("invoiceNo"+i);
						invoiceAmount = Double.valueOf(request.getParameter("invoiceAmount"+i) == null ? "0" : request.getParameter("invoiceAmount"+i));
						poAmount = Double.valueOf(request.getParameter("poAmount"+i) == null ? "0" : request.getParameter("poAmount"+i));
						actualRequestedAmount=request.getParameter("actualRequestedAmt"+i);
						paymentId = request.getParameter("paymentSeqId"+i) == null ? "0" : request.getParameter("paymentSeqId"+i);
						siteId = request.getParameter("siteId"+i);

						if(remarks !=null && !remarks.equals("")){
							if(StringUtils.isNotBlank(comments)){
								remarks = remarks + "@@@" + comments;
							}
						}else{
							remarks = comments;
						}

						String remainingAmountInAdvanceInDB = objPaymentProcessDao.getRemainingAmountInAdvance(poNo);
						if((doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance)>Double.valueOf(remainingAmountInAdvanceInDB)){
							successList.add("Failed");
							continue;
						}
						if(paymentType.equals("DIRECT")){
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+(Double.valueOf(requestedAmount)-Double.valueOf(actualRequestedAmount))+(doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance))>invoiceAmount){successList.add("Failed");continue;}
						}
						if(paymentType.equals("ADVANCE")){
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+(Double.valueOf(requestedAmount)-Double.valueOf(actualRequestedAmount))+(doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance))>poAmount){successList.add("Failed");continue;}
						}

						objPaymentDto.setIntAccDeptPaymentProcessId(intAccDeptPaymentProcessId);
						objPaymentDto.setIntPaymentDetailsId(Integer.parseInt(paymentDetailsId));
						objPaymentDto.setDoubleAmountToBeReleased(Double.valueOf(requestedAmount));
						objPaymentDto.setStrPendingEmpId(strPendingEmpId);
						objPaymentDto.setStrPaymentReqDate(requestedDate);
						objPaymentDto.setStrRefrenceNo(strTransactionRefrenceno);
						objPaymentDto.setStrRemarks(remarks);
						objPaymentDto.setIntSiteWisePaymentId(Integer.parseInt(strSiteWisePaymentId));
						objPaymentDto.setPaymentMode(paymentMode);
						objPaymentDto.setPaymentType(paymentType);
						objPaymentDto.setDoubleAdjustAmountFromAdvance(doubleAdjustAmountFromAdvance);
						objPaymentDto.setStrEmployeeId(strEmpId);
						objPaymentDto.setStrSiteId(siteId);


						if(!strPendingEmpId.equals("") && !strPendingEmpId.equals("VND")){


							int TempPaymentId = objPaymentProcessDao.getAccTempPaymentTransactionSeqNo();
							objPaymentProcessDao.insertTempPaymentTransactionsTbl(objPaymentDto,TempPaymentId);



							objPaymentProcessDao.updateAccDeptPaymentProcsstbl(objPaymentDto);

							objPaymentProcessDao.saveAccountsApproveRejectTable(objPaymentDto,intAccDeptPaymentProcessId,TempPaymentId);

							objPaymentProcessDao.saveAccountApprovalDetails(intAccDeptPaymentProcessId,strEmpId,"",0,siteId);

						}

						successList.add("PaymentDetailsId: "+String.valueOf(paymentDetailsId)+" ,"+(StringUtils.isNotBlank(invoiceNo)?("InvoiceNumber: "+invoiceNo):("PONumber: "+poNo))+"  => Success");
					}//if-approve
					else if(strPaymentIntiateType.equalsIgnoreCase("Rejected")){
						requestReceiveFrom = request.getParameter("requestReceiveFrom"+i);
						intAccDeptPaymentProcessId = Integer.parseInt(request.getParameter("accDeptPmtProcessId"+i));
						paymentDetailsId = request.getParameter("paymentDetailsId"+i);
						siteId = request.getParameter("siteId"+i);
						actualRequestedAmount=request.getParameter("actualRequestedAmt"+i);
						paymentId = request.getParameter("paymentSeqId"+i) == null ? "0" : request.getParameter("paymentSeqId"+i);
						actualDoubleAdjustAmountFromAdvance=Double.valueOf(request.getParameter("actualAdjustAmountFromAdvance"+i));
						poNo = request.getParameter("poNo"+i);
						invoiceNo = request.getParameter("invoiceNo"+i);
						strVendorName = request.getParameter("vendorName"+i);
						//objPaymentProcessDao.updateRequestedPaymentDeptIdOnAccDeptReject(paymentDetailsId,requestReceiveFrom);
						//objPaymentProcessDao.removeRowInAccDeptPmtProcessTbl(intAccDeptPaymentProcessId);
						objPaymentProcessDao.setInactiveRowInAccDeptPmtProcessTbl(intAccDeptPaymentProcessId);
						objPaymentProcessDao.saveAccountRejectDetails(intAccDeptPaymentProcessId,strEmpId,"",0,siteId);


						//objPaymentProcessDao.saveRejectDetails(paymentId,strUserId,comments,paymentDetailsId,site_id);

						objPaymentProcessDao.updateReqUptoInAccPaymentOnReject(paymentId,actualRequestedAmount,actualDoubleAdjustAmountFromAdvance);

						objPaymentProcessDao.updateIntiateAmountInAdvancePaymentPOOnReject(poNo,actualDoubleAdjustAmountFromAdvance);


					
						successList.add("PaymentDetailsId: "+String.valueOf(paymentDetailsId)+" ,"+(StringUtils.isNotBlank(invoiceNo)?("InvoiceNumber: "+invoiceNo):("PONumber: "+poNo))+"  => Success");
						
						PaymentBean objPB = new PaymentBean();
						objPB.setIntPaymentDetailsId(Integer.parseInt(paymentDetailsId));
						objPB.setStrInvoiceNo(invoiceNo);
						objPB.setStrPONo(poNo);
						objPB.setDoubleAmountToBeReleased(Double.valueOf(actualRequestedAmount));
						objPB.setStrVendorName(strVendorName);
						if(PaymentRejectMapToMail.containsKey(siteId)){
							PaymentRejectMapToMail.get(siteId).add(objPB);
						}
						else{
							List<PaymentBean> list = new ArrayList<PaymentBean>();
							list.add(objPB);
							PaymentRejectMapToMail.put(siteId,list);
						}
						
					}
					
				}

			}
			strResponse="Success";
		} catch (Exception e) {
			successList.add("Failed");
			e.printStackTrace();
		}
		if(PaymentRejectMapToMail.size()!=0){

			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{


				executorService.execute(new Runnable() {
					public void run() {
						EmailFunction objEmailFunction = new EmailFunction();
						for(Map.Entry<String, List<PaymentBean>> entry : PaymentRejectMapToMail.entrySet()){
							String [] emailToAddress = getAllSiteLevelEmails(entry.getKey());
							objEmailFunction.paymentRejectedMail(entry.getValue(), emailToAddress);
						}
					}
				});
				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}

		}
		//strResponse = objPaymentProcessDao.getAccDeptPaymentPendingDetails(steEmpId);
		return successList;
	}
	private String[] getAllSiteLevelEmails(String siteId) {
		return objPaymentProcessDao.getAllSiteLevelEmails(siteId);
	}

	@Override
	public List<PaymentBean> updateAccountDeptTransaction(HttpServletRequest request, HttpServletResponse response , String strEmpId) {

		final List<PaymentBean> SuccessDataListToMail = new ArrayList<PaymentBean>();
		List<PaymentBean> paymentDetailsList = new ArrayList<PaymentBean>();
		int intTempPaymentTransactionId=0;
		int intPaymentDetailsId=0;
		int intPaymentId=0;
		String paymentType="";
		String requestedDate="";
		String utrChequeNo="";
		String remarks="";
		int intSiteWisePaymentId=0;
		PaymentDto objPaymentDto = null;
		PaymentBean paymentBean = null;
		int intTotalNoOfRecords = 0;
		String requestedAmount="";
		String invoiceNo="";
		String poNo="";
		double doublePOAmount=0.0;
		double doubleAdjustAmountFromAdvance=0.0;
		double actualDoubleAdjustAmountFromAdvance=0.0;
		double doubleInvoiceAmount=0.0;
		int intAccDeptPaymentProcessId=0;
		String siteId = "";
		String actualUtrChequeNo="";
		String actualPaymentMode="";
		String invoiceDate = "";
		String invoiceReceiveDate = "";
		String poDate = "";
		String creditNoteNumber = "";
		String creditTotalAmount = "";
		String vendorName = "";
		String vendorId = "";
		int intSerialNo = 0;
		Double doublePaidAmount = 0.0;
		String strPaymentRequestReceivedDate = "";
		String siteName="";
		String comments = "";
		boolean isDownload = false;
		Map<String,String> requestedDateMap=new HashMap<String,String>();
		

		try {
			intTotalNoOfRecords = Integer.parseInt(request.getParameter("noOfPendingPayments") == null ? "0" : request.getParameter("noOfPendingPayments").toString());
			if(intTotalNoOfRecords > 0){


				String strPendingEmpId = objPaymentProcessDao.getApproverEmpIdInAccounts(strEmpId);	

				for(int i = 1;i<=intTotalNoOfRecords;i++){

					String strPaymentIntiateType = request.getParameter("paymentIntiateType"+i);
					intTempPaymentTransactionId=Integer.parseInt(request.getParameter("tempPaymentTransactionId"+i));
					intAccDeptPaymentProcessId=Integer.parseInt(request.getParameter("accDeptPmtProcessId"+i));
					intPaymentDetailsId=Integer.parseInt(request.getParameter("paymentDetailsId"+i));
					intPaymentId=Integer.parseInt(request.getParameter("paymentId"+i));
					paymentType=request.getParameter("paymentType"+i);
					requestedDate=request.getParameter("requestedDate"+i);
					utrChequeNo=request.getParameter("utrChequeNo"+i);
					actualUtrChequeNo=request.getParameter("actualUtrChequeNo"+i);
					actualPaymentMode=request.getParameter("actualPaymentMode"+i);
					remarks=request.getParameter("remarks"+i);
					comments=request.getParameter("comments"+i);
					intSiteWisePaymentId=Integer.parseInt(request.getParameter("siteWisePaymentId"+i));
					requestedAmount = request.getParameter("requestAmount"+i);
					poNo = request.getParameter("poNo"+i);
					invoiceNo = request.getParameter("invoiceNo"+i);
					doubleAdjustAmountFromAdvance = Double.valueOf(request.getParameter("AdjustAmountFromAdvance"+i));
					actualDoubleAdjustAmountFromAdvance=Double.valueOf(request.getParameter("actualAdjustAmountFromAdvance"+i));
					doubleInvoiceAmount = Double.valueOf(request.getParameter("invoiceAmount"+i) == null ? "0" : request.getParameter("invoiceAmount"+i));
					doublePOAmount = Double.valueOf(request.getParameter("poAmount"+i) == null ? "0" : request.getParameter("poAmount"+i));
					siteId = request.getParameter("siteId"+i);
					siteName = request.getParameter("siteName"+i);
					invoiceDate=request.getParameter("invoiceDate"+i);
					invoiceReceiveDate=request.getParameter("invoiceReceiveDate"+i);
					poDate=request.getParameter("poDate"+i);
					creditNoteNumber=request.getParameter("creditNoteNumber"+i);
					creditTotalAmount=request.getParameter("creditTotalAmount"+i);
					vendorName=request.getParameter("vendorName"+i);
					vendorId=request.getParameter("vendorId"+i);
					strPaymentRequestReceivedDate=request.getParameter("paymentRequestReceivedDate"+i);
					doublePaidAmount = Double.valueOf(request.getParameter("paymentDoneUpto"+i));

					if(remarks !=null && !remarks.equals("")){
						if(StringUtils.isNotBlank(comments)){
							remarks = remarks + "@@@" + comments;
						}
					}else{
						remarks = comments;
					}

					paymentBean = new PaymentBean();
					paymentBean.setStrPONo(poNo);
					paymentBean.setStrInvoiceNo(invoiceNo);
					paymentBean.setDoublePOTotalAmount(doublePOAmount);
					paymentBean.setDoubleInvoiceAmount(doubleInvoiceAmount);
					paymentBean.setStrInvoiceDate(invoiceDate);
					paymentBean.setStrInvoiceReceivedDate(invoiceReceiveDate);
					paymentBean.setStrPODate(poDate);
					paymentBean.setStrCreditNoteNumber(creditNoteNumber);
					paymentBean.setDoubleCreditTotalAmount(Double.valueOf(creditTotalAmount));
					paymentBean.setStrRemarks(comments);
					paymentBean.setStrVendorName(vendorName);
					paymentBean.setStatus(strPaymentIntiateType);
					paymentBean.setStrPaymentRequestReceivedDate(strPaymentRequestReceivedDate);
					paymentBean.setRequestedAmount(requestedAmount);
					paymentBean.setStrSiteId(siteId);
					paymentBean.setStrSiteName(siteName);
					paymentBean.setPaymentType(paymentType);
					/*if(paymentType.equals("DIRECT")){
						paymentBean.setDoublePaidAmount(doublePaidAmount);
						paymentBean.setDoubleBalanceAmount(doubleInvoiceAmount-doublePaidAmount);
					}*/
					if(paymentType.equals("DIRECT")){
						paymentBean.setDoublePaidAmount(doublePaidAmount+Double.valueOf(requestedAmount)+doubleAdjustAmountFromAdvance);
						paymentBean.setDoubleBalanceAmount(doubleInvoiceAmount-doublePaidAmount-Double.valueOf(requestedAmount)-doubleAdjustAmountFromAdvance);
					}
					if(paymentType.equals("ADVANCE")){
						paymentBean.setDoubleBalanceAmount(doublePOAmount);
					}


					if(strPaymentIntiateType.equalsIgnoreCase("Approved")){

						String paymentMode = request.getParameter("paymentMode"+i);
						if(StringUtils.isNotBlank(paymentMode)|| (StringUtils.isNotBlank(strPendingEmpId) && !strPendingEmpId.equals("VND"))){

						boolean isRowChanged = false;
						objPaymentDto = new PaymentDto();



						String remainingAmountInAdvanceInDB = objPaymentProcessDao.getRemainingAmountInAdvance(poNo);
						if((doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance)>Double.valueOf(remainingAmountInAdvanceInDB)){
							continue;
						}
						if(paymentType.equals("DIRECT")){
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+(doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance))>doubleInvoiceAmount){continue;}
						}
						if(paymentType.equals("ADVANCE")){
							double paymentReqUpto = Double.valueOf(request.getParameter("paymentReqUpto"+i) == null ? "0" : request.getParameter("paymentReqUpto"+i));
							double paymentDoneUpto = Double.valueOf(request.getParameter("paymentDoneUpto"+i) == null ? "0" : request.getParameter("paymentDoneUpto"+i));

							if((paymentReqUpto+paymentDoneUpto+(doubleAdjustAmountFromAdvance-actualDoubleAdjustAmountFromAdvance))>doublePOAmount){continue;}
						}

						objPaymentDto.setIntTempPaymentTransactionId(intTempPaymentTransactionId);
						objPaymentDto.setIntPaymentDetailsId(intPaymentDetailsId);
						objPaymentDto.setIntPaymentId(intPaymentId);
						objPaymentDto.setPaymentType(paymentType);
						objPaymentDto.setStrPaymentReqDate(requestedDate);
						objPaymentDto.setPaymentMode(paymentMode);
						objPaymentDto.setUtrChequeNo(utrChequeNo);
						objPaymentDto.setStrRemarks(remarks);
						objPaymentDto.setIntSiteWisePaymentId(intSiteWisePaymentId);
						objPaymentDto.setDoubleAmountToBeReleased(Double.valueOf(requestedAmount));
						objPaymentDto.setStrPONo(poNo);
						objPaymentDto.setStrInvoiceNo(invoiceNo);
						objPaymentDto.setDoublePOAmount(doublePOAmount);
						objPaymentDto.setDoubleInvoiceAmount(doubleInvoiceAmount);
						objPaymentDto.setDoubleAdjustAmountFromAdvance(doubleAdjustAmountFromAdvance);
						objPaymentDto.setActualDoubleAdjustAmountFromAdvance(actualDoubleAdjustAmountFromAdvance);
						objPaymentDto.setStrSiteId(siteId);



						if(doubleAdjustAmountFromAdvance!=actualDoubleAdjustAmountFromAdvance){
							isRowChanged = true;
							objPaymentProcessDao.updateIntiateAmountInAdvancePaymentPO(poNo,actualDoubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance);
						}
						if(!paymentMode.equals(actualPaymentMode)||!utrChequeNo.equals(actualUtrChequeNo)){
							isRowChanged = true;
						}

						if(StringUtils.isNotBlank(strPendingEmpId) && !strPendingEmpId.equals("VND")){


							objPaymentProcessDao.updateTempPaymentTransactionsTbl(objPaymentDto,strPendingEmpId);

							if(actualDoubleAdjustAmountFromAdvance!=doubleAdjustAmountFromAdvance){
								objPaymentProcessDao.updateReqUptoInAccPayment(String.valueOf(intPaymentId),"0","0",actualDoubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance);
							}



						}
						else if(StringUtils.isNotBlank(strPendingEmpId)){

							objPaymentProcessDao.updateTempPaymentTransactionsTbl(objPaymentDto,strPendingEmpId);

							int intPaymentTransactionId = objPaymentProcessDao.getIntPaymentTransactionId();
							objPaymentProcessDao.insertPaymentTransactionsTbl(objPaymentDto,intPaymentTransactionId);
							if(paymentType.equals("DIRECT")){
								objPaymentProcessDao.insertInvoiceHistory(objPaymentDto,intPaymentTransactionId);
							}
							if(objPaymentDto.getDoubleAdjustAmountFromAdvance()>0){
								int intPaymentTransactionIdadjust = objPaymentProcessDao.getIntPaymentTransactionId();
								objPaymentProcessDao.insertPaymentTransactionsTblAdjust(objPaymentDto,intPaymentTransactionIdadjust);
								if(paymentType.equals("DIRECT")){
									objPaymentProcessDao.insertInvoiceHistoryAdjust(objPaymentDto,intPaymentTransactionIdadjust);
								}
							}
							objPaymentProcessDao.updatePaymentReqUptoInAccPaymentTable(objPaymentDto);

							/*if(paymentType.equals("DIRECT")){
									paymentBean.setDoublePaidAmount(doublePaidAmount+Double.valueOf(requestedAmount)+doubleAdjustAmountFromAdvance);
									paymentBean.setDoubleBalanceAmount(doubleInvoiceAmount-doublePaidAmount-Double.valueOf(requestedAmount)-doubleAdjustAmountFromAdvance);
								}*/


							if(paymentType.equals("ADVANCE")){
								objPaymentProcessDao.insertPoHistory(objPaymentDto);
							}



								if(paymentType.equals("ADVANCE")){
									objPaymentProcessDao.insertPaidAmountInAdvancePaymentPoTable(objPaymentDto);
								}
								if(paymentType.equals("DIRECT")){
									objPaymentProcessDao.updateAdvancePaymentPoTable(poNo,doubleAdjustAmountFromAdvance);
								}
								if(paymentType.equals("DIRECT")){
									objPaymentProcessDao.setInactiveAccPaymentAfterCheck(intPaymentId);
								}

								if(StringUtils.isNotBlank(paymentMode)){
									if(paymentMode.charAt(0)!='C'){
										if(StringUtils.isNotBlank(strPendingEmpId) && strPendingEmpId.equals("VND")){
										request.setAttribute("isDownload", "true");
											createTxtDocOfVendorPaymentDetails(vendorName,requestedAmount,intPaymentDetailsId,vendorId,paymentMode,requestedDate,request,response,strEmpId,requestedDateMap);
											isDownload = true;
										}
									}
								}
							}

						objPaymentProcessDao.saveAccountApprovalDetails(intAccDeptPaymentProcessId,strEmpId,"",intTempPaymentTransactionId,siteId);
						if(isRowChanged){
							PaymentBean objPaymentBean = new PaymentBean();
							objPaymentBean.setIntTempPaymentTransactionId(intTempPaymentTransactionId);
							objPaymentBean.setStrEmployeeId(strEmpId);
							objPaymentBean.setStrRemarks("");
							objPaymentBean.setActualDoubleAdjustAmountFromAdvance(actualDoubleAdjustAmountFromAdvance);
							objPaymentBean.setDoubleAdjustAmountFromAdvance(doubleAdjustAmountFromAdvance);
							objPaymentBean.setActualPaymentMode(actualPaymentMode);
							objPaymentBean.setPaymentMode(paymentMode);
							objPaymentBean.setActualUtrChequeNo(actualUtrChequeNo);
							objPaymentBean.setUtrChequeNo(utrChequeNo);
							objPaymentProcessDao.saveAccountChangedDetails(objPaymentBean,"M"); 


						}
						paymentBean.setIntSerialNo(++intSerialNo);
						paymentDetailsList.add(paymentBean);

					}//if-paymentMode
					}//if-approve
					else if(strPaymentIntiateType.equalsIgnoreCase("Rejected")){

						String strLowerEmpId = objPaymentProcessDao.getLowerEmpIdInAccounts(strEmpId);
						/*List<String> paymentInitiatorList = new ArrayList<String>(Arrays.asList("997_B_1","997_H_1"));//objPaymentProcessDao.getPaymentInitiatorInAccounts();
						
						boolean matchFound = false;
						if(paymentInitiatorList.contains(strLowerEmpId)){
							matchFound = true;
							break;
						}*/
						
						if(strLowerEmpId.equals("997_B_1")||strLowerEmpId.equals("997_H_1")){
							objPaymentProcessDao.removeRowInAccTempPaymentTransactions(intTempPaymentTransactionId);
							objPaymentProcessDao.updateIntiateAmountInAccDeptPaymentProcesstbl(requestedAmount,intAccDeptPaymentProcessId,actualDoubleAdjustAmountFromAdvance);
						}
						else{
							objPaymentProcessDao.revertPendingApprovalToLowerEmployee(strLowerEmpId,intTempPaymentTransactionId);
						}
						objPaymentProcessDao.saveAccountRejectDetails(intAccDeptPaymentProcessId,strEmpId,"",intTempPaymentTransactionId,siteId);
						/*paymentBean.setIntSerialNo(++intSerialNo);
							paymentDetailsList.add(paymentBean);*/
					}

				}//For loop
				
				//Generating zip file for final payment approval
				try {
						if (null != requestedDateMap) {
						if (requestedDateMap.size() > 0) {

							String zipFileName = "PaymentFiles.zip";

							FileOutputStream out = new FileOutputStream(zipFileName);
							ZipOutputStream zos = new ZipOutputStream(out);

							Set<Entry<String, String>> requestedDateFile = requestedDateMap.entrySet();
							for (Entry<String, String> entry : requestedDateFile) {
								String fileName = entry.getValue();
								String paymentDate = entry.getKey();
								System.out.println(entry);
								File file = new File(fileName);

								InputStream in = new FileInputStream(file);
								BufferedInputStream bis = new BufferedInputStream(in);
								zos.putNextEntry(new ZipEntry(file.getName()));
								// Get the file
								FileInputStream fis = null;
								try {
									fis = new FileInputStream(file);
								} catch (FileNotFoundException fnfe) {
									// If the file does not exists, write an
									// error entry instead of
									// file
									// contents
									zos.write(("ERRORld not find file " + file.getName()).getBytes());
									zos.closeEntry();
									System.out.println("Couldfind file " + file.getAbsolutePath());
									continue;
								}
								BufferedInputStream fif = new BufferedInputStream(fis);
								// Write the contents of the file
								int data = 0;
								while ((data = fif.read()) != -1) {
									zos.write(data);
								}

								fif.close();
								fis.close();
								in.close();
								bis.close();

								boolean flag = file.delete();
								zos.closeEntry();
								try {
									if (file.exists())
									file.delete();
								} catch (Exception e) {

								}			
						System.out.println("Finishedng file " + file.getName() + " and deleted " + flag);
					} // for loop
					
					zos.close();
					out.close();
					}
				}
					request.removeAttribute("requestedDatePaymentList");
				
				} catch (Exception e) {
					e.printStackTrace();
				}
				requestedDateMap=null;
			}
			
			//strResponse = "Success";
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(SuccessDataListToMail.size()!=0){

			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{


				executorService.execute(new Runnable() {
					public void run() {
						EmailFunction objEmailFunction = new EmailFunction();
						//objEmailFunction.sendPaymentInitiatedMail(SuccessDataListToMail);
					}
				});
				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}

		}
		final HttpServletRequest request_final = request;
		final HttpServletResponse response_final = response;
		final String strEmpId_final = strEmpId;
		
		if(isDownload){
			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{


				executorService.execute(new Runnable() {
					public void run() {
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						downloadTxtFileToClientMachine(request_final,response_final,strEmpId_final);
					}
				});
				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}
		}
		return paymentDetailsList;
	}

	@Override
	public String getPendingEmpId(String user_id) {
		return objPaymentProcessDao.getPendingEmpId(user_id);
	}	

	public static void main(String [] args){


		double val = 425.58*87895.25;

		System.out.println( val);

		System.out.printf("dexp: %f\n", val);

		String firstNumberAsString = String.format ("%.2f", val);

		System.out.println( firstNumberAsString);

	}

	@Override
	public String updateRefNoInAccDeptTransaction(HttpServletRequest request, String strUserId) {


		String strResponse = "";
		int intPaymentTransactionId=0;
		String strRefNo = "";
		int intTotalNoOfRecords = 0;
		String paymentMode = "";
		String paymentDate = "";

		try {
			intTotalNoOfRecords = Integer.parseInt(request.getParameter("noOfPendingPayments") == null ? "0" : request.getParameter("noOfPendingPayments").toString());
			if(intTotalNoOfRecords > 0){


				for(int i = 1;i<=intTotalNoOfRecords;i++){

					if(request.getParameter("checkboxname"+i)!=null){
						intPaymentTransactionId = Integer.parseInt(request.getParameter("paymentTransactionId"+i));
						strRefNo = request.getParameter("utrChequeNo"+i);
						paymentMode = request.getParameter("paymentMode"+i);
						paymentDate = request.getParameter("paymentDate"+i);
						objPaymentProcessDao.updateRefNoInAccDeptTransaction(strRefNo,intPaymentTransactionId,paymentMode,paymentDate);
						objPaymentProcessDao.updateRefNoInInvoiceHistory(strRefNo,paymentMode,intPaymentTransactionId);
					}

				}

			}
			strResponse = "Success";
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return strResponse;

	}
	


	public void createTxtDocOfVendorPaymentDetails(String vendorName,String requestedAmount, int intPaymentDetailsId, String vendorId, String paymentMode, String requestedDate, HttpServletRequest request, HttpServletResponse response, String strEmpId, Map<String, String> requestedDateMap){
		VendorDetails vd = objPaymentProcessDao.getVendorAccountDetails(vendorId);
		int portNo = request.getLocalPort();
		String path = "";
		if(portNo==80){
			path = validateParams.getProperty("LIVE_PAYMENTS_FILE_PATH");
		} else if (portNo == 8079) {
			path = validateParams.getProperty("CUG_PAYMENTS_FILE_PATH");
		} else {
			path = validateParams.getProperty("LOCAL_PAYMENTS_FILE_PATH");
		}

		// this request attribute for loading file names when they are going to
		// download
        File files = new File(path);
        if (!files.exists()) {
            if (files.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
	
		request.setAttribute("requestedDatePaymentList", requestedDateMap);
		String tempRequestedDate = requestedDate.replace("/", "-");
		String fileName = path+"/PaymentsTextfile-"+tempRequestedDate + ".txt";
		if (requestedDateMap.containsKey(tempRequestedDate)) {
			fileName =requestedDateMap.get(tempRequestedDate);	
		}
	
		File file = new File(fileName);
		try {
			if (!file.exists())
				file.createNewFile();
			else
				System.out.println(file.getAbsolutePath());
		} catch (Exception e) {
			e.printStackTrace();
		}
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fw = new FileWriter(file, true);
			bw = new BufferedWriter(fw);
			requestedDateMap.put(tempRequestedDate, fileName);
			String ifsc_code = vd.getIfsc_Code();
			if(StringUtils.isNotBlank(ifsc_code)){
				if(ifsc_code.length()>3){
					if(ifsc_code.substring(0, 4).equalsIgnoreCase("hdfc")){
						bw.write("I"+",");
						bw.write(vd.getVendor_name().substring(0, 4).toUpperCase()+",");
					}
					else{
						bw.write("N"+",,");
					}
					
				}
				else{
					bw.write("N"+",,");
				}
			}
			else{
				bw.write("N"+",,");
			}
			bw.write(vd.getAcc_Number() + ",");
			bw.write(get_17point2_lengthNumber(requestedAmount) + ",");
			if(vd.getVendor_name().length()>40){
				bw.write(vd.getVendor_name().substring(0,40)+",");
			}
			else{
				bw.write(vd.getVendor_name()+",");
			}bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			if(vd.getVendor_name().length()>20){
				bw.write(vd.getVendor_name().substring(0,20)+",");
			}
			else{
				bw.write(vd.getVendor_name()+",");
			}bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(getRequiredFormatDate(requestedDate) + ",");
			bw.write(",");
			bw.write(vd.getIfsc_Code() + ",");
			bw.write(vd.getBank_name() + ",");
			bw.write(",");
			if(vd.getVendor_email().contains(",")){
				bw.write(vd.getVendor_email().split(",")[0]);
			}
			else{
				bw.write(vd.getVendor_email());
			}
			bw.newLine();

		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException el) {
				el.printStackTrace();
			}
		}

		/*File file = new File("Payments.txt");
		if(!file.exists()){
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println(file.getAbsolutePath());
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fw = new FileWriter(file,true);
			bw = new BufferedWriter(fw);
			
			String ifsc_code = vd.getIfsc_Code();
			if(StringUtils.isNotBlank(ifsc_code)){
				if(ifsc_code.length()>3){
					bw.write(((ifsc_code.substring(0, 4).equalsIgnoreCase("hdfc"))?"I":"N")+",");
				}
				else{
					bw.write("N"+",");
				}
			}
			else{
				bw.write("N"+",");
			}
			
			bw.write(vd.getVendor_name().substring(0, 4).toUpperCase()+",");
			bw.write(vd.getAcc_Number()+",");
			bw.write(get_17point2_lengthNumber(requestedAmount)+",");
			bw.write(vd.getVendor_name()+",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(vd.getVendor_name()+",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(",");
			bw.write(getRequiredFormatDate(requestedDate)+",");
			bw.write(",");
			bw.write(vd.getIfsc_Code()+",");
			bw.write(vd.getBank_name()+",");
			bw.write(",");
			bw.write(vd.getVendor_email());
			bw.newLine();
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		finally{
            try {
                bw.close();
                fw.close();
            } catch (IOException el) {
                el.printStackTrace();
            }
        }*/
		//*************File open code**************//
		/*if (System.getProperty("os.name").toLowerCase().contains("windows")) {
		  String cmd=null;
		try {
			cmd = "rundll32 url.dll,FileProtocolHandler " + file.getCanonicalPath();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		  try {
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			e.printStackTrace();
		}
		} 
		else {
		  try {
			Desktop.getDesktop().edit(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}*/
		
		
		
	}
	private void downloadTxtFileToClientMachine(HttpServletRequest request, HttpServletResponse response, String strEmpId) {
		System.out.println("PaymentProcessServiceImpl.downloadTxtFileToClientMachine()");
		/*String tempFile = "";
		response.setContentType("text/html");
		PrintWriter out = null;
		try {
			out = response.getWriter();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int portNo = request.getLocalPort();
		String filepath = "";
		if(portNo==80){
			filepath = validateParams.getProperty("LIVE_PAYMENTS_FILE_PATH");
		}
		else if(portNo==8081){
			filepath = validateParams.getProperty("CUG_PAYMENTS_FILE_PATH");
		}
		else{
			filepath = validateParams.getProperty("LOCAL_PAYMENTS_FILE_PATH");
		}
		String filename = "PaymentsTempfile.txt";//input file in server
		tempFile = filename;

		 *//***  Creating Output Filename & Setting to Response as Text File  ***//*
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    Date now = new Date();
	    String strDate = sdfDate.format(now);
	    strDate = strDate.replace(":", ".");
	    String responsefilename = "Payments "+strDate+" "+strEmpId+".txt";
		response.setContentType("APPLICATION/OCTET-STREAM");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ responsefilename + "\"");

		// use inline if you want to view the content in browser, helpful for
		// pdf file
		// response.setHeader("Content-Disposition","inline; filename=\"" +
		// filename + "\"");

		  *//***  Downloading Text File To Client Machine  ***//*
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(tempFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int i;
		try {
			while ((i = fileInputStream.read()) != -1) {
				out.write(i);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fileInputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.close();

		   *//***  deleting temporary file  ***//*
		new File(tempFile).delete();*/

	}
	private String getRequiredFormatDate(String requestedDate) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(DateUtil.convertToJavaDateFormat(requestedDate));
		
	}
	public String get_17point2_lengthNumber(String requestedAmount) {
		
		DecimalFormat df = new DecimalFormat("00000000000000000.00");
		requestedAmount = String.valueOf(df.format(Double.parseDouble(requestedAmount))); 
		return requestedAmount;
	}
}

//save site approval code
/*if(invoiceAmount>=tmpRequestedAmount){


	amtAfterModified=tmpactualRequestedAmount-tmpRequestedAmount;

	if(amtAfterModified<0){

		amtAfterModified=Math.abs(amtAfterModified);
		tmpactualRequestedAmount +=amtAfterModified;
		objPaymentProcessDao.UpDatePaymentDetails(paymentDetailsId,tmpactualRequestedAmount);

	}else if(amtAfterModified>0){

		tmpactualRequestedAmount =(tmpactualRequestedAmount)-(amtAfterModified); 
		objPaymentProcessDao.UpDatePaymentDetails(paymentDetailsId,tmpactualRequestedAmount);
	}

}*/
