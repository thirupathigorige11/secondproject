package com.sumadhura.in;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.IndentReceiveBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.service.DCFormService;
import com.sumadhura.service.IndentIssueService;
import com.sumadhura.service.IndentReceiveService;
import com.sumadhura.service.PurchaseDepartmentIndentrocessService;
import com.sumadhura.transdao.IndentIssueDaoImpl;
import com.sumadhura.transdao.IndentReceiveDaoImpl;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.util.CheckSessionValidation;
import com.sumadhura.util.CommonUtilities;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;


@Controller
public class IndentReceiveController extends UIProperties {

	@Autowired
	@Qualifier("irsClass")
	IndentReceiveService irs;
	
	@Autowired
	private UtilDao utilDao;

	@Autowired
	CommonUtilities objCommonUtilities;
	@Autowired
	@Qualifier("dcFormClass")
	DCFormService dcFormService;

	@RequestMapping(value = "/launchIndentReceivePage", method = {RequestMethod.GET,RequestMethod.POST})
	public String launchIndentReceivePage(Model model,HttpSession session) {
		model.addAttribute("indentReceiveModelForm", new IndentReceiveBean());
		model.addAttribute("productsMap", irs.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("gstMap", irs.getGSTSlabs());
		model.addAttribute("chargesMap", irs.getOtherCharges());
		String StrRoleId = String.valueOf(session.getAttribute("Roleid"));
		String StrSiteId= String.valueOf(session.getAttribute("SiteId"));
		//System.out.println("the role id of  "+no);

		if(StrRoleId.equals("2") && !StrSiteId.equals("102")){
			model.addAttribute("noOfDays",7);
		}else if(StrRoleId.equals("2") && StrSiteId.equals("102")){
			model.addAttribute("noOfDays",14);
		}
		else if(StrRoleId.equals("4")){
			model.addAttribute("noOfDays",30);
		}else if(StrRoleId.equals("5")){
			model.addAttribute("noOfDays",100);
		}else if(StrRoleId.equals("1")){
			model.addAttribute("noOfDays",10);
		}else if(StrRoleId.equals("12")){
			model.addAttribute("noOfDays",20);
		}else if(StrRoleId.equals("13")){
			model.addAttribute("noOfDays",20);
		}else{
			model.addAttribute("noOfDays",0);
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();

		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id = String.valueOf(session.getAttribute("SiteId"));
		//String indentEntrySeqNum=String.valueOf(session.getAttribute("indentEntrySeqNum"));
		audit.auditLog("0",user_id,"New Receive View","success",site_id);


		return "indentReceive";
	}

	@RequestMapping(value = "/indentReceiveSubProducts", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueSubProducts(@RequestParam("mainProductId") String mainProductId) {
		return irs.loadSubProds(mainProductId);
	}
	@RequestMapping(value = "/indentReceiveSubProductsByPONumber", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueSubProductsByPONumber(@RequestParam("mainProductId") String mainProductId,
			@RequestParam("poNumber") String poNumber,@RequestParam("reqSiteId") String reqSiteId) {
		String s = irs.loadSubProdsByPONumber(mainProductId,poNumber,reqSiteId);
		//System.out.println(s);
		return s;
	}

	@RequestMapping(value = "/indentReceiveChildProducts", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueChildProducts(@RequestParam("subProductId") String subProductId) {
		return irs.loadChildProds(subProductId);
	}
	@RequestMapping(value = "/indentReceiveChildProductsByPONumber", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueChildProductsByPONumber(@RequestParam("subProductId") String subProductId,
			@RequestParam("poNumber") String poNumber,@RequestParam("reqSiteId") String reqSiteId) {
		String s = irs.loadChildProdsByPONumber(subProductId,poNumber,reqSiteId);
		//System.out.println(s);
		return s;
	}
	@RequestMapping(value = "/getPriceRatesByChildProduct", method = RequestMethod.POST)
	@ResponseBody
	public String getPriceRatesByChildProduct(@RequestParam("childProdId") String childProdId,
			@RequestParam("poNumber") String poNumber,@RequestParam("reqSiteId") String reqSiteId) {
		String productDetails = irs.getPriceRatesByChildProduct( childProdId,  poNumber,  reqSiteId);
		//System.out.println(productDetails);
		return productDetails;
	}

	@RequestMapping(value = "/listIndentReciveUnitsOfChildProducts", method = RequestMethod.POST)
	@ResponseBody
	public String listUnitsOfSubProducts(@RequestParam("productId") String productId) {
		return irs.loadIndentReceiveMeasurements(productId);
	}

	@RequestMapping(value = "/loadAndSetVendorInfo", method = RequestMethod.POST)
	@ResponseBody
	public String loadAndSetVendorInfo(@RequestParam("vendName") String vendName) {
		return irs.getVendorInfo(vendName);
	}
	@RequestMapping(value = "/getReceiveCount", method = RequestMethod.POST)
	@ResponseBody
	public int getReceiveCount(@RequestParam("invoiceNumber") String strInvoicNo,
			@RequestParam("vendorname") String strVendorName,
			@RequestParam("receiveDate") String strReceiveDate
	) {
		return irs.getInvoiceCount(  strInvoicNo,  strVendorName,  strReceiveDate);
	}

	@RequestMapping(value = "/getCheckIndentAvailable", method = RequestMethod.POST)
	@ResponseBody
	public int getCheckIndentAvailable(@RequestParam("indentNumber") String indentNumber
			
	) {
		return irs.getCheckIndentAvailable(indentNumber);
	}
	
	@RequestMapping(value = "/getCheckPoAvailable", method = RequestMethod.POST)
	@ResponseBody
	public int getCheckPoAvailable(@RequestParam("poNumber") String poNumber,@RequestParam("vendorId") String vendorId
			
			
	) {
		return irs.getCheckPoAvailable(poNumber,vendorId);
	}
	
	@RequestMapping(value = "/doIndentReceive", method = RequestMethod.POST)
	public String doIndentReceive(@ModelAttribute("indentReceiveModelForm")IndentReceiveBean indentRecModel, BindingResult result, Model model, HttpServletRequest request, HttpSession session, @RequestParam("file") MultipartFile[] files) throws IllegalStateException, IOException {
	System.out.println("IndentReceiveController.doIndentReceive()");
	 
		String response1 = irs.indentProcess(model, request, session);
		String viewToBeSelected = "";
		//-----------------------
		String[] response_array = response1.split("@@");
		String response = response_array [0];
		String site_id = String.valueOf(session.getAttribute("SiteId"));

		String imgname = response_array [1];//"vname_invoiceno_entryid";
		imgname = imgname.replace("/","$$");
		for (int i = 0; i < files.length; i++) {
			MultipartFile multipartFile = files[i];



			if (response.equalsIgnoreCase("Success")&&!multipartFile.isEmpty()) {
				try {

					String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
					File dir = new File(rootFilePath+site_id);
					if (!dir.exists())
						dir.mkdirs();

					String filePath = dir.getAbsolutePath()
					+ File.separator + imgname+"_Part"+i+".jpg"; 

					multipartFile.transferTo(new File(filePath));


					//System.out.println("Image Uploaded");
					//return "You successfully uploaded file" ;
				} catch (Exception e) {
					//System.out.println("Image NOT Uploaded");
					//return "You failed to upload " ;
				}
			} else {
				//return "You failed to upload " + " because the file was empty.";
			}

		}

		//------------------------

		//-------------------------

		if(response.equalsIgnoreCase("Success")) {

			int intSavedCount = irs.isInvoicesaved(  request );

			if(intSavedCount == 0){
				response="Failed";
				request.setAttribute("exceptionMsg", "This Invoice not inserted");
			}
		}

		if(response.equalsIgnoreCase("Success")) {

			viewToBeSelected = "viewGRN";
		}
		else if(response.equalsIgnoreCase("Failed")){
			viewToBeSelected = "indentReceiveResponse";
		} else if (response.equalsIgnoreCase("SessionFailed")){
			request.setAttribute("Message", "Session Expired, Please Login Again");
			viewToBeSelected = "index";
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();


		String user_id=String.valueOf(session.getAttribute("UserId"));

		String indentEntrySeqNum=String.valueOf(session.getAttribute("indentEntrySeqNum"));
		audit.auditLog(indentEntrySeqNum,user_id,"New Receive Save Data ",response,site_id);

		return viewToBeSelected;
	}

	@RequestMapping(value="viewReciveDetails.spring", method={RequestMethod.GET, RequestMethod.POST})
	public ModelAndView viewIndentIssueDetails(HttpServletRequest request,HttpSession session) {

		ModelAndView model = null;

		try {
			model = new ModelAndView();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("ViewIndentReciveDetails");
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"View Received Details","success",site_id);

		return model;
	}
/**
 * @author Aniket Chavan
 * @param request
 * @param session
 * @since 04-may-2018
 * @return
 */
	@RequestMapping(value = "/getSiteWiseReceiveDetails.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getSiteWiseReceiveDetails(HttpServletRequest request,HttpSession session) {
		System.out.println("ReportsController.getSiteWiseReceiveDetails() started to execute");
		ModelAndView mav = new ModelAndView();
		String userid = "0";
		try {
			userid = (String) CheckSessionValidation.validateUserSession(mav,
					session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));
			if (!userid.equals("0")) {
				List<Map<String, Object>> allSitesList = utilDao.getAllSites();
				request.setAttribute("SEARCHTYPE", "ADMIN");
				System.out.println("SearchType is admin");
				request.setAttribute("allSitesList", allSitesList);
				mav.setViewName("ViewIndentReciveDetails");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"View Received Details","success",site_id);

		System.out.println("ReportsController.getSiteWiseReceiveDetails() executed..");
		return mav;
	}
	
	
	
	@RequestMapping(value ="getIndentReciveViewDts.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getIndentViewDts(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		ModelAndView model = null;
		String response="";
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
				session = request.getSession(false);
				//  site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				//ACP
				site_id = request.getParameter("dropdown_SiteId") == null ? "" : request.getParameter("dropdown_SiteId");
				if (!site_id.equals("")) {
					List<Map<String, Object>> allSitesList = utilDao.getAllSites();
					request.setAttribute("SEARCHTYPE", "ADMIN");
					System.out.println("SearchType is admin");
					request.setAttribute("allSitesList", allSitesList);
					System.out.println("IndentReceiveController.getIndentViewDts() DropDown value is not empty");
				} else if (site_id.equals("")) {
					System.out.println("IndentReceiveController.getIndentViewDts() DropDown value is empty");
					site_id =  session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				}
				//ACP
				//System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					indentIssueData = new IndentIssueDaoImpl().getViewIndentIssueDetails(fromDate, toDate, site_id, "Val");
					if(indentIssueData != null && indentIssueData.size() >0){
						request.setAttribute("showGrid", "true");
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failed";
					}
					model.addObject("indentIssueData",indentIssueData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("ViewIndentReciveDetails");
					response="success";

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failed";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
				model.addObject("indentIssueData",indentIssueData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.setViewName("ViewIndentReciveDetails");
				response="failed";
			}
		} catch (Exception ex) {
			response="failed";
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"get invoice Details View data",response,site_id1);

		return model;
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value ="getInvoiceReciveViewDts.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getInvoiceViewDts(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		ModelAndView model = null;
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();				
				//System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					indentIssueData = new IndentReceiveDaoImpl().getSiteWiseInvoiceDetails(fromDate, toDate, site_id);
					if(indentIssueData != null && indentIssueData.size() >0){
						request.setAttribute("showGrid", "true");
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
					}
					model.addObject("indentIssueData",indentIssueData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("ViewSecificSiteInvoices");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
				model.addObject("indentIssueData",indentIssueData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.setViewName("ViewSecificSiteInvoices");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"Get Invoice Details Viewed","success",site_id1);

		return model;
	}

	@SuppressWarnings("static-access")
	@RequestMapping(value ="getAllSiteReciveInvoiceDts.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getAllSiteReciveInvoiceDts(HttpServletRequest request,HttpSession session) {


		String toDate = "";
		String fromDate = "";
		String siteId =  "";
		ModelAndView model = null;
		String response="";
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			siteId = request.getParameter("siteId");
			if ((StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) && StringUtils.isNotBlank(siteId)) {
				session = request.getSession(false);
				//site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();				
				//System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+siteId);
				if (StringUtils.isNotBlank(siteId)) {
					indentIssueData = new IndentReceiveDaoImpl().getSiteWiseInvoiceDetails(fromDate, toDate, siteId);
					if(indentIssueData != null && indentIssueData.size() >0){
						request.setAttribute("showGrid", "true");
						response="success";
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failed";
					}
					//String strIndentEntryId = request.getAttribute("INDENT_ENTRY_ID") == null ? "" : request.getAttribute("INDENT_ENTRY_ID").toString();
					//model.addObject("indentEntryId",strIndentEntryId);
					model.addObject("indentIssueData",indentIssueData);
					model.addObject("getSiteList", objCommonUtilities.getSiteList());
					model.setViewName("ViewAllSiteInvoices");
					response="success";

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failed";
					return model;
				}
			} else {
				//model.addObject("displayErrMsg", "Please Select From Date or To Date and site!");
				model.addObject("getSiteList", objCommonUtilities.getSiteList());
				model.setViewName("ViewAllSiteInvoices");
				response="success";
			}
		} catch (Exception ex) {
			response="failed";
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"Get All site Invoice Details View",response,site_id1);




		return model;
	}

	@RequestMapping(value = "/inwardsFromPO.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public String inwardsFromPO(HttpServletRequest request, HttpSession session,Model model){

		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));

		model.addAttribute("listOfPOs",irs.getListOfActivePOs(site_id1));

		SaveAuditLogDetails.auditLog("0",user_id,"Inwards From PO","success",site_id1);


		return "ShowPOListToConvertToInvoice";

	}

	@RequestMapping(value = "/showPODetails.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public String showPODetails(Model model, HttpServletRequest request,HttpSession session) {

		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			String poNumber = request.getParameter("poNumber");
			int count = irs.checkPOisActive(poNumber);
			if(count==0){
				model.addAttribute("listOfPOs",irs.getListOfActivePOs(String.valueOf(site_id)));
				model.addAttribute("errorMessage","Invalid PO Number");
				SaveAuditLogDetails.auditLog("0",user_id,"Inwards From PO","success",String.valueOf(site_id));
				return "ShowPOListToConvertToInvoice";
			}

			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));


			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());

			ProductDetails objProductDetails = new ProductDetails();
			model.addAttribute("CreatePOModelForm", objProductDetails);

			List<ProductDetails> IndentDetails = null;
			model.addAttribute("poNumber",poNumber);
			String reqSiteId = String.valueOf(site_id);
			model.addAttribute("productsMap", dcFormService.loadProdsByPONumber(poNumber,reqSiteId));
			model.addAttribute("poDetails",irs.getPODetails(poNumber,reqSiteId));
			List<ProductDetails>  ProductDetailslist = irs.getProductDetailsLists(poNumber,reqSiteId);
			List<ProductDetails>  transportChargesList = irs.getTransChrgsDtls(poNumber,reqSiteId);

			model.addAttribute("listOfGetProductDetails",ProductDetailslist);
			model.addAttribute("listOfTransChrgsDtls",transportChargesList);


			//List<ProductDetails>  list = irs.getProductDetailsLists(poNumber,reqSiteId);
			double productTotalAmount = 0.0;
			double totalAmount = 0.0;
			for(int i = 0;i<ProductDetailslist.size();i++){

				productTotalAmount = Double.valueOf(ProductDetailslist.get(i).getAmountAfterTax());
				totalAmount = totalAmount+productTotalAmount;
			}
			double transportIndividualAmount = 0.0;
			double transportTotalAmount = 0.0;
			for(int i = 0;i<transportChargesList.size();i++){

				transportIndividualAmount = Double.valueOf(transportChargesList.get(i).getAmountAfterTaxx1());
				transportTotalAmount = transportTotalAmount+transportIndividualAmount;
			}


			totalAmount = Double.parseDouble(new DecimalFormat("##.##").format(totalAmount));
			transportTotalAmount = Double.parseDouble(new DecimalFormat("##.##").format(transportTotalAmount));

			model.addAttribute("totalAmount",totalAmount+transportTotalAmount);

		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Showing PO Detailss","Success",String.valueOf(site_id));
		return "InwardsfromCreatePO";


	}

	@RequestMapping(value = "/convertPOtoInvoice", method = RequestMethod.POST)
	public String convertPOtoInvoice(@ModelAttribute("CreatePOModelForm")ProductDetails objProductDetails, BindingResult result, Model model, HttpServletRequest request, HttpSession session, @RequestParam("file") MultipartFile[] files) throws IllegalStateException, IOException {
		String response1 = irs.processingPOasInvoice(model, request, session);
		String viewToBeSelected = "";
		//-----------------------
		String[] response_array = response1.split("@@");
		String response = response_array [0];
		String site_id = String.valueOf(session.getAttribute("SiteId"));

		String imgname = response_array [1];//"vname_invoiceno_entryid";
		for (int i = 0; i < files.length; i++) {
			MultipartFile multipartFile = files[i];



			if (response.equalsIgnoreCase("Success")&&!multipartFile.isEmpty()) {
				try {

					String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
					File dir = new File(rootFilePath+site_id);
					if (!dir.exists())
						dir.mkdirs();

					String filePath = dir.getAbsolutePath()
					+ File.separator + imgname+"_Part"+i+".jpg"; 

					multipartFile.transferTo(new File(filePath));


					//System.out.println("Image Uploaded");
					//return "You successfully uploaded file" ;
				} catch (Exception e) {
					System.out.println("Image NOT Uploaded");
					//return "You failed to upload " ;
				}
			} else {
				//return "You failed to upload " + " because the file was empty.";
			}

		}

		//------------------------

		//-------------------------

		/*if(response.equalsIgnoreCase("Success")) {

			int intSavedCount = irs.isInvoicesaved(  request );

			if(intSavedCount == 0){
				response="Failed";
				request.setAttribute("exceptionMsg", "This Invoice not inserted");
			}
		}*/


		if(response.equalsIgnoreCase("Success")) {

			viewToBeSelected  = "viewGRN";
		}
		else if(response.equalsIgnoreCase("Failed")){
			viewToBeSelected = "indentReceiveResponse";
		} else if (response.equalsIgnoreCase("SessionFailed")){
			request.setAttribute("Message", "Session Expired, Please Login Again");
			viewToBeSelected = "index";
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();


		String user_id=String.valueOf(session.getAttribute("UserId"));

		String indentEntrySeqNum=String.valueOf(session.getAttribute("indentEntrySeqNum"));

		audit.auditLog(indentEntrySeqNum,user_id,"Converting PO to Invoice ",response,site_id);

		return viewToBeSelected;
	}

}
