package com.sumadhura.in;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.PaymentBean;
import com.sumadhura.bean.PaymentModesBean;
import com.sumadhura.service.PaymentProcessService;
import com.sumadhura.transdao.PaymentProcessDaoImpl;
import com.sumadhura.util.SaveAuditLogDetails;

@Controller
public class PaymentProcessController {

	@Autowired
	PaymentProcessService objPaymentProcessService;



	@RequestMapping(value = "/IntiatePayment.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView payment( HttpServletRequest request,HttpSession session) {


		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String vendorId = "";
		String invoiceNumber = "";
		ModelAndView model = null;
		List<PaymentBean> listTotalInvoices = null;
		try {
			model = new ModelAndView();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String pendingEmpId = objPaymentProcessService.getPendingEmpId(user_id);
			if(pendingEmpId.equals("-")){
				model.addObject("message1","You cannot Intiate Payment");
				model.setViewName("response");
				return model;
			}
			
			
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			vendorId = request.getParameter("vendorId");
			invoiceNumber = request.getParameter("InvoiceNumber");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate) || StringUtils.isNotBlank(invoiceNumber)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();				
				System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					listTotalInvoices = objPaymentProcessService.getInvoiceDetails(fromDate, toDate, site_id,vendorId,invoiceNumber);
					if(listTotalInvoices != null && listTotalInvoices.size() >0){
						request.setAttribute("showGrid", "true");
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
					}
					model.addObject("listTotalInvoicesSize",listTotalInvoices.size());
					model.addObject("listTotalInvoices",listTotalInvoices);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("payment/paymentForInvoice");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date or InvoiceNumber!");
				model.addObject("listTotalInvoices",listTotalInvoices);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.setViewName("payment/paymentForInvoice");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"Get Invoice Details Viewed","success",site_id1);

		return  model;

		//return "payment/payment";


	}

	@RequestMapping(value = "/savePaymentIntiateDetails.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView savePaymentIntiateDetails( HttpServletRequest request,HttpSession session) {

		ModelAndView modelAndView = new ModelAndView();
		List<String> successList = objPaymentProcessService.savePaymentIntiateDetails(request, session);

		modelAndView.addObject("successList",successList);
		if(successList.size()==0){
			modelAndView.addObject("message1", "No Payments Selected");
		}
		modelAndView.setViewName("payment/paymentResponse");
		return modelAndView;

	}
	@RequestMapping(value = "/PaymentForApproval.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView paymentForApproval( HttpServletRequest request,HttpSession session) {
		
		String site_id = "";
		
		ModelAndView model = null;
		List<PaymentBean> listTotalInvoices = null;
		try {
				model = new ModelAndView();
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				String user_id=String.valueOf(session.getAttribute("UserId"));
				
				if (StringUtils.isNotBlank(site_id)) {
					listTotalInvoices = new PaymentProcessDaoImpl().getPaymentApprovalDetails(site_id,user_id);
					if(listTotalInvoices != null && listTotalInvoices.size() >0){
						request.setAttribute("showGrid", "true");
					}
					int size=0;
					for(PaymentBean element:listTotalInvoices){
						if(!element.isVendorHeader()){size++;}
					}
					model.addObject("listTotalInvoicesSize",size);
					model.addObject("listTotalInvoices",listTotalInvoices);
					
					model.setViewName("payment/PaymentApprovalSiteLevel");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					return model;
				}
			
		}
			catch (Exception ex) {
				ex.printStackTrace();
			} 
	
	return model;
	}
	@RequestMapping(value = "/PaymentApprovalForAccDept.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView paymentApprovalForAccDept( HttpServletRequest request,HttpSession session) {
		
		String site_id = "";
		
		ModelAndView model = null;
		List<PaymentBean> listofPendingPayments = null;
		List<PaymentModesBean> PaymentModes = new ArrayList<PaymentModesBean>();
		try {
				model = new ModelAndView();
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				String user_id=String.valueOf(session.getAttribute("UserId"));
				
				if (StringUtils.isNotBlank(site_id)) {
					PaymentModes = new PaymentProcessDaoImpl().getPaymentModes();
					model.addObject("PaymentModes",PaymentModes);
					
					listofPendingPayments = new PaymentProcessDaoImpl().getAccDeptPaymentApprovalDetails(site_id,user_id);
					if(listofPendingPayments != null && listofPendingPayments.size() >0){
						request.setAttribute("showGrid", "true");
					} 
					int size=0;
					for(PaymentBean element:listofPendingPayments){
						if(!element.isVendorHeader()){size++;}
					}
					model.addObject("listTotalInvoicesSize",size);
					model.addObject("listTotalInvoices",listofPendingPayments);
					
					/*String approverEmpId = new PaymentProcessDaoImpl().getApproverEmpIdInAccounts(user_id);
					if(approverEmpId.equals("VND")){
						model.addObject("isShowPaymentDoneDate","true");
					}*/
					
					model.setViewName("payment/PaymentApprovalAccountLevel");//AccDeptPaymentForApproval

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					return model;
				}
			
		}
			catch (Exception ex) {
				ex.printStackTrace();
			} 
	
	return model;
	}
	
	
	@RequestMapping(value = "/savePaymentApprovalDetails.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public String  savePaymentApprovalDetails(HttpServletRequest request,HttpSession session,Model model) {
		
		
		String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		
	//	String site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();	

		List<String> successList = objPaymentProcessService.savePaymentApprovalAndRejectDetails(request,session,strUserId);
		
		
		model.addAttribute("successList",successList);
		if(successList.size()==0){
			model.addAttribute("message1", "No Payments Selected");
		}
		
		return "payment/paymentResponse";

	}
	
	@RequestMapping(value = "/IntiatePaymentFromPO.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView paymentFromPO( HttpServletRequest request,HttpSession session) {


		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String vendorId = "";
		String poNumber = "";
		ModelAndView model = null;
		List<PaymentBean> listTotalPOs = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			vendorId = request.getParameter("vendorId");
			poNumber = request.getParameter("PONumber");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate) || StringUtils.isNotBlank(poNumber)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();				
				System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					listTotalPOs = objPaymentProcessService.getPODetails(fromDate, toDate, site_id, vendorId,poNumber);
					if(listTotalPOs != null && listTotalPOs.size() >0){
						request.setAttribute("showGridForPO", "true");
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
					}
					model.addObject("listTotalPOsSize",listTotalPOs.size());
					model.addObject("listTotalPOs",listTotalPOs);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("payment/paymentForPO");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date or PONumber!");
				model.addObject("listTotalPOs",listTotalPOs);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.setViewName("payment/paymentForPO");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"Get Invoice Details Viewed","success",site_id1);

		return  model;

		//return "payment/payment";


	}
	
	@RequestMapping(value = "/getAccountDeptPendingRequests.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView  getAccountDeptPendingRequests(HttpServletRequest request,HttpSession session,ModelAndView model) {
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		List<PaymentModesBean> PaymentModes = new ArrayList<PaymentModesBean>();
		
		try{


			String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();


			PaymentModes = new PaymentProcessDaoImpl().getPaymentModes();
			model.addObject("PaymentModes",PaymentModes);
			
			list = objPaymentProcessService.getAccDeptPaymentPendingDetails(strUserId);

			if(list != null && list.size() >0){
				request.setAttribute("showGrid", "true");
			} else {
				model.addObject("succMessage","The above Dates Data Not Available");
			}
			model.addObject("listTotalInvoices",list);
			
			int size=0;
			for(PaymentBean element:list){
				if(!element.isVendorHeader()){size++;}
			}
			
			model.addObject("listTotalInvoicesSize",size);
			model.setViewName("payment/PaymentPendingAccountLevel");//AccDeptPaymentPending

		}catch(Exception e){
			e.printStackTrace();
			model.addObject("listofPendingPayments",list);
			model.setViewName("payment/PaymentPendingAccountLevel");

		}

		return model;

	}
	
	@RequestMapping(value = "/createAccDeptPaymentTransaction.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView  createAccDeptPaymentTransaction(HttpServletRequest request,HttpSession session,ModelAndView model) {
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		ModelAndView modelAndView = new ModelAndView();
		try{


			String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();



			List<String> successList = objPaymentProcessService.createAccountDeptTransaction(request,strUserId);

			modelAndView.addObject("successList",successList);
			if(successList.size()==0){
				modelAndView.addObject("message1", "No Payments Selected");
			}
			modelAndView.setViewName("payment/paymentResponse");
			
		}catch(Exception e){
			e.printStackTrace();

		}

		return modelAndView;

	}
	
	
	private static final String APPLICATION_TEXT = "application/zip";

	@RequestMapping(value = "/generatePaymentTextFile.spring", method = RequestMethod.GET, produces = APPLICATION_TEXT)
	public @ResponseBody String generateTextFile(HttpServletResponse response, HttpServletRequest request,
			HttpSession session) {
		System.out.println("PaymentProcessController.generateTextFile()");
		String str = request.getParameter("generateFileifTrue");
		boolean flag = Boolean.valueOf(str);
		try {
			String zipFileName = "PaymentFiles.zip";
			FileInputStream fileInputStream = new FileInputStream(zipFileName);
			BufferedInputStream bufferedInputStream=new BufferedInputStream(fileInputStream);
			
			File file = new File(zipFileName);
			// Set the content type based to zip
			request.setAttribute("refreshOneTime", "true");
			response.setContentType(APPLICATION_TEXT);
			response.setHeader("Content-Disposition","attachment; filename=PaymentFile.zip");
			FileCopyUtils.copy(bufferedInputStream, response.getOutputStream());
			boolean flag1=file.delete();
			System.out.println("file deleted on Controller "+flag1);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			
		}

		session.removeAttribute("requestedDatePaymentMap");
		return "payment/AccntPrint";
	}
	
	@RequestMapping(value = "/updateAccDeptPaymentTransaction.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView  updateAccDeptPaymentTransaction(HttpServletRequest request,HttpServletResponse response,HttpSession session,ModelAndView model) {
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		try{


			String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			
			

			list=objPaymentProcessService.updateAccountDeptTransaction(request,response,strUserId);

			
			if(list != null && list.size() >0){
				request.setAttribute("showGrid", "true");
			}
			boolean flag = Boolean.valueOf(String.valueOf(request.getAttribute("isDownload")));
			//set this object to session for downloading the files
			Map<String,String> requestedDateMap =(Map<String, String>) request.getAttribute("requestedDatePaymentList");
			session.setAttribute("requestedDatePaymentMap", requestedDateMap);
			if (flag) {
				System.out.println("File is downloading \n");
				model.addObject("generateFile", true);
			}
			model.addObject("listofPendingPayments",list);
			
			model.addObject("listTotalPaymentReqSize",list.size());
			if(list.size()>0){
				model.setViewName("payment/AccntPrint");
			}
			else {
				model.setViewName("payment/paymentResponse");
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
			
		}

		return model;

	}
	
	@RequestMapping(value ="viewPaymentDetails.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getIndentViewDts(HttpServletRequest request,HttpSession session) {

		String toDate = "";
		String fromDate = "";
		ModelAndView model = null;
		String response="";
		String vendorId = "";
		String site_id = "";
		List<PaymentBean> listOfPayments = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			vendorId = request.getParameter("vendorId");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				if (StringUtils.isNotBlank(site_id))  {
					listOfPayments = new PaymentProcessDaoImpl().getViewPaymentDetails(fromDate, toDate,vendorId);
					if(listOfPayments != null && listOfPayments.size() >0){
						request.setAttribute("showGrid", "true");
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failed";
					}
					model.addObject("listOfPayments",listOfPayments);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("payment/ViewPayments");
					response="success";

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failed";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
				model.addObject("listOfPayments",listOfPayments);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.setViewName("payment/ViewPayments");
				response="failed";
			}
		} catch (Exception ex) {
			response="failed";
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"get invoice Details View data",response,site_id1);




		return model;
	}
	
	@RequestMapping(value ="viewMyPayment.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView viewMyPayment(HttpServletRequest request,HttpSession session) {

		String toDate = "";
		String fromDate = "";
		ModelAndView model = null;
		String response="";
		String site_id = "";
		List<PaymentBean> listOfPayments = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				String user_id=String.valueOf(session.getAttribute("UserId"));
				if (StringUtils.isNotBlank(site_id)) {
					listOfPayments = new PaymentProcessDaoImpl().viewMyPayment(fromDate, toDate, site_id, user_id);
					if(listOfPayments != null && listOfPayments.size() >0){
						request.setAttribute("showGrid", "true");
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failed";
					}
					model.addObject("listOfPayments",listOfPayments);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("payment/ViewMyPayment");
					response="success";

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failed";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
				model.addObject("listOfPayments",listOfPayments);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.setViewName("payment/ViewMyPayment");
				response="failed";
			}
		} catch (Exception ex) {
			response="failed";
			ex.printStackTrace();
		} 

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"get invoice Details View data",response,site_id1);




		return model;
	}

	

	
	
	
	
	@RequestMapping(value = "/updatePaymentDetails.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView updatePaymentDetails( HttpServletRequest request,HttpSession session) {
		String site_id = "";
		String fromDate = "";
		String toDate = "";
		
		ModelAndView model = null;
		List<PaymentBean> listofPendingPayments = new ArrayList<PaymentBean>();//null;
		try {
				model = new ModelAndView();
				fromDate = request.getParameter("fromDate");
				toDate = request.getParameter("toDate");
				
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				String user_id=String.valueOf(session.getAttribute("UserId"));
				
				if (StringUtils.isNotBlank(site_id)) {
					if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
						listofPendingPayments = new PaymentProcessDaoImpl().getAccDeptPaymentDetailsToUpdate(site_id,user_id,fromDate,toDate);
					}
					if(listofPendingPayments != null && listofPendingPayments.size() >0){
						request.setAttribute("showGrid", "true");
					} 
					model.addObject("listTotalPaymentReqSize",listofPendingPayments.size());
					model.addObject("listofPendingPayments",listofPendingPayments);
					model.setViewName("payment/AccDeptPaymentUpdate");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					return model;
				}
			
		}
			catch (Exception ex) {
				ex.printStackTrace();
			} 
	
	return model;
	
	}
	
	@RequestMapping(value = "/updateRefNoInAccDeptTransaction.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView  updateRefNoInAccDeptTransaction(HttpServletRequest request,HttpSession session,ModelAndView model) {
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		ModelAndView modelAndView = new ModelAndView();
		try{


			String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();



			String strResponse=objPaymentProcessService.updateRefNoInAccDeptTransaction(request,strUserId);

			
			if(strResponse.equals("Success")){

				modelAndView.addObject("message", "Payment Updated Successfully");
				modelAndView.setViewName("response");
			}else{
				modelAndView.addObject("message1", "Sorry, Payment Updation Failed");
				modelAndView.setViewName("response");
			}
			
		}catch(Exception e){
			e.printStackTrace();
			
		}

		return modelAndView;

	}
}
