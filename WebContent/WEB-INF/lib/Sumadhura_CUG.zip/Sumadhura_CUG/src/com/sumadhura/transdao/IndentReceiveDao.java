package com.sumadhura.transdao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.CreditNoteDto;
import com.sumadhura.dto.IndentReceiveDto;

public interface IndentReceiveDao {

	public Map<String, String> loadProds();
	public String loadSubProds(String prodId);
	public String loadChildProds(String subProductId);
	public String loadIndentReceiveMeasurements(String childProdId);
	public Map<String, String> getGSTSlabs();
	public int getIndentEntrySequenceNumber();
	public int insertInvoiceData(int indentEntrySeqNum, IndentReceiveDto objIndentReceiveDto);
	public String getVendorInfo(String vendName);
	public int insertIndentReceiveData(int indentEntrySeqNum, int intIndentEntryDetailsSeqNo,IndentReceiveDto irdto, String userId, String siteId,int intPriceListSeqNo);	
	public int updateIndentAvalibility(IndentReceiveDto irdto, String siteId);	
	public void updateIndentAvalibilityWithNewIndent(IndentReceiveDto irdto, String siteId);
	public String getProductAvailability(String prodId, String subProductId, String childProdId, String measurementId, String siteId);
	public void saveReciveDetailsIntoSumduraPriceList(IndentReceiveDto irdto, String invoiceNumber, String siteId, String id,int entryDetailssequenceId,int intPriceListSeqNo,String typeOfPurchase);
	public String getIndentAvailableId(IndentReceiveDto irdto, String site_id);
	public String getProductAvailabilitySequenceNumber();
	public int getEntryDetailsSequenceNumber();
	public String getindentEntrySerialNo() ;
	public void saveReciveDetailsIntoSumadhuraCloseBalance(IndentReceiveDto irdto, String siteId);
	public void saveReceivedDataIntoSumadhuClosingBalByProduct(IndentReceiveDto irdto, String siteId);
	public Map<String, String> getOtherCharges();
	public void saveTransactionDetails(String invoiceNum, String transactionId, String gstId, String gstAmount, String totAmtAfterGSTTax, String transactionInvoiceId, String transAmount, String siteId, String indentEntrySeqNum);
	public int getInvoiceCount(String  strInvoiceNmber, String vendorId,String strReceiveStartDate, String receiveDate);
	public int getIndentEntryDtails_SeqNumber();
	public int getInvoiceSaveCount(String  strInvoiceNmber, String vendorId,String receiveDate);
	public List<ViewIndentIssueDetailsBean> getSiteWiseInvoiceDetails(String fromDate, String toDate, String siteId);
	public List<ProductDetails> getPODetails(String poNumber, String reqSiteId);
	public List<ProductDetails> getProductDetailsLists(String poNumber, String reqSiteId);
	public List<ProductDetails> getTransChrgsDtls(String poNumber, String reqSiteId);
	public int updateReceiveQuantityInIndentCreationDtls(String string, String string2);
	public int setPOInactive(String string, String reqSiteId);
	public int setIndentInactiveAfterChecking(String indentNumber);
	public List<Map<String, Object>> getListOfActivePOs(String site_id);
	public int getPriceList_SeqNumber();
	public int getCreditNoteSequenceNumber();
	public int getCreditNoteDetailsSequenceNumber();
	public int insertCreditNote(CreditNoteDto creditNoteDto);
	public int insertCreditNoteDetails(CreditNoteDto creditNoteDto,ProductDetails productDetails);
	public String loadSubProdsByPONumber(String prodId, String poNumber, String reqSiteId);
	public String loadChildProdsByPONumber(String subProductId, String poNumber, String reqSiteId);
	public String getPriceRatesByChildProduct(String childProdId, String poNumber, String reqSiteId);
	public int updateAllocatedQuantityInPurchaseDeptTable(String receiveQuantity,String indentCreationDetailsId,HttpServletRequest request);
	public int updateInvoiceNoInAccPaymentTbl(String invoiceNumber, String invoiceAmount, String invoiceDate,String receviedDate, String poNo,
			String vendorId,String creditNoteNumber,String creditTotalAmount,String indentEntryNo, String site_id);
	public int checkPOisActive(String poNumber);
	public int updateReceivedQuantityInPoEntryDetails(String totalQuantity, String poEntryDetailsId);
	public int getCheckIndentAvailable(String  strInvoiceNmber);
	public String getPoEntryDetailsandIndentCreationDetails(String poNumber,String childProdId,String indentNumber);
	public String getIndentCreationDetailsId(String indentNumber,String childProdId);
	public int getCheckPoAvailable(String poNumber,String vendorId);
	

}
