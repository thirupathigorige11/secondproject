package com.sumadhura.in;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.IssueToOtherSiteBean;
import com.sumadhura.bean.IssueToOtherSiteInwardBean;
import com.sumadhura.service.IndentReceiveService;
import com.sumadhura.service.IssueToOtherSiteService;
import com.sumadhura.util.SaveAuditLogDetails;

@Controller
public class IssueToOtherSiteController {

	@Autowired
	@Qualifier("itosc")
	IssueToOtherSiteService itoss;
	
	@Autowired
	@Qualifier("irsClass")
	IndentReceiveService irs;

	@RequestMapping(value = "/indentIssueToOtherSite", method = RequestMethod.GET)
	public String indentIssueToOtherSite(Model model, HttpSession session) {
		IssueToOtherSiteBean itosb = new IssueToOtherSiteBean();
		model.addAttribute("indentIssueOtherSiteForm", itosb);
		model.addAttribute("productsMap", itoss.issueToOtherSiteProducts());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		 String reqid=String.valueOf(itoss.getIndentEntrySequenceNumber());	
		 itosb.setReqId(reqid);
		//itosb.setProjectName(itoss.getProjectName(session));
		model.addAttribute("sitesMap", itoss.loadSites());

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			//String indentEntrySeqNum=String.valueOf(session.getAttribute("indentEntrySeqNum"));
			audit.auditLog(reqid,user_id,"Issue to Other Site","success",site_id1);
			
		
		return "IssueToOtherSite";
	}

	@RequestMapping(value = "/issueToOtherSiteSubProducts", method = RequestMethod.POST)
	@ResponseBody
	public String issueToOtherSiteSubProducts(@RequestParam("mainProductId") String mainProductId) {
		return itoss.issueToOtherSiteSubProducts(mainProductId);
	}

	@RequestMapping(value = "/issueToOtherSiteChildProducts", method = RequestMethod.POST)
	@ResponseBody
	public String issueToOtherSiteChildProducts(@RequestParam("subProductId") String subProductId) {
		return itoss.issueToOtherSiteChildProducts(subProductId);
	}

	@RequestMapping(value = "/issueToOtherSiteMeasurements", method = RequestMethod.POST)
	@ResponseBody
	public String issueToOtherSiteMeasurements(@RequestParam("childProductId") String childProductId) {
		return itoss.issueToOtherSiteMeasurements(childProductId);
	}
	
	@RequestMapping(value = "/getIssueToOtherSiteProductAvailability", method = RequestMethod.POST)
	@ResponseBody
	public String getIssueToOtherSiteProductAvailability(@RequestParam("prodId") String prodId, @RequestParam("subProductId") String subProductId, @RequestParam("childProdId") String childProdId, @RequestParam("measurementId") String measurementId, HttpServletRequest request, HttpSession session) {
		return itoss.getIssueToOtherSiteProductAvailability(prodId, subProductId, childProdId, measurementId, request, session);
	}
	@RequestMapping(value = "/doIndentIssueToOtherSite", method = RequestMethod.POST)
	public String doIndentIssueToOtherSite(@ModelAttribute("indentIssueOtherSiteForm")IssueToOtherSiteBean issueToOtherSiteModel, BindingResult result, Model model, HttpServletRequest request, HttpSession session) {
		String response = itoss.doIndentIssueToOtherSite(model, request, session);
		String viewToBeSelected = "";
		if(response.equalsIgnoreCase("Success")) {
			viewToBeSelected = "DCviewGRN";
		}
		else if(response.equalsIgnoreCase("Failed")){
			viewToBeSelected = "IndentIssueToOtherSiteResponse";
		} else if (response.equalsIgnoreCase("SessionFailed")){
			request.setAttribute("Message", "Session Expired, Please Login Again");
			viewToBeSelected = "index";
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			String indentEntrySeqNum=String.valueOf(session.getAttribute("indentEntrySeqNum"));
			audit.auditLog(indentEntrySeqNum,user_id,"Issue to Other Site clicked Submit","success",site_id1);
			
		
		return viewToBeSelected;
	}
	
	
	/*============== inwards get invoice details*/
	
	@RequestMapping(value = "/IssueToOtherSitGetInvoiceId", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView doIndentIssueToOtherSite(HttpSession session){

		ModelAndView model = null;

		try {
			model = new ModelAndView();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("issueToOtherSite_GetInvoiceId");
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Inwards From Other Site View","success",site_id1);
			
		return model;
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/IssueToOtherSitGetInvoiceIdDetails", method ={ RequestMethod.POST,RequestMethod.GET})
	public String doIndentIssueToOtherSiteInwards(HttpServletRequest request, HttpSession session,Model model){

		String RequestId = "";
		String siteId = "";
		String strIssueType = "";
		String view = "";
		String response="";
		try {
			RequestId = request.getParameter("RequestId") == null ? "" : request.getParameter("RequestId");
			siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

			if ( StringUtils.isNotBlank(RequestId)){


				List<IssueToOtherSiteInwardBean> listSiteDetail= itoss.getIssuesToOtherLists(session,RequestId, siteId,strIssueType);

				if(listSiteDetail != null && listSiteDetail.size() > 0){


					model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
					model.addAttribute("issueToOtherSiteModelForm", new IssueToOtherSiteInwardBean());
					model.addAttribute("listOfIssueToOtherSiteInwardList",listSiteDetail);

					strIssueType = session.getAttribute("IssueType") == null ? "" : session.getAttribute("IssueType").toString();

					model.addAttribute("listOfIssueToOtherSiteProductDetails",itoss.getGetProductDetailsLists(session,RequestId, siteId,strIssueType));
					model.addAttribute("listOfIssueToOtherSiteTransportChargesDetails",itoss.getTransportChargesList(RequestId, siteId));
					model.addAttribute("gstMap", irs.getGSTSlabs());
					model.addAttribute("chargesMap", irs.getOtherCharges());
					double doubleFinalAmount = Double.valueOf(session.getAttribute("doubleFinalAmount") == null ? "" : session.getAttribute("doubleFinalAmount").toString());
					model.addAttribute("doubleFinalAmount",doubleFinalAmount);
					model.addAttribute("strIssueType", strIssueType);
					if(strIssueType.equals("NonReturnable")){
						response="success";
						view = "IssueToOtherSiteNonReturnableView";
					}else if(strIssueType.equals("Returnable")){
						response="success";
						view = "IssueToOtherSiteReturableView";
					}else{
						view = "IssueToOtherSiteReturableView";
						response="failed";
					}

				}else{
					model.addAttribute("Message", "Sorry no data found with specified request number");
					response="failure";
					SaveAuditLogDetails audit=new SaveAuditLogDetails();
						String indentEntrySeqNum=RequestId;
						String user_id=String.valueOf(session.getAttribute("UserId"));
						String site_id1 = String.valueOf(session.getAttribute("SiteId"));
						audit.auditLog("0",user_id,"Inwards from Other Site entered requested id click submit",response,site_id1);
						
					
					view = "issueToOtherSite_GetInvoiceId";
				}

			}else{
				model.addAttribute("Message", "*Please enter the requestID");
				response="failed";
				view = "issueToOtherSite_GetInvoiceId";
			}
		} catch (Exception ex) {
			response="failed";
			ex.printStackTrace();
		} 
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Inwards from Other Site entered requested id click submit",response,site_id1);
		

		return view ;
	}

	@RequestMapping(value = "/doinwardsFromOtherSite", method = RequestMethod.POST)
	public String doinwardsFromOtherSite(@ModelAttribute("issueToOtherSiteModelForm")IssueToOtherSiteInwardBean objIssueToOtherSiteInwardBean, BindingResult result, Model model, HttpServletRequest request, HttpSession session) {
		String response = itoss.doIndentInwardsFromOtherSite(model, request, session);
		String viewToBeSelected = "";
		
		
		
		if(response.equalsIgnoreCase("Success")) {
			model.addAttribute("Message", "Inwards done successfuly");
			viewToBeSelected = "issueToOtherSite_GetInvoiceId";
		}
		else if(response.equalsIgnoreCase("Failed")){
			model.addAttribute("Message", "error occured during the inwards");
			viewToBeSelected = "issueToOtherSite_GetInvoiceId";
		} else if (response.equalsIgnoreCase("SessionFailed")){
			request.setAttribute("Message", "Session Expired, Please Login Again");
			viewToBeSelected = "index";
		}
		
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog(indentEntrySeqNum,user_id,"Inwards from Other Site click submit to save data",response,site_id1);
	

		return viewToBeSelected;
	}
	
	public static void main(String [] args) throws UnknownHostException{
		


        InetAddress ip;
        String hostname;
        try {
            ip = InetAddress.getLocalHost();
            hostname = ip.getHostName();
            System.out.println("Your current IP address : " + ip);
            System.out.println("Your current Hostname : " + hostname);

        } catch (UnknownHostException e) {

            e.printStackTrace();
        }
	}
}
