package com.sumadhura.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sumadhura.transdao.WorkOrderDao;

@Service(value = "workControllerService")
public class WorkOrderServiceImpl implements WorkOrderService {

	@Autowired
	@Qualifier("workControllerDao")
	WorkOrderDao workControllerDao;

	@Override
	public List<Map<String, Object>> loadChildProduct(String prodId, String prodName) {
		List<Map<String, Object>> list = workControllerDao.loadChildProduct(prodId, prodName);
		return list;
	}

	@Override
	public Map<String, String> loadQSProducts() {
		Map<String, String> list = workControllerDao.loadQSProducts();
		return list;
	}

	@Override
	public String loadWOSubProds(String mainProductId) {
		// TODO Auto-generated method stub
		return workControllerDao.loadWOSubProds(mainProductId);
	}

	@Override
	public String loadWOChildProds(String subProductId) {
		// TODO Auto-generated method stub
		return workControllerDao.loadWOChildProds( subProductId);
	}

	@Override
	public String loadWorkOrderMeasurements(String childProductId) {
	
		return workControllerDao.loadWorkOrderMeasurements( childProductId);
	}

	@Override
	public List<String> getVendorInfo(String vendorName, String loadVendorData) {
	boolean flag=Boolean.valueOf(loadVendorData);
		return workControllerDao.getVendorInfo(vendorName,flag);
	}

	@Override
	public List<Map<String, Object>> loadWOAreaMapping(String siteId) {
		return workControllerDao.loadWOAreaMapping(siteId);
		
	}

	@Override
	public int getQS_WO_Temp_Issue_Dtls() {
		// TODO Auto-generated method stub
		return workControllerDao.getQS_WO_Temp_Issue_Dtls();
	}

}
