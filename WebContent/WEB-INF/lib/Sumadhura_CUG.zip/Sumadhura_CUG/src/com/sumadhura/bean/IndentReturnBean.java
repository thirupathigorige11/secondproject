package com.sumadhura.bean;

public class IndentReturnBean {
	
	
	private String strProductId;
	private String strSubProductId;
	private String strChildProductId;
	private String strProductName;
	private String strSubProductName;
	private String strChildProductName;
	private String strQuantity;
	private Integer strIndententrtDetailsId;
	private String strMesurmentName;
	private String issueSlipNumber;
	private String requesterName;
	private String contractorName;
	private String blockName;
	private String date;
	
	
	
	
	public String getBlockName() {
		return blockName;
	}
	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getIssueSlipNumber() {
		return issueSlipNumber;
	}
	public void setIssueSlipNumber(String issueSlipNumber) {
		this.issueSlipNumber = issueSlipNumber;
	}
	public String getRequesterName() {
		return requesterName;
	}
	public void setRequesterName(String requesterName) {
		this.requesterName = requesterName;
	}
	public String getContractorName() {
		return contractorName;
	}
	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}
	public String getStrMesurmentName() {
		return strMesurmentName;
	}
	public void setStrMesurmentName(String strMesurmentName) {
		this.strMesurmentName = strMesurmentName;
	}
	public String getStrProductId() {
		return strProductId;
	}
	public void setStrProductId(String strProductId) {
		this.strProductId = strProductId;
	}
	public String getStrSubProductId() {
		return strSubProductId;
	}
	public void setStrSubProductId(String strSubProductId) {
		this.strSubProductId = strSubProductId;
	}
	public String getStrChildProductId() {
		return strChildProductId;
	}
	public void setStrChildProductId(String strChildProductId) {
		this.strChildProductId = strChildProductId;
	}
	public String getStrProductName() {
		return strProductName;
	}
	public void setStrProductName(String strProductName) {
		this.strProductName = strProductName;
	}
	public String getStrSubProductName() {
		return strSubProductName;
	}
	public void setStrSubProductName(String strSubProductName) {
		this.strSubProductName = strSubProductName;
	}
	public String getStrChildProductName() {
		return strChildProductName;
	}
	public void setStrChildProductName(String strChildProductName) {
		this.strChildProductName = strChildProductName;
	}
	
	public String getStrQuantity() {
		return strQuantity;
	}
	public void setStrQuantity(String strQuantity) {
		this.strQuantity = strQuantity;
	}
	public Integer getStrIndententrtDetailsId() {
		return strIndententrtDetailsId;
	}
	public void setStrIndententrtDetailsId(Integer strIndententrtDetailsId) {
		this.strIndententrtDetailsId = strIndententrtDetailsId;
	}
	
	
	
	

}
