package com.sumadhura.in;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sumadhura.bean.VendorDetails;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.transdao.VendorDao;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Controller
public class VendorController extends UIProperties{
	@Autowired
	private VendorDao dao;

	@Autowired
	private UtilDao utilDao;

	@RequestMapping(value = "/AddVendor.spring")
	public ModelAndView showform(HttpServletRequest request,HttpSession session) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("AddVendor");
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		// HttpSession session=request.getSession(true);  
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Vendor Master Viewed","success",site_id1);
			
		
		
		
		return mav;
	}

	@RequestMapping(value = "/savevendor.spring", method = RequestMethod.POST)
	public ModelAndView save(HttpServletRequest request,HttpSession session, @RequestParam("file") MultipartFile[] files) throws Exception {

		ModelAndView model = new ModelAndView();
		System.out.println("controler");
		String strVendorName = "";
		String straddress = "";
		String strmobilenumber = "";
		String strgsinnumber = "";
		String strvendorstate = "";
		String strvendoremail = "";
		String landline = "";
		String statecode = "";
		String vendorcontactperson = "";
		String response="";
		String vendorContactPerson_2="";
		String mobile_number_2="";
		String type_Of_Business="";
		String nature_Of_Business="";
		String Pan_number="";
		String bank_Name="";
		String acc_Type="";
		String acc_Holder_Name="";
		long acc_Number=0;
		String ifsc_Code="";
		String strResponse="";
		String manfuturer="";
		String authorizedAgent="";
		String trader="";
		String consultingCompany="";
		String other="";
		String gstinNumber="";
		String tmpAccountNumber="";
		int intCount = 0;
		try {
		String strServiceType = request.getParameter("ServiceType");
		if (StringUtils.isNotBlank(strServiceType)) {
			if (strServiceType.equals("add")) {
				strVendorName = request.getParameter("vendor");
				 straddress = request.getParameter("address");
				 strmobilenumber = request.getParameter("mobilenumber");
				 strgsinnumber = request.getParameter("gsinnumber");
				 strvendorstate = request.getParameter("state");
				 strvendoremail = request.getParameter("email");
				 landline = request.getParameter("landnumber");
				 statecode = request.getParameter("statecode");
				 vendorcontactperson = request.getParameter("vendorContactPerson");
				 vendorContactPerson_2 = request.getParameter("vendorContactPerson2");
				 type_Of_Business = request.getParameter("typeOfBusiness");
				 authorizedAgent= request.getParameter("Authorized")==null ? "":request.getParameter("Authorized").toString();
				 trader= request.getParameter("Trader")==null ? "":request.getParameter("Trader").toString();
				 consultingCompany= request.getParameter("Consulting")==null ? "":request.getParameter("Consulting").toString();
				 other= request.getParameter("natureOfBusiness")==null ? "":request.getParameter("natureOfBusiness").toString();
				 
				 mobile_number_2 = request.getParameter("vendorMobileNumber2");
				 manfuturer = request.getParameter("Manufacturer")==null ? "":request.getParameter("Manufacturer").toString();
				 bank_Name = request.getParameter("bankName");
				 acc_Type = request.getParameter("accountType");
				 acc_Holder_Name = request.getParameter("accountHolderName");
				 acc_Number=Long.parseLong(request.getParameter("accountNumber"));
				// acc_Number =Long.parseLong(tmpAccountNumber);
				 ifsc_Code=request.getParameter("ifscCode");
				 Pan_number=request.getParameter("panNumber");
				 
				 nature_Of_Business = authorizedAgent +" "+trader +" "+consultingCompany +" "+manfuturer +" "+other;
				/* if(nature_Of_Business.contains(" ")){
					 nature_Of_Business=nature_Of_Business.replace(" ",",");
				 
				 }*/
				 VendorDetails vd = new VendorDetails();
				 vd.setAddress(straddress);
				 vd.setMobile_number(strmobilenumber);
				 vd.setGsin_number(strgsinnumber);
				 vd.setState_code(statecode);
				 vd.setVendor_state(strvendorstate);
				 vd.setVendor_email(strvendoremail);
				 vd.setVendorcontact_person(vendorcontactperson);
				 vd.setLandline(landline);
				 vd.setVendor_Contact_Person_2(vendorContactPerson_2);
				 vd.setMobile_Number_2(mobile_number_2);
				 vd.setAcc_Holder_Name(acc_Holder_Name);
				 vd.setAcc_Number(acc_Number);
				 vd.setAcc_Type(acc_Type);
				 vd.setBank_name(bank_Name);
				 vd.setType_Of_Business(type_Of_Business);
				 vd.setNature_Of_Business(nature_Of_Business);
				 vd.setVendor_name(strVendorName);
				 vd.setPan_Number(Pan_number);
				
				 vd.setIfsc_Code(ifsc_Code);
				 
				 gstinNumber=dao.checkGstinNumber(strgsinnumber);
				 strResponse=dao.checkMandatoryData(vd);
	 
	
				 if (strResponse.equalsIgnoreCase("true") && gstinNumber.equalsIgnoreCase("true")) {
					
					 int getVendorId = dao.getVendorSeqNo("vendor");
					String strVendorId = "VND" + getVendorId;
					 vd.setVendor_Id(strVendorId);
					 
					
					
					 System.out.println("strVendor name " + strVendorName);
						System.out.println("strVendor Id " + strVendorId);
						int existCount = dao.checkVendorAvailableOrNot(strVendorName);
						
					if (existCount == 0) {
						intCount = dao.save(strVendorName,vd);
						if (intCount == 1) {
							for (int i = 0; i < files.length; i++) {
								MultipartFile multipartFile = files[i];
								if(!multipartFile.isEmpty()){
								try {
										String rootFilePath = validateParams.getProperty("VENDOR_IMAGE_PATH") == null ? "" : validateParams.getProperty("VENDOR_IMAGE_PATH").toString();
										File dir = new File(rootFilePath+strVendorId);
										if (!dir.exists())
											dir.mkdirs();

										String filePath = dir.getAbsolutePath()
										+ File.separator + strVendorId+"_Part"+i+".jpg"; 
										File convFile = new File(filePath);
									    convFile.createNewFile(); 
									    FileOutputStream fos = new FileOutputStream(convFile); 
									    fos.write(multipartFile.getBytes());
									    fos.close(); 
										/*if(!multipartFile.isEmpty()){
											multipartFile.transferTo(new File(filePath));
											
										}*/
										
										

										System.out.println("Image Uploaded");
										//return "You successfully uploaded file" ;
									} catch (Exception e) {
										System.out.println("Image NOT Uploaded");
										//return "You failed to upload " ;
									}
								

							}

	
							}
							
							model.addObject("succMessage", "Vendor added successfully");
							response="success";
						} else if (intCount == 9) {
							model.addObject("errMessage", "Vendor Name Already Exist in Database");
							response="failure";
						} else {
							model.addObject("errMessage", "Vendor adding failed");
							response="failure";
						}
					} else {
						model.addObject("errMessage", "Vendor Name was already Added, Please try with Another Vendor Name");
						response="failure";
					
					}
					
				 } else {
					 model.addObject("errMessage", "All Fileds are Mandatory");
				 }
			} else if (strServiceType.equals("delete")) {
				strVendorName = request.getParameter("VendarName_Delete");
				intCount = dao.deletevendor(strVendorName);
				if (intCount > 0) {
					model.addObject("succMessage", "Vendor deleted successfully");
					
					response="failure";
					
					
				} else {
					model.addObject("errMessage", "Vendor deleting failed");
					response="failure";
				}
			}
		} else {
			model.addObject("errMessage", "ServiceType not empty.");
		}
		}catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("AddVendor");
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Vendor Master clicked submit",response,site_id1);
			
		
		
		
		
		return model;
	}

	@RequestMapping("/ViewVendor.spring")
	public @ResponseBody List<VendorDetails> getAllVendorsList(HttpServletRequest request,HttpSession session,Model model) {

		System.out.println("get Total vendors...");
		String strVendorName = request.getParameter("vendor");
		List<VendorDetails> listAllVendorsList = new ArrayList<VendorDetails>();
		try {
			listAllVendorsList = dao.getAllVendors();
			System.out.println("get All vendors List..."
					+ listAllVendorsList.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Vendor Master Viewed Details","success",site_id1);
			
		return listAllVendorsList;
	}


	@RequestMapping("/viewVendorMaster.spring")
	public ModelAndView getAllVendorsListForView(HttpServletRequest request, HttpSession session, Model model) {
		ModelAndView mav = new ModelAndView();
		System.out.println("VendorController.getAllVendorsList()");
		String strVendorName = request.getParameter("vendor");
		List<VendorDetails> listAllVendorsList = new ArrayList<VendorDetails>();
		try {
			listAllVendorsList = dao.getAllVendors();
			System.out.println("get All vendors List..." + listAllVendorsList.size());
			mav.addObject("isVendorDetailEditable", "false");
			mav.addObject("AllVendorsList", listAllVendorsList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails audit = new SaveAuditLogDetails();
		// String
		// indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id = String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0", user_id, "Vendor Master Viewed Details", "success", site_id1);
		mav.setViewName("ShowAllVendors");
		return mav;
	}

	@RequestMapping("/autoSearchvendor.spring")
	public @ResponseBody String getAutoSearchVendorNames(
			@RequestParam(value = "term") String term) {
		System.out.println("get Total Products...");
		List<String> listAllVendorsList = new ArrayList<String>();
		String searchvendorList = "";
		try {
			listAllVendorsList = utilDao.getVendorsBySearch(term);
			searchvendorList = new Gson().toJson(listAllVendorsList);
			System.out.println("get Products..." + listAllVendorsList.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return searchvendorList;
	}
	@RequestMapping("/getVendorDetails.spring")
	public String getVendorsList(HttpServletRequest request,HttpSession session,Model model) {

		System.out.println("get Total vendors...");
		String vendorId=request.getParameter("vendor_Id");
		String isVendorDetailEditable=request.getParameter("edt");
		request.setAttribute("isVendorDetailEditable", isVendorDetailEditable);
		List<VendorDetails> listAllVendorsList = new ArrayList<VendorDetails>();
		try {
			listAllVendorsList = dao.getAllVendorsList(vendorId);
			int count = 0;
			for(int i=0;i<8;i++){
				String rootFilePath = validateParams.getProperty("VENDOR_IMAGE_PATH") == null ? "" : validateParams.getProperty("VENDOR_IMAGE_PATH").toString();
				File f = new File(rootFilePath+vendorId+"/"+vendorId+"_Part"+i+".jpg");

				if(f.exists()){
					count++;
					DataInputStream dis = new DataInputStream(new FileInputStream(f));
					byte[] barray = new byte[(int) f.length()];
					dis.readFully(barray); 
					byte[] encodeBase64 = Base64.encodeBase64(barray);
					String base64Encoded = new String(encodeBase64, "UTF-8");
					model.addAttribute("image"+i,base64Encoded);
				}
			}
			request.setAttribute("imagecount", count);
		
			model.addAttribute("listAllVendorsList",listAllVendorsList);
			System.out.println("get All vendors List..."
					+ listAllVendorsList.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Vendor Master Viewed Details","success",site_id1);
			
		return "ViewAllVendors";
	}


@RequestMapping("/editAndSaveVendorDetails.spring")
public ModelAndView editSaveVendorDetails(HttpServletRequest request,HttpSession session, @RequestParam("file") MultipartFile[] files) {
System.out.println("VendorController.editSaveVendorDetails()");
	String response = "";
	ModelAndView model = new ModelAndView();
	System.out.println("Edit & Save vendor...");
	String vendorId=request.getParameter("vendorId");
	String vendorName=request.getParameter("vendorName");
	String gsinNumber=request.getParameter("gsinNumber");
	String vendorState=request.getParameter("vendorState");
	String vendorEmail=request.getParameter("vendorEmail");
	String landline=request.getParameter("landline");
	String stateCode=request.getParameter("stateCode");
	String contactPerson=request.getParameter("contactPerson");
	String mobileNumber=request.getParameter("mobileNumber");
	String address=request.getParameter("address");
	
	
	String vendorContactPerson_2 = request.getParameter("vendorContactPerson_2");
	String type_Of_Business = request.getParameter("typeOfBusiness");
	String mobile_number_2 = request.getParameter("mobileNumber_2");
	String nature_Of_Business = request.getParameter("natureOfBusiness");
	String bank_Name = request.getParameter("bankName");
	String acc_Type = request.getParameter("accountType");
	String acc_Holder_Name = request.getParameter("accountHolderName");
	long acc_Number = Long.parseLong(request.getParameter("bankAccountNumber"));
	 String ifsc_Code=request.getParameter("ifscCode");
	 String panNumber=request.getParameter("panNumber");
	 
	
	VendorDetails vd = new VendorDetails();
	vd.setVendor_Id(vendorId);
	vd.setVendor_name(vendorName);
	vd.setGsin_number(gsinNumber);
	vd.setVendor_state(vendorState);
	vd.setVendor_email(vendorEmail);
	vd.setLandline(landline);
	vd.setState_code(stateCode);
	vd.setVendorcontact_person(contactPerson);
	vd.setMobile_number(mobileNumber);
	vd.setAddress(address);
	
	 vd.setVendor_Contact_Person_2(vendorContactPerson_2);
	 vd.setMobile_Number_2(mobile_number_2);
	 vd.setAcc_Holder_Name(acc_Holder_Name);
	 vd.setAcc_Number(acc_Number);
	 vd.setAcc_Type(acc_Type);
	 vd.setBank_name(bank_Name);
	 vd.setType_Of_Business(type_Of_Business);
	 vd.setNature_Of_Business(nature_Of_Business);
	 vd.setIfsc_Code(ifsc_Code);
	 vd.setPan_Number(panNumber);
	

	 int result = dao.editAndSaveVendor(vd);System.out.println(result);
	if (result > 0) {
		model.addObject("succMessage", "Vendor Saved successfully");
		
		response="success";
		
		int imagesAlreadyPresent = Integer.parseInt(request.getParameter("imagesAlreadyPresent"));

		for (int i = imagesAlreadyPresent; i < files.length; i++) {
			MultipartFile multipartFile = files[i];
			if(!multipartFile.isEmpty()){
			try {
					String rootFilePath = validateParams.getProperty("VENDOR_IMAGE_PATH") == null ? "" : validateParams.getProperty("VENDOR_IMAGE_PATH").toString();
					File dir = new File(rootFilePath+vendorId);
					if (!dir.exists())
						dir.mkdirs();

					String filePath = dir.getAbsolutePath()
					+ File.separator + vendorId+"_Part"+i+".jpg"; 
					/*Path path = Paths.get(filePath);
					try {
					    Files.delete(path);
					} catch (NoSuchFileException x) {
					    System.err.format("%s: no such" + " file or directory%n", filePath);
					} catch (DirectoryNotEmptyException x) {
					    System.err.format("%s not empty%n", filePath);
					} catch (IOException x) {
					    // File permission problems are caught here.
					    System.err.println(x);
					}*/
					File convFile = new File(filePath);
				    convFile.createNewFile(); 
				    FileOutputStream fos = new FileOutputStream(convFile); 
				    fos.write(multipartFile.getBytes());
				    fos.close(); 
					/*if(!multipartFile.isEmpty()){
						multipartFile.transferTo(new File(filePath));
					}*/

					System.out.println("Image Uploaded");
					//return "You successfully uploaded file" ;
				} catch (Exception e) {
					System.out.println("Image NOT Uploaded");
					//return "You failed to upload " ;
					model.addObject("succMessage", "Vendor Saved successfully. But Image NOT Uploaded");
				}
			finally{
				
			}
			

		}

		}
			
	} else {
		model.addObject("errMessage", "Vendor Saving failed");
		response="failure";
	}
	SaveAuditLogDetails audit=new SaveAuditLogDetails();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"Vendor Master Edit & Save Details",response,site_id1);
		
		model.setViewName("AddVendor");
		return model;
}

@RequestMapping("/ViewAllProductList.spring")
public String  getAllProductDetailsList(HttpServletRequest request,HttpSession session,Model model) {

	 List<Map<String,Object>> listAllProductList = new ArrayList<Map<String,Object>>();
	
	try {
		listAllProductList = dao.getAllProductDetails();
	
		model.addAttribute("allProductlist", listAllProductList);
		System.out.println("get All product List..."
				+ listAllProductList.size());
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return "ViewAllProductList";
	
}
@RequestMapping(value = "/vendor_registration.spring")
public ModelAndView Vendor_Registration(HttpServletRequest request,HttpSession session) {
	ModelAndView mav = new ModelAndView();
	mav.setViewName("Vendor_Registration");
	
	return mav;
}



@RequestMapping(value = "/getGstinNumber", method = RequestMethod.POST)
@ResponseBody
public String getGstinNumber(@RequestParam("GstiNumber") String strGstinNumber) {
	
	String response="";
	String strValue="";
	strValue=dao.checkGstinNumber(strGstinNumber);
	if(strValue.equalsIgnoreCase("true")){
		response="true";
		
	}else{
		response="false";
	}
	
	return response;
}




}