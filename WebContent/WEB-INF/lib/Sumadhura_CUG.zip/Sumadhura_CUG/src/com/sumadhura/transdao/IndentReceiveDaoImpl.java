package com.sumadhura.transdao;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sumadhura.bean.AuditLogDetailsBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.CreditNoteDto;
import com.sumadhura.dto.IndentReceiveDto;
import com.sumadhura.util.DBConnection;
import com.sumadhura.util.DateUtil;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Repository
public class IndentReceiveDaoImpl extends UIProperties  implements IndentReceiveDao {

	static Logger log = Logger.getLogger(IndentReceiveDaoImpl.class);

	@Autowired(required = true)
	private JdbcTemplate jdbcTemplate;

	public Map<String, String> loadProds() {

		Map<String, String> products = null;
		List<Map<String, Object>> dbProductsList = null;

		products = new HashMap<String, String>();

		String prodsQry = "SELECT PRODUCT_ID, NAME FROM PRODUCT WHERE STATUS = 'A'";
		log.debug("Query to fetch product = "+prodsQry);

		dbProductsList = jdbcTemplate.queryForList(prodsQry, new Object[]{});

		for(Map<String, Object> prods : dbProductsList) {
			products.put(String.valueOf(prods.get("PRODUCT_ID")), String.valueOf(prods.get("NAME")));
		}
		return  printMap(products);
	}



	public String loadSubProds(String prodId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbSubProductsList = null;	

		log.debug("Product Id = "+prodId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT SUB_PRODUCT_ID, NAME FROM SUB_PRODUCT WHERE PRODUCT_ID = ? AND STATUS = 'A' ORDER BY NAME ASC";
		log.debug("Query to fetch subproduct = "+subProdsQry);

		dbSubProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{prodId});

		for(Map<String, Object> subProds : dbSubProductsList) {
			sb = sb.append(String.valueOf(subProds.get("SUB_PRODUCT_ID"))+"_"+String.valueOf(subProds.get("NAME"))+"|");
		}		
		return sb.toString();
	}
	@Override
	public String loadSubProdsByPONumber(String prodId, String poNumber, String reqSiteId) {
		StringBuffer sb = null;
		List<Map<String, Object>> dbSubProductsList = null;	

		log.debug("Product Id = "+prodId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT SP.SUB_PRODUCT_ID , max(SP.NAME) as SUB_PRODUCT_NAME "
			+ " FROM SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE,SUB_PRODUCT SP  "
			+ " WHERE SPED.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID AND  "
			+ " SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' AND SPED.PRODUCT_ID = '"+prodId+"' group by SP.SUB_PRODUCT_ID";
		log.debug("Query to fetch subproduct = "+subProdsQry);

		dbSubProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{});

		for(Map<String, Object> subProds : dbSubProductsList) {
			sb = sb.append(String.valueOf(subProds.get("SUB_PRODUCT_ID"))+"_"+String.valueOf(subProds.get("SUB_PRODUCT_NAME"))+"|");
		}		
		return sb.toString();
	}

	public String loadChildProds(String subProductId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbChildProductsList = null;

		log.debug("Sub Product Id = "+subProductId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT CHILD_PRODUCT_ID, NAME FROM CHILD_PRODUCT WHERE SUB_PRODUCT_ID = ? AND STATUS = 'A' ORDER BY NAME ASC";
		log.debug("Query to fetch child product = "+subProdsQry);

		dbChildProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{subProductId});

		for(Map<String, Object> childProds : dbChildProductsList) {
			sb = sb.append(String.valueOf(childProds.get("CHILD_PRODUCT_ID"))+"_"+String.valueOf(childProds.get("NAME"))+"|");
		}		
		return sb.toString();
	}
	@Override
	public String loadChildProdsByPONumber(String subProductId, String poNumber, String reqSiteId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbChildProductsList = null;

		log.debug("Sub Product Id = "+subProductId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT CP.CHILD_PRODUCT_ID , max(CP.NAME) as CHILD_PRODUCT_NAME "
			+ " FROM SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE,CHILD_PRODUCT CP  "
			+ " WHERE SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID AND "
			+ " SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' AND SPED.SUB_PRODUCT_ID = '"+subProductId+"' group by CP.CHILD_PRODUCT_ID ";
		log.debug("Query to fetch child product = "+subProdsQry);

		dbChildProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{});

		for(Map<String, Object> childProds : dbChildProductsList) {
			sb = sb.append(String.valueOf(childProds.get("CHILD_PRODUCT_ID"))+"_"+String.valueOf(childProds.get("CHILD_PRODUCT_NAME"))+"|");
		}		
		return sb.toString();
	}

	public String loadIndentReceiveMeasurements(String childProdId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbMeasurementsList = null;

		log.debug("Child Product Id = "+childProdId);

		sb = new StringBuffer();

		String measurementsQry = "SELECT MEASUREMENT_ID, NAME FROM MEASUREMENT WHERE CHILD_PRODUCT_ID = ? and STATUS = ?";
		log.debug("Query to fetch measurement(s) = "+measurementsQry);

		dbMeasurementsList = jdbcTemplate.queryForList(measurementsQry, new Object[]{childProdId,"A"});

		for(Map<String, Object> measurements : dbMeasurementsList) {
			sb = sb.append(String.valueOf(measurements.get("MEASUREMENT_ID"))+"_"+String.valueOf(measurements.get("NAME"))+"|");
		}			
		return sb.toString();
	}

	public Map<String, String> getGSTSlabs() {

		Map<String, String> gst = null;
		List<Map<String, Object>> dbGstSlabList = null;

		gst = new TreeMap<String, String>();

		String gstSlabsQry = "SELECT TAX_ID, TAX_PERCENTAGE FROM INDENT_GST";
		log.debug("Query to fetch gst slab = "+gstSlabsQry);

		dbGstSlabList = jdbcTemplate.queryForList(gstSlabsQry, new Object[]{});

		for(Map<String, Object> gstSlabs : dbGstSlabList) {
			gst.put(String.valueOf(gstSlabs.get("TAX_ID")).trim(), String.valueOf(gstSlabs.get("TAX_PERCENTAGE")).trim());
		}
		return gst;
	}

	@Override
	public Map<String, String> getOtherCharges() {

		Map<String, String> otherCharges = null;
		List<Map<String, Object>> dbOtherChargesSlabList = null;

		otherCharges = new TreeMap<String, String>();

		String getOtherCharges = "SELECT CHARGE_ID, CHARGE_NAME FROM SUMADHURA_TRNS_OTHR_CHRGS_MST WHERE STATUS='A'";
		log.debug("Query to fetch other charges = "+getOtherCharges);

		dbOtherChargesSlabList = jdbcTemplate.queryForList(getOtherCharges, new Object[]{});

		for(Map<String, Object> otherChargesSlabs : dbOtherChargesSlabList) {
			otherCharges.put(String.valueOf(otherChargesSlabs.get("CHARGE_ID")).trim(), String.valueOf(otherChargesSlabs.get("CHARGE_NAME")).trim());
		}
		return otherCharges;
	}

	public int getIndentEntrySequenceNumber() {

		int indentEntrySeqNum = 0;

		indentEntrySeqNum = jdbcTemplate.queryForInt("SELECT INDENT_ENTRY_SEQ.NEXTVAL FROM DUAL");

		return indentEntrySeqNum;
	}


	//pavan changed method
	public int insertInvoiceData(int indentEntrySeqNum, IndentReceiveDto objIndentReceiveDto ) {

		//IndentReceiveDto objIndentReceiveDto = null;

		int result = 0;
		Calendar cal1 = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");

		String invoiceInsertionQry = "INSERT INTO INDENT_ENTRY (INDENT_ENTRY_ID, USER_ID, SITE_ID, INVOICE_ID, ENTRY_DATE, VENDOR_ID, TOTAL_AMOUNT, INDENT_TYPE, NOTE, RECEIVED_OR_ISSUED_DATE, INVOICE_DATE," +
		" TRANSPORTERNAME,EWAYBILLNO,VEHICLENO,PODATE,DC_NUMBER, STATE,PO_ID, GRN_NO,INDENT_CREATION_ID)" +
		" VALUES (?, ?, ?,?, sysdate, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?)";
		log.debug("Query for invoice insertion = "+invoiceInsertionQry);

		result = jdbcTemplate.update(invoiceInsertionQry, new Object[] {indentEntrySeqNum,
				objIndentReceiveDto.getStrUserId(), objIndentReceiveDto.getStrSiteId(), objIndentReceiveDto.getStrInvoiceNo(),
				objIndentReceiveDto.getStrVendorId(), objIndentReceiveDto.getTotalAmnt(), "IN", objIndentReceiveDto.getStrRemarks(),
				objIndentReceiveDto.getStrReceiveDate()+" "+sdf.format(cal1.getTime()), objIndentReceiveDto.getStrInoviceDate()+" "+sdf.format(cal1.getTime()),
				objIndentReceiveDto.getTransporterName(),objIndentReceiveDto.geteWayBillNo(),objIndentReceiveDto.getVehileNo(),objIndentReceiveDto.getPoDate(),
				objIndentReceiveDto.getDcNo(),objIndentReceiveDto.getState(),objIndentReceiveDto.getPoNo(),objIndentReceiveDto.getGrnNumber(),objIndentReceiveDto.getIndentNumber()
		});





		log.debug("Result = "+result);			
		logger.info("IndentReceiveDao --> insertInvoiceData() --> Result = "+result);

		return result;
	}

	public String getVendorInfo(String vendName) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbVendorList = null;		


		vendName = vendName.replace("$$", "&");

		log.debug("Vendor Name = "+vendName);

		sb = new StringBuffer();

		String vendorInfoQry = "SELECT VENDOR_ID, ADDRESS, GSIN_NUMBER FROM VENDOR_DETAILS WHERE VENDOR_NAME = ? AND STATUS='A'";
		log.debug("Query to fetch vendor info = "+vendorInfoQry);

		dbVendorList = jdbcTemplate.queryForList(vendorInfoQry, new Object[]{vendName.trim()});

		for(Map<String, Object> vendInfo : dbVendorList) {
			sb = sb.append(String.valueOf(vendInfo.get("VENDOR_ID"))+"|"+String.valueOf(vendInfo.get("ADDRESS"))+"|"+String.valueOf(vendInfo.get("GSIN_NUMBER")));
		}			
		return sb.toString();
	}


	public int insertIndentReceiveData(int indentEntrySeqNum,int intIndentEntryDetailsSeqNo, IndentReceiveDto irdto, String userId, String siteId,int intPriceListSeqNo) {

		int result = 0;	
		AuditLogDetailsBean auditBean = null;
		//String indentIssueQry = "INSERT INTO INDENT_ENTRY_DETAILS (INDENT_ENTRY_DETAILS_ID, INDENT_ENTRY_ID, PRODUCT_ID, PRODUCT_NAME, SUB_PRODUCT_ID, SUB_PRODUCT_NAME, CHILD_PRODUCT_ID, CHILD_PRODUCT_NAME, RECEVED_QTY, MEASUR_MNT_ID, MEASUR_MNT_NAME, PRICE, BASIC_AMOUNT, TAX, HSN_CODE, TAX_AMOUNT, AMOUNT_AFTER_TAX, OTHER_CHARGES, TAX_ON_OTHER_TRANSPORT_CHG, OTHER_CHARGES_AFTER_TAX, TOTAL_AMOUNT, ENTRY_DATE,EXPIRY_DATE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate,?)";
		String indentIssueQry = "INSERT INTO INDENT_ENTRY_DETAILS (INDENT_ENTRY_DETAILS_ID, INDENT_ENTRY_ID, PRODUCT_ID, PRODUCT_NAME, SUB_PRODUCT_ID, SUB_PRODUCT_NAME, CHILD_PRODUCT_ID, CHILD_PRODUCT_NAME, RECEVED_QTY, MEASUR_MNT_ID, MEASUR_MNT_NAME,  ENTRY_DATE,EXPIRY_DATE,REMARKS,PRICE_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate,?,?,?)";
		log.debug("Query for indent issue = "+indentIssueQry);

		result = jdbcTemplate.update(indentIssueQry, new Object[] { 
				intIndentEntryDetailsSeqNo,
				indentEntrySeqNum, 
				irdto.getProdId(), 
				irdto.getProdName(), 
				irdto.getSubProdId(), 
				irdto.getSubProdName(), 
				irdto.getChildProdId(), 
				irdto.getChildProdName(), 
				irdto.getQuantity(), 
				irdto.getMeasurementId(), 
				irdto.getMeasurementName(), 
				//irdto.getPrice(), 
				//irdto.getBasicAmnt(), 
				//irdto.getTax(), 
				//	irdto.getHsnCd(), 
				//	irdto.getTaxAmnt(), 
				//.getAmntAfterTax(), 
				//	irdto.getOtherOrTranportChrgs(), 
				//	irdto.getTaxOnOtherOrTranportChrgs(), 
				//	irdto.getOtherOrTransportChrgsAfterTax(), 
				//	irdto.getTotalAmnt(),
				irdto.getExpiryDate(),irdto.getStrRemarks(),intPriceListSeqNo
		}
		);

		/*auditBean = new AuditLogDetailsBean();
		auditBean.setEntryDetailsId(String.valueOf(indentEntrySeqNum));
		auditBean.setLoginId(userId);
		auditBean.setOperationName("New Recive");
		auditBean.setStatus("Info");
		auditBean.setSiteId(siteId);
		new SaveAuditLogDetails().saveAuditLogDetails(auditBean);
		log.debug("Result = "+result);
		logger.info("IndentIssueDao --> insertIndentReceiveData() --> Result = "+result);*/

		return result;
	}



	//pavan changed the query
	/*public int insertIndentReceiveData(int indentEntrySeqNum, IndentReceiveDto irdto, String userId, String siteId) {

		int result = 0;	
		AuditLogDetailsBean auditBean = null;
		//String indentIssueQry = "INSERT INTO INDENT_ENTRY_DETAILS (INDENT_ENTRY_DETAILS_ID, INDENT_ENTRY_ID, PRODUCT_ID, PRODUCT_NAME, SUB_PRODUCT_ID, SUB_PRODUCT_NAME, CHILD_PRODUCT_ID, CHILD_PRODUCT_NAME, RECEVED_QTY, MEASUR_MNT_ID, MEASUR_MNT_NAME, PRICE, BASIC_AMOUNT, TAX, HSN_CODE, TAX_AMOUNT, AMOUNT_AFTER_TAX, OTHER_CHARGES, TAX_ON_OTHER_TRANSPORT_CHG, OTHER_CHARGES_AFTER_TAX, TOTAL_AMOUNT, INVOICE_OTHER_CHG, ENTRY_DATE,PO_NUMBER,DC_NUMBER,EXPIRY_DATE,PODATE,EWAYBILLNO,VEHICLENO,TRANSPORTERNAME) VALUES (INDENT_ENTRY_DETAILS_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate,?,?,?,?, ?, ?,?)";
		String indentIssueQry = "INSERT INTO INDENT_ENTRY_DETAILS (INDENT_ENTRY_DETAILS_ID, INDENT_ENTRY_ID, PRODUCT_ID, PRODUCT_NAME, SUB_PRODUCT_ID, SUB_PRODUCT_NAME, CHILD_PRODUCT_ID, CHILD_PRODUCT_NAME, RECEVED_QTY, MEASUR_MNT_ID, MEASUR_MNT_NAME, PRICE, BASIC_AMOUNT, TAX, HSN_CODE, TAX_AMOUNT, AMOUNT_AFTER_TAX, OTHER_CHARGES, TAX_ON_OTHER_TRANSPORT_CHG, OTHER_CHARGES_AFTER_TAX, TOTAL_AMOUNT, INVOICE_OTHER_CHG, ENTRY_DATE,EXPIRY_DATE) VALUES (INDENT_ENTRY_DETAILS_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,sysdate,?)";
		log.debug("Query for indent issue = "+indentIssueQry);

		result = jdbcTemplate.update(indentIssueQry, new Object[] { 
				indentEntrySeqNum, 
				irdto.getProdId(), 
				irdto.getProdName(), 
				irdto.getSubProdId(), 
				irdto.getSubProdName(), 
				irdto.getChildProdId(), 
				irdto.getChildProdName(), 
				irdto.getQuantity(), 
				irdto.getMeasurementId(), 
				irdto.getMeasurementName(), 
				irdto.getPrice(), 
				irdto.getBasicAmnt(), 
				irdto.getTax(), 
				irdto.getHsnCd(), 
				irdto.getTaxAmnt(), 
				irdto.getAmntAfterTax(), 
				irdto.getOtherOrTranportChrgs(), 
				irdto.getTaxOnOtherOrTranportChrgs(), 
				irdto.getOtherOrTransportChrgsAfterTax(), 
				irdto.getTotalAmnt(), 
				irdto.getOtherChrgs(),
				irdto.getExpiryDate()
		}
		);

		auditBean = new AuditLogDetailsBean();
		auditBean.setEntryDetailsId(String.valueOf(indentEntrySeqNum));
		auditBean.setLoginId(userId);
		auditBean.setOperationName("New Recive");
		auditBean.setStatus("Info");
		auditBean.setSiteId(siteId);
		new SaveAuditLogDetails().saveAuditLogDetails(auditBean);
		log.debug("Result = "+result);
		logger.info("IndentIssueDao --> insertIndentReceiveData() --> Result = "+result);

		return result;
	}
	 */

	public int updateIndentAvalibility(IndentReceiveDto irdto, String siteId) {

		List<Map<String, Object>> dbProductDetailsList = null;
		int result = 0;
		String availability_Id="";
		double receive_Form_Quantity=0.0;
		double quantity=0.0;
		
		String query="SELECT PRODUT_QTY,INDENT_AVAILABILITY_ID FROM INDENT_AVAILABILITY WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID=? AND CHILD_PRODUCT_ID=? AND MESURMENT_ID= ? AND SITE_ID=?  ";
		
		dbProductDetailsList = jdbcTemplate.queryForList(query, new Object[] {

				irdto.getProdId(), 
				irdto.getSubProdId(), 
				irdto.getChildProdId(), 
				irdto.getMeasurementId(), 
				siteId
		});
		
		if (null != dbProductDetailsList && dbProductDetailsList.size() > 0) {
			for (Map<String, Object> prods : dbProductDetailsList) {
				quantity = Double.parseDouble(prods.get("PRODUT_QTY") == null ? "0" : prods.get("PRODUT_QTY").toString());
				availability_Id = (prods.get("INDENT_AVAILABILITY_ID") == null ? "" : prods.get("INDENT_AVAILABILITY_ID").toString());
			}
		}
		
		receive_Form_Quantity=Double.parseDouble(irdto.getQuantity());
		quantity=quantity+receive_Form_Quantity;


		String updateIndentAvalibilityQry = "UPDATE INDENT_AVAILABILITY SET PRODUT_QTY ='"+quantity+"' WHERE INDENT_AVAILABILITY_ID ='"+availability_Id+"'";
		log.debug("Query for update indent avalibility = "+updateIndentAvalibilityQry);

		result = jdbcTemplate.update(updateIndentAvalibilityQry, new Object[] {});
		log.debug("Result = "+result);
		logger.info("IndentReceiveDao --> updateIndentAvalibility() --> Result = "+result);
		return result;
	}

	public void updateIndentAvalibilityWithNewIndent(IndentReceiveDto irdto, String siteId) {

		int result = 0;		

		String requesterQry = "INSERT INTO INDENT_AVAILABILITY (INDENT_AVAILABILITY_ID, PRODUCT_ID, SUB_PRODUCT_ID, CHILD_PRODUCT_ID, PRODUT_QTY, MESURMENT_ID, SITE_ID) VALUES (INDENT_AVAILABILITY_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?)";
		log.debug("Query for new indent entry in indent availability = "+requesterQry);

		result = jdbcTemplate.update(requesterQry, new Object[] {
				irdto.getProdId(), 
				irdto.getSubProdId(), 
				irdto.getChildProdId(), 
				irdto.getQuantity(), 
				irdto.getMeasurementId(), 
				siteId
		}
		);
		log.debug("Result = "+result);			
		logger.info("IndentReceiveDao --> updateIndentAvalibilityWithNewIndent() --> Result = "+result);
	}

	@Override
	public String getProductAvailability(String prodId, String subProductId, String childProdId, String measurementId, String siteId) {

		List<Map<String, Object>> dbProductAvailabilityList = null;		

		log.debug("Product Id = "+prodId+", Sub Product Id = "+subProductId+", Child Product Id = "+childProdId+", Measurement Id = "+measurementId+" and Site Id = "+siteId);

		String indentAvaQry = "SELECT PRODUT_QTY FROM INDENT_AVAILABILITY WHERE PRODUCT_ID = ? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID = ? AND MESURMENT_ID = ? AND SITE_ID = ?";
		log.debug("Query to fetch product availability = "+indentAvaQry);

		dbProductAvailabilityList = jdbcTemplate.queryForList(indentAvaQry, new Object[] {
				prodId,
				subProductId,
				childProdId,
				measurementId,
				siteId
		}
		);

		String qty = "";
		for(Map<String, Object> availableQuantity : dbProductAvailabilityList) {
			String measurementName = getMeasurementName(measurementId);
			qty = String.valueOf(availableQuantity.get("PRODUT_QTY")+" "+measurementName);
			break;
		}
		return qty;
	}

	public String getMeasurementName(String measurementId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbMeasurementList = null;

		log.debug("Measurement Id = "+measurementId);

		sb = new StringBuffer();

		String measurementQry = "SELECT NAME FROM MEASUREMENT WHERE MEASUREMENT_ID = ?";
		log.debug("Query to fetch measurement name = "+measurementQry);

		dbMeasurementList = jdbcTemplate.queryForList(measurementQry, new Object[]{measurementId});

		for(Map<String, Object> subProds : dbMeasurementList) {
			sb = sb.append(String.valueOf(subProds.get("NAME")));
			break;
		}
		return sb.toString();
	}

	// written by Madhu on 27-July-2017 start
	@Override
	public void saveReciveDetailsIntoSumduraPriceList(IndentReceiveDto irdto,
			String invoiceNumber, String siteId, String id,int entryDetailssequenceId,int intPriceListSeqNo,String typeOfPurchase) {
		String query = "";
		Double perPiceAmt = 0.0;
		Double totalAmt = 0.0;
		Double quantity = 0.0;
		//String entryDetailssequenceId = getEntryDetailsSequenceNumber();


		totalAmt = Double.valueOf(irdto.getTotalAmnt());
		quantity = Double.valueOf(irdto.getQuantity());
		//perPiceAmt = Double.valueOf(totalAmt/quantity);

		if(quantity > 0){
			perPiceAmt = Double.valueOf(totalAmt/quantity);
		}else{
			perPiceAmt = 0.0;
		}
		query = "INSERT INTO SUMADHURA_PRICE_LIST(PRICE_ID, INVOICE_NUMBER, PRODUCT_ID, SUB_PRODUCT_ID, CHILD_PRODUCT_ID, INDENT_AVAILABILITY_ID, STATUS, AVAILABLE_QUANTITY, AMOUNT_PER_UNIT_AFTER_TAXES, SITE_ID, UNITS_OF_MEASUREMENT,INDENT_ENTRY_DETAILS_ID,CREATED_DATE"
			+ "   , AMOUNT_PER_UNIT_BEFORE_TAXES, BASIC_AMOUNT, TAX, TAX_AMOUNT, AMOUNT_AFTER_TAX, OTHER_CHARGES, TAX_ON_OTHER_TRANSPORT_CHG, OTHER_CHARGES_AFTER_TAX, TOTAL_AMOUNT,HSN_CODE,RECEVED_QTY,TYPE_OF_PURCHASE) VALUES"
			+ "    (?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?,?)";
		log.debug("   Query for save recive details into sumadhura price list table " + query);

		jdbcTemplate.update(query, new Object[] {intPriceListSeqNo,invoiceNumber, irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(),id , "A", 
				irdto.getQuantity(), perPiceAmt, siteId, irdto.getMeasurementId(),entryDetailssequenceId, irdto.getDate(),
				irdto.getPrice(),  irdto.getBasicAmnt(),  irdto.getTax(),  irdto.getTaxAmnt(),  irdto.getAmntAfterTax(), 
				irdto.getOtherOrTranportChrgs(),  irdto.getTaxOnOtherOrTranportChrgs(),  irdto.getOtherOrTransportChrgsAfterTax(), 
				irdto.getTotalAmnt(),irdto.getHsnCd(),irdto.getQuantity(),typeOfPurchase


		});


	}

	public int getIndentEntryDtails_SeqNumber(){
		int intIndentEntryDetailsSeqNo = getEntryDetailsSequenceNumber();
		return intIndentEntryDetailsSeqNo;
	}

	public int getPriceList_SeqNumber(){

		String query = "select SUMADHU_PRICE_LIST.NEXTVAL from dual";

		return jdbcTemplate.queryForInt(query);
		//return getPriceList_SeqNumber;
	}

	@Override
	public String getIndentAvailableId(IndentReceiveDto irdto, String site_id) {

		String query = "SELECT INDENT_AVAILABILITY_ID FROM INDENT_AVAILABILITY WHERE PRODUCT_ID = ? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID = ? AND MESURMENT_ID = ? AND SITE_ID = ? ";
		return String.valueOf(jdbcTemplate.queryForInt(query, new Object[] {
				irdto.getProdId(), 
				irdto.getSubProdId(), 
				irdto.getChildProdId(), 
				irdto.getMeasurementId(), 
				site_id}));

	}

	@Override
	public String getProductAvailabilitySequenceNumber() {

		String query = "SELECT INDENT_AVAILABILITY_SEQ.NEXTVAL FROM DUAL";
		return String.valueOf(jdbcTemplate.queryForInt(query));
	}
	@Override
	public int getEntryDetailsSequenceNumber() {

		//String query = "SELECT MAX(INDENT_ENTRY_DETAILS_ID) FROM INDENT_ENTRY_DETAILS";
		String query = "select INDENT_ENTRY_DETAILS_SEQ.NEXTVAL from dual";

		return jdbcTemplate.queryForInt(query);
	}
	// written by Madhu on 27-July-2017 end	


	@Override
	public String getindentEntrySerialNo() {

		int indentEntrySeqNum = 0;

		String fianlVal = "";
		indentEntrySeqNum = jdbcTemplate.queryForInt("SELECT SerialNo_ID_SEQ.NEXTVAL FROM DUAL");

		DateFormat df = new SimpleDateFormat("yy"); // Just the year, with 2 digits
		String formattedDate = df.format(Calendar.getInstance().getTime());

		int i = Integer.parseInt(formattedDate);
		if (indentEntrySeqNum >9) {
			fianlVal = "/"+indentEntrySeqNum+"/"+formattedDate+"-"+(i+1);
		} else {
			fianlVal = "/0"+indentEntrySeqNum+"/"+formattedDate+"-"+(i+1);
		}

		logger.info(fianlVal);

		return fianlVal;
	}

	public static <K, V> Map<K, V> printMap(Map<K, V> map) {
		Map<K, V> mapObje = new TreeMap<K, V>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			mapObje.put( entry.getKey(), entry.getValue());

		}

		return mapObje;
	}


	// 11-AUG MADHU START
	@Override
	public void saveReciveDetailsIntoSumadhuraCloseBalance(IndentReceiveDto irdto, String siteId) {

		String query = "";
		Double quantity = 0.0;
		Double totalAmt = 0.0;
		List<Map<String, Object>> dbClosingBalancesList = null;
		query = "SELECT CLOSING_BALANCE_ID,QUANTITY, PRICE, TOTAL_AMOUNT FROM SUMADHURA_CLOSING_BALANCE WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) = TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')";
		dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});
		if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {
			query = "";
			query = "UPDATE SUMADHURA_CLOSING_BALANCE SET QUANTITY= QUANTITY + '"+irdto.getQuantity().trim()+"', TOTAL_AMOUNT=TOTAL_AMOUNT+'"+irdto.getTotalAmnt().trim()+"'WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) >= TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')";
			jdbcTemplate.update(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});

		} else {
			query = "";
			query = "SELECT CLOSING_BALANCE_ID,QUANTITY, PRICE, TOTAL_AMOUNT FROM SUMADHURA_CLOSING_BALANCE WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) <= TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')  AND ROWNUM <= 1 ORDER BY DATE_AND_TIME  DESC";
			dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});
			if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {
				for (Map<String, Object> prods : dbClosingBalancesList) {

					quantity = Double.parseDouble(prods.get("QUANTITY") == null ? "" : prods.get("QUANTITY").toString());
					totalAmt = Double.parseDouble(prods.get("TOTAL_AMOUNT") == null ? "" : prods.get("TOTAL_AMOUNT").toString());
				}
			}

			query = "";
			query = "INSERT INTO SUMADHURA_CLOSING_BALANCE(CLOSING_BALANCE_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,QUANTITY,SITE,PRICE,TOTAL_AMOUNT,DATE_AND_TIME,MEASUREMENT_ID)VALUES(SUMADHURA_CLOSING_BALANCE_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?)";
			jdbcTemplate.update(query,new Object[] {irdto.getProdId(),irdto.getSubProdId(), irdto.getChildProdId(),quantity + Double.parseDouble(irdto.getQuantity()),siteId, irdto.getAmntAfterTax(),Double.parseDouble(irdto.getTotalAmnt())+totalAmt,irdto.getDate(), irdto.getMeasurementId()});
			query = "";
			query = "UPDATE SUMADHURA_CLOSING_BALANCE SET QUANTITY= QUANTITY + '"+irdto.getQuantity().trim()+"', TOTAL_AMOUNT=TOTAL_AMOUNT+'"+irdto.getTotalAmnt().trim()+"'WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) > TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')";
			jdbcTemplate.update(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});

		} 

	}

	@Override
	public void saveReceivedDataIntoSumadhuClosingBalByProduct(IndentReceiveDto irdto, String siteId) {
		String query = "";
		Double quantity = 0.0;
		Double totalAmt = 0.0;
		List<Map<String, Object>> dbClosingBalancesList = null;


		Date today = new Date();                   
		@SuppressWarnings("deprecation")
		Date myDate = new Date(irdto.getDate()+" 23:59:59");


		if (today.compareTo(myDate)>0) {

			query = "SELECT CLOSING_BAL_BY_PRODUCT_ID,QUANTITY, TOTAL_AMOUNT FROM SUMADHU_CLOSING_BAL_BY_PRODUCT WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) = TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')";
			dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});

			if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {
				query = "";
				query = "UPDATE SUMADHU_CLOSING_BAL_BY_PRODUCT SET QUANTITY= QUANTITY + '"+irdto.getQuantity().trim()+"', TOTAL_AMOUNT=TOTAL_AMOUNT+'"+irdto.getTotalAmnt().trim()+"'WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) >= TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')";
				jdbcTemplate.update(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});

			} else {
				query = "";
				String dateTime = "";
				query = "SELECT DATE_AND_TIME, CLOSING_BAL_BY_PRODUCT_ID,QUANTITY, TOTAL_AMOUNT FROM SUMADHU_CLOSING_BAL_BY_PRODUCT WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) <= TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')  AND ROWNUM <= 1 ORDER BY DATE_AND_TIME  DESC";
				dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});
				if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {
					for (Map<String, Object> prods : dbClosingBalancesList) {
						//dateTime = prods.get("DATE_AND_TIME") == null ? "" : prods.get("DATE_AND_TIME").toString();
						quantity = Double.parseDouble(prods.get("QUANTITY") == null ? "" : prods.get("QUANTITY").toString());
						totalAmt = Double.parseDouble(prods.get("TOTAL_AMOUNT") == null ? "" : prods.get("TOTAL_AMOUNT").toString());
					}
				}

				query = "";
				query = "INSERT INTO SUMADHU_CLOSING_BAL_BY_PRODUCT(CLOSING_BAL_BY_PRODUCT_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,QUANTITY,SITE_ID,TOTAL_AMOUNT,DATE_AND_TIME,MEASUREMENT_ID)VALUES(SUMA_CLOSING_BAL_BY_PRODUCT.NEXTVAL,?,?,?,?,?,?,?,?)";
				jdbcTemplate.update(query,new Object[] {irdto.getProdId(),irdto.getSubProdId(), irdto.getChildProdId(),quantity + Double.parseDouble(irdto.getQuantity()),siteId,Double.parseDouble(irdto.getTotalAmnt())+totalAmt,irdto.getDate(), irdto.getMeasurementId()});
				query = "";

				query = "SELECT TO_CHAR(TRUNC(DATE_AND_TIME)) AS DATE_AND_TIME FROM SUMADHU_CLOSING_BAL_BY_PRODUCT WHERE TRUNC(DATE_AND_TIME) > TO_DATE('"+irdto.getDate()+"','dd-MM-yy') AND PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ? AND ROWNUM <= 1";
				dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});

				Date curDate = null;
				Date curDate1 = null;
				Calendar c = Calendar.getInstance(); 
				if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {
					for (Map<String, Object> prods : dbClosingBalancesList) {
						dateTime = prods.get("DATE_AND_TIME") == null ? "" : prods.get("DATE_AND_TIME").toString();
						curDate = new Date(dateTime+" 23:59:59");
						curDate1 = new Date(irdto.getDate()+" 23:59:59");


						long diff = curDate.getTime() - curDate1.getTime();
						Long ii = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
						int k = ii.intValue();
						for (int h=1; h<=k-1; h++) {

							c.setTime(myDate); 
							c.add(Calendar.DATE, h);
							Date yourDate1 = c.getTime();
							query = "INSERT INTO SUMADHU_CLOSING_BAL_BY_PRODUCT(CLOSING_BAL_BY_PRODUCT_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,QUANTITY,SITE_ID,TOTAL_AMOUNT,DATE_AND_TIME,MEASUREMENT_ID)VALUES(SUMA_CLOSING_BAL_BY_PRODUCT.NEXTVAL,?,?,?,?,?,?,?,?)";
							jdbcTemplate.update(query,new Object[] {irdto.getProdId(),irdto.getSubProdId(), irdto.getChildProdId(),quantity, siteId,totalAmt,yourDate1, irdto.getMeasurementId()});

						}
					}
				} else {
					curDate1 = new Date(irdto.getDate()+" 23:59:59");

					curDate = new Date();
					long diff = curDate.getTime() - curDate1.getTime();
					Long ii = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
					int k = ii.intValue();
					for (int h=1; h<=k; h++) {

						c.setTime(myDate); 
						c.add(Calendar.DATE, h);
						Date yourDate1 = c.getTime();
						query = "INSERT INTO SUMADHU_CLOSING_BAL_BY_PRODUCT(CLOSING_BAL_BY_PRODUCT_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,QUANTITY,SITE_ID,TOTAL_AMOUNT,DATE_AND_TIME,MEASUREMENT_ID)VALUES(SUMA_CLOSING_BAL_BY_PRODUCT.NEXTVAL,?,?,?,?,?,?,?,?)";
						jdbcTemplate.update(query,new Object[] {irdto.getProdId(),irdto.getSubProdId(), irdto.getChildProdId(),quantity ,siteId,totalAmt,yourDate1, irdto.getMeasurementId()});
					}
				}
				query="";
				query = "UPDATE SUMADHU_CLOSING_BAL_BY_PRODUCT SET QUANTITY= QUANTITY + '"+irdto.getQuantity().trim()+"', TOTAL_AMOUNT=TOTAL_AMOUNT+'"+irdto.getTotalAmnt().trim()+"' WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) > TO_DATE('"+irdto.getDate()+"', 'dd-MM-yy')";
				jdbcTemplate.update(query, new Object[] {irdto.getProdId(), irdto.getSubProdId(), irdto.getChildProdId(), siteId,  irdto.getMeasurementId()});
			}
		}

	}
	// 11-AUG MADHU END



	@Override
	public void saveTransactionDetails(String invoiceNum, String transactionId, String gstId,
			String gstAmount, String totAmtAfterGSTTax,
			String transactionInvoiceId, String transAmount, String siteId, String indentEntrySeqNum) {

		String query = "INSERT INTO SUMADHURA_TRNS_OTHR_CHRGS_DTLS(ID, TRANSPORT_ID, TRANSPORT_GST_PERCENTAGE, TRANSPORT_GST_AMOUNT, TOTAL_AMOUNT_AFTER_GST_TAX, TRANSPORT_INVOICE_ID, INDENT_ENTRY_INVOICE_ID, DATE_AND_TIME, TRANSPORT_AMOUNT, SITE_ID, INDENT_ENTRY_ID) VALUES(TRANS_SEQ_ID.NEXTVAL,?,?,?,?,?,?,SYSDATE,?,?,?)";
		jdbcTemplate.update(query, new Object[] {transactionId, gstId, gstAmount, totAmtAfterGSTTax, transactionInvoiceId,invoiceNum, transAmount,siteId, indentEntrySeqNum});

	}



	public int getInvoiceCount(String  strInvoiceNmber, String vendorId,String strReceiveStartDate, String receiveDate){
		String query  = "select count(1) from  INDENT_ENTRY where INVOICE_ID = ? and VENDOR_ID = ? and TRUNC(RECEIVED_OR_ISSUED_DATE,'yy') = TRUNC(to_date(?,'dd-MM-yy'),'yy')";
		int intCount =    jdbcTemplate.queryForInt(query, new Object[] {strInvoiceNmber, vendorId, receiveDate});
		return intCount;
	}

	// 11-AUG MADHU END

	public int getInvoiceSaveCount(String  strInvoiceNmber, String vendorId,String receiveDate){

		int intCount =  0;
		try{

			String query  = "select INDENT_ENTRY_ID from  INDENT_ENTRY where INVOICE_ID = ? and VENDOR_ID = ? and TRUNC(RECEIVED_OR_ISSUED_DATE) = to_date(?,'dd-MM-yy')";
			intCount =    jdbcTemplate.queryForInt(query, new Object[] {strInvoiceNmber, vendorId, receiveDate});
		}catch(Exception e){
			intCount = 0;
			e.printStackTrace();
		}

		return intCount;
	}


	@Override
	public List<ViewIndentIssueDetailsBean> getSiteWiseInvoiceDetails(String fromDate, String toDate, String siteId) {

		String query = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		String total="";
		List<Map<String, Object>> dbIndentDts = null;
		List<ViewIndentIssueDetailsBean> list = new ArrayList<ViewIndentIssueDetailsBean>();
		ViewIndentIssueDetailsBean indentObj = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			if(siteId.equals("All")){

				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = "SELECT  IE.INVOICE_ID, min(IE.INDENT_ENTRY_ID) as INDENT_ENTRY_ID,min(S.SITE_NAME) as SITE_NAME, min(S.SITE_ID) as SITE_ID,min(IE.RECEIVED_OR_ISSUED_DATE) as RECEVED_DATE,min(IE.INVOICE_DATE) as INVOICE_DATE, min(VD.VENDOR_NAME) as VENDOR_NAME,min(VD.VENDOR_ID) as VENDOR_ID,min(IE.PO_ID) as PO_ID,min(IE.PODATE) as PODATE FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED,  VENDOR_DETAILS VD,SITE S WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN'   AND IE.VENDOR_ID=VD.VENDOR_ID AND S.SITE_ID = IE.SITE_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy') group by IE.INVOICE_ID,IE.VENDOR_ID,IE.SITE_ID,TRUNC( IE.INVOICE_DATE,'yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = "SELECT  IE.INVOICE_ID,min(IE.INDENT_ENTRY_ID) as INDENT_ENTRY_ID,min(S.SITE_NAME) as SITE_NAME,min(S.SITE_ID) as SITE_ID,min(IE.RECEIVED_OR_ISSUED_DATE) as RECEVED_DATE, min(IE.INVOICE_DATE) as INVOICE_DATE, min(VD.VENDOR_NAME) as VENDOR_NAME,min(VD.VENDOR_ID) as VENDOR_ID,min(IE.PO_ID) as PO_ID,min(IE.PODATE) as PODATE FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED,  VENDOR_DETAILS VD , SITE S WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN'  AND IE.VENDOR_ID=VD.VENDOR_ID AND AND S.SITE_ID = IE.SITE_ID TRUNC(IE.RECEIVED_OR_ISSUED_DATE) =TO_DATE('"+fromDate+"', 'dd-MM-yy') group by IE.INVOICE_ID,IE.VENDOR_ID,IE.SITE_ID,TRUNC( IE.INVOICE_DATE,'yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = "SELECT  IE.INVOICE_ID,min(IE.INDENT_ENTRY_ID) as INDENT_ENTRY_ID,min(S.SITE_NAME) as SITE_NAME,min(S.SITE_ID) as SITE_ID,min(IE.RECEIVED_OR_ISSUED_DATE) as RECEVED_DATE, min(IE.INVOICE_DATE) as INVOICE_DATE, min(VD.VENDOR_NAME) as VENDOR_NAME,min(VD.VENDOR_ID) as VENDOR_ID,min(IE.PO_ID) as PO_ID,min(IE.PODATE) as PODATE FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED,  VENDOR_DETAILS VD ,SITE S WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN'  AND IE.VENDOR_ID=VD.VENDOR_ID AND S.SITE_ID = IE.SITE_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) =TO_DATE('"+toDate+"', 'dd-MM-yy') group by IE.INVOICE_ID,IE.VENDOR_ID,IE.SITE_ID,TRUNC( IE.INVOICE_DATE,'yy')";
				}


			}else{
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = "SELECT  IE.INVOICE_ID,min(IE.INDENT_ENTRY_ID) as INDENT_ENTRY_ID,min(S.SITE_NAME) as SITE_NAME, min(S.SITE_ID) as SITE_ID,min(IE.RECEIVED_OR_ISSUED_DATE) as RECEVED_DATE,min(IE.INVOICE_DATE) as INVOICE_DATE, min(VD.VENDOR_NAME) as VENDOR_NAME,min(VD.VENDOR_ID) as VENDOR_ID,min(IE.PO_ID) as PO_ID,min(IE.PODATE) as PODATE FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED,  VENDOR_DETAILS VD,SITE S WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"'  AND IE.VENDOR_ID=VD.VENDOR_ID AND S.SITE_ID = IE.SITE_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy') group by IE.INVOICE_ID,IE.VENDOR_ID,IE.SITE_ID,TRUNC( IE.INVOICE_DATE,'yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = "SELECT  IE.INVOICE_ID,min(IE.INDENT_ENTRY_ID) as INDENT_ENTRY_ID,min(S.SITE_NAME) as SITE_NAME,min(S.SITE_ID) as SITE_ID,min(IE.RECEIVED_OR_ISSUED_DATE) as RECEVED_DATE, min(IE.INVOICE_DATE) as INVOICE_DATE, min(VD.VENDOR_NAME) as VENDOR_NAME,min(VD.VENDOR_ID) as VENDOR_ID,min(IE.PO_ID) as PO_ID,min(IE.PODATE) as PODATE FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED,  VENDOR_DETAILS VD,SITE S WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID AND S.SITE_ID = IE.SITE_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) =TO_DATE('"+fromDate+"', 'dd-MM-yy') group by IE.INVOICE_ID,IE.VENDOR_ID,IE.SITE_ID,TRUNC( IE.INVOICE_DATE,'yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = "SELECT  IE.INVOICE_ID,min(IE.INDENT_ENTRY_ID) as INDENT_ENTRY_ID,min(S.SITE_NAME) as SITE_NAME,min(S.SITE_ID) as SITE_ID,min(IE.RECEIVED_OR_ISSUED_DATE) as RECEVED_DATE, min(IE.INVOICE_DATE) as INVOICE_DATE, min(VD.VENDOR_NAME) as VENDOR_NAME,min(VD.VENDOR_ID) as VENDOR_ID,min(IE.PO_ID) as PO_ID,min(IE.PODATE) as PODATE FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED,  VENDOR_DETAILS VD,SITE S WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID AND S.SITE_ID = IE.SITE_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) =TO_DATE('"+toDate+"', 'dd-MM-yy') group by IE.INVOICE_ID,IE.VENDOR_ID,IE.SITE_ID,TRUNC( IE.INVOICE_DATE,'yy')";
				}
			}



			dbIndentDts = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			for(Map<String, Object> prods : dbIndentDts) {
				serialNo++;
				indentObj = new ViewIndentIssueDetailsBean();
				indentObj.setSerialNo(serialNo);
				indentObj.setRequesterId(prods.get("INVOICE_ID")==null ? "" : prods.get("INVOICE_ID").toString());
				String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
				indentObj.setVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
				indentObj.setVendorId(prods.get("VENDOR_ID")==null ? "" : prods.get("VENDOR_ID").toString());
				String receviedDate=prods.get("RECEVED_DATE")==null ? "" : prods.get("RECEVED_DATE").toString();
				String poDate = prods.get("PODATE")==null ? "" : prods.get("PODATE").toString();
				String strIndentEntryId = prods.get("INDENT_ENTRY_ID")==null ? "" : prods.get("INDENT_ENTRY_ID").toString();
				String strSiteId = prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString();



				SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				//String convertreceive_date = "";
				String convertreceive_time = "";
				//	String convertinvoice_date = "";
				try{

					
					
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");


					if(!poDate.equals("")){

						Date po_date = dt.parse(poDate);
						poDate = dt1.format(po_date);
					}
					if(!invoicedate.equals("")){
						Date invoice_date = dt.parse(invoicedate);
						invoicedate = dt1.format(invoice_date);
						}
					if(!receviedDate.equals("")){
						Date receive_date = dt.parse(receviedDate);
						receviedDate = dt1.format(receive_date);
						convertreceive_time = time1.format(receive_date);
					}
					// System.out.println("Time: " + time1.format(receviedDate));
					
					
				}catch(Exception e){
					e.printStackTrace();
				}
				//System.out.println("the date is "+date2);
				indentObj.setIndentEntryId(strIndentEntryId);
				indentObj.setStrInvoiceDate(invoicedate);
				indentObj.setDate(receviedDate);
				indentObj.setTime(convertreceive_time);
				indentObj.setPoDate(poDate);
				indentObj.setSiteId(strSiteId);
				indentObj.setSiteName(prods.get("SITE_NAME")==null ? "" : prods.get("SITE_NAME").toString());
				indentObj.setPoNo(prods.get("PO_ID")==null ? "" : prods.get("PO_ID").toString());


				String date=prods.get("RECEVED_DATE")==null ? "" : prods.get("RECEVED_DATE").toString();
				if (StringUtils.isNotBlank(date)) {
					date = DateUtil.dateConversion(date);
				} else {
					date = "";
				}
				indentObj.setReceivedDate(date);
				String strInvoiceNo = prods.get("INVOICE_ID") == null ? "" : prods.get("INVOICE_ID").toString();
				String vendorId = prods.get("VENDOR_ID") == null ? "" : prods.get("VENDOR_ID").toString();
				String invoiceDate = prods.get("INVOICE_DATE") == null ? "" : prods.get("INVOICE_DATE").toString();
				if(!invoicedate.equals("")){
					invoiceDate = DateUtil.dateConversion(invoiceDate);
				}
				//System.out.println("invoiceDate: "+invoiceDate);
				String query1 = "select sum(TOTAL_AMOUNT) as SUM_TOTAL_AMOUNT from INDENT_ENTRY where INVOICE_ID = ? AND VENDOR_ID = ?  "+ " AND trunc(INVOICE_DATE,'yy') = trunc(TO_DATE( ? ,'dd-MM-yy'),'yy')";
				List<Map<String, Object>> dbIndentDts1 = null;
			//	System.out.println("invoice No : ---> " + strInvoiceNo);
				dbIndentDts1 = template.queryForList(query1, new Object[]{ strInvoiceNo,vendorId,invoiceDate});

				for(Map<String, Object> prods1 : dbIndentDts1) {
					total = prods1.get("SUM_TOTAL_AMOUNT")==null ? "" : prods1.get("SUM_TOTAL_AMOUNT").toString();

					double converttotal=0.0;
					try {
						converttotal = Double.parseDouble(total);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
					String totalamt = numberFormat.format(converttotal);

					//	System.out.println("the amount"+numberAsString);
					//	String numberAsString = String.format("%d", strInvoiceNo);
					//	System.out.println("the amount after"+numberAsString);
					indentObj.setStrTotalAmount(totalamt);
				}
				list.add(indentObj);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			log.debug("Exception = "+ex.getMessage());
			logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;
	}


	@Override
	public List<Map<String, Object>> getListOfActivePOs(String site_id){

		List<Map<String, Object>> poList = null;
		String sql="select SPE.PO_NUMBER,VD.VENDOR_NAME,SPE.INDENT_NO,SIC.SITEWISE_INDENT_NO,S.SITE_NAME,SPE.PO_DATE,SPE.SITE_ID "
			+ " from SUMADHURA_PO_ENTRY SPE,VENDOR_DETAILS VD,SITE S,SUMADHURA_INDENT_CREATION SIC "
			+ " where SPE.VENDOR_ID = VD.VENDOR_ID AND SPE.SITE_ID = S.SITE_ID AND SPE.PO_STATUS = 'A'"
			+ " and SIC.INDENT_CREATION_ID = SPE.INDENT_NO"
			+ " and SPE.SITE_ID = '"+site_id+"'";

		poList = jdbcTemplate.queryForList(sql, new Object[] {});
		return poList;

	}

	@Override
	public List<ProductDetails> getPODetails(String poNumber, String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<ProductDetails> list = new ArrayList<ProductDetails>(); 
		List<Map<String, Object>> dbPODts = null;
		try{
		String query = "select VD.VENDOR_ID,VD.VENDOR_NAME,VD.GSIN_NUMBER,VD.ADDRESS,SPE.INDENT_NO,SIC.SITEWISE_INDENT_NO,SPE.PO_DATE,S.SITE_ID,S.SITE_NAME,SIC.CREATE_DATE "
			+ " from SUMADHURA_PO_ENTRY SPE,VENDOR_DETAILS VD,SITE S,SUMADHURA_INDENT_CREATION SIC "
			+ " where SPE.VENDOR_ID = VD.VENDOR_ID AND SPE.SITE_ID = S.SITE_ID "
			+ " AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' and SIC.INDENT_CREATION_ID = SPE.INDENT_NO";
		dbPODts = template.queryForList(query, new Object[]{});

		for(Map<String, Object> prods : dbPODts) {
			ProductDetails pd = new ProductDetails();
			pd.setVendorId(prods.get("VENDOR_ID") == null ? "" : prods.get("VENDOR_ID").toString());
			pd.setVendorName(prods.get("VENDOR_NAME") == null ? "" : prods.get("VENDOR_NAME").toString());
			pd.setStrGSTINNumber(prods.get("GSIN_NUMBER") == null ? "" : prods.get("GSIN_NUMBER").toString());
			pd.setVendorAddress(prods.get("ADDRESS") == null ? "" : prods.get("ADDRESS").toString());
			pd.setIndentNo(prods.get("INDENT_NO") == null ? "" : prods.get("INDENT_NO").toString());
			pd.setSiteWiseIndentNo(prods.get("SITEWISE_INDENT_NO") == null ? "0" : prods.get("SITEWISE_INDENT_NO").toString());
			pd.setSite_Id(prods.get("SITE_ID") == null ? "" : prods.get("SITE_ID").toString());
			pd.setSiteName(prods.get("SITE_NAME") == null ? "" : prods.get("SITE_NAME").toString());
			String poDate = prods.get("PO_DATE") == null ? "" : prods.get("PO_DATE").toString();
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			
			String strCreateDate = prods.get("CREATE_DATE") == null ? "0000-00-00 00:00:00.000" : prods.get("CREATE_DATE").toString();
			
			Date createDate = null;
			createDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(strCreateDate);
			strCreateDate = new SimpleDateFormat("dd-MM-yyyy").format(createDate);
			pd.setStrCreateDate(strCreateDate);
			Date date = null;
			try {
				date = format.parse(poDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			poDate = new SimpleDateFormat("dd-MMM-yy").format(date);
			pd.setPoDate(poDate);
			list.add(pd);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}



	@Override
	public List<ProductDetails> getProductDetailsLists(String poNumber,String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<ProductDetails> list = new ArrayList<ProductDetails>(); 
		List<Map<String, Object>> dbPODts = null;
		double doublePOTotalAmount = 0;
		double doubleTotalAmount = 0;

		/*String query = "SELECT P.PRODUCT_ID,SP.SUB_PRODUCT_ID,CP.CHILD_PRODUCT_ID,MST.MEASUREMENT_ID,"
			+ " P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,"
			+ " SPED.PO_QTY,SPED.PRICE,SPED.BASIC_AMOUNT,"
			+ " SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,SPED.HSN_CODE,SPED.TAX,SPED.TAX_AMOUNT,"
			+ " SPED.AMOUNT_AFTER_TAX,SPED.OTHER_CHARGES,SPED.TAX_ON_OTHER_TRANSPORT_CHG,"
			+ " SPED.OTHER_CHARGES_AFTER_TAX,SPED.TOTAL_AMOUNT,SPED.INDENT_CREATION_DTLS_ID,SPED.PO_ENTRY_DETAILS_ID"
			+ " FROM SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE,"
			+ " PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST WHERE SPED.PRODUCT_ID = P.PRODUCT_ID "
			+ " AND SPED.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID AND "
			+ " SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID AND "
			+ " SPED.MEASUR_MNT_ID = MST.MEASUREMENT_ID AND"
			+ " SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"'";
		dbPODts = template.queryForList(query, new Object[]{});*/
		
		String query = "SELECT P.PRODUCT_ID,SP.SUB_PRODUCT_ID,CP.CHILD_PRODUCT_ID,MST.MEASUREMENT_ID,"
		+ " P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,"
		+ " SPED.PO_QTY,SPED.PRICE,SPED.BASIC_AMOUNT,SPED.VENDOR_PRODUCT_DESC,"
		+ " SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,SPED.HSN_CODE,SPED.TAX,SPED.TAX_AMOUNT,"
		+ " SPED.AMOUNT_AFTER_TAX,SPED.OTHER_CHARGES,SPED.TAX_ON_OTHER_TRANSPORT_CHG,"
		+ " SPED.OTHER_CHARGES_AFTER_TAX,SPED.TOTAL_AMOUNT,SPED.INDENT_CREATION_DTLS_ID," +
		   "SPED.PO_ENTRY_DETAILS_ID,TAX_PERCENTAGE "
		+ " FROM SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE,"
		+ " PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST,INDENT_GST INGST WHERE SPED.PRODUCT_ID = P.PRODUCT_ID "
		+ " AND SPED.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID AND "
		+ " SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID AND "
		+ " SPED.MEASUR_MNT_ID = MST.MEASUREMENT_ID AND  INGST.TAX_ID = SPED.TAX and"
		+ " SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' order by SPED.INDENT_CREATION_DTLS_ID " ;
		//+ "AND PO_STATUS = 'A'";
	
		
		int serialno = 0;
		dbPODts = template.queryForList(query, new Object[]{});
		
		for(Map<String, Object> prods : dbPODts) {
			ProductDetails pd = new ProductDetails();
			serialno++;
			pd.setSerialno(serialno);
			pd.setProductId(prods.get("PRODUCT_ID") == null ? "" : prods.get("PRODUCT_ID").toString());
			pd.setSub_ProductId(prods.get("SUB_PRODUCT_ID") == null ? "" : prods.get("SUB_PRODUCT_ID").toString());
			pd.setChild_ProductId(prods.get("CHILD_PRODUCT_ID") == null ? "" : prods.get("CHILD_PRODUCT_ID").toString());
			pd.setMeasurementId(prods.get("MEASUREMENT_ID") == null ? "" : prods.get("MEASUREMENT_ID").toString());
			pd.setProductName(prods.get("PRODUCT_NAME") == null ? "" : prods.get("PRODUCT_NAME").toString());
			pd.setSub_ProductName(prods.get("SUB_PRODUCT_NAME") == null ? "" : prods.get("SUB_PRODUCT_NAME").toString());
			pd.setChild_ProductName(prods.get("CHILD_PRODUCT_NAME") == null ? "" : prods.get("CHILD_PRODUCT_NAME").toString());
			pd.setMeasurementName(prods.get("MEASUREMENT_NAME") == null ? "" : prods.get("MEASUREMENT_NAME").toString());
			pd.setRequiredQuantity(prods.get("PO_QTY") == null ? "" : prods.get("PO_QTY").toString());
			pd.setPrice(prods.get("PRICE") == null ? "" : prods.get("PRICE").toString());
			pd.setBasicAmt(prods.get("BASIC_AMOUNT") == null ? "" : prods.get("BASIC_AMOUNT").toString());
			pd.setStrDiscount(prods.get("DISCOUNT") == null ? "" : prods.get("DISCOUNT").toString());
			pd.setStrAmtAfterDiscount(prods.get("AMOUNT_AFTER_DISCOUNT") == null ? "" : prods.get("AMOUNT_AFTER_DISCOUNT").toString());
			pd.setHsnCode(prods.get("HSN_CODE") == null ? "" : prods.get("HSN_CODE").toString());
			pd.setChildProductCustDisc(prods.get("VENDOR_PRODUCT_DESC") == null ? "-" : prods.get("VENDOR_PRODUCT_DESC").toString());
			String taxId = prods.get("TAX") == null ? "" : prods.get("TAX").toString();
			//String query1 = "select TAX_PERCENTAGE from INDENT_GST where TAX_ID = "+taxId+ " ";
		//	String taxValue = template.queryForObject(query1,String.class);
			String taxValue = prods.get("TAX_PERCENTAGE") == null ? "" : prods.get("TAX_PERCENTAGE").toString();
			
			
			pd.setTaxId(taxId);
			pd.setTax(taxValue);
			pd.setTaxAmount(prods.get("TAX_AMOUNT") == null ? "" : prods.get("TAX_AMOUNT").toString());
			pd.setAmountAfterTax(prods.get("AMOUNT_AFTER_TAX") == null ? "" : prods.get("AMOUNT_AFTER_TAX").toString());
			pd.setOthercharges1(prods.get("OTHER_CHARGES") == null ? "" : prods.get("OTHER_CHARGES").toString());
			pd.setTaxonothertranportcharge1(prods.get("TAX_ON_OTHER_TRANSPORT_CHG") == null ? "" : prods.get("TAX_ON_OTHER_TRANSPORT_CHG").toString());
			pd.setOtherchargesaftertax1(prods.get("OTHER_CHARGES_AFTER_TAX") == null ? "" : prods.get("OTHER_CHARGES_AFTER_TAX").toString());
			
			
			pd.setTotalAmount(prods.get("TOTAL_AMOUNT") == null ? "" : prods.get("TOTAL_AMOUNT").toString());
			pd.setIndentCreationDetailsId(prods.get("INDENT_CREATION_DTLS_ID") == null ? "" : prods.get("INDENT_CREATION_DTLS_ID").toString());
			pd.setPoEntryDetailsId(prods.get("PO_ENTRY_DETAILS_ID") == null ? "" : prods.get("PO_ENTRY_DETAILS_ID").toString());
			
		//	doubleTotalAmount = Double.valueOf(prods.get("TOTAL_AMOUNT") == null ? "0" : prods.get("TOTAL_AMOUNT").toString());
		//	doublePOTotalAmount = doublePOTotalAmount+doubleTotalAmount;
			
			
			
			list.add(pd);
		}
		
		
	
		return list;
	}

	@Override
	public List<ProductDetails> getTransChrgsDtls(String poNumber,String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<ProductDetails> list = new ArrayList<ProductDetails>(); 
		List<Map<String, Object>> dbTransDts = null;

		String query = "select SPTOCD.ID,SPTOCD.TRANSPORT_ID,STOCM.CHARGE_NAME,SPTOCD.TRANSPORT_GST_PERCENTAGE,IG.TAX_PERCENTAGE,SPTOCD.TRANSPORT_GST_AMOUNT,"
			+ " SPTOCD.TOTAL_AMOUNT_AFTER_GST_TAX,SPTOCD.TRANSPORT_AMOUNT from SUMADHURA_PO_TRNS_O_CHRGS_DTLS  SPTOCD, "
			+ " SUMADHURA_TRNS_OTHR_CHRGS_MST STOCM,INDENT_GST IG,SUMADHURA_PO_ENTRY SPE where  SPTOCD.TRANSPORT_ID = STOCM.CHARGE_ID and "
			+ " IG.TAX_ID = SPTOCD.TRANSPORT_GST_PERCENTAGE and SPE.PO_ENTRY_ID = SPTOCD.PO_NUMBER and SPE.PO_NUMBER = ? and SPE.SITE_ID = ? ";
		dbTransDts = template.queryForList(query, new Object[]{poNumber,reqSiteId});
		int sno = 0;
		for(Map<String, Object> prods : dbTransDts) {
			ProductDetails pd = new ProductDetails();
			sno++;
			pd.setStrSerialNumber(String.valueOf(sno));
			pd.setConveyanceId1(prods.get("TRANSPORT_ID") == null ? "" : prods.get("TRANSPORT_ID").toString());
			pd.setConveyance1(prods.get("CHARGE_NAME") == null ? "" : prods.get("CHARGE_NAME").toString());
			pd.setConveyanceAmount1(prods.get("TRANSPORT_AMOUNT") == null ? "" : prods.get("TRANSPORT_AMOUNT").toString());
			pd.setGSTTaxId1(prods.get("TRANSPORT_GST_PERCENTAGE") == null ? "" : prods.get("TRANSPORT_GST_PERCENTAGE").toString());
			pd.setGSTTax1(prods.get("TAX_PERCENTAGE") == null ? "" : prods.get("TAX_PERCENTAGE").toString());
			pd.setGSTAmount1(prods.get("TRANSPORT_GST_AMOUNT") == null ? "" : prods.get("TRANSPORT_GST_AMOUNT").toString());
			pd.setAmountAfterTaxx1(prods.get("TOTAL_AMOUNT_AFTER_GST_TAX") == null ? "" : prods.get("TOTAL_AMOUNT_AFTER_GST_TAX").toString());
			pd.setPoTransChrgsDtlsSeqNo(prods.get("ID") == null ? "" : prods.get("ID").toString());

			list.add(pd);
		}
		return list;

	}

	@Override
	public int updateReceiveQuantityInIndentCreationDtls(String receiveQuantity,String indentCreationDetailsId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		String query = "update  SUMADHURA_INDENT_CREATION_DTLS set RECEIVE_QUANTITY = RECEIVE_QUANTITY+? "
			+ " where INDENT_CREATION_DETAILS_ID = ? ";
		int result = template.update(query, new Object[]{Double.valueOf(receiveQuantity),indentCreationDetailsId});
		//System.out.print(result+",");
		return result;
	}
	@Override
	public int updateReceivedQuantityInPoEntryDetails(String totalQuantity, String poEntryDetailsId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		String query1 = "select RECEIVED_QUANTITY from SUMADHURA_PO_ENTRY_DETAILS where PO_ENTRY_DETAILS_ID = ? ";
		String strReceivedQuantity = template.queryForObject(query1, new Object[]{poEntryDetailsId},String.class);
		double receivedQuantity = Double.valueOf(strReceivedQuantity==null?"0":strReceivedQuantity)+Double.valueOf(totalQuantity);
		
		String query = "update SUMADHURA_PO_ENTRY_DETAILS set RECEIVED_QUANTITY = ? where PO_ENTRY_DETAILS_ID = ?";
		int result = template.update(query, new Object[]{receivedQuantity,poEntryDetailsId});
		
		return result;
	}
	@Override
	public int setPOInactive(String poNumber,String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		//=========checking all po_quantity received?==========
		boolean doInactive = true;
		List<Map<String, Object>> dbIndentDts = null;

		String query1 = "select SPED.PO_QTY,SPED.RECEIVED_QUANTITY from SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE "
				+ "where SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID and SPE.PO_NUMBER = ? and SPE.SITE_ID = ? ";
		dbIndentDts = template.queryForList(query1, new Object[]{poNumber,reqSiteId});
		try {
			for(Map<String, Object> prods : dbIndentDts) {
				String strPOQuantity = prods.get("PO_QTY") == null ? "0" : prods.get("PO_QTY").toString();
				String strReceivedQuantity = prods.get("RECEIVED_QUANTITY") == null ? "0" : prods.get("RECEIVED_QUANTITY").toString();
				double poQuantity = Double.parseDouble(strPOQuantity);
				double receivedQuantity = Double.parseDouble(strReceivedQuantity);
				if(receivedQuantity<poQuantity){
					doInactive = false;
				}
			}
		} catch (Exception e) {
			doInactive = false;
			e.printStackTrace();
		}
		//==============================================================
		int result=0;
		if(doInactive){
			String query = "update SUMADHURA_PO_ENTRY set PO_STATUS = 'I' where PO_NUMBER = ? and SITE_ID = ? ";
			result = template.update(query, new Object[]{poNumber,reqSiteId});
		}
		//System.out.println("PO inactive: "+result);
		return result;
	}
	@Override
	public int setIndentInactiveAfterChecking(String indentNumber) {
		int result = 0;
		boolean doInactive=true;
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<Map<String, Object>> dbIndentDts = null;

		String query = "select REQ_QUANTITY,RECEIVE_QUANTITY from SUMADHURA_INDENT_CREATION_DTLS "
			+ " where INDENT_CREATION_ID = ? ";
		dbIndentDts = template.queryForList(query, new Object[]{indentNumber});
		try {
			for(Map<String, Object> prods : dbIndentDts) {
				String strRequiredQuantity = prods.get("REQ_QUANTITY") == null ? "" : prods.get("REQ_QUANTITY").toString();
				String strReceivedQuantity = prods.get("RECEIVE_QUANTITY") == null ? "" : prods.get("RECEIVE_QUANTITY").toString();
				double requiredQuantity = Double.parseDouble(strRequiredQuantity);
				double receivedQuantity = Double.parseDouble(strReceivedQuantity);
				if(receivedQuantity<requiredQuantity){
					doInactive = false;
				}
			}
		} catch (Exception e) {
			doInactive = false;
			e.printStackTrace();
		}
		if(doInactive){
			String query1 = "update SUMADHURA_INDENT_CREATION set STATUS = 'I' , PENDIND_DEPT_ID = 'REC' where INDENT_CREATION_ID = ? ";
			result = template.update(query1, new Object[]{Integer.parseInt(indentNumber)});

		}
		//System.out.println("Indent inactive: "+result);
		return result;
	}

	@Override
	public int insertCreditNote(CreditNoteDto creditNoteDto) {
		int result = 0;
		String query = "insert into SUMADHURA_CREDIT_NOTE(CREDIT_NOTE_SEQ_ID,CREDIT_NOTE_NUMBER,"
			+ " INDENT_ENTRY_NUMBER,ENTRY_DATE,INVOICE_NUMBER,CREDIT_TOTAL_AMOUNT,DC_NUMBER) "
			+ " values(?, ?, ?, sysdate, ?, ?, ?)";

		result = jdbcTemplate.update(query, new Object[] {
				creditNoteDto.getCreditSeqNo(),
				creditNoteDto.getCreditNoteNumber(),
				creditNoteDto.getIndentEntryId(),
				creditNoteDto.getInvoiceNumber(),
				creditNoteDto.getCreditTotalAmount(),
				creditNoteDto.getDcNumber()
		});
		//System.out.println("insert credit note: "+result);
		return result;
	}
	@Override
	public int insertCreditNoteDetails(CreditNoteDto creditNoteDetailsDto,ProductDetails productDetails) {
		int result = 0;
		String query = "insert into SUMADHURA_CREDIT_NOTE_DETAILS(CREDIT_NOTE_DTLS_SEQ_ID,CREDIT_NOTE_SEQ_ID,"
			+ " INDENT_ENTRY_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,MEASUR_MNT_ID,RECEIVED_QTY,"
			+ " ENTRY_DATE,PRICE,TAX,TAX_AMOUNT,AMOUNT_AFTER_TAX,OTHER_CHARGES,OTHER_CHARGES_AFTER_TAX,"
			+ " TOTAL_AMOUNT,HSN_CODE,BASIC_AMOUNT,TAX_ON_OTHER_TRANSPORT_CHG) "
			+ " values(?, ?, ?, ?, ?, ?, ?, ?, sysdate, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		result = jdbcTemplate.update(query, new Object[] {
				creditNoteDetailsDto.getCreditNoteDtlsSeqId(),
				creditNoteDetailsDto.getCreditSeqNo(),
				creditNoteDetailsDto.getIndentEntryId(),
				productDetails.getProductId(),
				productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),
				productDetails.getMeasurementId(),
				productDetails.getRecivedQty(),
				productDetails.getPrice(),
				productDetails.getTax(),
				productDetails.getTaxAmount(),
				productDetails.getAmountAfterTax(),
				productDetails.getOtherOrTransportCharges1(),
				productDetails.getOtherOrTransportChargesAfterTax1(),
				productDetails.getTotalAmount(),
				productDetails.getHsnCode(),
				productDetails.getBasicAmt(),
				productDetails.getTaxOnOtherOrTransportCharges1()
		});
	//	System.out.println("insert credit note detail: "+result);
		return result;
	}
	@Override
	public int getCreditNoteSequenceNumber() {
		return jdbcTemplate.queryForInt("SELECT SUMADHURA_CREDIT_NOTE_SEQ.NEXTVAL FROM DUAL");
	}
	@Override
	public int getCreditNoteDetailsSequenceNumber() {
		return jdbcTemplate.queryForInt("SELECT SUMADHURA_CREDIT_NOTE_DTLS_SEQ.NEXTVAL FROM DUAL");
	}

	@Override
	public String getPriceRatesByChildProduct(String childProdId,String poNumber,String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		StringBuffer sb = new StringBuffer();
		List<Map<String, Object>> dbPODts = null;

		String query = "SELECT SPED.PO_QTY,SPED.PRICE,SPED.BASIC_AMOUNT,"
			+ " SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,SPED.HSN_CODE,SPED.TAX,SPED.TAX_AMOUNT,"
			+ " SPED.AMOUNT_AFTER_TAX,SPED.OTHER_CHARGES,SPED.TAX_ON_OTHER_TRANSPORT_CHG,"
			+ " SPED.OTHER_CHARGES_AFTER_TAX,SPED.TOTAL_AMOUNT,SPED.INDENT_CREATION_DTLS_ID,SPED.PO_ENTRY_DETAILS_ID " 
			+ " FROM SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE,CHILD_PRODUCT CP WHERE "
			+ " SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID AND " 
			+ " SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' AND SPED.CHILD_PRODUCT_ID = '"+childProdId+"'";
		dbPODts = template.queryForList(query, new Object[]{});
		for(Map<String, Object> prods : dbPODts) {
			sb.append(prods.get("PO_QTY") == null ? "0" : prods.get("PO_QTY").toString()+":");
			sb.append(prods.get("PRICE") == null ? "0" : prods.get("PRICE").toString()+":");
			sb.append(prods.get("BASIC_AMOUNT") == null ? "0" : prods.get("BASIC_AMOUNT").toString()+":");
			sb.append(prods.get("DISCOUNT") == null ? "0" : prods.get("DISCOUNT").toString()+":");
			sb.append(prods.get("AMOUNT_AFTER_DISCOUNT") == null ? "0" : prods.get("AMOUNT_AFTER_DISCOUNT").toString()+":");
			sb.append(prods.get("HSN_CODE") == null ? "0" : prods.get("HSN_CODE").toString()+":");
			String taxId = prods.get("TAX") == null ? "0" : prods.get("TAX").toString();
			String query1 = "select TAX_PERCENTAGE from INDENT_GST where TAX_ID = ? ";
			String taxValue = template.queryForObject(query1, new Object[]{taxId},String.class);
			sb.append(taxId+":");
			sb.append(taxValue.substring(0, taxValue.length()-1)+":");
			sb.append(prods.get("TAX_AMOUNT") == null ? "0" : prods.get("TAX_AMOUNT").toString()+":");
			sb.append(prods.get("AMOUNT_AFTER_TAX") == null ? "0" : prods.get("AMOUNT_AFTER_TAX").toString()+":");
			sb.append(prods.get("OTHER_CHARGES") == null ? "0" : prods.get("OTHER_CHARGES").toString()+":");
			sb.append(prods.get("TAX_ON_OTHER_TRANSPORT_CHG") == null ? "0" : prods.get("TAX_ON_OTHER_TRANSPORT_CHG").toString()+":");
			sb.append(prods.get("OTHER_CHARGES_AFTER_TAX") == null ? "0" : prods.get("OTHER_CHARGES_AFTER_TAX").toString()+":");
			sb.append(prods.get("TOTAL_AMOUNT") == null ? "0" : prods.get("TOTAL_AMOUNT").toString()+":");
			sb.append(prods.get("INDENT_CREATION_DTLS_ID") == null ? "0" : prods.get("INDENT_CREATION_DTLS_ID").toString()+":");
			sb.append(prods.get("PO_ENTRY_DETAILS_ID") == null ? "0" : prods.get("PO_ENTRY_DETAILS_ID").toString());

			break;
		}
		return sb.toString();
	}



	@Override
	public int updateAllocatedQuantityInPurchaseDeptTable(String receiveQuantity,String indentCreationDetailsId,HttpServletRequest request) {
		JdbcTemplate template = null;
		List<Map<String, Object>> dbIndentDts = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		String query = "update  SUM_PURCHASE_DEPT_INDENT_PROSS set ALLOCATED_QUANTITY = ALLOCATED_QUANTITY+? "
				+ ", PENDING_QUANTIY = PENDING_QUANTIY-? , PO_INTIATED_QUANTITY = PO_INTIATED_QUANTITY-? "
			+ " where INDENT_CREATION_DETAILS_ID = ? ";
		int result = template.update(query, new Object[]{Double.valueOf(receiveQuantity),Double.valueOf(receiveQuantity),Double.valueOf(receiveQuantity),indentCreationDetailsId});
	
		return result;
	}


	@Override
	public int updateInvoiceNoInAccPaymentTbl(String invoiceNumber, String invoiceAmount, String invoiceDate,String receviedDate,
			String poNo, String vendorId, String creditNoteNumber,String creditTotalAmount,String indentEntryNo,String site_id) {
		List<Map<String, Object>> dbPODts = null;
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		int count = jdbcTemplate.queryForInt("select count(*) from ACC_PAYMENT where PO_NUMBER = '"+poNo+"'");
		
		if(count==1){
			String query1 = "select INVOICE_NUMBER,PO_AMOUNT,PO_DATE,REMARKS from ACC_PAYMENT where PO_NUMBER = '"+poNo+"'";
			dbPODts = template.queryForList(query1, new Object[]{});
			String invoiceNoIn_DB_AP = null;
			String po_amount = null;
			String po_date = null;
			String remarks = null;
			for(Map<String, Object> prods : dbPODts) {
				invoiceNoIn_DB_AP = prods.get("INVOICE_NUMBER") == null ? null : prods.get("INVOICE_NUMBER").toString();
				po_amount = prods.get("PO_AMOUNT") == null ? null : prods.get("PO_AMOUNT").toString();
				po_date = prods.get("PO_DATE") == null ? null : prods.get("PO_DATE").toString();
				remarks = prods.get("REMARKS") == null ? null : prods.get("REMARKS").toString();
			}
			
			if(invoiceNoIn_DB_AP==null){
				String query = "update  ACC_PAYMENT set INVOICE_NUMBER = ? "
						+ ", INVOICE_AMOUNT = ? , INVOICE_DATE = ?, INVOICE_RECEIVED_DATE = ? ,CREDIT_NOTE_NUMBER = ?,CREDIT_TOTAL_AMOUNT = ?,INDENT_ENTRY_ID = ? "
						+ " where PO_NUMBER = ? and VENDOR_ID = ? ";
				count= template.update(query, new Object[]{ 
						invoiceNumber, invoiceAmount, invoiceDate, receviedDate, creditNoteNumber,creditTotalAmount,indentEntryNo, poNo, vendorId});
			}
			else{
				String query = "insert into ACC_PAYMENT(PAYMENT_ID,INVOICE_NUMBER,INVOICE_AMOUNT " +
						",SITE_ID,CREATED_DATE, PAYMENT_DONE_UPTO, DC_NUMBER, PAYMENT_REQ_UPTO, STATUS, " +
						" REMARKS, VENDOR_ID, PO_NUMBER,PO_AMOUNT,INVOICE_DATE,PO_DATE,DC_DATE,INVOICE_RECEIVED_DATE,INDENT_ENTRY_ID,CREDIT_TOTAL_AMOUNT,CREDIT_NOTE_NUMBER) " +
						"values(PAYMENT_SEQ_ID.nextval,?,?,?,SYSDATE,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				count = jdbcTemplate.update(query, new Object[] {
						invoiceNumber, invoiceAmount,
						site_id,0.0,null,0.0,"A",
						remarks,vendorId,poNo,po_amount,DateUtil.convertToJavaDateFormat(invoiceDate),DateUtil.convertToJavaDateFormat(po_date),null,receviedDate,indentEntryNo,creditTotalAmount,creditNoteNumber
				});

			}
		}
		
		return count;
	}



	@Override
	public int checkPOisActive(String poNumber) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		int count = template.queryForInt("select count(*) from SUMADHURA_PO_ENTRY where PO_NUMBER = '"+poNumber+"' and PO_STATUS = 'A'");
		return count;
	}

	public int getCheckIndentAvailable(String  indentNumber){
		String query  = "select count(1) from  SUMADHURA_INDENT_CREATION where SITEWISE_INDENT_NO =? AND STATUS='A'";
		int intCount =    jdbcTemplate.queryForInt(query, new Object[] {indentNumber});
		return intCount;
	}
	@Override
	public String getPoEntryDetailsandIndentCreationDetails(String poNumber,String childProdId,String indentNumber) {
		JdbcTemplate template = null;
		String value="";
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		StringBuffer sb = new StringBuffer();
		List<Map<String, Object>> dbPODts = null;
		
		
		String query = "select STPE.PO_ENTRY_ID,STPE.INDENT_CREATION_DTLS_ID,STPE.PO_ENTRY_DETAILS_ID,SPE.SITE_ID,SPE.INDENT_NO"
						+" from  SUMADHURA_PO_ENTRY SPE,SUMADHURA_PO_ENTRY_DETAILS STPE "
						+" where SPE.PO_NUMBER =? AND SPE.PO_ENTRY_ID=STPE.PO_ENTRY_ID AND STPE.CHILD_PRODUCT_ID=?";
		dbPODts = template.queryForList(query, new Object[]{poNumber,childProdId});
		for(Map<String, Object> prods : dbPODts) {
			String po_Entry_Id=prods.get("PO_ENTRY_ID") == null ? "0" : prods.get("PO_ENTRY_ID").toString();
			String inedent_Creation_Details_Id=prods.get("INDENT_CREATION_DTLS_ID") == null ? "0" : prods.get("INDENT_CREATION_DTLS_ID").toString();
			String po_Entry_detailsId=prods.get("PO_ENTRY_DETAILS_ID") == null ? "0" : prods.get("PO_ENTRY_DETAILS_ID").toString();
			String site_Id=prods.get("SITE_ID") == null ? "0" : prods.get("SITE_ID").toString();
			String indent_No=prods.get("INDENT_NO") == null ? "0" : prods.get("INDENT_NO").toString();
			 value=po_Entry_Id+"@@"+inedent_Creation_Details_Id+"@@"+po_Entry_detailsId+"@@"+site_Id+"@@"+indent_No;
			
	
		}
		return value;
	}
	@Override
	public String getIndentCreationDetailsId(String indentNumber,String childProdId) {
		List<Map<String, Object>> dbPODts = null;
		JdbcTemplate template = null;
		String result="";
		try {
			 template =new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String Query = "select SICD.INDENT_CREATION_DETAILS_ID,SICD.INDENT_CREATION_ID from SUMADHURA_INDENT_CREATION_DTLS SICD,SUMADHURA_INDENT_CREATION SIC"
					+" where SICD.CHILD_PRODUCT_ID='"+childProdId+"' and SIC.SITEWISE_INDENT_NO='"+indentNumber+"' AND SIC.INDENT_CREATION_ID=SICD.INDENT_CREATION_ID"; 
		dbPODts = template.queryForList(Query, new Object[]{});
		for(Map<String, Object> prods : dbPODts) {
			String indentCreationDetailsId=prods.get("INDENT_CREATION_DETAILS_ID") == null ? "0" : prods.get("INDENT_CREATION_DETAILS_ID").toString();
			String indent_Id=prods.get("INDENT_CREATION_ID") == null ? "0" : prods.get("INDENT_CREATION_ID").toString();
			result=indentCreationDetailsId+"@@"+indent_Id;
		}
		return result;

	}
	
	@Override
	public int getCheckPoAvailable(String poNumber,String vendorId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		int count = template.queryForInt("select count(*) from SUMADHURA_PO_ENTRY where PO_NUMBER = '"+poNumber+"' and PO_STATUS = 'A' AND VENDOR_ID='"+vendorId+"'");
		return count;
	}

	
	
}

