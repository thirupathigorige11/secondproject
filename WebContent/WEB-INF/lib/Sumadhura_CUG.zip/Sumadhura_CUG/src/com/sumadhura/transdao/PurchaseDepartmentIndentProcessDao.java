package com.sumadhura.transdao;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.dto.TransportChargesDto;

public interface PurchaseDepartmentIndentProcessDao {



	public List<IndentCreationDto> getPendingIndents(String pendingEmpId,String strSiteId);

	public List<IndentCreationBean> getIndentCreationDetailsLists(int indentNumber);

	public List<Map<String, Object>> getVendorOrSiteAddress(String SiteId);

	public int insertTempPOEntryDetails(ProductDetails productDetails,String poEntrySeqNo);

	public int updatePurchaseDeptIndentProcesstbl(double intQuantity,int purchaseDeptSeqId,String strStatus);

	public int getPoEnterSeqNo();

	public int getPoEnterSeqNoOrMaxId(String poState);

	public int getTempPoEnterSeqNoOrMaxId();

	public int insertTempPOEntry(ProductDetails productDetails,String tempuser,String ccEmailId,String subject);

	public List<IndentCreationBean> getupdatePurchaseDeptIndentProcess(int indentNumber,String intEmployeeId,String siteId,String strApproverEmpId,String sessionSiteId);

	public List<Map<String, Object>> getAllProducts(String purchaseDeptId);

	public List<ProductDetails> getIndentsProductWise(String product, String subProduct, String childProduct);
	public int insertPurchaseIndentProcess(int purchaseIndentProcessId, IndentCreationBean purchaseIndentDetails,
			int IndentCreationDetailsId, int indentReqSiteId, String reqReceiveFrom);


	public int insertVendorEnquiryForm(ProductDetails productDetails);

	public int insertVendorEnquiryFormDetails(IndentCreationBean indentCreationBean);

	public int getEnquiryFormSeqNo();

	public String getVendorEmail(String vendor_Id);

	public String getIndentCreationDate(int intIndentNumber);

	public int setVendorPasswordInDB(String vendor_Pass, String vendor_Id);

	public String getVendorPasswordInDB(String vendor_Id);

	public List<Map<String, Object>> getComparisionDetails(String indentNumber, String strProductDtls,String vendorId);

	public double getIntiatedQuantityInPurchaseTable(String purchaseDepartmentIndentProcessSeqId);

	public int getPoTransChrgsEntrySeqNo();

	public int insertPOTempTransportDetails(int poTransChrgsSeqNo, ProductDetails productDetails,
			TransportChargesDto transportChargesDto);

	/*public List<ProductDetails> getTermasAndconditions();*/

	public int getEnquiryFormDetailsId();

	public int updateEnquiryFormDetails(ProductDetails productDetails);
	public String  getTemproryuser(String strUserId);
	public List<IndentCreationBean> ViewPoPendingforApproval(String fromDate, String toDate, String siteId,String tempPoNumber);
	public int saveTempTermsconditions(String termsAndCondition,String strPONumber,String strVendorId,String strIndentNo);
	public String getPendingVendorDetails(String poNumber, String siteId,HttpServletRequest request,String siteName) throws ParseException;
	public String getPendingProductDetails(String poNumber, String siteId,HttpServletRequest request,String deliverySiteState);
	public String getPendingTransportChargesList(String poNumber,String strSiteId,String gstinumber,HttpServletRequest request,String deliverySiteState);
	public String getAndsaveVendorDetails(String poNumber, String siteId,String userId,HttpServletRequest request,String revision_No,String old_Po_Number,String siteLevelPoPreparedBy,String siteName);
	public String getAndsavePendingProductDetails(String poNumber, String siteId,HttpServletRequest request,String permponumber,int intPOEntrySeqId);
	public String getAndsavePendingTransportChargesList(String poNumber,String strSiteId,HttpServletRequest request,int poEntryId);
	public int updatepoEntrydetails(String poNumber,String indentnumber,String strSiteId,String strUserId,String sessionSite_id);
	public String gettermsconditions(String poNumber,String permPoNumber);
	public int insertPOEntry(ProductDetails productDetails);
	public int saveTermsconditions(String termsAndCondition,int strPONumber,String strVendorId,String strIndentNo);
	public int insertPOTransportDetails(int poTransChrgsSeqNo, ProductDetails productDetails, TransportChargesDto transportChargesDto);
	public int insertPOEntryDetails(ProductDetails productDetails,int poEntrySeqNo);
	public int updatePurchaseDeptIndentProcestbl(String indentNumber,String poNumber, String quantity,String indentCreationdtlsId);
	public int saveVendorTermsconditions(String termsAndCondition,String strVendorId,String strIndentNo);
	public List<String> getVendortermsconditions(String indentNo,String vendorId);
	public String getVendorDetails(String poNumber, String siteId, String userId, HttpServletRequest request);
	public int doInactiveInIndentCreation(String indentNumber);

	public int getIndentCreationApprovalSequenceNumber();

	public int insertIndentCreationApprovalDtls(int indentCreationApprovalSeqNum, String indentNumber,
			IndentCreationDto indentCreationDto);

	public int doInactiveInPurchaseTable(String indentNumber,String typeOfPurchase);


	public List<ProductDetails> getProductDetailsLists(String indentNo, String vendorName,List<ProductDetails> listProductDetails,HttpServletRequest request);
	public Map<String, String> getApproveCreateEmp(int indentnumber,HttpServletRequest request);
	public void getVerifiedEmpNames(int indentnumber,HttpServletRequest request,String siteId);
	public List<String> getAllEmployeeEmailsUnderDepartment(String deptId);

	public int getSiteIdByPONumber(String poNumber);
	public int updateTempPoEntry(String approvalEmpId,String poNumber,String ccmailId);

	public int insertTempPOorPOCreateApproverDtls(String strTempPoNumber,String poNumber,String strEmpId,String strSIteId,String strOperationType,String remaks);

	public List<IndentCreationBean> ViewTempPo(String fromDate, String toDate,String tempPoNumber);

	public List<Map<String, Object>> getListOfActivePOs();

	public int updatePOEntryDetails(ProductDetails productDetails);

	public int updatePOTransportChargesDetails(TransportChargesDto transportChargesDto, int id);

	public int getPoEnterSeqNoByPONumber(String poNumber, String toSite);

	public int deletePOEntryDetails(String poEntryDetailsId);

	public int updatePOIntiatedQuantityInPDTable(String indentCreationDetailsId, String quantity);

	public int deletePOTransportChargesDetails(int poTransChrgsDtlsSeqNo);

	public List<IndentCreationBean> getDeletedProductDetailsLists(int indentNumber);

	public String getStateNameForTermsAndConditions(String site_id);
	public int getPoInfinityNumberGenerator(String serviceState);
	public int getPoYearWiseNumberGenerator(String serviceState);
	public int getUpdatePoNumberGeneratorHeadOfficeWise(int infinityNumber,int yearWiseNumber,String serviceName);
	
	public String getSiteWisePoNumber(String siteWise_Number);
	public String getStateWiseYearPoNumber(String siteWise_Number);
	public int getUpdateStateWisePoNumber(int siteWise_Number,int stateYearWisePoNum,String strSiteId);
	public int getStateWisePoNumber(String strSiteId);
	public int getStateWiseYearPo_Number(String SiteId);
	public int getHeadOfficeInfinitMaxId(String poState);
	public String getSiteAddress(String siteId);
	public int getSiteWiseIndentNo(int indentNumber);
	public int updateTablesOnTempPORejection(String indentNumber,String ponumber,String indentCreationdtlsId);
	public String getPoCreatedEmpName(String userId);
	public String getPoCreatedEmpId(String tempPoNumber);
	public int productWiseInactiveInPurchaseTable(String indentNumber,String typeOfPurchase);
	
	public List<IndentCreationBean> purchasePrintIndent(int indentNumber);
	public int insertPurchaseDepttbl(int purchaseIndentProcessId,String sessionSiteId,String strUserId,ProductDetails productDetails);

	public int insertIndentCreationtbl(ProductDetails productDetails,String indentCreationId);
	public String  getpendingEmpId(String poNumber,String userId);
	public int updateEmpId(String pendingEmpId,String temp_Po_Number);
	public List<ProductDetails> getListOfCancelPo(String userId);
	public List<ProductDetails> getViewCancelPoDetails(String poNumber, String reqSiteId) ;
	public List<ProductDetails> getProductDetailsListsForCancelPo(String poNumber,String reqSiteId);
	public List<ProductDetails> getTransChrgsDtlsForCancelPo(String poNumber,String reqSiteId);
	public int getPoEnterSeqNoByTempPONumber(String poNumber,String toSite);
	public int updateTempPOEntryDetails(ProductDetails productDetails);
	public int insertTempPOTransportDetails(int poTransChrgsSeqNo, ProductDetails productDetails, TransportChargesDto transportChargesDto,String poNumber);
	public int updateTempPOTransportChargesDetails(TransportChargesDto transportChargesDto,int id);
	public int deleteTempPOTransportChargesDetails(int poTransChrgsDtlsSeqNo);
	public int deleteTempPOEntryDetails(String poEntryDetailsId);
	public int updateTempPOQuantityDetails(String indentCreationDetailsId, String quantity,String strQuantity);
	
	public int updateTempPOVendorDetails(String vendorId,String poNumber,String ccEmailId,String subject,String isUpdate);
	public String  getpendingUserId(String temp_Po_Number);
	public int updateTempPoVieworCancel(String temp_Po_Number,String siteId);
	public String tempPoSubProducts(String prodId, String indentNumber, String reqSiteId);
	public String tempPoChildProducts(String subProdId, String indentNumber, String reqSiteId);
	public int insertTempPOEntryDetails(ProductDetails productDetails,int poEntrySeqNo);
	public String  getPoInitiateQuan(String indentCreationDetailsId);
	public List<String> getTempTermsAndConditions(String poNumber,String isRevised,String siteId);
	public int deleteTemppoTermsAdnConditions(String poNumber,String isUpadted);
	public String  getCancelPoComments(String  poNumber);
	public String getTempPOSubject(String poNumber);
	public String getTempPoCCEmails(String poNumber);
	public int getRevisionNumber(String editPoNumber);
	public int inactiveOldPo(String old_Po_Number);
	public double getRequestedQuantityInPurchaseTable(String indentCreationDetailsId);
	//public int updatePurchasetblForRevision(String indentCreationDetailsId,String poIntiatedQuantity,String status);
	public int checkIOndentCreationtbl(String indentNumber);
	public String getSiteLevelPoNumber(String site_Id);
	public int insertSiteLevelIndentData(int site_Id,String user_Id,int indent_Number,String siteWiseIndent);
	public int updateSiteLeveltbl(String site_Id,int total_Records,int current_Records);
	public int updateAccPayment(String old_Po_Number,String new_Po_Number);
}
