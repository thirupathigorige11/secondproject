package com.sumadhura.transdao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

@Repository("workControllerDao")
public class WorkOrderDaoImpl implements WorkOrderDao {
	@Autowired(required = true)
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Map<String, Object>> loadChildProduct(String prodId, String prodName) {
		final String query = "SELECT DISTINCT SPL.CHILD_PRODUCT_ID,CPD.NAME  FROM  CHILD_PRODUCT cpd,PRODUCT PD, SUMADHURA_PRICE_LIST spl  WHERE SPL.CHILD_PRODUCT_ID=CPD.CHILD_PRODUCT_ID AND PD.PRODUCT_ID=SPL.PRODUCT_ID AND  spl.product_id=? AND SPL.SITE_ID=?";
		List<Map<String, Object>> m = jdbcTemplate.queryForList(query, prodId, prodName);
		return m;
	}

	@Override
	public Map<String, String> loadQSProducts() {
		Map<String, String> qs_wo_majorheadList = null;
		qs_wo_majorheadList = new HashMap<String, String>();
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select WO_MAJORHEAD_ID,WO_MAJORHEAD_DESC from QS_WO_MAJORHEAD where status='A'");
		for (Map<String, Object> prods : list) {
			qs_wo_majorheadList.put(String.valueOf(prods.get("WO_MAJORHEAD_ID")),
					String.valueOf(prods.get("WO_MAJORHEAD_DESC")));
		}
		return qs_wo_majorheadList;
	}

	@Override
	public String loadWOSubProds(String prodId) {
		System.out.println("WorkOrderDaoImpl.loadWOSubProds()");
		StringBuffer sb = null;
		List<Map<String, Object>> dbSubProductsList = null;
		sb = new StringBuffer();
		String subProdsQry = "SELECT WO_MINORHEAD_ID, WO_MINORHEAD_DESC FROM QS_WO_MINORHEAD WHERE WO_MAJORHEAD_ID = ? AND STATUS = 'A' ORDER BY WO_MINORHEAD_DESC ASC";
		dbSubProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[] { prodId });
		for (Map<String, Object> subProds : dbSubProductsList) {
			sb = sb.append(String.valueOf(subProds.get("WO_MINORHEAD_ID")) + "_"
					+ String.valueOf(subProds.get("WO_MINORHEAD_DESC")) + "|");
		}

		return sb.toString();
	}

	@Override
	public String loadWOChildProds(String subProductId) {
		System.out.println("WorkOrderDaoImpl.loadWOChildProds()");
		StringBuffer sb = null;
		List<Map<String, Object>> dbChildProductsList = null;

		sb = new StringBuffer();

		String subProdsQry = "SELECT WO_WORK_DESC_ID, WO_WORK_DESCRIPTION FROM QS_WO_WORKDESC WHERE WO_MINORHEAD_ID = ? AND STATUS = 'A' ORDER BY WO_WORK_DESCRIPTION ASC";

		dbChildProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[] { subProductId });

		for (Map<String, Object> childProds : dbChildProductsList) {
			sb = sb.append(String.valueOf(childProds.get("WO_WORK_DESC_ID")) + "_"
					+ String.valueOf(childProds.get("WO_WORK_DESCRIPTION")) + "|");
		}
		return sb.toString();
	}

	@Override
	public String loadWorkOrderMeasurements(String childProductId) {
		StringBuffer sb = null;
		List<Map<String, Object>> dbMeasurementsList = null;
		sb = new StringBuffer();
		String measurementsQry = "SELECT WO_MEASURMENT_ID, WO_MEASURMEN_NAME FROM QS_WO_MEASURMENT WHERE WO_WORK_DESC_ID = ? and STATUS = ?";

		dbMeasurementsList = jdbcTemplate.queryForList(measurementsQry, new Object[] { childProductId, "A" });

		for (Map<String, Object> measurements : dbMeasurementsList) {
			sb = sb.append(String.valueOf(measurements.get("WO_MEASURMENT_ID")) + "_"
					+ String.valueOf(measurements.get("WO_MEASURMEN_NAME")) + "|");
		}
		return sb.toString();
	}

	@Override
	public List<String> getVendorInfo(String vendorName, boolean loadVendorData) {
		String contractorInfoQry = "SELECT VENDOR_NAME FROM VENDOR_DETAILS WHERE upper(VENDOR_NAME) like upper('"
				+ vendorName + "%')  and status='A'";

		String loadContractorInfoQry = "SELECT VENDOR_ID,VENDOR_NAME,ADDRESS,MOBILE_NUMBER,EMP_EMAIL,PAN_NUMBER FROM VENDOR_DETAILS "
				+ "WHERE upper(VENDOR_NAME) like upper('" + vendorName + "')  and status='A'";

		List<String> dbVendorList = new ArrayList<String>();
		if (!loadVendorData) {

			dbVendorList = jdbcTemplate.query(contractorInfoQry, new ResultSetExtractor<List<String>>() {

				@Override
				public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
					List<String> list = new ArrayList<String>();
					while (rs.next()) {
						list.add(rs.getString(1));
					}
					return list;
				}
			});
		} else {
			System.out.println("WorkOrderDaoImpl.getVendorInfo() in dao" + vendorName);
			dbVendorList = jdbcTemplate.query(loadContractorInfoQry, new ResultSetExtractor<List<String>>() {

				@Override
				public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
					List<String> vendorList = new ArrayList<String>();

					while (rs.next()) {
						String vendorId = rs.getString("VENDOR_ID");
						String vendorName = rs.getString("VENDOR_NAME") == null ? "" : rs.getString("VENDOR_NAME");
						String vendorAddress = rs.getString("ADDRESS") == null ? "" : rs.getString("ADDRESS");
						String mobileNo = rs.getString("MOBILE_NUMBER") == null ? " " : rs.getString("MOBILE_NUMBER");
						String email = rs.getString("EMP_EMAIL") == null ? " " : rs.getString("EMP_EMAIL");
						String panNo = rs.getString("PAN_NUMBER") == null ? " " : rs.getString("PAN_NUMBER");
						String vendorData = vendorId + "@@" + vendorName + "@@" + vendorAddress + "@@" + mobileNo + "@@"
								+ email + "@@" + panNo;

						System.out.println(vendorData);
						vendorList.add(vendorData);
					}
					return vendorList;
				}
			});
		}

		return dbVendorList;
	}
	
	@Override
	public List<Map<String, Object>> loadWOAreaMapping(String siteId) {
		String loadWoAreaMapping = "select QWAM.WO_WORK_AREA_ID,QWAM.WO_WORK_DESC_ID,WO_WORK_DESCRIPTION,QWAM.WO_MEASURMENT_ID,QWM.WO_MEASURMEN_NAME,FO.NAME AS FLOOR_NAME,QWAM.FLAT_ID,B.NAME as BLOCK_NAME,SI.SITE_NAME,QWAM.WO_WORK_AREA,QWAM.WO_WORK_AVAILABE_AREA,QWAM.WO_PERCENTAGE_AVAIL,QWAM.CREATED_DATE from QS_WORKOREDER_AREA_MAPPING QWAM,QS_WO_MEASURMENT QWM,QS_WO_WORKDESC QWW,FLOOR FO,BLOCK B,SITE SI where QWW.WO_WORK_DESC_ID=QWAM.WO_WORK_DESC_ID AND QWM.WO_MEASURMENT_ID=QWAM.WO_MEASURMENT_ID AND FO.FLOOR_ID=QWAM.FLOOR_ID AND SI.SITE_ID=QWAM.SITE_ID AND QWAM.BLOCK_ID=B.BLOCK_ID AND QWAM.site_id=?  and QWAM.status='A'";
		List<Map<String, Object>> areaMappingList = jdbcTemplate.queryForList(loadWoAreaMapping, siteId);
		return areaMappingList;

	}

	@Override
	public int getQS_WO_Temp_Issue_Dtls() {
		int workorderDetailsSeqNum = jdbcTemplate.queryForInt("SELECT QS_WO_TEMP_ISSUE_SEQ.NEXTVAL FROM DUAL");
		return workorderDetailsSeqNum;
	}
}
