package com.sumadhura.bean;

public class WorkOrderBean {

	
	
	private String WO_MajorHead1;
	private String WO_MinorHead1;
	private String WO_Desc1;
	private String WO_Manual_Desc;	
	private String UnitsOfMeasurement1;
	private String Quantity1;
	private String AcceptedRate1;
	private String TotalAmount1;
	private String Comments1;
	
	
	private String workOrderId;
	private String workOrderDate;
	private String contractorName;
	
	private String Purpose;
	
	
	
	
	
	public String getPurpose() {
		return Purpose;
	}
	public void setPurpose(String purpose) {
		Purpose = purpose;
	}
	public String getWorkOrderId() {
		return workOrderId;
	}
	public void setWorkOrderId(String workOrderId) {
		this.workOrderId = workOrderId;
	}
	public String getWorkOrderDate() {
		return workOrderDate;
	}
	public void setWorkOrderDate(String workOrderDate) {
		this.workOrderDate = workOrderDate;
	}
	public String getContractorName() {
		return contractorName;
	}
	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}
	public String getWO_MajorHead1() {
		return WO_MajorHead1;
	}
	public void setWO_MajorHead1(String wO_MajorHead1) {
		WO_MajorHead1 = wO_MajorHead1;
	}
	public String getWO_MinorHead1() {
		return WO_MinorHead1;
	}
	public void setWO_MinorHead1(String wO_MinorHead1) {
		WO_MinorHead1 = wO_MinorHead1;
	}
	public String getWO_Desc1() {
		return WO_Desc1;
	}
	public void setWO_Desc1(String wO_Desc1) {
		WO_Desc1 = wO_Desc1;
	}
	public String getWO_Manual_Desc() {
		return WO_Manual_Desc;
	}
	public void setWO_Manual_Desc(String wO_Manual_Desc) {
		WO_Manual_Desc = wO_Manual_Desc;
	}
	public String getUnitsOfMeasurement1() {
		return UnitsOfMeasurement1;
	}
	public void setUnitsOfMeasurement1(String unitsOfMeasurement1) {
		UnitsOfMeasurement1 = unitsOfMeasurement1;
	}
	public String getQuantity1() {
		return Quantity1;
	}
	public void setQuantity1(String quantity1) {
		Quantity1 = quantity1;
	}
	public String getAcceptedRate1() {
		return AcceptedRate1;
	}
	public void setAcceptedRate1(String acceptedRate1) {
		AcceptedRate1 = acceptedRate1;
	}
	public String getTotalAmount1() {
		return TotalAmount1;
	}
	public void setTotalAmount1(String totalAmount1) {
		TotalAmount1 = totalAmount1;
	}
	public String getComments1() {
		return Comments1;
	}
	public void setComments1(String comments1) {
		Comments1 = comments1;
	}


	
	
	
}
