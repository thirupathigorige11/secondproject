package com.sumadhura.service;

import java.util.List;
import java.util.Map;

public interface WorkOrderService {

	List<Map<String, Object>> loadChildProduct(String prodId, String prodName);

	Map<String, String> loadQSProducts();

	String loadWOSubProds(String mainProductId);

	String loadWOChildProds(String subProductId);

	String loadWorkOrderMeasurements(String childProductId);

	List<String> getVendorInfo(String employeeName, String loadVendorData);

	List<Map<String, Object>> loadWOAreaMapping(String siteId);

	int getQS_WO_Temp_Issue_Dtls();

}
