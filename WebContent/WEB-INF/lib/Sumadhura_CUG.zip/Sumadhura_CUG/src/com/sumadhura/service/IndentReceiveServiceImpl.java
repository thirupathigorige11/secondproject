package com.sumadhura.service;

import java.lang.reflect.Method;
import org.apache.commons.lang3.StringUtils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.Model;

import com.sumadhura.bean.AuditLogDetailsBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.dto.CreditNoteDto;
import com.sumadhura.dto.IndentReceiveDto;
import com.sumadhura.transdao.IndentReceiveDao;
import com.sumadhura.util.NumberToWord;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Service("irsClass")
public class IndentReceiveServiceImpl extends UIProperties implements IndentReceiveService {

	@Autowired
	private IndentReceiveDao ird;

	@Autowired
	PlatformTransactionManager transactionManager;

	@Override
	public Map<String, String> loadProds() {
		return ird.loadProds();
	}

	@Override
	public String loadSubProds(String prodId) {
		return ird.loadSubProds(prodId);
	}
	@Override
	public String loadSubProdsByPONumber(String prodId,String poNumber,String reqSiteId) {
		return ird.loadSubProdsByPONumber(prodId,poNumber,reqSiteId);
	}

	@Override
	public String loadChildProds(String subProductId) {
		return ird.loadChildProds(subProductId);
	}
	@Override
	public String loadChildProdsByPONumber(String subProductId, String poNumber, String reqSiteId) {
		return ird.loadChildProdsByPONumber(subProductId, poNumber, reqSiteId);
	}

	@Override
	public String loadIndentReceiveMeasurements(String childProdId) {
		return ird.loadIndentReceiveMeasurements(childProdId);
	}

	@Override
	public Map<String, String> getGSTSlabs() {
		return ird.getGSTSlabs();
	}

	@Override
	public int getIndentEntrySequenceNumber() {
		return ird.getIndentEntrySequenceNumber();
	}

	@Override
	public int insertInvoiceData(int indentEntrySeqNum, IndentReceiveDto objIndentReceiveDto) {
		return ird.insertInvoiceData(indentEntrySeqNum,  objIndentReceiveDto);
	}

	@Override
	public String getVendorInfo(String vendName) {
		return ird.getVendorInfo(vendName);
	}

	

	@Override
	public int updateIndentAvalibility(IndentReceiveDto irdto, String siteId) {
		return ird.updateIndentAvalibility(irdto, siteId);
	}

	@Override
	public void updateIndentAvalibilityWithNewIndent(IndentReceiveDto irdto, String siteId) {
		ird.updateIndentAvalibilityWithNewIndent(irdto, siteId);
	}


	@Override
	public String indentProcess(Model model, HttpServletRequest request, HttpSession session) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in InRe_indPro, ");
		String response1 = "Failed@@_";
		String poNumber="";
		String indentNumber="";
		int poEntryId=0;
		String strPoEntryId="";
		String indentCreationDetailsId="";
		String po_EntryDetailsId="";
		String req_SiteId="";
		
		try{
			Map<String,String> map = new HashMap<String,String>();
			List<Map<String,String>> transMapList = new ArrayList<Map<String,String>>();
			List<Map<String,String>> prodMapList = new ArrayList<Map<String,String>>();
			WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , InvoiceNumber:"+request.getParameter("InvoiceNumber"));

			String typeOfPurchase=request.getParameter("typeOfPurchase");
			if(typeOfPurchase.equalsIgnoreCase("P0")){
				
				poNumber=request.getParameter("poNumber");
				
			
				
			}else{
				indentNumber=request.getParameter("indentNumber");
			}
			
			map.put("typeOfPurchase",typeOfPurchase);
			map.put("indentNumber",indentNumber);

			map.put("invoiceNum",request.getParameter("InvoiceNumber"));
			String recordsCount = request.getParameter("numbeOfRowsToBeProcessed");
			map.put("recordsCount",recordsCount);
			map.put("poNo",poNumber);
			map.put("dcNo",request.getParameter("dcNo"));
			map.put("invoiceNumber",request.getParameter("InvoiceNumber"));
			map.put("invoiceDate",request.getParameter("InvoiceDate"));
			map.put("vendorName",request.getParameter("VendorName"));
			map.put("vendorId",request.getParameter("VendorId"));
			map.put("vendorAddress",request.getParameter("VendorAddress"));
			map.put("gstinNumber",request.getParameter("GSTINNumber"));
			map.put("note",request.getParameter("Note"));
			map.put("state",request.getParameter("state"));
			map.put("ttlAmntForIncentEntryTbl",request.getParameter("ttlAmntForIncentEntry"));
			map.put("poDate",request.getParameter("poDate"));
			map.put("eWayBillNo",request.getParameter("eWayBillNo"));
			map.put("vehileNo",request.getParameter("vehileNo"));
			map.put("transporterName",request.getParameter("transporterName"));
			map.put("otherChrgs",request.getParameter("otherCharges"));//quotes placed
			map.put("receviedDate",request.getParameter("receivedDate"));
			String transRows = request.getParameter("numbeOfChargesRowsToBeProcessed");
			map.put("chargesRecordsCount", transRows);

			String transportId ="Conveyance";
			String transportGSTPercentage = "GSTTax";
			String transportGSTAmount = "GSTAmount";
			String totalAmountAfterGSTTax = "AmountAfterTaxx";
			String transportInvoiceId = "TransportInvoice";
			String transportAmount = "ConveyanceAmount";

			int trans_rows = transRows.split("\\|").length;
			for(int charNum=1;charNum<=trans_rows;charNum++){
				Map<String,String> transMap = new HashMap<String,String>();
				transMap.put("transactionDts",request.getParameter(transportId+charNum));
				transMap.put("gstPercentage",request.getParameter(transportGSTPercentage+charNum));
				transMap.put("gstAmount",request.getParameter(transportGSTAmount+charNum));
				transMap.put("totAmtAfterGSTTax",request.getParameter(totalAmountAfterGSTTax+charNum));
				transMap.put("transactionInvoiceId",request.getParameter(transportInvoiceId+charNum));
				transMap.put("transAmount",request.getParameter(transportAmount+charNum));
				transMapList.add(transMap);
			}


			String prod = "Product";
			String subProd = "SubProduct";
			String childProd = "ChildProduct";
			String qty = "Quantity";
			String expireDate = "expireDate";
			String price = "Price";
			String basicAmount = "BasicAmount";
			String measurements = "UnitsOfMeasurement";				
			String gstTax = "Tax";
			String hsnCode = "HSNCode";
			String taxAmount = "TaxAmount";				
			String amountAfterTax = "AmountAfterTax";				
			String otherOrTransportCharges = "OtherOrTransportCharges";				
			String taxOnOtherOrTransportCharges = "TaxOnOtherOrTransportCharges";				
			String otherOrTransportChargesAfterTax = "OtherOrTransportChargesAfterTax";				
			String totalAmount = "TotalAmount";
			String otherCharges = "OtherCharges";
			int records_Count = recordsCount.split("\\|").length;
			for(int num=1;num<=records_Count;num++){
				Map<String,String> prodMap = new HashMap<String,String>();
				prodMap.put("product",request.getParameter(prod+num));					
				prodMap.put("subProduct",request.getParameter(subProd+num));
				prodMap.put("expiryDate",request.getParameter(expireDate+num));
				prodMap.put("childProduct",request.getParameter(childProd+num));
				prodMap.put("quantity",request.getParameter(qty+num));
				prodMap.put("prc",request.getParameter(price+num));
				prodMap.put("basicAmnt",request.getParameter(basicAmount+num));
				prodMap.put("unitsOfMeasurement",request.getParameter(measurements+num));
				prodMap.put("tax",request.getParameter(gstTax+num));
				prodMap.put("hsnCd",request.getParameter(hsnCode+num));
				prodMap.put("taxAmnt",request.getParameter(taxAmount+num));
				prodMap.put("amntAfterTax",request.getParameter(amountAfterTax+num));
				prodMap.put("otherOrTranportChrgs",request.getParameter(otherOrTransportCharges+num));
				prodMap.put("taxOnOtherOrTranportChrgs",request.getParameter(taxOnOtherOrTransportCharges+num));
				prodMap.put("otherOrTransportChrgsAfterTax",request.getParameter(otherOrTransportChargesAfterTax+num));
				prodMap.put("totalAmnt",request.getParameter(totalAmount+num));
				prodMap.put("otherChrgss",request.getParameter("otherChrgs"+num));//quotes placed
				prodMap.put("remarks",request.getParameter("Remarks"+num));
				prodMapList.add(prodMap);		
			}
		//	System.out.println(map);
		//	System.out.println(transMapList);
		//	System.out.println(prodMapList);

			response1 = indentProcessCommmon(map,transMapList,prodMapList,request,session);
			String[] response_array = response1.split("@@");
			String response = response_array [0];
		/************************************************************check for po number and inactive*************************************/	
		for(Map<String,String> productMap:prodMapList){
				String childProduct = productMap.get("childProduct");
				String childProdsInfo[] = childProduct.split("\\$");					
				String childProdId = childProdsInfo[0];
				double creditQuantity = request.getAttribute(childProdId)==null ? 0.0 : Double.parseDouble(request.getAttribute(childProdId).toString());
				double takenQuantity = Double.parseDouble(productMap.get("quantity").toString());
				String totalQuantity = String.valueOf(takenQuantity);
				
				if(poNumber!=null && !poNumber.equals("") && indentNumber.equals("")){
					
					String retValue=ird.getPoEntryDetailsandIndentCreationDetails(poNumber,childProdId,indentNumber);	
					if(retValue!=null && !retValue.equals("")){
						String data[]=retValue.split("@@");
						 strPoEntryId=data[0];
						 indentCreationDetailsId=data[1];
						 po_EntryDetailsId=data[2];
						 req_SiteId=data[3];
						 String strIndentNumber=data[4];
			
						ird.updateReceiveQuantityInIndentCreationDtls(totalQuantity,indentCreationDetailsId);
						ird.updateAllocatedQuantityInPurchaseDeptTable(totalQuantity,indentCreationDetailsId,request);
						ird.updateReceivedQuantityInPoEntryDetails(totalQuantity,po_EntryDetailsId);
						ird.setPOInactive(poNumber,req_SiteId);
						ird.setIndentInactiveAfterChecking(strIndentNumber);
						}
				}
				
				else if(indentNumber!=null && !indentNumber.equals("")){
					String result=ird.getIndentCreationDetailsId(indentNumber,childProdId);
					if(result!=null && !result.equals("")){
					String data[]=result.split("@@");
					indentCreationDetailsId=data[0];
					String strIndentNumber=data[1];
					if(indentCreationDetailsId!=null && !indentCreationDetailsId.equals("")){
					ird.updateReceiveQuantityInIndentCreationDtls(totalQuantity,indentCreationDetailsId);
					ird.updateAllocatedQuantityInPurchaseDeptTable(totalQuantity,indentCreationDetailsId,request);
					ird.setIndentInactiveAfterChecking(strIndentNumber);
					}
					}
				}
		}
			
			if (response.equalsIgnoreCase("Success")){
				transactionManager.commit(status);
				WriteTrHistory.write("Tr_Completed");
			}
			else{
				transactionManager.rollback(status);
				WriteTrHistory.write("Tr_Completed");
			}
		}
		catch(Exception e){
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			e.printStackTrace();
		}
		return response1;
	
	}
	
	public String indentProcessCommmon(Map<String,String> map,List<Map<String,String>> transMapList,List<Map<String,String>> prodMapList,HttpServletRequest request, HttpSession session) {
		//String viewToBeSelected = "";
		String imgname = "_";//"vname_invoiceno_entryid";
		String CGST = "";
		String SGST = "";
		String IGST = "";
		Double percent = 0.0;
		Double CGSTAMT = 0.0;
		Double SGSTAMT = 0.0;
		Double IGSTAMT = 0.0;
		Double amt = 0.0;
		String userId = "";
		String site_id = "";
		String invoiceNum = map.get("invoiceNumber");
		
		String chargeIGST = "";
		Double chargeIGSTAMT = 0.0;
		Double taxChargesPercentage = 0.0;
		Double chargeSGSTAMT = 0.0;
		Double chargeCGSTAMT =  0.0;
		Double chargeAmt = 0.0;
		String chargeSGST = "";
		String chargeCGST = "";
		String tblChargeName = "";
		String gstChargePercentage = "";
		String transAmount = "";
		String totAmtAfterGSTTax = "";
		String gstAmount = "";
		String typeOfPurchase="";
		
		StringBuffer tblCharges = new StringBuffer();
		double doubleSumOfOtherCharges = 0.0;

		int indentEntrySeqNum = 0;
		Map<String, String> viewGrnPageDataMap = null;
		IndentReceiveDto irdto = null;

		

		String result = "";

		try {
			viewGrnPageDataMap = new HashMap<String, String>();
			String recordsCount = map.get("recordsCount");
			//logger.info("");
			logger.info("Records To Be Processed = "+recordsCount);

			String numOfRec[] = null;
			if((recordsCount != null) && (!recordsCount.equals(""))) {
				numOfRec = recordsCount.split("\\|");
			}

			if(numOfRec != null && numOfRec.length > 0) {

				typeOfPurchase=map.get("typeOfPurchase");			
				String poNo = map.get("poNo");
				String dcNo = map.get("dcNo");
				String invoiceNumber = map.get("invoiceNumber");
				String invoiceDate = map.get("invoiceDate");
				String vendorName = map.get("vendorName");

				String vendorId = map.get("vendorId");
				String vendorAddress = map.get("vendorAddress");
				String gstinNumber = map.get("gstinNumber");
				String note = map.get("note");
				String state = map.get("state");
				String ttlAmntForIncentEntryTbl = map.get("ttlAmntForIncentEntryTbl");
				String poDate = map.get("poDate");
				String eWayBillNo = map.get("eWayBillNo");
				String vehileNo = map.get("vehileNo");
				String transporterName = map.get("transporterName");
				String otherChrgs = map.get("otherChrgs");
				String receviedDate = map.get("receviedDate");
				String hsnCode = map.get("hsnCode");
				String indentNumber= map.get("indentNumber");
				logger.info(invoiceNumber+" <--> "+invoiceDate+" <--> "+vendorName+" <--> "+vendorId+" <--> "+vendorAddress+" <--> "+gstinNumber+" <--> "+hsnCode+" <--> "+ttlAmntForIncentEntryTbl+" <--> "+note);

				String strReceiveStartDate  = validateParams.getProperty("INDENTRECSTARTDT") == null ? "" : validateParams.getProperty("INDENTRECSTARTDT").toString();
				int invoiceCount = ird.getInvoiceCount(  invoiceNumber,  vendorId, strReceiveStartDate, receviedDate);

				if(invoiceCount == 0){

					IndentReceiveDto objIndentReceiveDto = new IndentReceiveDto();

					//pavan settings objects
					objIndentReceiveDto.setStrInvoiceNo(invoiceNumber);
					objIndentReceiveDto.setStrInoviceDate(invoiceDate);
					objIndentReceiveDto.setStrVendorId(vendorId);
					objIndentReceiveDto.setTotalAmnt(ttlAmntForIncentEntryTbl);
					objIndentReceiveDto.setStrRemarks(note);
					objIndentReceiveDto.setStrReceiveDate(receviedDate);
					objIndentReceiveDto.setTransporterName(transporterName);
					objIndentReceiveDto.seteWayBillNo(eWayBillNo);
					objIndentReceiveDto.setVehileNo(vehileNo);
					objIndentReceiveDto.setPoDate(poDate);
					objIndentReceiveDto.setDcNo(dcNo);
					objIndentReceiveDto.setPoNo(poNo);
					objIndentReceiveDto.setIndentNumber(indentNumber);


					//userId = 1013
					//site_id = 021

					userId = String.valueOf(session.getAttribute("UserId"));
					//logger.info("User Id = "+userId);

					site_id = String.valueOf(session.getAttribute("SiteId"));
					//logger.info("Site Id = "+site_id);
					if (StringUtils.isNotBlank(site_id)){

					} else {
						//transactionManager.rollback(status);
						return result = "SessionFailed";
					}
					indentEntrySeqNum = ird.getIndentEntrySequenceNumber();
					session.setAttribute("indentEntrySeqNum",indentEntrySeqNum);
					request.setAttribute("indentEntryNo",indentEntrySeqNum);
					imgname=vendorName+"_"+invoiceNumber+"_"+indentEntrySeqNum;

					/*start 01-setp-17*/
					String chargesRecordsCount =  map.get("chargesRecordsCount");
					String numOfChargeRec[] = null;
					if((chargesRecordsCount != null) && (!chargesRecordsCount.equals(""))) {
						numOfChargeRec = chargesRecordsCount.split("\\|");
						if(numOfChargeRec != null && numOfChargeRec.length > 0) {
							for(String charNum : numOfChargeRec) {
								int index = Integer.parseInt(charNum)-1;
								String transactionDts = transMapList.get(index).get("transactionDts");
								String transDts[] = transactionDts.split("\\$");
								String transactionId = transDts[0];
								tblChargeName = transDts[1];
								String gstPercentage = transMapList.get(index).get("gstPercentage");
								String arraypercent[] = gstPercentage.split("\\$");
								String gstId = arraypercent[0];
								gstChargePercentage = arraypercent[1];
								gstChargePercentage = gstChargePercentage.replace("%", "").trim();
								gstAmount = transMapList.get(index).get("gstAmount");
								totAmtAfterGSTTax = transMapList.get(index).get("totAmtAfterGSTTax");
								 NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
								
								 String totamtaftergst=String.valueOf(totAmtAfterGSTTax);
								 double ttamt=Double.parseDouble(totamtaftergst);
								String totAmtAfterGSTTax1=numberFormat.format(ttamt);
								String transactionInvoiceId = transMapList.get(index).get("transactionInvoiceId");
								transAmount = transMapList.get(index).get("transAmount");

								ird.saveTransactionDetails(invoiceNum,transactionId, gstId, gstAmount, totAmtAfterGSTTax, transactionInvoiceId, transAmount, site_id, String.valueOf(indentEntrySeqNum));

								if (state.equals("1")) {
									if (gstChargePercentage.equals("0")) {
										chargeCGST = "0";
										chargeSGST = "0";
									} else {
										taxChargesPercentage = Double.parseDouble(gstChargePercentage)/2;
										chargeAmt = Double.parseDouble(gstAmount)/2;
										chargeCGSTAMT = chargeAmt;
										chargeSGSTAMT = chargeAmt;
										chargeCGST = String.valueOf(taxChargesPercentage);
										chargeSGST = String.valueOf(taxChargesPercentage);
									}
								}else {
									taxChargesPercentage = Double.parseDouble(gstChargePercentage);
									chargeAmt = Double.parseDouble(gstAmount);
									chargeIGST = String.valueOf(taxChargesPercentage);
									chargeIGSTAMT = chargeAmt;
								}
								if (state.equals("1")) {
									tblCharges.append(tblChargeName+"@@"+transAmount+"@@"+chargeCGST+"@@"+chargeCGSTAMT+"@@"+chargeSGST+"@@"+chargeSGSTAMT+"@@"+""+"@@"+""+"@@"+totAmtAfterGSTTax1+"@@"+"-"+"&&");
								} else {
									tblCharges.append(tblChargeName+"@@"+transAmount+"@@"+""+"@@"+""+"@@"+""+"@@"+""+"@@"+chargeIGST+"@@"+chargeIGSTAMT+"@@"+totAmtAfterGSTTax1+"@@"+"-"+"&&");
								}
							}

						}
					}
					/*end 01-sept-17*/ 
					logger.info("Indent Entry Seq. Num. = "+indentEntrySeqNum);

					//pavan added object
					objIndentReceiveDto.setStrUserId(userId);
					objIndentReceiveDto.setStrSiteId(site_id);
					if (state.equals("1")) {
						objIndentReceiveDto.setState("Local");
					} else {
						objIndentReceiveDto.setState("Non Local");
					}
					String grn_no = session.getAttribute("SiteName")+ird.getindentEntrySerialNo();
					objIndentReceiveDto.setGrnNumber(grn_no);
					int insertReceiveReult = ird.insertInvoiceData(indentEntrySeqNum, objIndentReceiveDto);
					logger.info("Insert Requester Reult = "+insertReceiveReult);

					if(insertReceiveReult >= 1) {

						int count = 1;

						StringBuffer tblOneData = new StringBuffer();
						Date grnDate = new Date();
						double totalAmt=Double.valueOf(ttlAmntForIncentEntryTbl);
						totalAmt =Double.parseDouble(new DecimalFormat("##.##").format(totalAmt));
						int val = (int) Math.ceil(totalAmt);
						double roundoff=Math.ceil(totalAmt)-totalAmt;
						double grandtotal=Math.ceil(totalAmt);
						
						int gtotal=(int)grandtotal;
						int total=(int)(totalAmt);
						NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
						
						
						//String strcontotal=numberFormat.format(total);//String.valueOf(totalAmt);
						String strcontotal=numberFormat.format(totalAmt);//String.valueOf(totalAmt);
						
						String strroundoff=String.format("%.2f",roundoff);
						String strcongrdtotal=numberFormat.format(gtotal);//String.valueOf((int)grandtotal);
						
					
						StringBuffer tblTwoData = new StringBuffer();
						int intPriceListSeqNo = 0; 
						int intIndentEntryDetailsSeqNo = 0; 
						int insertIndentReceiveResult = 0;
						
						for(String num : numOfRec) {

							irdto = new IndentReceiveDto();

							num = num.trim();
							
							int index = Integer.parseInt(num)-1;

							String product = prodMapList.get(index).get("product");				
							String prodsInfo[] = product.split("\\$");					
							String prodId = prodsInfo[0];
							String prodName = prodsInfo[1];
							//logger.info("Product Id = "+prodId+" and Product Name = "+prodName);

							String subProduct = prodMapList.get(index).get("subProduct");	
							String subProdsInfo[] = subProduct.split("\\$");					
							String subProdId = subProdsInfo[0];
							String subProdName = subProdsInfo[1];					
							//logger.info("Sub Product Id = "+subProdId+" and Sub Product Name = "+subProdName);
							String expiryDate = prodMapList.get(index).get("expiryDate");	
							String childProduct = prodMapList.get(index).get("childProduct");	
							String childProdsInfo[] = childProduct.split("\\$");					
							String childProdId = childProdsInfo[0];
							String childProdName = childProdsInfo[1];
							//logger.info("Child Product Id = "+childProdId+" and Child Product Name = "+childProdName);

							String quantity = prodMapList.get(index).get("quantity");	
							String prc = prodMapList.get(index).get("prc");	
							String basicAmnt = prodMapList.get(index).get("basicAmnt");	

							String unitsOfMeasurement = prodMapList.get(index).get("unitsOfMeasurement");	
							String measurementsInfo[] = unitsOfMeasurement.split("\\$");
							String measurementId = measurementsInfo[0];
							String measurementName = measurementsInfo[1];
							//logger.info("Measurement Id = "+measurementId+" and Measurement Name = "+measurementName);

							String tax = prodMapList.get(index).get("tax");	
							String taxInfo[] = tax.split("\\$");
							String taxId = taxInfo[0];
							String taxPercentage = taxInfo[1];
							//logger.info("Tax Id = "+taxId+" and Tax Percentage = "+taxPercentage);
							if (taxPercentage.contains("%")) {
								taxPercentage = taxPercentage.substring(0,taxPercentage.length()-1);
							}

							String hsnCd = prodMapList.get(index).get("hsnCd");	
							String taxAmnt = prodMapList.get(index).get("taxAmnt");	
							String amntAfterTax = prodMapList.get(index).get("amntAfterTax");	
							String otherOrTranportChrgs = prodMapList.get(index).get("otherOrTranportChrgs");	
							String taxOnOtherOrTranportChrgs = prodMapList.get(index).get("taxOnOtherOrTranportChrgs");	
							String otherOrTransportChrgsAfterTax = prodMapList.get(index).get("otherOrTransportChrgsAfterTax");	
							String totalAmnt = prodMapList.get(index).get("totalAmnt");	
							String otherChrgss = request.getParameter(otherChrgs+num);
							String remarks = prodMapList.get(index).get("remarks");	
							String baiscamt=String.valueOf(basicAmnt);
							double baiscat=Double.parseDouble(baiscamt);
						     String 	basicAmnt1=numberFormat.format(baiscat);
							//amntAfterTax=numberFormat.format(amntAfterTax);

							logger.info(prodId+" <--> "+prodName+" <--> "+subProdId+" <--> "+subProdName+" <--> "+childProdId+" <--> "+childProdName+" <--> "+quantity+" <--> "+measurementId+" <--> "+measurementName+" <--> "+hsnCd);

							logger.info(product+" <--> "+subProduct+" <--> "+childProduct+" <--> "+quantity+" <--> "+unitsOfMeasurement+" <--> "+prc+" <--> "+basicAmnt+" <--> "+taxId+" <--> "+taxPercentage+"<-->"+taxAmnt+"<-->"+amntAfterTax+"<-->"+otherOrTranportChrgs+"<-->"+taxOnOtherOrTranportChrgs+"<-->"+otherOrTransportChrgsAfterTax+"<-->"+totalAmnt+"<-->"+otherChrgs);
							if (StringUtils.isNotBlank(prodId) && StringUtils.isNotBlank(subProdId) && StringUtils.isNotBlank(childProdId)) {

							} else {
								//transactionManager.rollback(status);
								return result = "Failed";
							}
							irdto.setProdId(prodId);
							irdto.setProdName(prodName);
							irdto.setSubProdId(subProdId);
							irdto.setSubProdName(subProdName);
							irdto.setChildProdId(childProdId);
							irdto.setChildProdName(childProdName);
							//irdto.setPrice(prc);
							irdto.setBasicAmnt(basicAmnt);
							//irdto.setQuantity(quantity);
							//irdto.setMeasurementId(measurementId);
							//irdto.setMeasurementName(measurementName);
							irdto.setTax(taxPercentage);
							irdto.setHsnCd(hsnCd);
							irdto.setTaxAmnt(taxAmnt);
							irdto.setAmntAfterTax(amntAfterTax);
							irdto.setOtherOrTranportChrgs(otherOrTranportChrgs);
							irdto.setTaxOnOtherOrTranportChrgs(taxOnOtherOrTranportChrgs);
							irdto.setOtherOrTransportChrgsAfterTax(otherOrTransportChrgsAfterTax);
							irdto.setTotalAmnt(totalAmnt);
							irdto.setOtherChrgs(otherChrgss);
							irdto.setPoNo(poNo);
							irdto.setStrRemarks(remarks);
							//irdto.setDcNo(dcNo);
							//irdto.setDate(invoiceDate);
							irdto.setDate(receviedDate);
							irdto.setExpiryDate(expiryDate);
							//irdto.setPoDate(poDate);
							//irdto.seteWayBillNo(eWayBillNo);
							//irdto.setVehileNo(vehileNo);
							//irdto.setTransporterName(transporterName);



							doubleSumOfOtherCharges = doubleSumOfOtherCharges + Double.valueOf(otherOrTransportChrgsAfterTax);

							//tblTwoData.append(count+"@@"+subProdName+" "+childProdName+"@@"+measurementName+"@@"+"-"+"@@"+quantity+"@@"+prc+"@@"+basicAmnt+"@@"+"-"+"&&");
							if (state.equals("1")) {
								/*						taxPercentage = taxPercentage.substring(0,taxPercentage.length()-1);*/
								if (taxPercentage.equals("0")) {
									CGST = "0";
									SGST = "0";
								} else {
									percent = Double.parseDouble(taxPercentage)/2;
									amt = Double.parseDouble(taxAmnt)/2;
									CGSTAMT = amt;
									SGSTAMT = amt;
									CGST = String.valueOf(percent);
									SGST = String.valueOf(percent);
								}
							} else {
								percent = Double.parseDouble(taxPercentage);
								amt = Double.parseDouble(taxAmnt);
								IGST = String.valueOf(percent);
								IGSTAMT = amt;
							}
							if (state.equals("1")) {
								tblTwoData.append(count+"@@"+childProdName+"@@"+hsnCd+"@@"+note+"@@"+measurementName+"@@"+quantity+"@@"+quantity+"@@"+prc+"@@"+basicAmnt1+"@@"+CGST+"@@"+CGSTAMT+"@@"+SGST+"@@"+SGSTAMT+"@@"+""+"@@"+""+"@@"+amntAfterTax+"@@"+remarks+"@@"+"-"+"&&");
							} else {
								tblTwoData.append(count+"@@"+childProdName+"@@"+hsnCd+"@@"+note+"@@"+measurementName+"@@"+quantity+"@@"+quantity+"@@"+prc+"@@"+basicAmnt1+"@@"+""+"@@"+""+"@@"+""+"@@"+""+"@@"+IGST+"@@"+IGSTAMT+"@@"+amntAfterTax+"@@"+remarks+"@@"+"-"+"&&");
								//tblTwoData.append(count+"@@"+hsnCd+" "+note+"@@"+measurementName+"@@"+"-"+"@@"+quantity+"@@"+quantity+"@@"+prc+"@@"+"@@"+basicAmnt+"@@"+"@@"+basicAmnt+"@@"+"-"+"&&");
							}


							String methodName = "";
							double doubleQuantity = 0.0;
							methodName  = validateParams.getProperty(childProdId) == null ? "" : validateParams.getProperty(childProdId).toString();

							if(!methodName.equals("")) {	
								Map<String, String> values = null;

								String strMesurmentConversionClassName  = validateParams.getProperty("MesurmentConversionClassName") == null ? "" : validateParams.getProperty("MesurmentConversionClassName").toString();

								//String strMesurmentConversionClassName = "comsumadhura.util.MesurmentConversions";
								Class<?> strMesurmentConversionClass = Class.forName(strMesurmentConversionClassName); // convert string classname to class
								Object mesurment = strMesurmentConversionClass.newInstance(); // invoke empty constructor


								double doubleActualQuantity  =  Double.valueOf(validateParams.getProperty(childProdId+"ActualQuantity") == null ? "0" : validateParams.getProperty(childProdId+"ActualQuantity").toString());
								double doubleInputQuantity =  Double.valueOf(quantity);
								String strConversionMesurmentId  =  validateParams.getProperty(childProdId+"ID") == null ? "" : validateParams.getProperty(childProdId+"ID").toString();
								// with multiple parameters
								//methodName = "convertCHP00536";
								Class<?>[] paramTypes = {String.class,double.class,double.class, String.class};
								Method printDogMethod = mesurment.getClass().getMethod(methodName, paramTypes);
								values = (Map<String, String>) printDogMethod.invoke(mesurment,basicAmnt,doubleActualQuantity,doubleInputQuantity,measurementName);
								
								for(Map.Entry<String, String> retVal : values.entrySet()) {
									quantity=retVal.getKey();
									prc=retVal.getValue(); 
								}	
								//quantity =  String.valueOf(doubleQuantity);
								/*if(measurementName.equalsIgnoreCase("PCS")){
									
									double price=Double.parseDouble(basicAmnt)/doubleQuantity;
									prc=String.valueOf(price);
								}*/
								measurementId = strConversionMesurmentId;
								measurementName = validateParams.getProperty(childProdId+"IDMNAME") == null ? "" : validateParams.getProperty(childProdId+"IDMNAME").toString();
							}
							irdto.setQuantity(quantity);
							irdto.setMeasurementId(measurementId);
							irdto.setMeasurementName(measurementName);
							irdto.setPrice(prc);
							
							//public  double convertCHP0016(double doubleActualQuantity,double inputQuantity,String inputMesurment)
							
							
							 intPriceListSeqNo = ird.getPriceList_SeqNumber(); 
							 intIndentEntryDetailsSeqNo = ird.getIndentEntryDtails_SeqNumber(); 
							 insertIndentReceiveResult = ird.insertIndentReceiveData(indentEntrySeqNum, intIndentEntryDetailsSeqNo,irdto, userId, site_id,intPriceListSeqNo);
							
							
							if(insertIndentReceiveResult >= 1) {
								int updateIndentAvalibilityResult = ird.updateIndentAvalibility(irdto, site_id);
								//viewToBeSelected = "viewGRN";
								result = "Success";
								//Making a new entry if new product.
								if(updateIndentAvalibilityResult == 0) {
									ird.updateIndentAvalibilityWithNewIndent(irdto, site_id);
									//viewToBeSelected = "viewGRN";
									result = "Success";
								}
								//27-July-2017 added by Madhu start
								String id = ird.getIndentAvailableId(irdto, site_id);
								if (StringUtils.isNotBlank(id)) {
									ird.saveReciveDetailsIntoSumduraPriceList(irdto, invoiceNumber, site_id, id,intIndentEntryDetailsSeqNo,intPriceListSeqNo,typeOfPurchase);
								} else {
									String id1 = ird.getProductAvailabilitySequenceNumber();
									ird.saveReciveDetailsIntoSumduraPriceList(irdto, invoiceNumber, site_id, id1,intIndentEntryDetailsSeqNo,intPriceListSeqNo,typeOfPurchase);
								}
								//ird.saveReciveDetailsIntoSumadhuraCloseBalance(irdto, site_id);
								ird.saveReceivedDataIntoSumadhuClosingBalByProduct(irdto, site_id);
								//27-July-2017 added by Madhu end




							}
							else {
								request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Receive.");
								//viewToBeSelected = "indentReceiveResponse";
								//transactionManager.rollback(status);
								return result = "Failed";
							}
							count++;
						}
						String strUserName  = String.valueOf(session.getAttribute("UserName"));
						SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");//dd/MM/yyyy
						Date now = new Date();
						String strDate = sdfDate.format(now);

						tblOneData.append(gstinNumber+"@@"+changeDateFormat(grnDate)+"@@"+invoiceNumber+"@@"+invoiceDate+"@@"+"Sumadhura"+"@@"+strcontotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+vendorAddress+"@@"+grn_no+"@@"+poNo+"@@"+dcNo+"@@"+vendorName+"@@"+poDate+"@@"+eWayBillNo+"@@"+vehileNo+"@@"+transporterName+"@@"+doubleSumOfOtherCharges+"@@"+receviedDate+"@@"+strroundoff+"@@"+strcongrdtotal+"@@"+strUserName+"@@"+strDate);

						viewGrnPageDataMap.put("tblOneData", tblOneData.toString());
						//start 03-sept
						String NamesOfCharges = tblCharges.toString().substring(0, tblCharges.toString().length() - 2);;
						viewGrnPageDataMap.put("NamesOfCharges", NamesOfCharges);
						//end 03-sept

						String fnlStr = tblTwoData.toString().substring(0, tblTwoData.toString().length() - 2);
						viewGrnPageDataMap.put("tblTwoData", fnlStr);
						request.setAttribute("viewGrnPageData", viewGrnPageDataMap);
						//transactionManager.commit(status);
					}
					else {
						request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Receive.");
						//viewToBeSelected = "indentReceiveResponse";
						//transactionManager.rollback(status);
						return result = "Failed";
					}

				}//invoice validation
				else {
					request.setAttribute("exceptionMsg", "This Invoice already exist");
					//viewToBeSelected = "indentReceiveResponse";
					//transactionManager.rollback(status);
					return result = "Failed";
				}
			}


			//invoice trans charges need to save

			else {
				request.setAttribute("exceptionMsg", "Sorry!, No Records Were Found To Be Processed.");
				//viewToBeSelected = "indentReceiveResponse";
				//transactionManager.rollback(status);
				//return result = "Failed";
			}
		}
		catch (Exception e) {
			//transactionManager.rollback(status);
			request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Receive.");
			//viewToBeSelected = "indentReceiveResponse";
			result = "Failed";
		/*	AuditLogDetailsBean auditBean = new AuditLogDetailsBean();
			auditBean.setEntryDetailsId(String.valueOf(indentEntrySeqNum));
			auditBean.setLoginId(userId);
			auditBean.setOperationName("New Recive");
			auditBean.setStatus("error");
			auditBean.setSiteId(site_id);
			new SaveAuditLogDetails().saveAuditLogDetails(auditBean);*/
			e.printStackTrace();
		}
		//logger.info("Final View To Be Selected = "+viewToBeSelected);
		return result+"@@"+imgname;
	}

	public String changeDateFormat(Date date) {

		String returnDate = "";

		try {
			returnDate = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss").format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return returnDate;
	}
	@Override
	public String loadProductAvailability(String prodId, String subProductId, String childProdId, String measurementId, HttpServletRequest request, HttpSession session) {
		return ird.getProductAvailability(prodId, subProductId, childProdId, measurementId, String.valueOf(request.getSession(true).getAttribute("SiteId").toString()));
	}

	@Override
	public void saveReciveDetailsIntoSumadhuraCloseBalance(
			IndentReceiveDto irdto, String siteId) {

	}

	@Override
	public void saveReceivedDataIntoSumadhuClosingBalByProduct(
			IndentReceiveDto irdto, String siteId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Map<String, String> getOtherCharges() {

		return ird.getOtherCharges();
	}



	@Override
	public void saveTransactionDetails(String invoiceNum, String transactionId,
			String gstId, String gstAmount, String totAmtAfterGSTTax,
			String transactionInvoiceId, String transAmount, String siteId,
			String indentEntrySeqNum) {

	}
	
	public int getInvoiceCount(String  strInvoiceNmber, String vendorId, String receiveDate){
		String strReceiveStartDate  = validateParams.getProperty("INDENTRECSTARTDT") == null ? "" : validateParams.getProperty("INDENTRECSTARTDT").toString();
		int intCount = ird.getInvoiceCount(strInvoiceNmber, vendorId, strReceiveStartDate, receiveDate);
		return intCount;
	}
	
	public int isInvoicesaved(HttpServletRequest request){
		String invoiceNumber = request.getParameter("InvoiceNumber");
		String vendorId = request.getParameter("VendorId");
		String receviedDate = request.getParameter("receivedDate");
		//String strReceiveStartDate  = validateParams.getProperty("INDENTRECSTARTDT") == null ? "" : validateParams.getProperty("INDENTRECSTARTDT").toString();
		int intCount = ird.getInvoiceSaveCount(  invoiceNumber,  vendorId, receviedDate);
		logger.info("Indent_entry id "+intCount +"invoice no "+invoiceNumber);
		return intCount;
	}

	@Override
	public List<Map<String, Object>> getListOfActivePOs(String site_id) {
		return ird.getListOfActivePOs(site_id);
	}
	@Override
	public List<ProductDetails> getPODetails(String poNumber, String reqSiteId) {
		return ird.getPODetails(poNumber, reqSiteId);
	}
	@Override
	public List<ProductDetails> getProductDetailsLists(String poNumber,String reqSiteId) {
		return ird.getProductDetailsLists(poNumber,reqSiteId);
	}
	@Override
	public List<ProductDetails> getTransChrgsDtls(String poNumber,String reqSiteId) {
		return ird.getTransChrgsDtls(poNumber,reqSiteId);
	}
	
	@Override
	public String processingPOasInvoice(Model model, HttpServletRequest request, HttpSession session) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in InRe_proPOI, ");
		Map<String,String> map = new HashMap<String,String>();
		List<Map<String,String>> transMapList = new ArrayList<Map<String,String>>();
		List<Map<String,String>> prodMapList = new ArrayList<Map<String,String>>();
		String finalresponse = "Failed@@_";
		try{
			WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , PONumber:"+request.getParameter("poNo")+" , InvoiceNumber:"+request.getParameter("InvoiceorDCNumber"));

			String recordsCount = request.getParameter("numbeOfRowsToBeProcessed");
			
			map.put("poNo",request.getParameter("poNo"));
			map.put("invoiceNumber",request.getParameter("InvoiceorDCNumber"));
			map.put("invoiceDate",request.getParameter("InvoiceorDCDate"));
			map.put("vendorName",request.getParameter("vendorName"));
			map.put("vendorId",request.getParameter("VendorId"));
			map.put("vendorAddress",request.getParameter("vendorAddress"));
			map.put("gstinNumber",request.getParameter("strGSTINNumber"));
			map.put("note",request.getParameter("Note"));
			map.put("state",request.getParameter("state"));
			map.put("ttlAmntForIncentEntryTbl",request.getParameter("ttlAmntForIncentEntry"));
			map.put("poDate",request.getParameter("poDate"));
			map.put("eWayBillNo",request.getParameter("eWayBillNo"));
			map.put("vehileNo",request.getParameter("vehileNo"));
			map.put("transporterName",request.getParameter("transporterName"));
			map.put("otherChrgs",request.getParameter("otherCharges"));//quotes placed
			map.put("receviedDate",request.getParameter("receivedDate"));
			String transRows = request.getParameter("numbeOfChargesRowsToBeProcessed");
			map.put("chargesRecordsCount", transRows);
			String[] recordsCountArray = recordsCount.split("\\|1\\|");
			recordsCount = recordsCountArray[0];
			recordsCount = recordsCount + "|";
			String creditRows="";
			if(recordsCountArray.length>1){
				creditRows = recordsCountArray[1]; 
			}
			creditRows = "1|" + creditRows;
			
			map.put("creditRows", creditRows);
			
			
			String transportId ="Conveyance";
			String transportGSTPercentage = "GSTTax";
			String transportGSTAmount = "GSTAmount";
			String totalAmountAfterGSTTax = "AmountAfterTax";
			String transportInvoiceId = "TransportInvoice";
			String transportAmount = "ConveyanceAmount";

			int trans_rows = transRows.split("\\|").length;
			for(int charNum=1;charNum<=trans_rows;charNum++){
				Map<String,String> transMap = new HashMap<String,String>();
				transMap.put("transactionDts",request.getParameter(transportId+charNum));
				transMap.put("gstPercentage",request.getParameter(transportGSTPercentage+charNum));
				transMap.put("gstAmount",request.getParameter(transportGSTAmount+charNum));
				transMap.put("totAmtAfterGSTTax",request.getParameter(totalAmountAfterGSTTax+charNum));
				transMap.put("transactionInvoiceId",request.getParameter(transportInvoiceId+charNum));
				transMap.put("transAmount",request.getParameter(transportAmount+charNum));
				transMapList.add(transMap);
			}


			String prod = "mainProduct";
			String subProd = "mainSubProduct";
			String childProd = "mainChildProduct";
			String qty = "mainquantity";
			String expireDate = "mainexpireDate";
			String price = "mainPrice";
			String basicAmount = "mainamtAfterDiscount";
			String measurements = "mainUnitsOfMeasurement";				
			String gstTax = "maintax";
			String hsnCode = "mainhsnCode";
			String taxAmount = "maintaxAmount";				
			String amountAfterTax = "mainamountAfterTax";				
			String otherOrTransportCharges = "mainotherOrTransportCharges";				
			String taxOnOtherOrTransportCharges = "maintaxOnOtherOrTransportCharges";				
			String otherOrTransportChargesAfterTax = "mainotherOrTransportChargesAfterTax";				
			String totalAmount = "maintotalAmount";
			String otherCharges = "mainOtherCharges";
			
			
			String recordsCountModified = "";
			int records_Count = recordsCount.split("\\|").length;
			String[] records_Array = recordsCount.split("\\|");
			for(int index=0;index<records_Count;index++){
				int num=Integer.parseInt(records_Array[index]);
				Map<String,String> prodMap = new HashMap<String,String>();
				prodMap.put("product",request.getParameter(prod+num));					
				prodMap.put("subProduct",request.getParameter(subProd+num));
				prodMap.put("expiryDate",request.getParameter(expireDate+num));
				prodMap.put("childProduct",request.getParameter(childProd+num));
				prodMap.put("quantity",request.getParameter(qty+num));
				prodMap.put("prc",request.getParameter(price+num));
				prodMap.put("basicAmnt",request.getParameter(basicAmount+num));
				prodMap.put("unitsOfMeasurement",request.getParameter(measurements+num));
				prodMap.put("tax",request.getParameter(gstTax+num));
				prodMap.put("hsnCd",request.getParameter(hsnCode+num));
				prodMap.put("taxAmnt",request.getParameter(taxAmount+num));
				prodMap.put("amntAfterTax",request.getParameter(amountAfterTax+num));
				prodMap.put("otherOrTranportChrgs",request.getParameter(otherOrTransportCharges+num));
				prodMap.put("taxOnOtherOrTranportChrgs",request.getParameter(taxOnOtherOrTransportCharges+num));
				prodMap.put("otherOrTransportChrgsAfterTax",request.getParameter(otherOrTransportChargesAfterTax+num));
				prodMap.put("totalAmnt",request.getParameter(totalAmount+num));
				prodMap.put("otherChrgss",request.getParameter("otherChrgs"+num));//quotes placed
				prodMap.put("remarks",request.getParameter("InvoiceRemarks"+num));
				prodMap.put("indentCreationDetailsId",request.getParameter("mainindentCreationDetailsId"+num));	
				prodMap.put("poEntryDetailsId",request.getParameter("mainPoEntryDetailsId"+num));	
				
				prodMapList.add(prodMap);
				recordsCountModified=recordsCountModified+(index+1)+"|";
			}
		//	System.out.println(map);
		//	System.out.println(transMapList);
		//	System.out.println(prodMapList);
			map.put("recordsCount",recordsCountModified);
			
			String indentNumber = request.getParameter("indentNumber");
			String reqSiteId = request.getParameter("toSiteId");
			String poNo = map.get("poNo");

			//============================

			String response1 = indentProcessCommmon(map,transMapList,prodMapList,request,session);

			//============================
			String[] response_array = response1.split("@@");
			String response = response_array [0];
			String response2 = "Failed";

			//String response = "Success",response1 = "Success",response2 = "Success"; //remove this line
			if (response.equalsIgnoreCase("Success")){
				try {
					//doing Credit Note
					if(request.getParameter("ChildProduct1")!=null){
					doCreditNote(map,request);
					}
					else{
						System.out.println("credit not done");
					}
					
				
				
					
					for(Map<String,String> productMap:prodMapList){
						String childProduct = productMap.get("childProduct");
						String childProdsInfo[] = childProduct.split("\\$");					
						String childProdId = childProdsInfo[0];
						double creditQuantity = request.getAttribute(childProdId)==null ? 0.0 : Double.parseDouble(request.getAttribute(childProdId).toString());
						double takenQuantity = Double.parseDouble(productMap.get("quantity").toString());
						String totalQuantity = String.valueOf(creditQuantity+takenQuantity);
						
						ird.updateReceiveQuantityInIndentCreationDtls(totalQuantity,productMap.get("indentCreationDetailsId"));
						ird.updateAllocatedQuantityInPurchaseDeptTable(totalQuantity,productMap.get("indentCreationDetailsId"),request);
						ird.updateReceivedQuantityInPoEntryDetails(totalQuantity,productMap.get("poEntryDetailsId"));
					}
					ird.setPOInactive(poNo,reqSiteId);
					
					ird.setIndentInactiveAfterChecking(indentNumber);
					String creditNoteNumber = request.getParameter("creditNoteNumber");
					String creditTotalAmount = request.getParameter("creditTotalAmount");
					String indentEntryNo = request.getAttribute("indentEntryNo").toString();
					String site_id = String.valueOf(session.getAttribute("SiteId"));
					ird.updateInvoiceNoInAccPaymentTbl(map.get("invoiceNumber"),map.get("ttlAmntForIncentEntryTbl"),map.get("invoiceDate"),map.get("receviedDate"),map.get("poNo"),map.get("vendorId"),creditNoteNumber,creditTotalAmount,indentEntryNo,site_id);
					response2 = "Success";
				} catch (Exception e) {
					response2 = "Failed";
					e.printStackTrace();
				}
				
			}else{}
			if(response2.equalsIgnoreCase("Success")){
				transactionManager.commit(status);
				WriteTrHistory.write("Tr_Completed");
				finalresponse = response1;
			}
			else{
				transactionManager.rollback(status);
				WriteTrHistory.write("Tr_Completed");
				finalresponse = "Failed@@_";
			}
			//===============================
		}
		catch(Exception e){
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			finalresponse = "Failed@@_";
			e.printStackTrace();
		}
		return finalresponse;
	
	}

	public void doCreditNote(Map<String, String> map, HttpServletRequest request){
		int creditSeqNo = ird.getCreditNoteSequenceNumber();
		String creditNoteNumber = request.getParameter("creditNoteNumber");
		String indentEntryNo = request.getAttribute("indentEntryNo").toString();
		String invoiceNumber = map.get("invoiceNumber");
		String creditTotalAmount = request.getParameter("creditTotalAmount");
		CreditNoteDto creditNoteDto = new CreditNoteDto();
		creditNoteDto.setCreditSeqNo(creditSeqNo);
		creditNoteDto.setCreditNoteNumber(creditNoteNumber);
		creditNoteDto.setIndentEntryId(indentEntryNo);
		creditNoteDto.setInvoiceNumber(invoiceNumber);
		creditNoteDto.setCreditTotalAmount(creditTotalAmount);
		ird.insertCreditNote(creditNoteDto);
		
		String creditRows = map.get("creditRows");
		int creditRowsCount = creditRows.split("\\|").length;
		for(int num=1;num<=creditRowsCount;num++)
		{
			int creditNoteDtlsSeqId = ird.getCreditNoteDetailsSequenceNumber();
			CreditNoteDto creditNoteDetailsDto = new CreditNoteDto();
			creditNoteDetailsDto.setCreditNoteDtlsSeqId(creditNoteDtlsSeqId);
			creditNoteDetailsDto.setCreditSeqNo(creditSeqNo);
			creditNoteDetailsDto.setIndentEntryId(indentEntryNo);

			String product = request.getParameter("Product"+num);
			String productId = product.split("\\$")[0];
			String sub_Product = request.getParameter("SubProduct"+num);
			String sub_ProductId = sub_Product.split("\\$")[0];
			String child_Product = request.getParameter("ChildProduct"+num);
			String child_ProductId = child_Product.split("\\$")[0];
			String measurement = request.getParameter("UnitsOfMeasurement"+num);
			String measurementId = measurement.split("\\$")[0];
			String recivedQty = request.getParameter("quantity"+num);
			request.setAttribute(child_ProductId, recivedQty);
			String Price = request.getParameter("PriceId"+num);
			String basicAmount = request.getParameter("BasicAmountId"+num);
			String tax = request.getParameter("TaxId"+num);
			String taxId = tax.split("\\$")[0];
			String taxAmount = request.getParameter("TaxAmountId"+num);
			String amountAfterTax = request.getParameter("AmountAfterTaxId"+num);
			String totalAmount = request.getParameter("TotalAmountId"+num);
			String hsnCode = request.getParameter("HSNCodeId"+num);
			Double OtherOrTransportCharges1 = Double.parseDouble((request.getParameter("OtherOrTransportChargesId"+num)==null||request.getParameter("OtherOrTransportChargesId"+num).equals(""))?"0":request.getParameter("OtherOrTransportChargesId"+num));
			Double TaxOnOtherOrTransportCharges1 = Double.parseDouble((request.getParameter("TaxOnOtherOrTransportChargesId"+num)==null||request.getParameter("TaxOnOtherOrTransportChargesId"+num).equals(""))?"0":request.getParameter("TaxOnOtherOrTransportChargesId"+num));
			Double OtherOrTransportChargesAfterTax1 = Double.parseDouble((request.getParameter("OtherOrTransportChargesAfterTaxId"+num)==null||request.getParameter("OtherOrTransportChargesAfterTaxId"+num).equals(""))?"0":request.getParameter("OtherOrTransportChargesAfterTaxId"+num));

			ProductDetails productDetails = new ProductDetails();
			productDetails.setProductId(productId);
			productDetails.setSub_ProductId(sub_ProductId);
			productDetails.setChild_ProductId(child_ProductId);
			productDetails.setMeasurementId(measurementId);
			productDetails.setRecivedQty(recivedQty);
			productDetails.setPrice(Price);
			productDetails.setBasicAmt(basicAmount);
			productDetails.setTax(taxId);
			productDetails.setTaxAmount(taxAmount);
			productDetails.setAmountAfterTax(amountAfterTax);
			productDetails.setTotalAmount(totalAmount);
			productDetails.setHsnCode(hsnCode);
			productDetails.setOtherOrTransportCharges1(OtherOrTransportCharges1);
			productDetails.setTaxOnOtherOrTransportCharges1(TaxOnOtherOrTransportCharges1);
			productDetails.setOtherOrTransportChargesAfterTax1(OtherOrTransportChargesAfterTax1);
			ird.insertCreditNoteDetails(creditNoteDetailsDto,productDetails);
		}
	}

	@Override
	public String getPriceRatesByChildProduct(String childProdId, String poNumber, String reqSiteId) {
		return ird.getPriceRatesByChildProduct( childProdId,  poNumber,  reqSiteId);
	}

	@Override
	public int checkPOisActive(String poNumber) {
		return ird.checkPOisActive(poNumber);
	}
	
	public int getCheckIndentAvailable(String  indentNumber){
		
		 
		return ird.getCheckIndentAvailable(indentNumber);
	}
	@Override
	public int getCheckPoAvailable(String poNumber,String vendorId) {
		return ird.getCheckPoAvailable(poNumber,vendorId);
	}
	
	
}
