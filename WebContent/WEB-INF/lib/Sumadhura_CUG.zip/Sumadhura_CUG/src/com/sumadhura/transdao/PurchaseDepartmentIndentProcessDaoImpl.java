package com.sumadhura.transdao;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.sumadhura.bean.GetInvoiceDetailsBean;
import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.dto.IndentCreationDetailsDto;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.dto.TransportChargesDto;
import com.sumadhura.util.DBConnection;
import com.sumadhura.util.DateUtil;
import com.sumadhura.util.NumberToWord;
import com.sumadhura.util.UIProperties;


@Repository("purchaseDeptIndentrocessDao")
public class PurchaseDepartmentIndentProcessDaoImpl extends UIProperties implements PurchaseDepartmentIndentProcessDao{

	static Logger log = Logger.getLogger(DCFormDaoImpl.class);
	@Autowired(required = true)
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	CentralSiteIndentProcessDao cntlIndentrocss;


	@Override
	public List<IndentCreationDto> getPendingIndents(String pendingEmpId,String strSiteId) {
		List<Map<String, Object>> dbIndentDts = null;
		List<IndentCreationDto> list = new ArrayList<IndentCreationDto>();
		IndentCreationDto indentObj = null; 

		String query = "SELECT SITEWISE_INDENT_NO,INDENT_CREATION_ID, CREATE_DATE, SCHEDULE_DATE, REQUIRED_DATE FROM SUMADHURA_INDENT_CREATION where PENDING_EMP_ID = ? AND STATUS = 'A' ";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {
				pendingEmpId
		});
		for(Map<String, Object> prods : dbIndentDts) {
			indentObj = new IndentCreationDto();

			indentObj.setIndentNumber(Integer.parseInt(prods.get("INDENT_CREATION_ID")==null ? "0" :   prods.get("INDENT_CREATION_ID").toString()));
			indentObj.setSiteWiseIndentNo(Integer.parseInt(prods.get("SITEWISE_INDENT_NO")==null ? "0" :   prods.get("SITEWISE_INDENT_NO").toString()));
			String strCreateDate = prods.get("CREATE_DATE")==null ? "0000-00-00 00:00:00.000" : prods.get("CREATE_DATE").toString();
			String strScheduleDate = prods.get("SCHEDULE_DATE")==null ? "0000-00-00 00:00:00.000" : prods.get("SCHEDULE_DATE").toString();
			String strRequiredDate = prods.get("REQUIRED_DATE")==null ? "0000-00-00 00:00:00.000" : prods.get("REQUIRED_DATE").toString();
			try {
				indentObj.setCreateDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(strCreateDate));
				indentObj.setScheduleDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(strScheduleDate));
				indentObj.setRequiredDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(strRequiredDate));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			list.add(indentObj);
		}

		return list;
	}



	@Override
	public List<IndentCreationBean> getIndentCreationDetailsLists(int indentNumber) {
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		List<Map<String, Object>> dbIndentDts = null;
		int strSerialNumber = 0;
		String strRemarks = "";
		String strdetailedRemarks = "";
		String dbRemarks="";
		Date myDate = new Date();
		String requesteddate = new SimpleDateFormat("dd-MMM-YY").format(myDate);
		String siteIdQuery = "SELECT SITE_ID FROM SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID = "+indentNumber; 
		String siteId = jdbcTemplate.queryForObject(siteIdQuery, String.class);

		String query ="SELECT P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,"+
				"SICD.PRODUCT_ID,SICD.SUB_PRODUCT_ID,SICD.CHILD_PRODUCT_ID,SICD.MEASUREMENT_ID,"+
				"SICD.REQ_QUANTITY,SICD.AVAIL_QUANTITY_AT_CREATION,SICD.REMARKS,SICD.INDENT_CREATION_DETAILS_ID,SICD.RECEIVE_QUANTITY,"
				+ "(select PO_INTIATED_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP where SPDIP.INDENT_CREATION_DETAILS_ID=SICD.INDENT_CREATION_DETAILS_ID)AS PO_INIT_QUANTITY, "
				+"(select TYPE_OF_PURCHASE from SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP where SPDIP.INDENT_CREATION_DETAILS_ID=SICD.INDENT_CREATION_DETAILS_ID)AS TYPE_OF_PURCHASE "
				+ " FROM SUMADHURA_INDENT_CREATION_DTLS SICD, PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST "+
				"WHERE SICD.PRODUCT_ID=P.PRODUCT_ID AND SICD.SUB_PRODUCT_ID=SP.SUB_PRODUCT_ID AND SICD.CHILD_PRODUCT_ID=CP.CHILD_PRODUCT_ID "+
				"AND SICD.MEASUREMENT_ID=MST.MEASUREMENT_ID  AND SICD.INDENT_CREATION_ID= ? order by SICD.INDENT_CREATION_DETAILS_ID";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
		for(Map<String, Object> prods : dbIndentDts) {
			IndentCreationBean indentCreationBean = new IndentCreationBean();
			String prodId = prods.get("PRODUCT_ID")==null ? "" :   prods.get("PRODUCT_ID").toString();
			String subProductId = prods.get("SUB_PRODUCT_ID")==null ? "" :   prods.get("SUB_PRODUCT_ID").toString();
			String childProdId = prods.get("CHILD_PRODUCT_ID")==null ? "" :   prods.get("CHILD_PRODUCT_ID").toString();
			String measurementId = prods.get("MEASUREMENT_ID")==null ? "" :   prods.get("MEASUREMENT_ID").toString();

			indentCreationBean.setProductId1(prodId);
			indentCreationBean.setSubProductId1(subProductId);
			indentCreationBean.setChildProductId1(childProdId);
			indentCreationBean.setUnitsOfMeasurementId1(measurementId);
			indentCreationBean.setProduct1(prods.get("PRODUCT_NAME")==null ? "" :   prods.get("PRODUCT_NAME").toString());
			indentCreationBean.setSubProduct1(prods.get("SUB_PRODUCT_NAME")==null ? "" :   prods.get("SUB_PRODUCT_NAME").toString());
			indentCreationBean.setChildProduct1(prods.get("CHILD_PRODUCT_NAME")==null ? "" :   prods.get("CHILD_PRODUCT_NAME").toString());
			indentCreationBean.setUnitsOfMeasurement1(prods.get("MEASUREMENT_NAME")==null ? "" :   prods.get("MEASUREMENT_NAME").toString());
			indentCreationBean.setRequiredQuantity1(prods.get("REQ_QUANTITY")==null ? "" :   prods.get("REQ_QUANTITY").toString());
			indentCreationBean.setProductAvailability1(prods.get("AVAIL_QUANTITY_AT_CREATION")==null ? "0" :   prods.get("AVAIL_QUANTITY_AT_CREATION").toString());
			indentCreationBean.setReceivedQuantity(prods.get("RECEIVE_QUANTITY")==null ? "0" :   prods.get("RECEIVE_QUANTITY").toString());
			indentCreationBean.setPoIntiatedQuantity(prods.get("PO_INIT_QUANTITY")==null ? "0" :   prods.get("PO_INIT_QUANTITY").toString());
			indentCreationBean.setType_Of_Purchase(prods.get("TYPE_OF_PURCHASE")==null ? "-" :   prods.get("TYPE_OF_PURCHASE").toString());

			/**/


			//As per rafi code this is not available 

			/*String dbProductAvailability = "";	
			String indentAvaQry = "SELECT  SUM(AVAILABLE_QUANTITY) FROM SUMADHURA_PRICE_LIST  WHERE PRODUCT_ID = ? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID = ? AND UNITS_OF_MEASUREMENT = ? AND SITE_ID = ? AND CREATED_DATE<= TO_DATE(?,'dd-MM-yy')";
			dbProductAvailability = jdbcTemplate.queryForObject(indentAvaQry, new Object[] {
					prodId,
					subProductId,
					childProdId,
					measurementId,siteId,requesteddate

			},String.class

			);

			if( dbProductAvailability == null || dbProductAvailability.equals("") ){

				dbProductAvailability = "0";
			}




			indentCreationBean.setProductAvailability1(dbProductAvailability);*/

			/**/
			strRemarks = prods.get("REMARKS")==null ? "" :   prods.get("REMARKS").toString();
			dbRemarks=strRemarks;
			indentCreationBean.setRemarks(dbRemarks);

			if(strRemarks.contains("@@@")){
				String strRemarksArr[] = strRemarks.split("@@@");

				for(int i =0 ; i< strRemarksArr.length;i++){

					strdetailedRemarks += " "+(i+1)+". "+strRemarksArr [i];

				}
				strRemarks = strdetailedRemarks;
			}
			strdetailedRemarks = "";

			//	strRemarks=HtmlUtils.htmlEscape(strRemarks);
			indentCreationBean.setRemarks1(strRemarks);
			//indentCreationBean.setRemarks1(prods.get("REMARKS")==null ? "" :   prods.get("REMARKS").toString());
			indentCreationBean.setIndentCreationDetailsId(Integer.parseInt(prods.get("INDENT_CREATION_DETAILS_ID")==null ? "" :   prods.get("INDENT_CREATION_DETAILS_ID").toString()));
			strSerialNumber++;
			indentCreationBean.setStrSerialNumber(String.valueOf(strSerialNumber));
			list.add(indentCreationBean);
		}	
		return list;
	}



	@Override
	public int insertTempPOEntryDetails(ProductDetails productDetails,String poEntrySeqNo)
	{
		String query = "INSERT INTO SUMADHURA_TEMP_PO_ENTRY_DTLS(PO_ENTRY_DETAILS_ID,PO_ENTRY_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,"+
		"MEASUR_MNT_ID, PO_QTY,ENTRY_DATE,PRICE,BASIC_AMOUNT,TAX,TAX_AMOUNT,AMOUNT_AFTER_TAX,OTHER_CHARGES,OTHER_CHARGES_AFTER_TAX,TOTAL_AMOUNT,HSN_CODE,TAX_ON_OTHER_TRANSPORT_CHG,DISCOUNT,AMOUNT_AFTER_DISCOUNT,INDENT_CREATION_DTLS_ID,VENDOR_PRODUCT_DESC,PD_PRODUCT_DESC"
		+ ") values(SUMADHURA_T_PO_ENTRY_DTLS_SEQ.nextval, ?, ?, ?, ?, ?, ?,sysdate, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

		int result = jdbcTemplate.update(query, new Object[] {
				poEntrySeqNo,
				productDetails.getProductId(),productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),productDetails.getMeasurementId(),
				productDetails.getQuantity(),productDetails.getPricePerUnit(),productDetails.getBasicAmt(),
				productDetails.getTax(),
				productDetails.getTaxAmount(),productDetails.getAmountAfterTax(),"0","0",
				productDetails.getTotalAmount(),productDetails.getHsnCode(),"0",
				productDetails.getStrDiscount(),productDetails.getStrAmtAfterDiscount(),
				productDetails.getIndentCreationDetailsId(),productDetails.getChildProductCustDisc(),productDetails.getChild_ProductName()

		});
		return result;
	}
	@Override
	public int insertPOEntryDetails(ProductDetails productDetails,int poEntrySeqNo)
	{
		String query = "INSERT INTO SUMADHURA_PO_ENTRY_DETAILS(PO_ENTRY_DETAILS_ID,PO_ENTRY_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,"+
		"MEASUR_MNT_ID, PO_QTY,ENTRY_DATE,PRICE,BASIC_AMOUNT,TAX,TAX_AMOUNT,AMOUNT_AFTER_TAX,OTHER_CHARGES,OTHER_CHARGES_AFTER_TAX,TOTAL_AMOUNT,HSN_CODE,TAX_ON_OTHER_TRANSPORT_CHG,DISCOUNT,AMOUNT_AFTER_DISCOUNT,INDENT_CREATION_DTLS_ID,VENDOR_PRODUCT_DESC,PD_PRODUCT_DESC"
		+ ") values(SUMADHURA_PO_ENTRY_DTLS_SEQ.nextval, ?, ?, ?, ?, ?, ?,sysdate, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

		int result = jdbcTemplate.update(query, new Object[] {
				poEntrySeqNo,
				productDetails.getProductId(),productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),productDetails.getMeasurementId(),
				productDetails.getQuantity(),productDetails.getPricePerUnit(),productDetails.getBasicAmt(),
				productDetails.getTax(),
				productDetails.getTaxAmount(),productDetails.getAmountAfterTax(),
				productDetails.getOtherOrTransportCharges1(),productDetails.getOtherOrTransportChargesAfterTax1(),
				productDetails.getTotalAmount(),productDetails.getHsnCode(),productDetails.getTaxOnOtherOrTransportCharges1(),
				productDetails.getStrDiscount(),productDetails.getStrAmtAfterDiscount(),
				productDetails.getIndentCreationDetailsId(),productDetails.getChildProductCustDisc(),productDetails.getChild_ProductName()

		});
		return result;
	}







	@Override
	public int updateEnquiryFormDetails(ProductDetails productDetails)
	{

		String query =  "update SUMADHURA_ENQUIRY_FORM_DETAILS set VENDOR_MENTIONED_QTY = ?, PRICE = ?, TAX= ?,TAX_AMOUNT = ?,AMOUNT_AFTER_TAX = ?, "+
		" OTHER_CHARGES = ?,OTHER_CHARGES_AFTER_TAX = ?,TOTAL_AMOUNT = ?,HSN_CODE = ?,BASIC_AMOUNT = ?,TAX_ON_OTHER_TRANSPORT_CHG = ?,"+
		" DISCOUNT = ?,AMOUNT_AFTER_DISCOUNT = ?,CHILDPROD_CUST_DESC = ? where INDENT_CREATION_DETAILS_ID = ? and VENDOR_ID = ? ";

		int result = jdbcTemplate.update(query, new Object[] {

				productDetails.getQuantity(),productDetails.getPricePerUnit(),productDetails.getTaxId(),
				productDetails.getTaxAmount(),productDetails.getAmountAfterTax(),productDetails.getOtherOrTransportCharges1(),productDetails.getOtherOrTransportChargesAfterTax1(),
				productDetails.getTotalAmount(),productDetails.getHsnCode(),productDetails.getBasicAmt(),productDetails.getTaxOnOtherOrTransportCharges1(),
				productDetails.getStrDiscount(),productDetails.getStrAmtAfterDiscount(),

				productDetails.getChildProductCustDisc(),productDetails.getIndentCreationDetailsId(),
				productDetails.getVendorId()


		});
		return result;
	}

	public int getCountInEnquiry(int indentCreationDetailsId,String vendorId ){
		String query  = "select count(1) from  SUMADHURA_ENQUIRY_FORM_DETAILS where INDENT_CREATION_DETAILS_ID = ? and VENDOR_ID = ? ";
		int intCount =    jdbcTemplate.queryForInt(query, new Object[] {indentCreationDetailsId,vendorId});
		return intCount;
	}

	@Override
	public int insertVendorEnquiryFormDetails(IndentCreationBean indentCreationBean)
	{
		int count = getCountInEnquiry(indentCreationBean.getIndentCreationDetailsId(),indentCreationBean.getVendorId());
		if(count>0){
			String query = "UPDATE SUMADHURA_ENQUIRY_FORM_DETAILS set INDENT_QTY = ? ,"+
			" PURCHASE_DEPT_CHILD_PROD_DISC = ?  where INDENT_CREATION_DETAILS_ID = ? and VENDOR_ID = ?  ";

			int result = jdbcTemplate.update(query, new Object[] {
					indentCreationBean.getRequiredQuantity1(),
					indentCreationBean.getPurchaseDeptChildProdDisc(),indentCreationBean.getIndentCreationDetailsId(),
					indentCreationBean.getVendorId()


			});
			return result;
		}
		else{
			String query = "INSERT INTO SUMADHURA_ENQUIRY_FORM_DETAILS(ENQUIRY_FORM_DETAILS_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,"+
			"MEASUREMENT_ID, INDENT_QTY,ENTRY_DATE,"+
			" VENDOR_ID ,SITE_ID, INDENT_NO,PURCHASE_DEPT_CHILD_PROD_DISC,INDENT_CREATION_DETAILS_ID) "+
			"values(?, ?, ?, ?, ?, ?,sysdate, ?, ?, ?,?,?)";

			int result = jdbcTemplate.update(query, new Object[] {
					indentCreationBean.getEnquiryFormDetailsId(),
					indentCreationBean.getProductId1(),indentCreationBean.getSubProductId1(),
					indentCreationBean.getChildProductId1(),indentCreationBean.getUnitsOfMeasurementId1(),
					indentCreationBean.getRequiredQuantity1(),
					indentCreationBean.getVendorId(),indentCreationBean.getSiteId(),indentCreationBean.getIndentNumber(),
					indentCreationBean.getPurchaseDeptChildProdDisc(),indentCreationBean.getIndentCreationDetailsId()


			});
			return result;
		}

	}




	@Override
	public int getEnquiryFormDetailsId()
	{
		int enquiryFormSeqId = 0;

		String query = "select SUM_ENQUIRY_FORM_DETAILS_SEQ.nextval from dual";

		enquiryFormSeqId = jdbcTemplate.queryForInt(query);


		return enquiryFormSeqId;

	}

	@Override
	public List<Map<String, Object>> getVendorOrSiteAddress(String siteId) {

		List<Map<String, Object>> dbIndentDts = null;
		String query = "select VENDOR_NAME,STATE,ADDRESS,MOBILE_NUMBER,GSIN_NUMBER,VENDOR_CON_PER_NAME,LANDLINE_NO,EMP_EMAIL from VENDOR_DETAILS where VENDOR_ID = ?";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {siteId});
		return dbIndentDts;
	}


	@Override
	public int updatePurchaseDeptIndentProcesstbl(double intQuantity,int intIndentCreationDetailsId,String strStatus) {



		double poIntiatedQuantity  = 0.0;
		List<Map<String, Object>> dbIndentDts = null;
		List<IndentCreationDto> list = new ArrayList<IndentCreationDto>();
		IndentCreationDto indentObj = null; 

		String query = "select PO_INTIATED_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS where INDENT_CREATION_DETAILS_ID = ?";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {
				intIndentCreationDetailsId
		});
		for(Map<String, Object> prods : dbIndentDts) {
			//indentObj = new IndentCreationDto();

			poIntiatedQuantity  = Double.valueOf(prods.get("PO_INTIATED_QUANTITY")==null ? "0" :   prods.get("PO_INTIATED_QUANTITY").toString());

		} 



		/*String query = "select PO_INTIATED_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS where INDENT_CREATION_DETAILS_ID = ?";

		double poIntiatedQuantity = jdbcTemplate.queryForInt(query, new Object[] {intIndentCreationDetailsId});
		 */
		poIntiatedQuantity = poIntiatedQuantity+intQuantity;

		poIntiatedQuantity = Double.parseDouble(new DecimalFormat("##.##").format(poIntiatedQuantity));
		String strPoIntiatedQuantity = String.valueOf(poIntiatedQuantity);
		

		query = "update SUM_PURCHASE_DEPT_INDENT_PROSS set " +
		"PO_INTIATED_QUANTITY = ?,STATUS=?"+
		" where INDENT_CREATION_DETAILS_ID = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				strPoIntiatedQuantity,strStatus,intIndentCreationDetailsId
		});
		return result;

	}

	@Override
	public List<Map<String, Object>> getAllProducts(String purchaseDeptId) {
		List<Map<String, Object>> dbIndentDts = null;
		String query = "SELECT distinct(P.PRODUCT_ID),P.NAME as PRODUCT_NAME FROM PRODUCT P, SUMADHURA_INDENT_CREATION_DTLS SICD, SUMADHURA_INDENT_CREATION SIC "+
		"WHERE SIC.INDENT_CREATION_ID = SICD.INDENT_CREATION_ID "+
		"AND SIC.PENDIND_DEPT_ID = ? AND SIC.STATUS = 'A' "+
		"AND SICD.PRODUCT_ID = P.PRODUCT_ID ";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {purchaseDeptId});
		return dbIndentDts;
	}

	/*@Override
	public int getPoEnterSeqNoOrMaxId(){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String intSeqNum = "select max(PO_NUMBER) from SUMADHURA_PO_ENTRY";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result+1;
	}*/


	public int getPoEnterSeqNoOrMaxId(String poState){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String intSeqNum = "select YEARWISE_NUMBER from SUMADHURA_HO_WISE_PO_NUMBER where SERVICE_NAME='"+poState+"' ";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result;
	}

	public String getSiteWisePoNumber(String siteWise_Number) {
		String query = "SELECT SITE_WISE_NUMBER FROM SUMADHURA_SITE_WISE_PO_NUMBER where SITE_ID = '"+siteWise_Number+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return result;

	}

	public String getStateWiseYearPoNumber(String siteWise_Number) {
		String query = "SELECT YEARWISE_NUMBER FROM SUMADHURA_SITE_WISE_PO_NUMBER where SITE_ID = '"+siteWise_Number+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return result;

	}







	@Override
	public int getPoEnterSeqNo(){

		String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		//String intSeqNum = "select max(PO_ENTRY_ID) from SUMADHURA_PO_ENTRY";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result;
	}

	@Override
	public int getTempPoEnterSeqNoOrMaxId(){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String intSeqNum = "select max(PO_ENTRY_ID) from SUMADHURA_TEMP_PO_ENTRY";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result+1;
	}


	@Override
	public int getPoTransChrgsEntrySeqNo(){

		String intSeqNum = "select  SUMADHURA_PO_TRNS_CHRGS_SEQ.nextval from dual";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result;
	}

	@Override
	public int getEnquiryFormSeqNo(){

		String intSeqNum = "select  SUMADHURA_ENQUIRY_FORM_SEQ.nextval from dual";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result;
	}


	@Override
	public int insertTempPOEntry(ProductDetails productDetails,String tempuserId,String ccEmailId,String subject)

	{



		//String userId=session.getAttribute("UserId");
		//Date refferenceDate=DateUtil.convertToJavaDateFormat(productDetails.getStrPoPrintRefdate());
		//SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
		//String strPoDate=dt1.format(refferenceDate);
		String query = "INSERT INTO SUMADHURA_TEMP_PO_ENTRY(PO_ENTRY_ID,PO_NUMBER,PO_DATE,VENDOR_ID,PO_STATUS,"+
		"PO_ENTRY_USER_ID, SITE_ID,INDENT_NO,TEMP_PO_PENDING_EMP_ID,CC_EMAIL_ID,SUBJECT,BILLING_ADDRESS,VERSION_NUMBER,PO_ISSUE_DATE,REFFERENCE_NO,REVISION,OLD_PO_NUMBER,PREPARED_BY) values(? , ?, sysdate, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?)";
		int result = jdbcTemplate.update(query, new Object[] {
				productDetails.getPoNumber(),
				productDetails.getPoNumber(),
				productDetails.getVendorId(),"A",
				productDetails.getUserId(),
				productDetails.getSite_Id(),
				productDetails.getIndentNo(),tempuserId,ccEmailId,productDetails.getSubject(),productDetails.getBillingAddress(),
				productDetails.getVersionNo(),DateUtil.convertToJavaDateFormat(productDetails.getStrPoPrintRefdate()),productDetails.getRefferenceNo(),
				productDetails.getRevision_Number(),productDetails.getEdit_Po_Number(),productDetails.getPreparedBy()
				//	productDetails.getStrTermsConditionId()

		});




		return result;
	}

	@Override
	public int insertPOEntry(ProductDetails productDetails)
	{
		String query = "INSERT INTO SUMADHURA_PO_ENTRY(PO_ENTRY_ID,PO_NUMBER,PO_DATE,VENDOR_ID,PO_STATUS,"+
		"PO_ENTRY_USER_ID, SITE_ID,INDENT_NO,TERMS_CONDITIONS_ID,SUBJECT,BILLING_ADDRESS,VERSION_NUMBER,PO_ISSUE_DATE,REFFERENCE_NO,REVISION,OLD_PO_NUMBER,PREPARED_BY) values(? , ?, sysdate, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?)";
		int result = jdbcTemplate.update(query, new Object[] {
				productDetails.getPoEntryId(),
				productDetails.getPoNumber(),
				productDetails.getVendorId(),"A",
				productDetails.getUserId(),
				productDetails.getSite_Id(),
				productDetails.getIndentNo(),"0",productDetails.getSubject(),productDetails.getBillingAddress(),
				productDetails.getVersionNo(),DateUtil.convertToJavaDateFormat(productDetails.getStrPoPrintRefdate()),productDetails.getRefferenceNo(),
				productDetails.getRevision_Number(),productDetails.getEdit_Po_Number(),productDetails.getPreparedBy()

		});
		return result;
	}




	@Override
	public int insertVendorEnquiryForm(ProductDetails productDetails)
	{
		String query = "INSERT INTO SUMADHURA_ENQUIRY_FORM(ENQUIRY_FORM_ID,VENDOR_ID,"+
		" SITE_ID,INDENT_NO,ENTRY_DATE) values(?, ?, ?, ?,sysdate)";
		int result = jdbcTemplate.update(query, new Object[] {
				productDetails.getPoEntrySeqNumber(),
				productDetails.getVendorId(),
				productDetails.getSite_Id(),
				productDetails.getIndentNo()

		});
		return result;
	}

	@Override
	public List<IndentCreationBean> getupdatePurchaseDeptIndentProcess(int indentNumber,String strUserId,String siteId,String approvalEmpId,String sessionSiteId) {
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		List<Map<String, Object>> dbIndentDts = null;

		int strSerialNumber = 0;
	//	double doublePendingQuantity = 0;
	//	double doublePOIntatedQuantity = 0;
	//	String strStatus = "I";
		int responseCount = 0;
		String status="";

		String query = "  select SPDIP.PENDING_QUANTIY,SPDIP.PO_INTIATED_QUANTITY,SPDIP.STATUS  from SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP ,SUMADHURA_INDENT_CREATION SIC, "+
		"SUMADHURA_INDENT_CREATION_DTLS SICD "+
		"where  SPDIP.INDENT_CREATION_DETAILS_ID = SICD.INDENT_CREATION_DETAILS_ID and "+
		" SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID and SIC.INDENT_CREATION_ID = ? ";

		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
		for(Map<String, Object> prods : dbIndentDts) {


			status=prods.get("STATUS")==null ? "0" :   prods.get("STATUS").toString();
		//	doublePendingQuantity = Double.valueOf(prods.get("PENDING_QUANTIY")==null ? "0" :   prods.get("PENDING_QUANTIY").toString());
		//	doublePOIntatedQuantity = Double.valueOf(prods.get("PO_INTIATED_QUANTITY")==null ? "0" :   prods.get("PO_INTIATED_QUANTITY").toString());

			if(status.equals("A")){
				//strStatus = "A";
				break;
			}



			//	list.add(indentCreationBean);
		}	


		if(status.equals("I")){

			if(!approvalEmpId.equals("VND")){
				approvalEmpId = "998_PDM";
			}

			query = "	   insert into SUM_INT_CREATION_APPROVAL_DTLS(INT_CREATION_APPROVAL_DTLS_ID,INDENT_CREATION_ID,INDENT_TYPE, "+
			" CREATION_DATE,SITE_ID,INDENT_CREATE_APPROVE_EMP_ID) values(INDENT_CREATION_APPROVAL_SEQ.NEXTVAL,?,?,"+
			"sysdate,?,?)";
			jdbcTemplate.update(query, new Object[]  {indentNumber,"A",sessionSiteId,strUserId});

			query = "update SUMADHURA_INDENT_CREATION set PENDIND_DEPT_ID = ?, MODIFYDATE= sysdate where INDENT_CREATION_ID = ?";
			responseCount = jdbcTemplate.update(query, new Object[]  {approvalEmpId,indentNumber});



		}	
		jdbcTemplate.setLazyInit(false);
		return list;
	}
	@Override
	public List<ProductDetails> getIndentsProductWise(String product, String subProduct, String childProduct) {
		List<Map<String, Object>> productList = null;
		List<ProductDetails> listProductDetails  = new ArrayList<ProductDetails>();

		/*String sql = "SELECT P.PRODUCT_ID,P.NAME as PRODUCT_NAME, SP.SUB_PRODUCT_ID, SP.NAME as SUB_PRODUCT_NAME, CP.CHILD_PRODUCT_ID,CP.NAME as CHILD_PRODUCT_NAME,"+
				"M.NAME as MEASUREMENT_NAME, SICD.REQ_QUANTITY, S.SITE_NAME,SIC.INDENT_CREATION_ID "+
				"FROM SUMADHURA_INDENT_CREATION_DTLS SICD, SUMADHURA_INDENT_CREATION SIC, "+ 
				"PRODUCT P, SUB_PRODUCT SP, CHILD_PRODUCT CP, MEASUREMENT M, SITE S "+
				"WHERE "+
				"SIC.INDENT_CREATION_ID = SICD.INDENT_CREATION_ID "+
				"AND SIC.PENDIND_DEPT_ID = '998' AND SIC.STATUS = 'A' "+
				"AND SICD.PRODUCT_ID = P.PRODUCT_ID "+
				"AND SICD.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID "+
				"AND SICD.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID "+
				"AND SICD.MEASUREMENT_ID = M.MEASUREMENT_ID "+
				"AND SIC.SITE_ID = S.SITE_ID ";
		String [] prod = product.split("@@");
		String prodId = prod[0];
		String [] subProd;
		String subProdId;
		String [] childProd;
		String childProdId;
		if(subProduct.equals("@@"))
		{
			sql+="AND SICD.PRODUCT_ID = ? ";
			productList = jdbcTemplate.queryForList(sql, new Object[] { prodId });
		}
		else{
			subProd = subProduct.split("@@");
			subProdId = subProd[0];

			if(childProduct.equals("@@"))
			{
				sql+="AND SICD.PRODUCT_ID = ? "+
						"AND SICD.SUB_PRODUCT_ID = ? ";
				productList = jdbcTemplate.queryForList(sql, new Object[] { prodId, subProdId });
			}
			else
			{
				childProd = childProduct.split("@@");
				childProdId = childProd[0];
				sql+="AND SICD.PRODUCT_ID = ? "+
						"AND SICD.SUB_PRODUCT_ID = ? "+
						"AND SICD.CHILD_PRODUCT_ID = ? ";
				productList = jdbcTemplate.queryForList(sql, new Object[] { prodId, subProdId, childProdId });
			}
		}*/
		String prodId = "";
		String subProdId = "";
		String childProdId = "";


		String [] childProd;

		if(!product.equals("@@")){

			String [] prod = product.split("@@");
			prodId = prod[0];
		}

		if(!subProduct.equals("@@")){
			String [] subProd;
			subProd = subProduct.split("@@");
			subProdId = subProd[0];

		}

		if(!childProduct.equals("@@")){
			childProd = childProduct.split("@@");
			childProdId = childProd[0];

		}
		if(!prodId.equals("") && subProdId.equals("") && childProdId.equals("")){

			String sql = " SELECT SPDP.PRODUCT_ID,P.NAME as PRODUCT_NAME, SPDP.SUB_PRODUCT_ID, SP.NAME as SUB_PRODUCT_NAME, SPDP.CHILD_PRODUCT_ID, SPDP.MEASUREMENT_ID ,  CP.NAME as CHILD_PRODUCT_NAME, 	M.NAME as MEASUREMENT_NAME, SPDP.PENDING_QUANTIY, S.SITE_NAME,S.SITE_ID,SPDP.INDENT_CREATION_DETAILS_ID ,  SPDP.PURCHASE_DEPT_INDENT_PROSS_SEQ ,SIC.INDENT_CREATION_ID,SIC.SITEWISE_INDENT_NO	FROM  SUM_PURCHASE_DEPT_INDENT_PROSS SPDP,  PRODUCT P, SUB_PRODUCT SP, CHILD_PRODUCT CP, MEASUREMENT M, SITE S , SUMADHURA_INDENT_CREATION_DTLS SICD, SUMADHURA_INDENT_CREATION SIC 	WHERE   SPDP.STATUS = 'A'  AND SPDP.PRODUCT_ID = P.PRODUCT_ID  	AND SPDP.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID  AND SPDP.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID  AND SPDP.MEASUREMENT_ID = M.MEASUREMENT_ID  AND SPDP.INDENT_REQ_SITE_ID = S.SITE_ID  AND SPDP.INDENT_CREATION_DETAILS_ID = SICD.INDENT_CREATION_DETAILS_ID  AND SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID"
				+ " and SPDP.PRODUCT_ID = ? ";

			productList = jdbcTemplate.queryForList(sql, new Object[] { prodId });

		}
		if(!prodId.equals("") && !subProdId.equals("") && childProdId.equals("")){

			String sql = " SELECT SPDP.PRODUCT_ID,P.NAME as PRODUCT_NAME, SPDP.SUB_PRODUCT_ID, SP.NAME as SUB_PRODUCT_NAME, SPDP.CHILD_PRODUCT_ID, SPDP.MEASUREMENT_ID ,  CP.NAME as CHILD_PRODUCT_NAME, 	M.NAME as MEASUREMENT_NAME, SPDP.PENDING_QUANTIY, S.SITE_NAME,S.SITE_ID,SPDP.INDENT_CREATION_DETAILS_ID ,  SPDP.PURCHASE_DEPT_INDENT_PROSS_SEQ ,SIC.INDENT_CREATION_ID,SIC.SITEWISE_INDENT_NO	FROM  SUM_PURCHASE_DEPT_INDENT_PROSS SPDP,  PRODUCT P, SUB_PRODUCT SP, CHILD_PRODUCT CP, MEASUREMENT M, SITE S , SUMADHURA_INDENT_CREATION_DTLS SICD, SUMADHURA_INDENT_CREATION SIC 	WHERE   SPDP.STATUS = 'A'  AND SPDP.PRODUCT_ID = P.PRODUCT_ID  	AND SPDP.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID  AND SPDP.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID  AND SPDP.MEASUREMENT_ID = M.MEASUREMENT_ID  AND SPDP.INDENT_REQ_SITE_ID = S.SITE_ID  AND SPDP.INDENT_CREATION_DETAILS_ID = SICD.INDENT_CREATION_DETAILS_ID  AND SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID"
				+ " and SPDP.PRODUCT_ID = ?  and  SPDP.SUB_PRODUCT_ID = ? ";

			productList = jdbcTemplate.queryForList(sql, new Object[] { prodId, subProdId });

		}
		if(!prodId.equals("") && !subProdId.equals("") && !childProdId.equals("")){

			String sql = " SELECT SPDP.PRODUCT_ID,P.NAME as PRODUCT_NAME, SPDP.SUB_PRODUCT_ID, SP.NAME as SUB_PRODUCT_NAME, SPDP.CHILD_PRODUCT_ID,SPDP.MEASUREMENT_ID ,  CP.NAME as CHILD_PRODUCT_NAME, 	M.NAME as MEASUREMENT_NAME, SPDP.PENDING_QUANTIY, S.SITE_NAME,S.SITE_ID,SPDP.INDENT_CREATION_DETAILS_ID ,  SPDP.PURCHASE_DEPT_INDENT_PROSS_SEQ ,SIC.INDENT_CREATION_ID,SIC.SITEWISE_INDENT_NO	FROM  SUM_PURCHASE_DEPT_INDENT_PROSS SPDP,  PRODUCT P, SUB_PRODUCT SP, CHILD_PRODUCT CP, MEASUREMENT M, SITE S , SUMADHURA_INDENT_CREATION_DTLS SICD, SUMADHURA_INDENT_CREATION SIC 	WHERE   SPDP.STATUS = 'A'  AND SPDP.PRODUCT_ID = P.PRODUCT_ID  	AND SPDP.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID  AND SPDP.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID  AND SPDP.MEASUREMENT_ID = M.MEASUREMENT_ID  AND SPDP.INDENT_REQ_SITE_ID = S.SITE_ID  AND SPDP.INDENT_CREATION_DETAILS_ID = SICD.INDENT_CREATION_DETAILS_ID  AND SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID"
				+ " and SPDP.PRODUCT_ID = ? and  SPDP.SUB_PRODUCT_ID = ? and SPDP.CHILD_PRODUCT_ID = ?";

			productList = jdbcTemplate.queryForList(sql, new Object[] { prodId, subProdId, childProdId });

		}

		int sno = 0;
		for (Map ProductDetails : productList) {

			ProductDetails objProductDetails  = new ProductDetails();
			sno++;
			objProductDetails.setProductId(ProductDetails.get("PRODUCT_ID") == null ? "" : ProductDetails.get("PRODUCT_ID").toString());
			objProductDetails.setSub_ProductId(ProductDetails.get("SUB_PRODUCT_ID") == null ? "" : ProductDetails.get("SUB_PRODUCT_ID").toString());
			objProductDetails.setChild_ProductId(ProductDetails.get("CHILD_PRODUCT_ID") == null ? "" : ProductDetails.get("CHILD_PRODUCT_ID").toString());
			objProductDetails.setProductName(ProductDetails.get("PRODUCT_NAME") == null ? "" : ProductDetails.get("PRODUCT_NAME").toString());
			objProductDetails.setSub_ProductName(ProductDetails.get("SUB_PRODUCT_NAME") == null ? "" : ProductDetails.get("SUB_PRODUCT_NAME").toString());
			objProductDetails.setChild_ProductName(ProductDetails.get("CHILD_PRODUCT_NAME") == null ? "" : ProductDetails.get("CHILD_PRODUCT_NAME").toString());
			objProductDetails.setMeasurementId(ProductDetails.get("MEASUREMENT_ID") == null ? "" : ProductDetails.get("MEASUREMENT_ID").toString());
			objProductDetails.setMeasurementName(ProductDetails.get("MEASUREMENT_NAME") == null ? "" : ProductDetails.get("MEASUREMENT_NAME").toString());
			objProductDetails.setQuantity(ProductDetails.get("PENDING_QUANTIY") == null ? "" 	: ProductDetails.get("PENDING_QUANTIY").toString());
			objProductDetails.setSiteName(ProductDetails.get("SITE_NAME") == null ? "" 	: ProductDetails.get("SITE_NAME").toString());
			objProductDetails.setStrIndentId(ProductDetails.get("INDENT_CREATION_ID") == null ? "" 	: ProductDetails.get("INDENT_CREATION_ID").toString());
			objProductDetails.setSite_Id(ProductDetails.get("SITE_ID") == null ? "" 	: ProductDetails.get("SITE_ID").toString());
			objProductDetails.setSiteWiseIndentNo(ProductDetails.get("SITEWISE_INDENT_NO") == null ? "0" 	: ProductDetails.get("SITEWISE_INDENT_NO").toString());
			objProductDetails.setIndentCreationDetailsId(ProductDetails.get("INDENT_CREATION_DETAILS_ID") == null ? "" 	: ProductDetails.get("INDENT_CREATION_DETAILS_ID").toString());

			objProductDetails.setStrSerialNumber(String.valueOf(sno));

			listProductDetails.add(objProductDetails);

		}
		return listProductDetails;
	}

	@Override
	public int insertPurchaseIndentProcess(int purchaseIndentProcessId,IndentCreationBean purchaseIndentDetails,int IndentCreationDetailsId,int indentReqSiteId,String reqReceiveFrom)
	{
		String query = "INSERT INTO SUM_PURCHASE_DEPT_INDENT_PROSS(PURCHASE_DEPT_INDENT_PROSS_SEQ,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,MEASUREMENT_ID,"+
		"PURCHASE_DEPT_REQ_QUANTITY, ALLOCATED_QUANTITY, PENDING_QUANTIY, PO_INTIATED_QUANTITY,"+
		"STATUS,INDENT_REQ_SITE_ID,REQ_RECEIVE_FROM,CREATION_DATE,INDENT_CREATION_DETAILS_ID,INDENT_REQ_QUANTITY) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,sysdate,?,?)";
		int result = jdbcTemplate.update(query, new Object[] {
				purchaseIndentProcessId,
				purchaseIndentDetails.getProductId1(),
				purchaseIndentDetails.getSubProductId1(),
				purchaseIndentDetails.getChildProductId1(),
				purchaseIndentDetails.getUnitsOfMeasurementId1(),
				purchaseIndentDetails.getRequiredQuantity1(),"0",
				purchaseIndentDetails.getRequiredQuantity1(),"0",
				"A",indentReqSiteId,reqReceiveFrom,IndentCreationDetailsId,
				purchaseIndentDetails.getRequiredQuantity1()
		});
		return result;
	}



	@Override
	public String getVendorEmail(String vendor_Id) {
		String query = "SELECT EMP_EMAIL FROM VENDOR_DETAILS where VENDOR_ID = '"+vendor_Id+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return result;

	}

	@Override
	public 	String getIndentCreationDate( int intIndentNumber) {
		if(intIndentNumber==0){return "";}
		String query = "select CREATE_DATE FROM SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID = '"+intIndentNumber+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return result;

	}



	@Override
	public int setVendorPasswordInDB(String vendor_Pass, String vendor_Id) {
		String query = "update VENDOR_DETAILS set PASSWORD = ? where VENDOR_ID = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				vendor_Pass,vendor_Id
		});
		return result;

	}



	@Override
	public String getVendorPasswordInDB(String vendor_Id) {
		List<Map<String, Object>> productList = null;

		String query = "select PASSWORD FROM VENDOR_DETAILS where VENDOR_ID = '"+vendor_Id+"'";
		String result = "";
		try {
			productList = jdbcTemplate.queryForList(query);



			for (Map ProductDetails : productList) {


				result = ProductDetails.get("PASSWORD") == null ? "" : ProductDetails.get("PASSWORD").toString();
			}
		}
		catch (DataAccessException e) {
			result="";
			e.printStackTrace();
		}  
		return result;
	}


	@Override
	public List<Map<String, Object>> getComparisionDetails(String indentNumber,String strProductDtls,String vendorId) {

		List<Map<String, Object>> dbIndentDts = null;
		String query = "select VD.VENDOR_NAME ,CP.NAME as CHILD_PRODUCT_NAME,M.NAME as Measurment_name,SEFD.INDENT_QTY,SEFD.VENDOR_MENTIONED_QTY,"+
		" SEFD.PRICE,SEFD.BASIC_AMOUNT,SEFD.DISCOUNT,SEFD.AMOUNT_AFTER_DISCOUNT,SEFD.TAX,SEFD.TAX_AMOUNT,SEFD.AMOUNT_AFTER_TAX,SEFD.TOTAL_AMOUNT,SEFD.CHILDPROD_CUST_DESC"+
		"  ,SEFD.CHILD_PRODUCT_ID from VENDOR_DETAILS VD,CHILD_PRODUCT CP,SUMADHURA_ENQUIRY_FORM_DETAILS SEFD , MEASUREMENT m "+
		" where SEFD.VENDOR_ID = VD.VENDOR_ID and SEFD.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID and  m.MEASUREMENT_ID =SEFD.MEASUREMENT_ID"+
		" and SEFD.INDENT_NO = ?  and CP.CHILD_PRODUCT_ID in("+strProductDtls+") order by SEFD.CHILD_PRODUCT_ID ,SEFD.PRICE ";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});

		return dbIndentDts;
	}



	@Override
	public double getIntiatedQuantityInPurchaseTable(String indentCreationDetailsId) {
		String query = "select PO_INTIATED_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS where INDENT_CREATION_DETAILS_ID = '"+indentCreationDetailsId+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return Double.valueOf(result);
	}



	@Override
	public int insertPOTempTransportDetails(int poTransChrgsSeqNo, ProductDetails productDetails, TransportChargesDto transportChargesDto) {
		String query = "INSERT INTO SUMADHURA_TEMP_PO_TRNS_O_CHRGS(ID,TRANSPORT_ID,TRANSPORT_GST_PERCENTAGE,TRANSPORT_GST_AMOUNT,"
			+ "TOTAL_AMOUNT_AFTER_GST_TAX,DATE_AND_TIME,TRANSPORT_AMOUNT,SITE_ID,PO_NUMBER,INDENT_NUMBER) "
			+ "values( ?, ?, ?, ?, ?, sysdate, ?, ?, ?, ?)";

		int result = jdbcTemplate.update(query, new Object[] {
				poTransChrgsSeqNo,
				transportChargesDto.getTransportId(),
				transportChargesDto.getTransportGSTPercentage(),
				transportChargesDto.getTransportGSTAmount(),
				transportChargesDto.getTotalAmountAfterGSTTax(),
				transportChargesDto.getTransportAmount(),
				productDetails.getSite_Id(),
				productDetails.getPoNumber(),
				productDetails.getIndentNo()
		});
		return result;

	}

	@Override
	public int insertPOTransportDetails(int poTransChrgsSeqNo, ProductDetails productDetails, TransportChargesDto transportChargesDto) {
		String query = "INSERT INTO SUMADHURA_PO_TRNS_O_CHRGS_DTLS(ID,TRANSPORT_ID,TRANSPORT_GST_PERCENTAGE,TRANSPORT_GST_AMOUNT,"
			+ "TOTAL_AMOUNT_AFTER_GST_TAX,DATE_AND_TIME,TRANSPORT_AMOUNT,SITE_ID,PO_NUMBER,INDENT_NUMBER) "
			+ "values( ?, ?, ?, ?, ?, sysdate, ?, ?, ?, ?)";

		int result = jdbcTemplate.update(query, new Object[] {
				poTransChrgsSeqNo,
				transportChargesDto.getTransportId(),
				transportChargesDto.getTransportGSTPercentage(),
				transportChargesDto.getTransportGSTAmount(),
				transportChargesDto.getTotalAmountAfterGSTTax(),
				transportChargesDto.getTransportAmount(),
				productDetails.getSite_Id(),
				productDetails.getPoEntryId(),
				productDetails.getIndentNo()
		});
		return result;

	}








	@Override
	public String  getTemproryuser(String strUserId)

	{
		int result=0;
		String tempUserId="";
		List<Map<String, Object>> dbIndentDts = null;
		//String userId=session.getAttribute("UserId");
		String query = " select SPAMD.APPROVER_EMP_ID FROM SUMADHURA_APPROVER_MAPPING_DTL SPAMD  WHERE  SPAMD.EMP_ID= ? and SPAMD.STATUS = 'A' AND SPAMD.MODULE_TYPE='PO'";

		dbIndentDts=jdbcTemplate.queryForList(query, new Object[] {strUserId});
		//	ails.getIndentNo()
		//	productDetails.getStrTermsConditionId()


		if(dbIndentDts!= null){
			for(Map<String, Object> prods : dbIndentDts) {

				tempUserId =prods.get("APPROVER_EMP_ID")==null ? "" :  prods.get("APPROVER_EMP_ID").toString();

			}	} 
		return tempUserId;


	}


	@Override
	public List<IndentCreationBean> ViewPoPendingforApproval(String fromDate, String toDate, String strUserId,String tempPoNumber) {

		String query = "";
		String strDCFormQuery = "";
		String strDCNumber = "";
		JdbcTemplate template = null;
		List<Map<String, Object>> dbIndentDts = null;
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		IndentCreationBean indentObj = null; 
		String old_Po_Number="";
		String type_Of_Purchase="";
		try {
			//if part is for view indent receive details,else part is for view indent issue details
			template = new JdbcTemplate(DBConnection.getDbConnection());

			if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
				query = "SELECT DISTINCT (STPE.PO_NUMBER),STPE.PO_DATE,S.SITE_NAME,STPE.INDENT_NO,STPE.PREPARED_BY,STPE.OLD_PO_NUMBER,SIC.SITEWISE_INDENT_NO,STPE.SITE_ID FROM   SUMADHURA_INDENT_CREATION SIC,SUMADHURA_TEMP_PO_ENTRY STPE, SITE S WHERE STPE.INDENT_NO=SIC.INDENT_CREATION_ID and STPE.TEMP_PO_PENDING_EMP_ID='"+strUserId+"' and STPE.PO_STATUS='A' and  S.SITE_ID =  STPE.SITE_ID and NVL(STPE.VIEWORCANCEL, ' ') != 'CANCEL' and TRUNC(STPE.PO_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";

				//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
			} else if (StringUtils.isNotBlank(fromDate)) {
				query = "SELECT DISTINCT (STPE.PO_NUMBER),STPE.PO_DATE,S.SITE_NAME,STPE.INDENT_NO,STPE.PREPARED_BY,STPE.OLD_PO_NUMBER,SIC.SITEWISE_INDENT_NO,STPE.SITE_ID FROM   SUMADHURA_INDENT_CREATION SIC,SUMADHURA_TEMP_PO_ENTRY STPE, SITE S WHERE STPE.INDENT_NO=SIC.INDENT_CREATION_ID and STPE.TEMP_PO_PENDING_EMP_ID='"+strUserId+"' and  STPE.PO_STATUS='A' and  S.SITE_ID =  STPE.SITE_ID and NVL(STPE.VIEWORCANCEL, ' ') != 'CANCEL' and TRUNC(STPE.PO_DATE)  =TO_DATE('"+fromDate+"', 'dd-MM-yy') ";



			} else if(StringUtils.isNotBlank(toDate)) {
				query = "SELECT DISTINCT (STPE.PO_NUMBER),STPE.PO_DATE,S.SITE_NAME,STPE.INDENT_NO,STPE.PREPARED_BY,STPE.OLD_PO_NUMBER,SIC.SITEWISE_INDENT_NO,STPE.SITE_ID FROM   SUMADHURA_INDENT_CREATION SIC,SUMADHURA_TEMP_PO_ENTRY STPE, SITE S WHERE STPE.INDENT_NO=SIC.INDENT_CREATION_ID and STPE.TEMP_PO_PENDING_EMP_ID='"+strUserId+"' and  STPE.PO_STATUS='A' and  S.SITE_ID =  STPE.SITE_ID and NVL(STPE.VIEWORCANCEL, ' ') != 'CANCEL' and TRUNC(STPE.PO_DATE)  =TO_DATE('"+toDate+"', 'dd-MM-yy')";
			}else if(StringUtils.isNotBlank(tempPoNumber)) {
				query = "SELECT DISTINCT (STPE.PO_NUMBER),STPE.PO_DATE,S.SITE_NAME,STPE.INDENT_NO,STPE.PREPARED_BY,STPE.OLD_PO_NUMBER,SIC.SITEWISE_INDENT_NO,STPE.SITE_ID FROM   SUMADHURA_INDENT_CREATION SIC,SUMADHURA_TEMP_PO_ENTRY STPE, SITE S WHERE STPE.INDENT_NO=SIC.INDENT_CREATION_ID and STPE.TEMP_PO_PENDING_EMP_ID='"+strUserId+"' and  STPE.PO_STATUS='A' and  S.SITE_ID =  STPE.SITE_ID and NVL(STPE.VIEWORCANCEL, ' ') != 'CANCEL' and  STPE.PO_NUMBER='"+tempPoNumber+"'";
			}


			dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{});

			for(Map<String, Object> prods : dbIndentDts) {
				indentObj = new IndentCreationBean();

				indentObj.setPonumber(prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString());
				//	indentObj.setStrInvoiceDate(prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString());
				indentObj.setStatus(prods.get("PO_STATUS")==null ? "" : prods.get("PO_STATUS").toString());
				indentObj.setSiteName(prods.get("SITE_NAME")==null ? "" : prods.get("SITE_NAME").toString());
				indentObj.setIndentNumber(Integer.parseInt(prods.get("INDENT_NO")==null ? "" : prods.get("INDENT_NO").toString()));
				indentObj.setSiteId(Integer.parseInt(prods.get("SITE_ID")==null ? "0" : prods.get("SITE_ID").toString()));
				indentObj.setSiteWiseIndentNo(Integer.parseInt(prods.get("SITEWISE_INDENT_NO")==null ? "0" : prods.get("SITEWISE_INDENT_NO").toString()));
				type_Of_Purchase=(prods.get("PREPARED_BY")==null ? "" : prods.get("PREPARED_BY").toString());
				old_Po_Number=(prods.get("OLD_PO_NUMBER")==null ? "" : prods.get("OLD_PO_NUMBER").toString());
				//indentObj.setType_Of_Purchase
				if(type_Of_Purchase.equals("") && !old_Po_Number.equals("") || (type_Of_Purchase.equalsIgnoreCase("PURCHASE_DEPT") && !old_Po_Number.equals(""))){
					
					indentObj.setType_Of_Purchase("REVISED_PO");
				}
				else if(type_Of_Purchase.equals("") || (type_Of_Purchase.equalsIgnoreCase("PURCHASE_DEPT") && old_Po_Number.equals(""))){
					
					indentObj.setType_Of_Purchase("PURCHASE_DEPT_PO");
				} else{
					
					indentObj.setType_Of_Purchase("SITELEVEL_PO");
				}

				String date=prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString();
				if (StringUtils.isNotBlank(date)) {
					date = DateUtil.dateConversion(date);
				} else {
					date = "";
				}
				indentObj.setStrScheduleDate(date);

				list.add(indentObj);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//.info("Exception Occured Inside getViewGrnDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;
	}

	@Override
	public int saveTempTermsconditions(String termsAndCondition,String strPONumber,String strVendorId,String strIndentNo)

	{



		String query1 = "INSERT INTO SUMADHURA_TEMP_PO_TERMS_COND(TERMS_CONDITION_ID,VENDOR_ID,INDENT_NO,PO_NUMBER,TERMS_CONDITION_DESC) values(SUMADHURA_PD_TERMS_COND_SEQ.NEXTVAL,?,?,?,?)";
		int result1 = jdbcTemplate.update(query1, new Object[] {
				strVendorId,
				strIndentNo,
				strPONumber,
				termsAndCondition
		});



		return result1;
	}

	@Override
	public int saveTermsconditions(String termsAndCondition,int strPONumber,String strVendorId,String strIndentNo)

	{

		//	int intPoNumber=Integer.parseInt(strPONumber);

		String query1 = "INSERT INTO SUMADHURA_PD_TERMS_CONDITIONS(TERMS_CONDITION_ID,VENDOR_ID,INDENT_NO,PO_ENTRY_ID,TERMS_CONDITION_DESC,ENTRY_DATE) values(SUMADHURA_PD_TERMS_COND_SEQ.NEXTVAL,?,?,?,?,sysdate)";
		int result1 = jdbcTemplate.update(query1, new Object[] {
				strVendorId,
				strIndentNo,
				strPONumber,
				termsAndCondition
		});



		return result1;
	}

	public String getPendingVendorDetails(String poNumber, String siteId,HttpServletRequest request,String siteName) throws ParseException {
		//	List<Map<String, Object>> productList = null;
		//	JdbcTemplate template;
		List<Map<String, Object>> dbIndentDts = null;
		List<Map<String, Object>> deleiverAddress = null;
		Map<String, String> Names = null;
		String tblOneData="";
		String indentnumber="";
		String ponumber="";
		String vendorid="";
		String vendorname="";
		String address="";
		String mobilenumber="";
		String gstinnumber="";
		String state="";
		String podate="";
		int strPOYear=0;
		int strPOMonth=0;
		String subject="";
		String contactPersonName="";
		String ccEmailId="";
		String billingAddress="";
		String preparedName="";
		String preparedDate="";
		String verifyName="";
		String verifyDate="";
		String strSiteId = "";
		String IndentCreatedDate = "";//request.getParameter("indentNumber") == null ? "" : request.getParameter("indentNumber").toString();
		String deliverySiteName="";
		String deliverySiteAddress="";
		String deliverySiteMobileNo="";
		String deliverySiteGSTIN="";
		String deliverySiteState="";
		String landLineNumber="";
		String emailId="";
		String siteWiseIndentNo = request.getParameter("siteWiseIndentNo");
		String billingAddressCompanyName="";
		String strDeliveryAddressContactPerson="";
		String deliveryAdddressLandLineNumber="";
		String strBillingAddressGSTIN="";
		String version_Number="";
		String poRefferenceDate="";
		String refference_No="";
		String revision_No="";
		String old_Po_Number="";
		String preparedBy="";
		
		if (StringUtils.isNotBlank(poNumber) ) {
			String query = "SELECT DISTINCT (STPE.INDENT_NO),STPE.PO_ENTRY_ID,STPE.BILLING_ADDRESS,STPE.SUBJECT,STPE.PO_DATE,STPE.VENDOR_ID,VD.VENDOR_CON_PER_NAME,VD.VENDOR_NAME,VD.ADDRESS, VD.MOBILE_NUMBER,VD.GSIN_NUMBER,VD.STATE,STPE.CC_EMAIL_ID,STPE.SITE_ID,VD.LANDLINE_NO,VD.EMP_EMAIL,STPE.VERSION_NUMBER,STPE.PO_ISSUE_DATE,STPE.REFFERENCE_NO,STPE.REVISION,STPE.OLD_PO_NUMBER,STPE.PREPARED_BY FROM VENDOR_DETAILS VD,SUMADHURA_TEMP_PO_ENTRY STPE WHERE STPE.VENDOR_ID =VD.VENDOR_ID  AND  STPE.PO_ENTRY_ID=?";


			dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{poNumber});

		}
		if (null != dbIndentDts && dbIndentDts.size() > 0) {
			for (Map<?, ?> IndentGetBean : dbIndentDts) {

				indentnumber=IndentGetBean.get("INDENT_NO") == null ? "" : IndentGetBean.get("INDENT_NO").toString();
				ponumber=IndentGetBean.get("PO_ENTRY_ID") == null ? "" : IndentGetBean.get("PO_ENTRY_ID").toString();
				vendorid=IndentGetBean.get("VENDOR_ID") == null ? "" : IndentGetBean.get("VENDOR_ID").toString();
				vendorname=IndentGetBean.get("VENDOR_NAME") == null ? "" : IndentGetBean.get("VENDOR_NAME").toString();
				address=IndentGetBean.get("ADDRESS") == null ? "" : IndentGetBean.get("ADDRESS").toString();
				mobilenumber=IndentGetBean.get("MOBILE_NUMBER") == null ? "" : IndentGetBean.get("MOBILE_NUMBER").toString();
				gstinnumber=IndentGetBean.get("GSIN_NUMBER") == null ? "" : IndentGetBean.get("GSIN_NUMBER").toString();
				state=IndentGetBean.get("STATE") == null ? "-" : IndentGetBean.get("STATE").toString();
				podate=IndentGetBean.get("PO_DATE") == null ? "-" : IndentGetBean.get("PO_DATE").toString();
				subject=IndentGetBean.get("SUBJECT") == null ? "-" : IndentGetBean.get("SUBJECT").toString();
				contactPersonName=IndentGetBean.get("VENDOR_CON_PER_NAME") == null ? "-" : IndentGetBean.get("VENDOR_CON_PER_NAME").toString();
				ccEmailId=IndentGetBean.get("CC_EMAIL_ID") == null ? "-" : IndentGetBean.get("CC_EMAIL_ID").toString();		
				billingAddress=IndentGetBean.get("BILLING_ADDRESS") == null ? "-" : IndentGetBean.get("BILLING_ADDRESS").toString();
				strSiteId =IndentGetBean.get("SITE_ID") == null ? "-" : IndentGetBean.get("SITE_ID").toString();
				landLineNumber=IndentGetBean.get("LANDLINE_NO") == null ? "-" : IndentGetBean.get("LANDLINE_NO").toString();
				emailId=IndentGetBean.get("EMP_EMAIL") == null ? "-" : IndentGetBean.get("EMP_EMAIL").toString();
				
				version_Number=IndentGetBean.get("VERSION_NUMBER") == null ? "-" : IndentGetBean.get("VERSION_NUMBER").toString();
				poRefferenceDate=IndentGetBean.get("PO_ISSUE_DATE") == null ? "-" : IndentGetBean.get("PO_ISSUE_DATE").toString();
				refference_No=IndentGetBean.get("REFFERENCE_NO") == null ? "-" : IndentGetBean.get("REFFERENCE_NO").toString();
				
				revision_No=IndentGetBean.get("REVISION") == null ? " " : IndentGetBean.get("REVISION").toString();
				old_Po_Number=IndentGetBean.get("OLD_PO_NUMBER") == null ? "-" : IndentGetBean.get("OLD_PO_NUMBER").toString();
				preparedBy=IndentGetBean.get("PREPARED_BY") == null ? "-" : IndentGetBean.get("PREPARED_BY").toString();
				
				if(!poRefferenceDate.equals("-")){
				DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
			    DateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
			    Date poReffDate = inputFormat.parse(poRefferenceDate);
			    poRefferenceDate=outputFormat.format(poReffDate);
				}
				
				
				request.setAttribute("versionNo", version_Number);
				request.setAttribute("refferenceNo", refference_No);
				request.setAttribute("strPoPrintRefdate",poRefferenceDate);
				
				
				billingAddressCompanyName=validateParams.getProperty("BILLING_NAME");
				
				if(billingAddress.contains("Sumadhura Infracon pvt Ltd")){
					
					billingAddress=billingAddress.replace("Sumadhura Infracon pvt Ltd,","");
		
					
				}
				
				if(!mobilenumber.equals("")){
					contactPersonName = contactPersonName+" ( "+mobilenumber;
				}if(!landLineNumber.equals("")){
					contactPersonName = contactPersonName+","+landLineNumber;
				}

				contactPersonName = " "+contactPersonName +" )";
				state=state+". Email Id : "+emailId;


				String indentCreationdtsId=getIndentCreationDetailsId(indentnumber);

				int tempiPOnumber = Integer.parseInt(ponumber);
				Names=getPOApproveCreateEmp(tempiPOnumber,request);

				getPOVerifiedEmpNames(tempiPOnumber,request);
				Map<String, String> verifyNames = (Map<String, String>)request.getAttribute("listOfVerifiedNames");

				for(Map.Entry<String, String> tax : Names.entrySet()) {
					preparedName=tax.getKey().toUpperCase();
					preparedDate=tax.getValue(); 
				}	

				for(Map.Entry<String, String> verify : verifyNames.entrySet()) {
					verifyName=verify.getKey().toUpperCase();
					verifyDate=verify.getValue(); 
				}	


				try{

					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(podate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
					SimpleDateFormat dt2 = new SimpleDateFormat("yy");
					podate=dt1.format(date);

					dt1.applyPattern("yyyy");

					strPOYear =Integer.parseInt((dt1.format(date)));
					dt1.applyPattern("MM");
					strPOMonth = Integer.parseInt((dt1.format(date)));
					int strPoYearYY=Integer.parseInt(dt2.format(date));
					String strFinacialYear = "";
					if(strPOMonth <=3){
						strFinacialYear = (strPOYear-1)+"-"+strPoYearYY;
					}else{
						strFinacialYear = strPOYear+"-"+(strPoYearYY+1);
					}

					request.setAttribute("strFinacialYear",strFinacialYear);





				}catch(Exception e){
					e.printStackTrace();
				}
				if (StringUtils.isNotBlank(poNumber) ) {
					String query = "SELECT CREATE_DATE FROM SUMADHURA_INDENT_CREATION WHERE INDENT_CREATION_ID=?";

					dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{indentnumber});




					if (null != dbIndentDts && dbIndentDts.size() > 0) {
						for (Map<?, ?> siteVendoraddress : dbIndentDts) {

							//	indentnumber = siteVendoraddress.get("INDENT_NO") == null ? "" : siteVendoraddress.get("INDENT_NO").toString();
							//	ponumber = siteVendoraddress.get("PO_ENTRY_ID") == null ? "" : siteVendoraddress.get("PO_ENTRY_ID").toString();
							IndentCreatedDate = siteVendoraddress.get("CREATE_DATE") == null ? "" : siteVendoraddress.get("CREATE_DATE").toString();



							SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
							Date date = dt.parse(IndentCreatedDate); 


							SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
							IndentCreatedDate = dt1.format(date);
						}

					}

				}

				if (StringUtils.isNotBlank(poNumber) ) {
					String query = "select VENDOR_NAME,STATE,ADDRESS,MOBILE_NUMBER,GSIN_NUMBER,VENDOR_CON_PER_NAME,LANDLINE_NO from VENDOR_DETAILS where VENDOR_ID = ?";


					deleiverAddress = jdbcTemplate.queryForList(query, new Object[]{strSiteId});

				}
				if (null != dbIndentDts && dbIndentDts.size() > 0) {
					for (Map<?, ?> deleiverAddressMap : deleiverAddress) {



						deliverySiteName = deleiverAddressMap.get("VENDOR_NAME") == null ? "" : deleiverAddressMap.get("VENDOR_NAME").toString();
						deliverySiteAddress = deleiverAddressMap.get("ADDRESS") == null ? "" : deleiverAddressMap.get("ADDRESS").toString();
						deliverySiteMobileNo = deleiverAddressMap.get("MOBILE_NUMBER") == null ? "" : deleiverAddressMap.get("MOBILE_NUMBER").toString();
						deliverySiteGSTIN = deleiverAddressMap.get("GSIN_NUMBER") == null ? "" : deleiverAddressMap.get("GSIN_NUMBER").toString();
						deliverySiteState=	 deleiverAddressMap.get("STATE") == null ? "" : deleiverAddressMap.get("STATE").toString();
						strDeliveryAddressContactPerson=deleiverAddressMap.get("VENDOR_CON_PER_NAME") == null ? "-" : deleiverAddressMap.get("VENDOR_CON_PER_NAME").toString();
						deliveryAdddressLandLineNumber=deleiverAddressMap.get("LANDLINE_NO") == null ? "-" : deleiverAddressMap.get("LANDLINE_NO").toString();

						request.setAttribute("deliverySiteState",deliverySiteState);

					}

				}

				if(deliverySiteState.equalsIgnoreCase("Telangana")){
					strBillingAddressGSTIN=validateParams.getProperty("GSTIN_HYDERABAD");
					
				}else{
					strBillingAddressGSTIN=validateParams.getProperty("GSTIN_BENGALORE");
				}


				//strIndentNumber = request.getParameter("indentNumber") == null ? "" : request.getParameter("indentNumber").toString();

				tblOneData+= ponumber+"@@"+podate+"@@"+indentnumber+"@@"+vendorname+"@@"+address+"@@"+state+"@@"+gstinnumber+
				"@@"+deliverySiteName+"@@"+deliverySiteAddress+"@@"+deliverySiteMobileNo+"@@"+deliverySiteGSTIN+"@@"+""+"@@"+subject+"@@"+contactPersonName+
				"@@"+ccEmailId+"@@"+billingAddress+"@@"+preparedName+"@@"+preparedDate+"@@"+indentCreationdtsId+"@@"+siteId+"@@"+verifyName+"@@"+verifyDate+"@@"+IndentCreatedDate+"@@"+siteWiseIndentNo+"@@"+billingAddressCompanyName+
				"@@"+strDeliveryAddressContactPerson+"@@"+deliveryAdddressLandLineNumber+"@@"+strBillingAddressGSTIN+"@@"+siteId+"@@"+siteName+"@@"+vendorid+"@@"+revision_No+"@@"+old_Po_Number+"@@"+preparedBy;
				
			}

			request.setAttribute("gstinumber",gstinnumber);
		}

		return tblOneData;

	}

	public String getPendingProductDetails(String poNumber, String siteId,HttpServletRequest request,String deliverySiteState) {
		List<Map<String, Object>> GetproductDetailsList = null;

		//List<GetInvoiceDetailsBean> GetInvoiceDetailsInward = new ArrayList<GetInvoiceDetailsBean>();
		//	IndentCreationBean objGetInvoiceDetailsInward=null;

		//	JdbcTemplate template = null;
		String sql = "";	
		String tblTwoData="";
		String subproduct="";
		String childproduct="";
		String measurement="";
		String quantity="";
		String tax="";
		String taxamount="";
		String amountaftertax="";
		String basicamount="";
		String price="";
		String hsncode="";
		String totalamount="";
		String gstinumber="";
		String CGST = "";
		String SGST = "";
		String IGST = "";
		Double percent = 0.0;
		Double CGSTAMT = 0.0;
		Double SGSTAMT = 0.0;
		Double IGSTAMT = 0.0;
		Double amt = 0.0;
		int sno=0;
		String discount="";
		String discountaftertax="";
		double totalAmt=0.0;
		String vendorProductDesc="";
		int strIndentCreationDetailsId = 0;
		String pd_Product_Desc="";
		String product_name="";
		String productId="";
		String sub_productId="";
		String child_productId="";
		String measurementId="";
		String indentCreationDetailsId="";
		try{
			if (StringUtils.isNotBlank(poNumber) ) {

				sql+="select (P.NAME)AS PRODUCT_NAME,SP.NAME AS SUB_PRODUCT,CP.NAME AS CHILD_PRODUCT,M.NAME,SPED.PRODUCT_ID,SPED.SUB_PRODUCT_ID,SPED.CHILD_PRODUCT_ID,SPED.MEASUR_MNT_ID, "
					+" SPED.PO_QTY,SPED.TAX,SPED.TAX_AMOUNT,SPED.AMOUNT_AFTER_TAX,SPED.BASIC_AMOUNT,SPED.PRICE, SPED.HSN_CODE,SPED.TOTAL_AMOUNT,SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,SPED.VENDOR_PRODUCT_DESC ,IGST.TAX_PERCENTAGE , "
					+" SPED.INDENT_CREATION_DTLS_ID,SPED.PD_PRODUCT_DESC  from SUMADHURA_TEMP_PO_ENTRY SPE,SUMADHURA_TEMP_PO_ENTRY_DTLS SPED, SUB_PRODUCT SP,"
					+ " CHILD_PRODUCT CP,MEASUREMENT M ,INDENT_GST IGST,PRODUCT P where IGST.TAX_ID = SPED.TAX and  SPE.PO_ENTRY_ID = SPED.PO_ENTRY_ID "
					+ " AND P.PRODUCT_ID=SPED.PRODUCT_ID and  SPED.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID and SPED.MEASUR_MNT_ID= M.MEASUREMENT_ID and SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID "
					+" and SPE.PO_ENTRY_ID =? AND SPE.SITE_ID=? order by SPED.INDENT_CREATION_DTLS_ID";

				GetproductDetailsList = jdbcTemplate.queryForList(sql, new Object[] {poNumber, siteId});
				//System.out.println("second product data in service"+GetproductDetailsList);
			} 
			if (null != GetproductDetailsList && GetproductDetailsList.size() > 0) {
				for (Map<?, ?> GetDetailsInwardBean : GetproductDetailsList) {
					//	objGetInvoiceDetailsInward = new IndentCreationBean();
					sno++;
					subproduct=GetDetailsInwardBean.get("SUB_PRODUCT") == null ? "": GetDetailsInwardBean.get("SUB_PRODUCT").toString();
					childproduct=GetDetailsInwardBean.get("CHILD_PRODUCT") == null ? "": GetDetailsInwardBean.get("CHILD_PRODUCT").toString();
					measurement=GetDetailsInwardBean.get("NAME") == null ? "": GetDetailsInwardBean.get("NAME").toString();
					quantity=GetDetailsInwardBean.get("PO_QTY") == null ? "": GetDetailsInwardBean.get("PO_QTY").toString();
					tax=GetDetailsInwardBean.get("TAX_PERCENTAGE") == null ? "": GetDetailsInwardBean.get("TAX_PERCENTAGE").toString();
					taxamount=GetDetailsInwardBean.get("TAX_AMOUNT") == null ? "": GetDetailsInwardBean.get("TAX_AMOUNT").toString();
					amountaftertax=GetDetailsInwardBean.get("AMOUNT_AFTER_TAX") == null ? "": GetDetailsInwardBean.get("AMOUNT_AFTER_TAX").toString();
					basicamount=GetDetailsInwardBean.get("BASIC_AMOUNT") == null ? "": GetDetailsInwardBean.get("BASIC_AMOUNT").toString();
					price=GetDetailsInwardBean.get("PRICE") == null ? "-": GetDetailsInwardBean.get("PRICE").toString();
					hsncode=GetDetailsInwardBean.get("HSN_CODE") == null ? "": GetDetailsInwardBean.get("HSN_CODE").toString();
					totalamount=GetDetailsInwardBean.get("TOTAL_AMOUNT") == null ? "": GetDetailsInwardBean.get("TOTAL_AMOUNT").toString();
					//gstinumber=GetDetailsInwardBean.get("GSIN_NUMBER") == null ? "": GetDetailsInwardBean.get("GSIN_NUMBER").toString();
					discount=GetDetailsInwardBean.get("DISCOUNT") == null ? "": GetDetailsInwardBean.get("DISCOUNT").toString();
					discountaftertax=GetDetailsInwardBean.get("AMOUNT_AFTER_DISCOUNT") == null ? "": GetDetailsInwardBean.get("AMOUNT_AFTER_DISCOUNT").toString();
					vendorProductDesc=GetDetailsInwardBean.get("VENDOR_PRODUCT_DESC") == null ? "-": GetDetailsInwardBean.get("VENDOR_PRODUCT_DESC").toString();
					strIndentCreationDetailsId = Integer.parseInt(GetDetailsInwardBean.get("INDENT_CREATION_DTLS_ID") == null ? "0": GetDetailsInwardBean.get("INDENT_CREATION_DTLS_ID").toString());
					pd_Product_Desc=GetDetailsInwardBean.get("PD_PRODUCT_DESC") == null ? "": GetDetailsInwardBean.get("PD_PRODUCT_DESC").toString();
					
					product_name=GetDetailsInwardBean.get("PRODUCT_NAME") == null ? "": GetDetailsInwardBean.get("PRODUCT_NAME").toString();
					productId=GetDetailsInwardBean.get("PRODUCT_ID") == null ? "": GetDetailsInwardBean.get("PRODUCT_ID").toString();
					sub_productId=GetDetailsInwardBean.get("SUB_PRODUCT_ID") == null ? "": GetDetailsInwardBean.get("SUB_PRODUCT_ID").toString();
					child_productId=GetDetailsInwardBean.get("CHILD_PRODUCT_ID") == null ? "": GetDetailsInwardBean.get("CHILD_PRODUCT_ID").toString();
					measurementId=GetDetailsInwardBean.get("MEASUR_MNT_ID") == null ? "": GetDetailsInwardBean.get("MEASUR_MNT_ID").toString();
					indentCreationDetailsId=GetDetailsInwardBean.get("INDENT_CREATION_DTLS_ID") == null ? "": GetDetailsInwardBean.get("INDENT_CREATION_DTLS_ID").toString();
					
					if(pd_Product_Desc!=null && !pd_Product_Desc.equals("")){
						
						childproduct=pd_Product_Desc;
					}
					
					
					gstinumber=request.getAttribute("gstinumber").toString();
					char firstLetterChar = gstinumber.charAt(0);
					char secondLetterChar=gstinumber.charAt(1);

					if(tax.contains("%")){
						String data[] = tax.split("%");
						tax=data[0];

					}


					if(deliverySiteState.equalsIgnoreCase("Telangana")){

						if (firstLetterChar=='3' && secondLetterChar=='6') {
							request.setAttribute("isCGSTSGST","true");


							if (tax.equals("0")) {
								CGST = "0";
								SGST = "0";
							} else {
								percent = Double.parseDouble(tax)/2;
								amt = Double.parseDouble(taxamount)/2;
								CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								CGST = String.valueOf(percent);
								SGST = String.valueOf(percent);
							}
						} else {
							
							request.setAttribute("isCGSTSGST","false");
							percent = Double.parseDouble(tax);
							amt = Double.parseDouble(taxamount);
							IGST = String.valueOf(percent);
							IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
						}


					}else{

						if (firstLetterChar=='2' && secondLetterChar=='9') {

							request.setAttribute("isCGSTSGST","true");

							if (tax.equals("0")) {
								CGST = "0";
								SGST = "0";
							} else {
								percent = Double.parseDouble(tax)/2;
								amt = Double.parseDouble(taxamount)/2;
								CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								CGST = String.valueOf(percent);
								SGST = String.valueOf(percent);
							}
						} else {
							
							request.setAttribute("isCGSTSGST","false");
							percent = Double.parseDouble(tax);
							amt = Double.parseDouble(taxamount);
							IGST = String.valueOf(percent);
							IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
						}
					}
					double totalvalue=Double.valueOf(totalamount);

					totalAmt=totalAmt+totalvalue;
					//	double totalAmt=Double.valueOf(totalamount);
					totalAmt =Double.parseDouble(new DecimalFormat("##.##").format(totalAmt));
					int val = (int) Math.ceil(totalAmt);
					double roundoff=Math.ceil(totalAmt)-totalAmt;
					double grandtotal=Math.ceil(totalAmt);
					String strroundoff=String.format("%.2f",roundoff);

					if(deliverySiteState.equalsIgnoreCase("Telangana")){

						if (firstLetterChar=='3' && secondLetterChar=='6') {

							tblTwoData += sno+"@@"+subproduct+"@@"+childproduct+"@@"+hsncode+"@@"+measurement+"@@"+
							quantity+"@@"+price+"@@"+basicamount+"@@"+discount+"@@"+discountaftertax+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+""+"@@"+""+"@@"+amountaftertax+"@@"+amountaftertax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"+strIndentCreationDetailsId+"@@"
							+product_name+"@@"+productId+"@@"+sub_productId+"@@"+child_productId+"@@"+measurementId+"@@"+indentCreationDetailsId+"&&";
						}else
						{

							tblTwoData += sno+"@@"+subproduct+"@@"+childproduct+"@@"+hsncode+"@@"+measurement+"@@"+
							quantity+"@@"+price+"@@"+basicamount+"@@"+discount+"@@"+discountaftertax+"@@"+""+"@@"+""+"@@"+""+"@@"+""+"@@"+IGST+"%"+"@@"+IGSTAMT+"@@"+amountaftertax+"@@"+amountaftertax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"+strIndentCreationDetailsId+"@@"
							+product_name+"@@"+productId+"@@"+sub_productId+"@@"+child_productId+"@@"+measurementId+"@@"+indentCreationDetailsId+"&&";

						}
					}else{

						if (firstLetterChar=='2' && secondLetterChar=='9') {

							tblTwoData += sno+"@@"+subproduct+"@@"+childproduct+"@@"+hsncode+"@@"+measurement+"@@"+
							quantity+"@@"+price+"@@"+basicamount+"@@"+discount+"@@"+discountaftertax+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+""+"@@"+""+"@@"+amountaftertax+"@@"+amountaftertax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"+strIndentCreationDetailsId+"@@"
							+product_name+"@@"+productId+"@@"+sub_productId+"@@"+child_productId+"@@"+measurementId+"@@"+indentCreationDetailsId+"&&";
						}else
						{

							tblTwoData += sno+"@@"+subproduct+"@@"+childproduct+"@@"+hsncode+"@@"+measurement+"@@"+
							quantity+"@@"+price+"@@"+basicamount+"@@"+discount+"@@"+discountaftertax+"@@"+""+"@@"+""+"@@"+""+"@@"+""+"@@"+IGST+"%"+"@@"+IGSTAMT+"@@"+amountaftertax+"@@"+amountaftertax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"+strIndentCreationDetailsId+"@@"
							+product_name+"@@"+productId+"@@"+sub_productId+"@@"+child_productId+"@@"+measurementId+"@@"+indentCreationDetailsId+"&&";

						}
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return tblTwoData;

	}

	@Override
	public String getPendingTransportChargesList(String poNumber,String strSiteId,String gstinumber,HttpServletRequest request,String deliverySiteState) {
		List<Map<String, Object>> productList = null;
		List<Map<String, Object>> termList = null;
		List<String> listOfTermsAndConditions = new ArrayList<String>();

		String sql="";
		String ConveyanceName="";
		String ConveyanceAmount="";
		String GSTTax="";
		String GSTAmount="";
		String AmountAfterTax="";
		String CGST = "";
		String SGST = "";
		String IGST = "";
		Double percent = 0.0;
		Double CGSTAMT = 0.0;
		Double SGSTAMT = 0.0;
		Double IGSTAMT = 0.0;
		Double amt = 0.0;
		String strTableThreeData="";
		String response="";
		String termscondition="";

		try {

			if (StringUtils.isNotBlank(poNumber) ) {
				sql += "SELECT STOCM.CHARGE_NAME,STOCD.TRANSPORT_AMOUNT,STOCD.TRANSPORT_GST_PERCENTAGE,STOCD.TRANSPORT_GST_AMOUNT,STOCD.TOTAL_AMOUNT_AFTER_GST_TAX,IGST.TAX_PERCENTAGE FROM SUMADHURA_TEMP_PO_TRNS_O_CHRGS STOCD,SUMADHURA_TRNS_OTHR_CHRGS_MST STOCM,INDENT_GST IGST WHERE  IGST.TAX_ID=STOCD.TRANSPORT_GST_PERCENTAGE AND STOCD.TRANSPORT_ID=STOCM.CHARGE_ID and STOCD.PO_NUMBER=?";	

				productList = jdbcTemplate.queryForList(sql, new Object[] {poNumber});

				if (null != productList && productList.size() > 0) {
					for (Map<?, ?> GetTransportChargesDetails : productList) {
						ConveyanceAmount = GetTransportChargesDetails.get("TRANSPORT_AMOUNT") == null ? "0" : GetTransportChargesDetails.get("TRANSPORT_AMOUNT").toString();	
						GSTTax = GetTransportChargesDetails.get("TAX_PERCENTAGE") == null ? "" : GetTransportChargesDetails.get("TAX_PERCENTAGE").toString();	
						GSTAmount = GetTransportChargesDetails.get("TRANSPORT_GST_AMOUNT") == null ? "0" : GetTransportChargesDetails.get("TRANSPORT_GST_AMOUNT").toString();
						AmountAfterTax = GetTransportChargesDetails.get("TOTAL_AMOUNT_AFTER_GST_TAX") == null ? "0" : GetTransportChargesDetails.get("TOTAL_AMOUNT_AFTER_GST_TAX").toString();
						ConveyanceName = GetTransportChargesDetails.get("CHARGE_NAME") == null ? "" : GetTransportChargesDetails.get("CHARGE_NAME").toString();

						char firstLetterChar = gstinumber.charAt(0);
						char secondLetterChar=gstinumber.charAt(1);
						if(GSTTax.contains("%")){
							String data[] = GSTTax.split("%");
							GSTTax=data[0];

						}


						if(deliverySiteState.equalsIgnoreCase("Telangana")){


							if (firstLetterChar=='3' && secondLetterChar=='6') {

								if (GSTTax.equals("0")) {
									CGST = "0";
									SGST = "0";
								} else {
									percent = Double.parseDouble(GSTTax)/2;
									amt = Double.parseDouble(GSTAmount)/2;
									CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
									SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
									CGST = String.valueOf(percent);
									SGST = String.valueOf(percent);
								}
							} else {
								percent = Double.parseDouble(GSTTax);
								amt = Double.parseDouble(GSTAmount);
								IGST = String.valueOf(percent);
								IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
							}

						}else{

							if (firstLetterChar=='2' && secondLetterChar=='9') {

								if (GSTTax.equals("0")) {
									CGST = "0";
									SGST = "0";
								} else {
									percent = Double.parseDouble(GSTTax)/2;
									amt = Double.parseDouble(GSTAmount)/2;
									CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
									SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
									CGST = String.valueOf(percent);
									SGST = String.valueOf(percent);
								}
							} else {
								percent = Double.parseDouble(GSTTax);
								amt = Double.parseDouble(GSTAmount);
								IGST = String.valueOf(percent);
								IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
							}
						}

						
						

						if(deliverySiteState.equalsIgnoreCase("Telangana")){

							if (firstLetterChar=='3' && secondLetterChar=='6') {

								strTableThreeData += ConveyanceName+"@@"+ConveyanceAmount+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+" "+"@@"+" "+"&&";

								response="success";
							}else{
								strTableThreeData += ConveyanceName+"@@"+ConveyanceAmount+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+IGST+"%"+"@@"+IGSTAMT+"&&";				
								response="success";
							}
						}else{


							if (firstLetterChar=='2' && secondLetterChar=='9') {

								strTableThreeData += ConveyanceName+"@@"+ConveyanceAmount+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+" "+"@@"+" "+"&&";

								response="success";
							}else{
								strTableThreeData += ConveyanceName+"@@"+ConveyanceAmount+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+IGST+"%"+"@@"+IGSTAMT+"&&";				
								response="success";
							}
						}
						
						
					}
				}

				if(response=="success"){

					String sql1="SELECT TERMS_CONDITION_DESC FROM  SUMADHURA_TEMP_PO_TERMS_COND WHERE PO_NUMBER=?";
					termList = jdbcTemplate.queryForList(sql1, new Object[] {poNumber});
					//System.out.println("the list size is "+termList.size());
					if (null != termList && termList.size() > 0) {
						for (Map<?, ?> GetTransportChargesDetails : termList) {

							termscondition = GetTransportChargesDetails.get("TERMS_CONDITION_DESC") == null ? "" : GetTransportChargesDetails.get("TERMS_CONDITION_DESC").toString();


							listOfTermsAndConditions.add(String.valueOf(termscondition));

						}
					}
				}
				request.setAttribute("listOfTermsAndConditions", listOfTermsAndConditions);

			}

		}catch(Exception e){
			e.printStackTrace();
		}

		return strTableThreeData;
	}	


	public String getAndsaveVendorDetails(String tempPONumber, String siteId,String user_id,HttpServletRequest request,String revision_No,String oldPoNumber,String siteLevelPoPreparedBy,String siteName) {

		List<Map<String, Object>> dbIndentDts = null;
		List<Map<String, Object>> dbIndentState = null;
		String indentnumber="";
		String ponumber ="";
		String vendorid="";
		String response="";
		int result=0;
		String subject="";
		String billingAddress="";
		String State="";
		String poState="";
		String siteWise_Number="";
		String stateYearWiseNum="";
		String siteWiseYearWiseNumber = "";
		int HOintYearwisePONumber = 0;
		int	 HOwiseinfinity_Number= 0;
		String strIndentFromSiteId = "";
		String version_Number="";
		String porefferenceDate="";
		String refference_No="";
		int temprevision_no=0;
		int revision_no=0;
		int total_Records=0;
		int current_Records=0;
		String preparedBy="";

		String strFinacialYear="";
		if (StringUtils.isNotBlank(tempPONumber) ) {
			String query = "SELECT DISTINCT (STPE.INDENT_NO),STPE.PO_ENTRY_ID,STPE.VENDOR_ID,STPE.SUBJECT,STPE.BILLING_ADDRESS,VD.STATE,STPE.SITE_ID,STPE.VERSION_NUMBER,STPE.PO_ISSUE_DATE,STPE.REFFERENCE_NO FROM VENDOR_DETAILS VD,SUMADHURA_TEMP_PO_ENTRY STPE WHERE STPE.VENDOR_ID =VD.VENDOR_ID  AND  STPE.PO_ENTRY_ID=?";


			dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{tempPONumber});

		}

		String query = "select STATE from VENDOR_DETAILS where VENDOR_ID='"+siteId+"'";
		State = jdbcTemplate.queryForObject(query, String.class);
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH)+1;





		Calendar cal = Calendar.getInstance();
		String currentYearYY = new SimpleDateFormat("YY").format(cal.getTime());






		if(currentMonth <=3){

			strFinacialYear = (currentYear-1)+"-"+Integer.parseInt(currentYearYY);
		}else{
			strFinacialYear = currentYear+"-"+(Integer.parseInt(currentYearYY)+1);
		}

		//	strFinacialYear=request.getAttribute("strFinacialYear").toString();
		if(!siteLevelPoPreparedBy.equals("-") && !siteLevelPoPreparedBy.equalsIgnoreCase("PURCHASE_DEPT")){
			
			String site_Level_Po_Number=getSiteLevelPoNumber(siteId);
			String data[] = site_Level_Po_Number.split("@@");

			 total_Records =Integer.parseInt(data[0]);
			 current_Records=Integer.parseInt(data[1]);
			
			 ponumber="PO/SIPL/"+siteName+"/"+total_Records+"/"+strFinacialYear+"/"+current_Records;
			 updateSiteLeveltbl(siteId,total_Records+1,current_Records+1);
			 preparedBy=siteName;
			 
		}else{
			
			preparedBy="PURCHASE_DEPT";
		if(oldPoNumber!=null && !oldPoNumber.equals("-")){
			
			revision_no=getRevisionNumber(oldPoNumber);
				inactiveOldPo(oldPoNumber);
				String tempPoNumber=oldPoNumber;
				if(tempPoNumber.contains("R")){ 
					temprevision_no=revision_no+1;
					ponumber=tempPoNumber.replace("R"+revision_no, "R"+temprevision_no);
					
				
				}else{
					temprevision_no=revision_no+1;
					ponumber=tempPoNumber+"/R"+temprevision_no;
					
				}
				updateAccPayment(oldPoNumber,ponumber);
				
			}else {
		

		if(State.equalsIgnoreCase("Telangana")){

			
			poState =validateParams.getProperty("PO_NUM_TELANGANA");
			HOintYearwisePONumber = getPoEnterSeqNoOrMaxId("PO_SIPL"); //PO_TELANGANA changed to PO_SIPL because requirment is changed they want SIPL level 
			HOwiseinfinity_Number=getHeadOfficeInfinitMaxId("PO_SIPL");
			siteWise_Number=getSiteWisePoNumber(siteId);
			siteWiseYearWiseNumber=getStateWiseYearPoNumber(siteId);
			ponumber=poState+String.valueOf(HOintYearwisePONumber)+"/"+siteWise_Number+"/"+strFinacialYear+"/"+siteWiseYearWiseNumber;
			//request.setAttribute("serviceState","PO_TELANGANA");


			getUpdatePoNumberGeneratorHeadOfficeWise(HOwiseinfinity_Number+1,HOintYearwisePONumber+1,"PO_SIPL"); //PO_TELANGANA changed to PO_SIPL because requirment is changed they want SIPL level
			getUpdateStateWisePoNumber(Integer.parseInt(siteWise_Number)+1,Integer.parseInt(siteWiseYearWiseNumber)+1,siteId);



		}else{
			poState =	validateParams.getProperty("PO_NUM_KARNATAKA");
			HOintYearwisePONumber  =getPoEnterSeqNoOrMaxId("PO_SIPL"); //PO_KARNATAKA changed to PO_SIPL because requirment is changed they want SIPL level
			HOwiseinfinity_Number=getHeadOfficeInfinitMaxId("PO_SIPL");
			siteWise_Number=getSiteWisePoNumber(siteId);
			siteWiseYearWiseNumber=getStateWiseYearPoNumber(siteId);
			ponumber=poState+String.valueOf(HOintYearwisePONumber)+"/"+siteWise_Number+"/"+strFinacialYear+"/"+siteWiseYearWiseNumber;
			//request.setAttribute("serviceState","PO_KARNATAKA");

			getUpdatePoNumberGeneratorHeadOfficeWise(HOwiseinfinity_Number+1,HOintYearwisePONumber+1,"PO_SIPL");  //PO_KARNATAKA changed to PO_SIPL because requirment is changed they want SIPL level
			getUpdateStateWisePoNumber(Integer.parseInt(siteWise_Number)+1,Integer.parseInt(siteWiseYearWiseNumber)+1,siteId);




		}

			}
		
		}

		//	ponumber = getPoEnterSeqNoOrMaxId();

		int poSeqNo = getPoEnterSeqNo();

		if (null != dbIndentDts && dbIndentDts.size() > 0) {
			for (Map<?, ?> IndentGetBean : dbIndentDts) {

				indentnumber=IndentGetBean.get("INDENT_NO") == null ? "" : IndentGetBean.get("INDENT_NO").toString();
				//ponumber=IndentGetBean.get("PO_ENTRY_ID") == null ? "" : IndentGetBean.get("PO_ENTRY_ID").toString();
				vendorid=IndentGetBean.get("VENDOR_ID") == null ? "" : IndentGetBean.get("VENDOR_ID").toString();
				subject=IndentGetBean.get("SUBJECT") == null ? "" : IndentGetBean.get("SUBJECT").toString();
				billingAddress=IndentGetBean.get("BILLING_ADDRESS") == null ? "" : IndentGetBean.get("BILLING_ADDRESS").toString();
				strIndentFromSiteId=IndentGetBean.get("SITE_ID") == null ? "" : IndentGetBean.get("SITE_ID").toString();
				
				version_Number=IndentGetBean.get("VERSION_NUMBER") == null ? "" : IndentGetBean.get("VERSION_NUMBER").toString();
				porefferenceDate=IndentGetBean.get("PO_ISSUE_DATE") == null ? "" : IndentGetBean.get("PO_ISSUE_DATE").toString();
				refference_No=IndentGetBean.get("REFFERENCE_NO") == null ? "" : IndentGetBean.get("REFFERENCE_NO").toString();
				//preparedBy=IndentGetBean.get("PREPARED_BY") == null ? "" : IndentGetBean.get("PREPARED_BY").toString();
				
				//	State=IndentGetBean.get("STATE") == null ? "" : IndentGetBean.get("STATE").toString();

				String query1 = "INSERT INTO SUMADHURA_PO_ENTRY(PO_ENTRY_ID,PO_NUMBER,PO_DATE,VENDOR_ID,PO_STATUS,"+
				"PO_ENTRY_USER_ID, SITE_ID,INDENT_NO,TERMS_CONDITIONS_ID,SUBJECT,BILLING_ADDRESS,VERSION_NUMBER,PO_ISSUE_DATE,REFFERENCE_NO,REVISION,OLD_PO_NUMBER,PREPARED_BY) values(? , ?, sysdate, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?)";
				result = jdbcTemplate.update(query1, new Object[] {
						poSeqNo,ponumber,vendorid,"A",user_id,
						siteId,indentnumber,"0" ,subject,billingAddress,version_Number,DateUtil.convertToJavaDateFormat(porefferenceDate),refference_No,temprevision_no,oldPoNumber,preparedBy});

			}
			request.setAttribute("tempPoNumber",tempPONumber);
			request.setAttribute("poEntrySeqID",poSeqNo);
			request.setAttribute("permentPoNumber",ponumber);
			request.setAttribute("State",State);
			/*request.setAttribute("versionNo",version_Number);
			request.setAttribute("refferenceNo",refference_No);
			request.setAttribute("strPoPrintRefdate",porefferenceDate);*/
			
			//request.setAttribute("IndentFromSiteId",strIndentFromSiteId);
			response="success";
		}


		return "response";

	}
	@Override
	public String getVendorDetails(String poNumber, String siteId,String user_id,HttpServletRequest request) {

		List<Map<String, Object>> dbIndentDts = null;
		String indentnumber="";
		String ponumber="";
		String vendorid="";
		String response="";
		int result=0;

		if (StringUtils.isNotBlank(poNumber) ) {
			String query = "SELECT DISTINCT (STPE.INDENT_NO),STPE.PO_ENTRY_ID,STPE.VENDOR_ID FROM VENDOR_DETAILS VD,SUMADHURA_TEMP_PO_ENTRY STPE WHERE STPE.VENDOR_ID =VD.VENDOR_ID  AND  STPE.PO_ENTRY_ID=?";


			dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{poNumber});

		}
		if (null != dbIndentDts && dbIndentDts.size() > 0) {
			for (Map<?, ?> IndentGetBean : dbIndentDts) {

				indentnumber=IndentGetBean.get("INDENT_NO") == null ? "" : IndentGetBean.get("INDENT_NO").toString();
				ponumber=IndentGetBean.get("PO_ENTRY_ID") == null ? "" : IndentGetBean.get("PO_ENTRY_ID").toString();
				vendorid=IndentGetBean.get("VENDOR_ID") == null ? "" : IndentGetBean.get("VENDOR_ID").toString();

			}


		}


		return vendorid;

	}
	public String getAndsavePendingProductDetails(String tempPONumber, String siteId,HttpServletRequest request,String premPONumber,int intPOEntrySeqId) {
		List<Map<String, Object>> GetproductDetailsList = null;

		String sql = "";	
		String product="";
		String subproduct="";
		String childproduct="";
		String measurement="";
		String quantity="";
		String tax="";
		String taxamount="";
		String amountaftertax="";
		String basicamount="";
		String price="";
		String hsncode="";
		String totalamount="";
		int sno=0;
		String discount="";
		String discountaftertax="";
		String podetailsid="";
		String response="";
		String indentCreationDetailsId="";
		String vendorProductDesc="";
		String pd_Product_Desc="";

		try{
			if (StringUtils.isNotBlank(tempPONumber) ) {

				sql+="select DISTINCT SP.SUB_PRODUCT_ID,SPED.PO_ENTRY_DETAILS_ID,CP.CHILD_PRODUCT_ID,M.MEASUREMENT_ID,SPED.PO_QTY,SPED.TAX,SPED.TAX_AMOUNT,SPED.AMOUNT_AFTER_TAX,SPED.BASIC_AMOUNT,SPED.PRICE,SPED.HSN_CODE,SPED.TOTAL_AMOUNT,SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,P.PRODUCT_ID,SPED.INDENT_CREATION_DTLS_ID,SPED.VENDOR_PRODUCT_DESC,SPED.PD_PRODUCT_DESC from SUMADHURA_TEMP_PO_ENTRY SPE,SUMADHURA_TEMP_PO_ENTRY_DTLS SPED,VENDOR_DETAILS VD,PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT M "  
					+"where P.PRODUCT_ID=SPED.PRODUCT_ID AND SPE.PO_ENTRY_ID = SPED.PO_ENTRY_ID and SPE.VENDOR_ID = VD.VENDOR_ID and SPED.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID and SPED.MEASUR_MNT_ID= M.MEASUREMENT_ID and SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID and SPE.PO_ENTRY_ID =? AND SPE.SITE_ID=?"; 

				GetproductDetailsList = jdbcTemplate.queryForList(sql, new Object[] {tempPONumber, siteId});
				//System.out.println("second product data in service"+GetproductDetailsList);
			} 
			if (null != GetproductDetailsList && GetproductDetailsList.size() > 0) {
				for (Map<?, ?> GetDetailsInwardBean : GetproductDetailsList) {

					sno++;
					subproduct=GetDetailsInwardBean.get("SUB_PRODUCT_ID") == null ? "": GetDetailsInwardBean.get("SUB_PRODUCT_ID").toString();
					childproduct=GetDetailsInwardBean.get("CHILD_PRODUCT_ID") == null ? "": GetDetailsInwardBean.get("CHILD_PRODUCT_ID").toString();
					measurement=GetDetailsInwardBean.get("MEASUREMENT_ID") == null ? "": GetDetailsInwardBean.get("MEASUREMENT_ID").toString();
					quantity=GetDetailsInwardBean.get("PO_QTY") == null ? "": GetDetailsInwardBean.get("PO_QTY").toString();
					tax=GetDetailsInwardBean.get("TAX") == null ? "": GetDetailsInwardBean.get("TAX").toString();
					taxamount=GetDetailsInwardBean.get("TAX_AMOUNT") == null ? "": GetDetailsInwardBean.get("TAX_AMOUNT").toString();
					amountaftertax=GetDetailsInwardBean.get("AMOUNT_AFTER_TAX") == null ? "": GetDetailsInwardBean.get("AMOUNT_AFTER_TAX").toString();
					basicamount=GetDetailsInwardBean.get("BASIC_AMOUNT") == null ? "": GetDetailsInwardBean.get("BASIC_AMOUNT").toString();
					price=GetDetailsInwardBean.get("PRICE") == null ? "-": GetDetailsInwardBean.get("PRICE").toString();
					hsncode=GetDetailsInwardBean.get("HSN_CODE") == null ? "": GetDetailsInwardBean.get("HSN_CODE").toString();
					totalamount=GetDetailsInwardBean.get("TOTAL_AMOUNT") == null ? "": GetDetailsInwardBean.get("TOTAL_AMOUNT").toString();
					product=GetDetailsInwardBean.get("PRODUCT_ID") == null ? "": GetDetailsInwardBean.get("PRODUCT_ID").toString();
					discount=GetDetailsInwardBean.get("DISCOUNT") == null ? "": GetDetailsInwardBean.get("DISCOUNT").toString();
					discountaftertax=GetDetailsInwardBean.get("AMOUNT_AFTER_DISCOUNT") == null ? "": GetDetailsInwardBean.get("AMOUNT_AFTER_DISCOUNT").toString();
					podetailsid=GetDetailsInwardBean.get("PO_ENTRY_DETAILS_ID") == null ? "": GetDetailsInwardBean.get("PO_ENTRY_DETAILS_ID").toString();
					indentCreationDetailsId=GetDetailsInwardBean.get("INDENT_CREATION_DTLS_ID") == null ? "": GetDetailsInwardBean.get("INDENT_CREATION_DTLS_ID").toString();
					vendorProductDesc=GetDetailsInwardBean.get("VENDOR_PRODUCT_DESC") == null ? "": GetDetailsInwardBean.get("VENDOR_PRODUCT_DESC").toString();
					pd_Product_Desc=GetDetailsInwardBean.get("PD_PRODUCT_DESC") == null ? "-": GetDetailsInwardBean.get("PD_PRODUCT_DESC").toString();

					String query1 = "INSERT INTO SUMADHURA_PO_ENTRY_DETAILS(PO_ENTRY_DETAILS_ID,PO_ENTRY_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,"+
					"MEASUR_MNT_ID, PO_QTY,ENTRY_DATE,PRICE,BASIC_AMOUNT,TAX,TAX_AMOUNT,AMOUNT_AFTER_TAX,OTHER_CHARGES,OTHER_CHARGES_AFTER_TAX,TOTAL_AMOUNT,HSN_CODE,TAX_ON_OTHER_TRANSPORT_CHG,DISCOUNT,AMOUNT_AFTER_DISCOUNT,INDENT_CREATION_DTLS_ID,VENDOR_PRODUCT_DESC,PD_PRODUCT_DESC"
					+ ") values(SUMADHURA_PO_ENTRY_DTLS_SEQ.nextval, ?, ?, ?, ?, ?, ?,sysdate, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

					int result = jdbcTemplate.update(query1, new Object[] {
							intPOEntrySeqId,product,subproduct,childproduct,measurement,
							quantity,price,basicamount,tax,taxamount,amountaftertax,
							"0","0",totalamount,hsncode,"0",discount,discountaftertax,indentCreationDetailsId,vendorProductDesc,pd_Product_Desc

					});
					response="success";

				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return "response";

	}

	public String getAndsavePendingTransportChargesList(String tempPONumber,String strSiteId,HttpServletRequest request,int poEntryId) {
		List<Map<String, Object>> productList = null;

		String sql="";
		String ConveyanceName="";
		String ConveyanceAmount="";
		String GSTTax="";
		String GSTAmount="";
		String AmountAfterTax="";
		String indentnumber="";
		String id="";
		String transportId="";
		String reponse="";

		try {

			if (StringUtils.isNotBlank(tempPONumber) ) {
				sql += "SELECT STOCD.ID,STOCD.INDENT_NUMBER,STOCD.TRANSPORT_ID,STOCM.CHARGE_NAME,STOCD.TRANSPORT_AMOUNT,STOCD.TRANSPORT_GST_PERCENTAGE,STOCD.TRANSPORT_GST_AMOUNT,STOCD.TOTAL_AMOUNT_AFTER_GST_TAX FROM SUMADHURA_TEMP_PO_TRNS_O_CHRGS STOCD,SUMADHURA_TRNS_OTHR_CHRGS_MST STOCM " 
					+" WHERE  STOCD.TRANSPORT_ID=STOCM.CHARGE_ID and STOCD.PO_NUMBER=?";	

				productList = jdbcTemplate.queryForList(sql, new Object[] {tempPONumber});

				if (null != productList && productList.size() > 0) {
					for (Map<?, ?> GetTransportChargesDetails : productList) {
						ConveyanceAmount = GetTransportChargesDetails.get("TRANSPORT_AMOUNT") == null ? "" : GetTransportChargesDetails.get("TRANSPORT_AMOUNT").toString();	
						GSTTax = GetTransportChargesDetails.get("TRANSPORT_GST_PERCENTAGE") == null ? "" : GetTransportChargesDetails.get("TRANSPORT_GST_PERCENTAGE").toString();	
						GSTAmount = GetTransportChargesDetails.get("TRANSPORT_GST_AMOUNT") == null ? "" : GetTransportChargesDetails.get("TRANSPORT_GST_AMOUNT").toString();
						AmountAfterTax = GetTransportChargesDetails.get("TOTAL_AMOUNT_AFTER_GST_TAX") == null ? "" : GetTransportChargesDetails.get("TOTAL_AMOUNT_AFTER_GST_TAX").toString();
						ConveyanceName = GetTransportChargesDetails.get("CHARGE_NAME") == null ? "" : GetTransportChargesDetails.get("CHARGE_NAME").toString();
						indentnumber = GetTransportChargesDetails.get("INDENT_NUMBER") == null ? "" : GetTransportChargesDetails.get("INDENT_NUMBER").toString();
						id = GetTransportChargesDetails.get("ID") == null ? "" : GetTransportChargesDetails.get("ID").toString();
						transportId = GetTransportChargesDetails.get("TRANSPORT_ID") == null ? "" : GetTransportChargesDetails.get("TRANSPORT_ID").toString();
						request.setAttribute("indentnumber","indentnumber");


						//	strTableThreeData += ConveyanceName+"@@"+ConveyanceAmount+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"&&";

						String query1 = "INSERT INTO SUMADHURA_PO_TRNS_O_CHRGS_DTLS(ID,TRANSPORT_ID,TRANSPORT_GST_PERCENTAGE,TRANSPORT_GST_AMOUNT,"
							+ "TOTAL_AMOUNT_AFTER_GST_TAX,DATE_AND_TIME,TRANSPORT_AMOUNT,SITE_ID,PO_NUMBER,INDENT_NUMBER) "
							+ "values( ?, ?, ?, ?, ?, sysdate, ?, ?, ?, ?)";

						int result = jdbcTemplate.update(query1, new Object[] {id,
								transportId,GSTTax,GSTAmount,AmountAfterTax,ConveyanceAmount,
								strSiteId,poEntryId,indentnumber	});

						reponse="success";
					}
				}

			}

		}catch(Exception e){
			e.printStackTrace();
		}

		return "reponse";
	}	

	public int updatepoEntrydetails(String poNumber,String indentnumber,String strSiteId,String strUserId,String sessionSite_id) {
		int result=0;

		String query1 ="UPDATE SUMADHURA_TEMP_PO_ENTRY set PO_STATUS = 'I' WHERE PO_NUMBER = ?";
		result = jdbcTemplate.update(query1, new Object[] {poNumber});

		List<Map<String, Object>> dbIndentDts = null;

		double doublePendingQuantity = 0;
		double doublePOIntatedQuantity = 0;
		String strStatus = "I";
		int responseCount = 0;

		String query = "  select SPDIP.PENDING_QUANTIY,SPDIP.PO_INTIATED_QUANTITY  from SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP ,SUMADHURA_INDENT_CREATION SIC, "+
		"SUMADHURA_INDENT_CREATION_DTLS SICD "+
		"where  SPDIP.INDENT_CREATION_DETAILS_ID = SICD.INDENT_CREATION_DETAILS_ID and "+
		" SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID and SIC.INDENT_CREATION_ID = ? ";

		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentnumber});
		for(Map<String, Object> prods : dbIndentDts) {

			doublePendingQuantity = Double.parseDouble(prods.get("PENDING_QUANTIY")==null ? "0" :   prods.get("PENDING_QUANTIY").toString());
			doublePOIntatedQuantity = Double.parseDouble(prods.get("PO_INTIATED_QUANTITY")==null ? "0" :   prods.get("PO_INTIATED_QUANTITY").toString());

			if(doublePendingQuantity > doublePOIntatedQuantity){
				strStatus = "A";
				break;
			}

		}	


		if(strStatus.equals("I")){

			query = " insert into SUM_INT_CREATION_APPROVAL_DTLS(INT_CREATION_APPROVAL_DTLS_ID,INDENT_CREATION_ID,INDENT_TYPE, "+
			" CREATION_DATE,SITE_ID,INDENT_CREATE_APPROVE_EMP_ID) values(INDENT_CREATION_APPROVAL_SEQ.NEXTVAL,?,?,"+
			"sysdate,?,?)";
			jdbcTemplate.update(query, new Object[]  {indentnumber,"A",sessionSite_id,strUserId});

			query = "update SUMADHURA_INDENT_CREATION set PENDIND_DEPT_ID = ?, MODIFYDATE= sysdate where INDENT_CREATION_ID = ?";
			responseCount = jdbcTemplate.update(query, new Object[]  {"VND",indentnumber});

		}	

		return result;
	}

	public String gettermsconditions(String tempPONumber,String permPoNumber) {

		List<Map<String, Object>> termList = null;

		String response="";

		String sql1="SELECT TERMS_CONDITION_ID,VENDOR_ID,INDENT_NO,PO_NUMBER,TERMS_CONDITION_DESC FROM  SUMADHURA_TEMP_PO_TERMS_COND WHERE PO_NUMBER=?";

		termList = jdbcTemplate.queryForList(sql1, new Object[] {tempPONumber});
		//System.out.println("the list size is "+termList.size());
		if (null != termList && termList.size() > 0) {
			for (Map<?, ?> GetTransportChargesDetails : termList) {

				String termsandconditions = GetTransportChargesDetails.get("TERMS_CONDITION_DESC") == null ? "" : GetTransportChargesDetails.get("TERMS_CONDITION_DESC").toString();
				String terms=GetTransportChargesDetails.get("TERMS_CONDITION_ID") == null ? "" : GetTransportChargesDetails.get("TERMS_CONDITION_ID").toString();
				String temppono=GetTransportChargesDetails.get("PO_NUMBER") == null ? "" : GetTransportChargesDetails.get("PO_NUMBER").toString();
				String tempindentno=GetTransportChargesDetails.get("INDENT_NO") == null ? "" : GetTransportChargesDetails.get("INDENT_NO").toString();
				String tempvenidno=GetTransportChargesDetails.get("VENDOR_ID") == null ? "" : GetTransportChargesDetails.get("VENDOR_ID").toString();


				int val=savetermconditions(termsandconditions,terms,permPoNumber,tempindentno,tempvenidno);

				response="success";
			}	
		}


		return "response";
	}

	public int savetermconditions(String termsandconditions,String terms,String temppono,String tempindentno,String tempvenidno)
	{

		int	result=0;
		String query2 ="INSERT INTO SUMADHURA_PD_TERMS_CONDITIONS(TERMS_CONDITION_ID,VENDOR_ID,INDENT_NO,PO_ENTRY_ID,TERMS_CONDITION_DESC,ENTRY_DATE) values(? , ?, ?, ?, ?,sysdate)";

		result = jdbcTemplate.update(query2, new Object[] {
				terms,tempvenidno,tempindentno,temppono,termsandconditions
		});						 


		return result;
	}

	public int updatePurchaseDeptIndentProcestbl(String indentNumber, String quantity,String ponumber,String indentCreationdtlsId) {

		
		List<Map<String, Object>> dbProductDetailsList = null;
		
		String availability_Id="";
		double purchase_Form_Quantity=0.0;
		double purchase_Init_Quantity=0.0;
		
		String sql="select PO_INTIATED_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS where INDENT_CREATION_DETAILS_ID=? ";
		
		dbProductDetailsList = jdbcTemplate.queryForList(sql, new Object[] {indentCreationdtlsId});
		if (null != dbProductDetailsList && dbProductDetailsList.size() > 0) {
			for (Map<String, Object> prods : dbProductDetailsList) {
				
				purchase_Init_Quantity = Double.parseDouble(prods.get("PO_INTIATED_QUANTITY") == null ? "" : prods.get("PO_INTIATED_QUANTITY").toString());
				
			}
		}
		purchase_Form_Quantity=Double.parseDouble(quantity);
		purchase_Init_Quantity=purchase_Init_Quantity-purchase_Form_Quantity;
		
		purchase_Init_Quantity=Double.parseDouble(new DecimalFormat("##.##").format(purchase_Init_Quantity));		
		String	query = "update SUM_PURCHASE_DEPT_INDENT_PROSS set STATUS= ?,PO_INTIATED_QUANTITY ='"+purchase_Init_Quantity+"' where INDENT_CREATION_DETAILS_ID = ?";
		int result = jdbcTemplate.update(query, new Object[] {"A",indentCreationdtlsId});



		return result;

	}


	public int updateTablesOnTempPORejection(String indentNumber, String ponumber,String indentCreationdtlsId) {



		String query1="update SUMADHURA_TEMP_PO_ENTRY set PO_STATUS =? where PO_NUMBER=?";	
		int result1 = jdbcTemplate.update(query1, new Object[] {"I",ponumber});





		String  deptnumber=getpendingdepId(indentNumber);
		if(deptnumber.equals("VND")){
			String query2="update SUMADHURA_INDENT_CREATION set PENDIND_DEPT_ID =? where INDENT_CREATION_ID=?";		
			jdbcTemplate.update(query2, new Object[] {"998_PDM",indentNumber});
		}
		else if(deptnumber.equals("998_PDM")){

			String query3= "update SUMADHURA_INDENT_CREATION set PENDIND_DEPT_ID =? where INDENT_CREATION_ID=?";		

			int val1=jdbcTemplate.update(query3, new Object[] {"998",indentNumber});

		}

		return result1;

	}



	public String getpendingdepId(String indentNumber){
		List<Map<String, Object>> dbIndentDts = null;
		String deptnumber="";

		String query="select PENDIND_DEPT_ID from SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID=?";
		dbIndentDts=jdbcTemplate.queryForList(query, new Object[] {indentNumber});

		if(dbIndentDts!= null){
			for(Map<String, Object> prods : dbIndentDts) {

				deptnumber =prods.get("PENDIND_DEPT_ID")==null ? "" :  prods.get("PENDIND_DEPT_ID").toString();

			}	} 

		return deptnumber;
	}

	@Override
	public int saveVendorTermsconditions(String termsAndCondition,String strVendorId,String strIndentNo)

	{

		String query1 = "INSERT INTO SUMADHURA_VND_TERMS_CONDITIONS(TERMS_CONDITION_ID,VENDOR_ID,INDENT_NO,ENTRY_DATE,TERMS_CONDITION_DESC) values(SUMADHURA_VND_TERMS_COND_SEQ.NEXTVAL,?,?,sysdate,?)";
		int result1 = jdbcTemplate.update(query1, new Object[] {
				strVendorId,
				strIndentNo,

				termsAndCondition
		});



		return result1;
	}






	public List<String> getVendortermsconditions(String indentNo,String vendorId) {

		List<Map<String, Object>> termList = null;
		List<String> listOfTermsAndConditions = new ArrayList<String>();
		String response="";

		String sql1="SELECT SVTC.TERMS_CONDITION_DESC FROM  SUMADHURA_VND_TERMS_CONDITIONS SVTC WHERE  SVTC.VENDOR_ID=? AND SVTC.INDENT_NO=?";


		termList = jdbcTemplate.queryForList(sql1, new Object[] {vendorId,indentNo});
	//	System.out.println("the list size is "+termList.size());
		if (null != termList && termList.size() > 0) {
			for (Map<?, ?> GetTransportChargesDetails : termList) {

				String termsandconditions = GetTransportChargesDetails.get("TERMS_CONDITION_DESC") == null ? "" : GetTransportChargesDetails.get("TERMS_CONDITION_DESC").toString();

				listOfTermsAndConditions.add(String.valueOf(termsandconditions));


				response="success";
			}	
		}


		return listOfTermsAndConditions;
	}


	@Override
	public int doInactiveInIndentCreation(String indentNumber) {
		String query = "UPDATE SUMADHURA_INDENT_CREATION  set STATUS = 'I' "
			+ " where INDENT_CREATION_ID = ? ";
		int result = jdbcTemplate.update(query, new Object[] {
				indentNumber
		});
		return result;

	}
	@Override
	public int getIndentCreationApprovalSequenceNumber() {
		int indentCreationDetailsSeqNum = jdbcTemplate.queryForInt("SELECT INDENT_CREATION_APPROVAL_SEQ.NEXTVAL FROM DUAL");
		return indentCreationDetailsSeqNum;
	}



	@Override
	public int insertIndentCreationApprovalDtls(int indentCreationApprovalSeqNum, String indentNumber,
			IndentCreationDto indentCreationDto) {
		String query = "INSERT INTO SUM_INT_CREATION_APPROVAL_DTLS(INT_CREATION_APPROVAL_DTLS_ID ,INDENT_CREATION_ID ,"
			+ "INDENT_TYPE ,creation_date ,SITE_ID ,INDENT_CREATE_APPROVE_EMP_ID, PURPOSE  ) "+
			"VALUES(?, ?, ?, sysdate, ?, ?, ?)";
		int result = jdbcTemplate.update(query, new Object[] {
				indentCreationApprovalSeqNum, 	indentNumber,
				"S", indentCreationDto.getSiteId(),indentCreationDto.getUserId(),indentCreationDto.getPurpose()
		});
		return result;

	}



	@Override
	public int doInactiveInPurchaseTable(String indentNumber,String typeOfPurchase) {
		String query = "UPDATE SUM_PURCHASE_DEPT_INDENT_PROSS set STATUS = 'I',TYPE_OF_PURCHASE='"+typeOfPurchase+"' "
			+ " where INDENT_CREATION_DETAILS_ID=? ";
			
		int result = jdbcTemplate.update(query, new Object[] {
				indentNumber
		});
		return result;

	}

	@Override
	public List<ProductDetails> getProductDetailsLists(String indentNo, String vendorName,List<ProductDetails> listProductDetails,HttpServletRequest request) {
		List<Map<String, Object>> getDetailsList = null;
		//	List<ProductDetails> listProductDetails  =  new ArrayList<ProductDetails>();

		List<ProductDetails> getPoDetails = new ArrayList<ProductDetails>();
		ProductDetails objGetDetails=null;

		//	JdbcTemplate template = null;
		String sql = "SELECT SEFD.INDENT_NO,(P.NAME) AS PRODUCTNAME,(SP.NAME) AS SUBPRODUCTNAME,(CP.NAME) AS CHILDPRODUCTNAME,M.NAME,SEFD.VENDOR_MENTIONED_QTY,"+
		" P.PRODUCT_ID,SP.SUB_PRODUCT_ID,CP.CHILD_PRODUCT_ID,M.MEASUREMENT_ID,"+
		" SEFD.PRICE,SEFD.BASIC_AMOUNT,SEFD.DISCOUNT,SEFD.AMOUNT_AFTER_DISCOUNT,SEFD.TAX,SEFD.TAX_AMOUNT,SEFD.AMOUNT_AFTER_TAX,SEFD.OTHER_CHARGES,"+
		" SEFD.OTHER_CHARGES_AFTER_TAX,SEFD.TOTAL_AMOUNT,SEFD.HSN_CODE,SEFD.TAX_ON_OTHER_TRANSPORT_CHG,SEFD.INDENT_CREATION_DETAILS_ID,SEFD.CHILDPROD_CUST_DESC,SEFD.PURCHASE_DEPT_CHILD_PROD_DISC,INGST.TAX_PERCENTAGE "+
		" FROM  SUMADHURA_ENQUIRY_FORM_DETAILS SEFD,PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT M,VENDOR_DETAILS VD,INDENT_GST INGST "+
		" WHERE  SEFD.PRODUCT_ID=P.PRODUCT_ID AND SEFD.SUB_PRODUCT_ID=SP.SUB_PRODUCT_ID AND SEFD.CHILD_PRODUCT_ID=CP.CHILD_PRODUCT_ID"+
		" AND SEFD.VENDOR_ID=VD.VENDOR_ID AND SEFD.MEASUREMENT_ID=M.MEASUREMENT_ID AND INGST.TAX_ID = SEFD.TAX and SEFD.INDENT_NO=? AND VD.VENDOR_NAME=?";
		getDetailsList = jdbcTemplate.queryForList(sql, new Object[] {indentNo,vendorName});		

		try {

			//	template = new JdbcTemplate(DBConnection.getDbConnection())	

			/*if (null != getDetailsList && getDetailsList.size() > 0) {
				int i = 1;
				double finalamountdiv=0.0;
				for (Map<?, ?> GetDetailsBean : getDetailsList) {

					objGetDetails = new ProductDetails();
					objGetDetails.setIndentNo(GetDetailsBean.get("INDENT_NO") == null ? "" : GetDetailsBean.get("INDENT_NO").toString());
					objGetDetails.setProductId(GetDetailsBean.get("PRODUCT_ID") == null ? "" : GetDetailsBean.get("PRODUCT_ID").toString());
					objGetDetails.setSub_ProductId(GetDetailsBean.get("SUB_PRODUCT_ID") == null ? "" : GetDetailsBean.get("SUB_PRODUCT_ID").toString());
					objGetDetails.setChild_ProductId(GetDetailsBean.get("CHILD_PRODUCT_ID") == null ? "" : GetDetailsBean.get("CHILD_PRODUCT_ID").toString());
					objGetDetails.setMeasurementId(GetDetailsBean.get("MEASUREMENT_ID") == null ? "" : GetDetailsBean.get("MEASUREMENT_ID").toString());

					objGetDetails.setProductName(GetDetailsBean.get("PRODUCTNAME") == null ? "" : GetDetailsBean.get("PRODUCTNAME").toString());
					objGetDetails.setSub_ProductName(GetDetailsBean.get("SUBPRODUCTNAME") == null ? "" : GetDetailsBean.get("SUBPRODUCTNAME").toString());
					objGetDetails.setChild_ProductName(GetDetailsBean.get("CHILDPRODUCTNAME") == null ? "" : GetDetailsBean.get("CHILDPRODUCTNAME").toString());
					objGetDetails.setMeasurementName(GetDetailsBean.get("NAME") == null ? "" : GetDetailsBean.get("NAME").toString());
					objGetDetails.setRequiredQuantity(GetDetailsBean.get("VENDOR_MENTIONED_QTY") == null ? "" : GetDetailsBean.get("VENDOR_MENTIONED_QTY").toString());
					objGetDetails.setPrice(GetDetailsBean.get("PRICE") == null ? "" : GetDetailsBean.get("PRICE").toString());
					objGetDetails.setBasicAmt(GetDetailsBean.get("BASIC_AMOUNT") == null ? "" : GetDetailsBean.get("BASIC_AMOUNT").toString());
					objGetDetails.setStrDiscount(GetDetailsBean.get("DISCOUNT") == null ? "" : GetDetailsBean.get("DISCOUNT").toString());
					objGetDetails.setStrAmtAfterDiscount(GetDetailsBean.get("AMOUNT_AFTER_DISCOUNT") == null ? "" : GetDetailsBean.get("AMOUNT_AFTER_DISCOUNT").toString());
					objGetDetails.setTax(GetDetailsBean.get("TAX") == null ? "" : GetDetailsBean.get("TAX").toString());
					objGetDetails.setTaxAmount(GetDetailsBean.get("TAX_AMOUNT") == null ? "" : GetDetailsBean.get("TAX_AMOUNT").toString());
					objGetDetails.setAmountAfterTax(GetDetailsBean.get("AMOUNT_AFTER_TAX") == null ? "" : GetDetailsBean.get("AMOUNT_AFTER_TAX").toString());
					objGetDetails.setOthercharges1(GetDetailsBean.get("OTHER_CHARGES") == null ? "" : GetDetailsBean.get("OTHER_CHARGES").toString());
					objGetDetails.setOtherchargesaftertax1(GetDetailsBean.get("OTHER_CHARGES_AFTER_TAX") == null ? "" : GetDetailsBean.get("OTHER_CHARGES_AFTER_TAX").toString());
					objGetDetails.setTotalAmount(GetDetailsBean.get("TOTAL_AMOUNT") == null ? "" : GetDetailsBean.get("TOTAL_AMOUNT").toString());
					objGetDetails.setHsnCode(GetDetailsBean.get("HSN_CODE") == null ? "" : GetDetailsBean.get("HSN_CODE").toString());
					objGetDetails.setTaxonothertranportcharge1(GetDetailsBean.get("TAX_ON_OTHER_TRANSPORT_CHG") == null ? "0" : GetDetailsBean.get("TAX_ON_OTHER_TRANSPORT_CHG").toString());


					objGetDetails.setFinalamtdiv(GetDetailsBean.get("TOTAL_AMOUNT") == null ? "" : GetDetailsBean.get("TOTAL_AMOUNT").toString());


					String s=objGetDetails.getFinalamtdiv();
					if(s!="")
					{
						finalamountdiv = finalamountdiv+Double.parseDouble(s);
						System.out.println("the final amount"+finalamountdiv);
						objGetDetails.setFinalamtdiv(String.valueOf(finalamountdiv));
					}

					objGetDetails.setSerialno(i);

					GetDetailsInward.add(objGetDetails);

					i++;
				}
			}*/



			ProductDetails objProductDetails = null;
			String strListChildProdId = "";
			String strListChildProdName = "";
			String serverChildProdId = "";
			String strListProductId = "";
			String strListProductName = "";
			String strListSubproductId = "";
			String strListSubproductName = "";
			String strListMesurementId = "";
			String strListMesurementName = "";
			String strFormIndentCreationDetailsId = "";
			String strQuantity = "";
			String strPOIntiatedQuantity = "";
			String purchasedeptRequestReceiveQuantity = "";
			
			String taxId = "";
			String required_Quan = "";
			String price = "";
			String discount = "";
			String amtAfterDiscount = "";
			String tax = "";
			String taxAmount = "";
			String otherCharges = "";
			String otherChargesAfterTax = "";
			String totalAmt = "";
			String hsnCode = "";
			String tax_other_tranport = "";
			String finalAmt = "";
			String basicAmt="";
			String amountAfterTax="";
			String childProductdesc="";
			
			
			
			
			boolean falg = true;
			String strTaxId = "";
			int j=1;
			int count=0;
			String prodValues="";

			String strTaxPercentage = "";
			for(int i =0 ; i < listProductDetails.size() ; i++){


				objProductDetails = listProductDetails.get(i);
				strListProductId=objProductDetails.getProductId();
				strListProductName=objProductDetails.getProductName();
				strListSubproductId=objProductDetails.getSub_ProductId();
				strListSubproductName=objProductDetails.getSub_ProductName();
				strListMesurementId=objProductDetails.getMeasurementId();
				strListMesurementName=objProductDetails.getMeasurementName();
				strListChildProdId = objProductDetails.getChild_ProductId();
				strListChildProdName = objProductDetails.getChild_ProductName();
				strFormIndentCreationDetailsId = objProductDetails.getIndentCreationDetailsId();
				strQuantity = objProductDetails.getQuantity();
				strPOIntiatedQuantity = objProductDetails.getPoIntiatedQuantity();
				purchasedeptRequestReceiveQuantity = objProductDetails.getPurchasedeptRequestReceiveQuantity();
				if (null != getDetailsList && getDetailsList.size() > 0) {

					for (Map<?, ?> getDetailsBean : getDetailsList) {

						objGetDetails = new ProductDetails();
						serverChildProdId = getDetailsBean.get("CHILD_PRODUCT_ID") == null ? "" : getDetailsBean.get("CHILD_PRODUCT_ID").toString();
						falg  = true;

						if(strListChildProdId.equals(serverChildProdId)){

							objGetDetails = new ProductDetails();

							objGetDetails.setProductId(strListProductId);
							objGetDetails.setSub_ProductId(strListSubproductId);
							objGetDetails.setSub_ProductName(strListSubproductName);
							objGetDetails.setChild_ProductName(getDetailsBean.get("PURCHASE_DEPT_CHILD_PROD_DISC") == null ? "0" : getDetailsBean.get("PURCHASE_DEPT_CHILD_PROD_DISC").toString());
							objGetDetails.setProductName(strListProductName);
							objGetDetails.setMeasurementId(strListMesurementId);
							objGetDetails.setChild_ProductId(strListChildProdId);
							objGetDetails.setMeasurementName(strListMesurementName);
							objGetDetails.setPoIntiatedQuantity(strPOIntiatedQuantity);
							objGetDetails.setPurchasedeptRequestReceiveQuantity(purchasedeptRequestReceiveQuantity);

							strTaxPercentage = "";
							strTaxId = getDetailsBean.get("TAX") == null ? "0" : getDetailsBean.get("TAX").toString();
							strTaxPercentage = getDetailsBean.get("TAX_PERCENTAGE") == null ? "0" : getDetailsBean.get("TAX_PERCENTAGE").toString();



							strTaxPercentage = strTaxId+"$"+strTaxPercentage;
							
							 required_Quan =getDetailsBean.get("VENDOR_MENTIONED_QTY") == null ? "0" : getDetailsBean.get("VENDOR_MENTIONED_QTY").toString();
							 price =getDetailsBean.get("PRICE") == null ? "0" : getDetailsBean.get("PRICE").toString();
							 basicAmt=getDetailsBean.get("BASIC_AMOUNT") == null ? "0" : getDetailsBean.get("BASIC_AMOUNT").toString();
							 discount =getDetailsBean.get("DISCOUNT") == null ? "0" : getDetailsBean.get("DISCOUNT").toString();
							 amtAfterDiscount =getDetailsBean.get("AMOUNT_AFTER_DISCOUNT") == null ? "0" : getDetailsBean.get("AMOUNT_AFTER_DISCOUNT").toString();
							 tax =getDetailsBean.get("TAX_PERCENTAGE") == null ? "0" : getDetailsBean.get("TAX_PERCENTAGE").toString();
							 taxAmount =getDetailsBean.get("TAX_AMOUNT") == null ? "0" : getDetailsBean.get("TAX_AMOUNT").toString();
							 amountAfterTax=getDetailsBean.get("AMOUNT_AFTER_TAX") == null ? "0" : getDetailsBean.get("AMOUNT_AFTER_TAX").toString();
							 otherCharges =getDetailsBean.get("OTHER_CHARGES") == null ? "0" : getDetailsBean.get("OTHER_CHARGES").toString();
							 otherChargesAfterTax =getDetailsBean.get("OTHER_CHARGES_AFTER_TAX") == null ? "0" : getDetailsBean.get("OTHER_CHARGES_AFTER_TAX").toString();
							 totalAmt =getDetailsBean.get("TOTAL_AMOUNT") == null ? "0" : getDetailsBean.get("TOTAL_AMOUNT").toString();
							 hsnCode =getDetailsBean.get("HSN_CODE") == null ? "0" : getDetailsBean.get("HSN_CODE").toString();
							 tax_other_tranport =getDetailsBean.get("TAX_ON_OTHER_TRANSPORT_CHG") == null ? "0" : getDetailsBean.get("TAX_ON_OTHER_TRANSPORT_CHG").toString();
							 finalAmt =getDetailsBean.get("TOTAL_AMOUNT") == null ? "0" : getDetailsBean.get("TOTAL_AMOUNT").toString();
							 childProductdesc=getDetailsBean.get("CHILDPROD_CUST_DESC") == null ? "-" : getDetailsBean.get("CHILDPROD_CUST_DESC").toString();

							objGetDetails.setTaxId(strTaxPercentage);	
							objGetDetails.setRequiredQuantity(required_Quan);
							objGetDetails.setPrice(price);
							objGetDetails.setBasicAmt(basicAmt);
							objGetDetails.setStrDiscount(discount);
							objGetDetails.setStrAmtAfterDiscount(amtAfterDiscount);
							objGetDetails.setTax(tax);
							objGetDetails.setTaxAmount(taxAmount);
							objGetDetails.setAmountAfterTax(amountAfterTax);
							objGetDetails.setOthercharges1(otherCharges);
							objGetDetails.setOtherchargesaftertax1(otherChargesAfterTax);
							objGetDetails.setTotalAmount(totalAmt);
							objGetDetails.setHsnCode(hsnCode);
							objGetDetails.setTaxonothertranportcharge1(tax_other_tranport);
							objGetDetails.setFinalamtdiv(finalAmt);
							objGetDetails.setIndentCreationDetailsId(getDetailsBean.get("INDENT_CREATION_DETAILS_ID") == null ? "0" : getDetailsBean.get("INDENT_CREATION_DETAILS_ID").toString());
							objGetDetails.setChildProductCustDisc(childProductdesc);

							objGetDetails.setSerialno(j);
							prodValues=strQuantity+"|"+purchasedeptRequestReceiveQuantity+
									"|"+price+"|"+basicAmt+"|"+discount+"|"+amtAfterDiscount+"|"+strTaxPercentage+"|"+taxAmount+"|"+amountAfterTax+
									"|"+otherCharges+"|"+otherChargesAfterTax+"|"+hsnCode+"|"+tax_other_tranport+"|"+finalAmt+"|"+strFormIndentCreationDetailsId+"|"+childProductdesc;
									
							request.setAttribute("productvalues",prodValues);
							j++;
							falg  = false;
							count++;
							getPoDetails.add(objGetDetails);
							break;

						}



					}
					request.setAttribute("falg","false");

					if(falg){
						objGetDetails = new ProductDetails();

						objGetDetails.setProductId(strListProductId);
						objGetDetails.setSub_ProductId(strListSubproductId);
						objGetDetails.setChild_ProductId(strListChildProdId);
						objGetDetails.setMeasurementId(strListMesurementId);
						objGetDetails.setProductName(strListProductName);
						objGetDetails.setSub_ProductName(strListSubproductName);
						objGetDetails.setChild_ProductName(strListChildProdName);
						objGetDetails.setMeasurementName(strListMesurementName);
						objGetDetails.setRequiredQuantity(strQuantity);
						objGetDetails.setPoIntiatedQuantity(strPOIntiatedQuantity);
						objGetDetails.setPurchasedeptRequestReceiveQuantity(purchasedeptRequestReceiveQuantity);
						
						
						// required_Quan =getDetailsBean.get("VENDOR_MENTIONED_QTY") == null ? "0" : getDetailsBean.get("VENDOR_MENTIONED_QTY").toString();
					
						 basicAmt="0";
						 discount ="0";
						 amtAfterDiscount ="0";
						 tax ="0";
						 strTaxPercentage="1$0%";
						 taxAmount ="0";
						 amountAfterTax="0";
						 otherCharges ="0";
						 otherChargesAfterTax ="0";
						 totalAmt ="0";
						 hsnCode ="0";
						 tax_other_tranport ="0";
						 finalAmt ="0";
						 required_Quan="0";
						 childProductdesc="-";

						objGetDetails.setPrice("");
						objGetDetails.setBasicAmt("0");
						objGetDetails.setStrDiscount("");
						objGetDetails.setStrAmtAfterDiscount("0");
						objGetDetails.setTax("0");
						objGetDetails.setTaxAmount("0");
						objGetDetails.setAmountAfterTax("0");
						objGetDetails.setOthercharges1("0");
						objGetDetails.setOtherchargesaftertax1("0");
						objGetDetails.setTotalAmount("0");
						objGetDetails.setHsnCode("0");
						objGetDetails.setTaxonothertranportcharge1("0");
						objGetDetails.setTaxId("1$0%");
						objGetDetails.setIndentCreationDetailsId(strFormIndentCreationDetailsId);
						objGetDetails.setChildProductCustDisc("");
						objGetDetails.setSerialno(j);
						j++;
						
						prodValues=strQuantity+"|"+purchasedeptRequestReceiveQuantity+
								"|"+price+"|"+basicAmt+"|"+discount+"|"+amtAfterDiscount+"|"+strTaxPercentage+"|"+taxAmount+"|"+amountAfterTax+
								"|"+otherCharges+"|"+otherChargesAfterTax+"|"+hsnCode+"|"+tax_other_tranport+"|"+finalAmt+"|"+strFormIndentCreationDetailsId+"|"+childProductdesc;;
						request.setAttribute("productvalues",prodValues);
						getPoDetails.add(objGetDetails);
						
						
						if(count!=0){
							request.setAttribute("falg","false");
						}else{
						request.setAttribute("falg","true");
					}
					}

					
					//	}	

				}else{


					 basicAmt="0";
					 discount ="0";
					 amtAfterDiscount ="0";
					 tax ="0";
					 strTaxPercentage="1$0%";
					 taxAmount ="0";
					 amountAfterTax="0";
					 otherCharges ="0";
					 otherChargesAfterTax ="0";
					 totalAmt ="0";
					 hsnCode ="0";
					 tax_other_tranport ="0";
					 finalAmt ="0";
					 required_Quan="0";
					 childProductdesc="-";
					objGetDetails = new ProductDetails();

					objGetDetails.setProductId(strListProductId);
					objGetDetails.setSub_ProductId(strListSubproductId);
					objGetDetails.setChild_ProductId(strListChildProdId);
					objGetDetails.setMeasurementId(strListMesurementId);

					objGetDetails.setProductName(strListProductName);
					objGetDetails.setSub_ProductName(strListSubproductName);
					objGetDetails.setChild_ProductName(strListChildProdName);
					objGetDetails.setMeasurementName(strListMesurementName);
					objGetDetails.setRequiredQuantity(strQuantity);
					objGetDetails.setPoIntiatedQuantity(strPOIntiatedQuantity);
					objGetDetails.setPurchasedeptRequestReceiveQuantity(purchasedeptRequestReceiveQuantity);
					objGetDetails.setPrice("");
					objGetDetails.setBasicAmt("0");
					objGetDetails.setStrDiscount("");
					objGetDetails.setStrAmtAfterDiscount("0");
					objGetDetails.setTax("0");
					objGetDetails.setTaxAmount("0");
					objGetDetails.setAmountAfterTax("0");
					objGetDetails.setOthercharges1("0");
					objGetDetails.setOtherchargesaftertax1("0");
					objGetDetails.setTotalAmount("0");
					objGetDetails.setHsnCode("0");
					objGetDetails.setTaxonothertranportcharge1("0");
					objGetDetails.setTaxId("1$0%");
					objGetDetails.setIndentCreationDetailsId(strFormIndentCreationDetailsId);
					objGetDetails.setChildProductCustDisc("");
					objGetDetails.setSerialno(j);
					j++;
					prodValues=strQuantity+"|"+purchasedeptRequestReceiveQuantity+
							"|"+price+"|"+basicAmt+"|"+discount+"|"+amtAfterDiscount+"|"+strTaxPercentage+"|"+taxAmount+"|"+amountAfterTax+
							"|"+otherCharges+"|"+otherChargesAfterTax+"|"+hsnCode+"|"+tax_other_tranport+"|"+finalAmt+"|"+strFormIndentCreationDetailsId+"|"+childProductdesc;
							
					request.setAttribute("productvalues",prodValues);
					getPoDetails.add(objGetDetails);
					
					if(count!=0){
						request.setAttribute("falg","false");
					}else{
					request.setAttribute("falg","true");
				}

				}
				

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return getPoDetails;
	}

	public Map<String, String> getApproveCreateEmp(int indentnumber,HttpServletRequest request)
	{
		List<Map<String, Object>> productList = null;

		Map<String, String> gst = null;
		gst = new TreeMap<String, String>();
		String empName="";
		String creationDate="";
		SimpleDateFormat df2 = new SimpleDateFormat("dd-mm-yyyy HH:mm:ss"); 
		String query = "SELECT SED.EMP_NAME,SICAD.CREATION_DATE FROM SUMADHURA_EMPLOYEE_DETAILS SED,SUM_INT_CREATION_APPROVAL_DTLS  SICAD"+
		" where INDENT_TYPE = 'C' and  SICAD.INDENT_CREATE_APPROVE_EMP_ID=SED.EMP_ID and INDENT_CREATION_ID = ?";

		productList = jdbcTemplate.queryForList(query, new Object[] {indentnumber});
		try{

			if(productList!= null){
				for(Map<String, Object> gstSlabs : productList) {


					creationDate=gstSlabs.get("CREATION_DATE").toString();
					//Date d1 = df2.parse(creationDate);
					//creationDate= df2.format(d1);
					System.out.println("the creation date"+creationDate);






					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(creationDate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					creationDate=dt1.format(date);

					gst.put(String.valueOf(gstSlabs.get("EMP_NAME")),creationDate);

				}	} 
		}catch(Exception e){
			e.printStackTrace();
		}

		return gst;
	}

	public Map<String, String> getPOApproveCreateEmp(int tempPONumber,HttpServletRequest request)
	{
		List<Map<String, Object>> productList = null;

		Map<String, String> gst = null;
		gst = new TreeMap<String, String>();
		String empName="";
		String creationDate="";
		SimpleDateFormat df2 = new SimpleDateFormat("dd-mm-yyyy HH:mm:ss"); 
		String query = "SELECT SED.EMP_NAME,SPCAD.CREATION_DATE FROM SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PO_CRT_APPRL_DTLS  SPCAD "+
		"where SPCAD.OPERATION_TYPE = 'C' and  SPCAD.PO_CREATE_APPROVE_EMP_ID=SED.EMP_ID and TEMP_PO_NUMBER = ?";

		productList = jdbcTemplate.queryForList(query, new Object[] {tempPONumber});
		try{

			if(productList!= null){
				for(Map<String, Object> gstSlabs : productList) {


					creationDate=gstSlabs.get("CREATION_DATE").toString();
					//Date d1 = df2.parse(creationDate);
					//creationDate= df2.format(d1);
				//	System.out.println("the creation date"+creationDate);






					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(creationDate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					creationDate=dt1.format(date);

					gst.put(String.valueOf(gstSlabs.get("EMP_NAME")),creationDate);

				}	} 
		}catch(Exception e){
			e.printStackTrace();
		}

		return gst;
	}

	public void getVerifiedEmpNames(int indentnumber,HttpServletRequest request,String siteId)
	{

		Map<String, String> names = null;
		names = new TreeMap<String, String>();
		Map<String, String> names1=new TreeMap<String, String>();
		List<Map<String, Object>> productList = null;
		List<Map<String, Object>> productList1 = null;
		//	List<String> listOfVerifiedNames = new ArrayList<String>();
		//	List<String> listOfVerifiedDates = new ArrayList<String>();
		//	List<String> listOfApprovedNames = new ArrayList<String>();
		//	List<String> listOfApprovedDates = new ArrayList<String>();
		//	String empName="";
		String creationDate="";

		String query = "SELECT SED.EMP_NAME,SICAD.CREATION_DATE FROM SUM_INT_CREATION_APPROVAL_DTLS SICAD,SUMADHURA_EMPLOYEE_DETAILS SED"+
		" where SICAD.INDENT_TYPE = 'A' and  SICAD.INDENT_CREATE_APPROVE_EMP_ID=SED.EMP_ID and SICAD.SITE_ID= ? and INDENT_CREATION_ID = ?  order by SICAD.CREATION_DATE  ASC"; 

		productList = jdbcTemplate.queryForList(query, new Object[] {siteId,indentnumber});

		String query1 = "SELECT SED.EMP_NAME,SICAD.CREATION_DATE FROM SUM_INT_CREATION_APPROVAL_DTLS SICAD,SUMADHURA_EMPLOYEE_DETAILS SED"+
		" where SICAD.INDENT_TYPE = 'A' and  SICAD.INDENT_CREATE_APPROVE_EMP_ID=SED.EMP_ID and SICAD.SITE_ID= ? and INDENT_CREATION_ID = ?  order by SICAD.CREATION_DATE  DESC"; 

		productList1 = jdbcTemplate.queryForList(query1, new Object[] {siteId,indentnumber});
		//DateFormat df2 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss"); 
		try{

			if(productList!= null){
				for(Map<String, Object> gstSlabs : productList) {

					creationDate=String.valueOf(gstSlabs.get("CREATION_DATE"));
					//Date d1 = df2.parse(creationDate);
					//creationDate= df2.format(d1);


					//String creationDate = "2018-03-01 11:01:53.0";

					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(creationDate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					creationDate=dt1.format(date);


					//System.out.println(creationDate);


					names.put(String.valueOf(gstSlabs.get("EMP_NAME")),creationDate);
					break;

				}	} 
			request.setAttribute("listOfVerifiedNames",names);


			if(productList1!= null){
				for(Map<String, Object> gstSlabs : productList1) {
					//SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					creationDate=String.valueOf(gstSlabs.get("CREATION_DATE"));
					//Date d1 = df2.parse(creationDate);
					//creationDate= df2.format(d1);


					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(creationDate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					creationDate=dt1.format(date);


					names1.put(String.valueOf(gstSlabs.get("EMP_NAME")),creationDate);
					break;

				}	} 
			request.setAttribute("listOfApprovedNames",names1);
		}


		catch(Exception e){
			e.printStackTrace();
		}
	}


	public void getPOVerifiedEmpNames(int intTempPONumber,HttpServletRequest request)
	{

		Map<String, String> names = null;
		names = new TreeMap<String, String>();
		Map<String, String> names1=new TreeMap<String, String>();
		List<Map<String, Object>> productList = null;
		List<Map<String, Object>> productList1 = null;
		//	List<String> listOfVerifiedNames = new ArrayList<String>();
		//	List<String> listOfVerifiedDates = new ArrayList<String>();
		//	List<String> listOfApprovedNames = new ArrayList<String>();
		//	List<String> listOfApprovedDates = new ArrayList<String>();
		//	String empName="";
		String creationDate="";

		String query = "SELECT SED.EMP_NAME,SPCAD.CREATION_DATE FROM SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PO_CRT_APPRL_DTLS  SPCAD "+
		"where SPCAD.OPERATION_TYPE = 'A' and  SPCAD.PO_CREATE_APPROVE_EMP_ID=SED.EMP_ID and TEMP_PO_NUMBER = ?   order by SPCAD.CREATION_DATE  ASC"; 

		productList = jdbcTemplate.queryForList(query, new Object[] {intTempPONumber});

		String query1 = "SELECT SED.EMP_NAME,SPCAD.CREATION_DATE FROM SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PO_CRT_APPRL_DTLS  SPCAD "+
		"where SPCAD.OPERATION_TYPE = 'A' and  SPCAD.PO_CREATE_APPROVE_EMP_ID=SED.EMP_ID and TEMP_PO_NUMBER = ?  order by SPCAD.CREATION_DATE  DESC"; 

		productList1 = jdbcTemplate.queryForList(query1, new Object[] {intTempPONumber});
		//DateFormat df2 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss"); 
		try{

			if(productList!= null){
				for(Map<String, Object> gstSlabs : productList) {

					creationDate=String.valueOf(gstSlabs.get("CREATION_DATE"));
					//Date d1 = df2.parse(creationDate);
					//creationDate= df2.format(d1);


					//String creationDate = "2018-03-01 11:01:53.0";

					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(creationDate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					creationDate=dt1.format(date);


					//System.out.println(creationDate);


					names.put(String.valueOf(gstSlabs.get("EMP_NAME")),creationDate);
					break;

				}	} 
			request.setAttribute("listOfVerifiedNames",names);


			if(productList1!= null){
				for(Map<String, Object> gstSlabs : productList1) {
					//SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					creationDate=String.valueOf(gstSlabs.get("CREATION_DATE"));
					//Date d1 = df2.parse(creationDate);
					//creationDate= df2.format(d1);


					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date date = dt.parse(creationDate); 


					SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					creationDate=dt1.format(date);


					names1.put(String.valueOf(gstSlabs.get("EMP_NAME")),creationDate);
					break;

				}	} 
			request.setAttribute("listOfApprovedNames",names1);
		}


		catch(Exception e){
			e.printStackTrace();
		}
	}


	@Override
	public List<String>  getAllEmployeeEmailsUnderDepartment(String deptId) {


		List<Map<String, Object>> dbIndentDts = null;
		String strEmailId = "";
		List<String> objList = new ArrayList<String>();
		//thisIsAStringArray[5] = "FFF";
		String query = " select EMP_EMAIL from SUMADHURA_EMPLOYEE_DETAILS SED where DEPT_ID = ? ";


		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {deptId});

		if(dbIndentDts!= null){



			for(Map<String, Object> prods : dbIndentDts) {



				strEmailId = prods.get("EMP_EMAIL")==null ? "" :   prods.get("EMP_EMAIL").toString();

				if(strEmailId.contains(",")){
					for(String strEmailId1 : strEmailId.split(","))
					{
						objList.add(strEmailId1);
					}
				}
				else if(!strEmailId.equals("") && strEmailId!=null){
				objList.add(strEmailId);
				}


			}	
		}

		return objList;

	}

	public String getIndentCreationDetailsId(String indentCreationId){
		List<Map<String, Object>> productList = null;
		String indentCreationDtslId="";
		String sql="select INDENT_CREATION_DETAILS_ID from SUMADHURA_INDENT_CREATION_DTLS where INDENT_CREATION_ID=?";

		productList = jdbcTemplate.queryForList(sql, new Object[] {indentCreationId});
		if (null != productList && productList.size() > 0) {
			for (Map<?, ?> getTransportChargesDetails : productList) {
				indentCreationDtslId = getTransportChargesDetails.get("INDENT_CREATION_DETAILS_ID") == null ? "" : getTransportChargesDetails.get("INDENT_CREATION_DETAILS_ID").toString();

			}
		}

		return indentCreationDtslId;
	}



	@Override
	public int getSiteIdByPONumber(String poNumber) {
		return jdbcTemplate.queryForInt("select SIC.SITE_ID from SUMADHURA_TEMP_PO_ENTRY STPE,"
				+ "SUMADHURA_INDENT_CREATION SIC where SIC.INDENT_CREATION_ID = STPE.INDENT_NO "
				+ "and STPE.PO_NUMBER = '"+poNumber+"'");

	}
	@Override
	public int updateTempPoEntry(String approvalEmpId,String poNumber,String ccmailId){
		int val=0;
		String response="";
		String query1 = "update SUMADHURA_TEMP_PO_ENTRY set TEMP_PO_PENDING_EMP_ID=?, CC_EMAIL_ID=? where PO_NUMBER=?";
		val = jdbcTemplate.update(query1, new Object[] {approvalEmpId,ccmailId,poNumber
		});


		return val;
	}

	@Override
	public int insertTempPOorPOCreateApproverDtls(String strTempPoNumber,String poNumber,String strEmpId,String strSIteId,String strOperationType,String remarks){

		String query1 = " insert into SUMADHURA_PO_CRT_APPRL_DTLS(PO_CREATION_APPROVAL_DTLS_ID,TEMP_PO_NUMBER,PO_ENTRY_ID,CREATION_DATE,SITE_ID,PO_CREATE_APPROVE_EMP_ID,OPERATION_TYPE,PURPOSE)"+
		"values( PO_CRT_APPROVAL_DTLS_ID_SEQ.nextval, ?, ?, sysdate, ?, ?,?,?)";

		int result = jdbcTemplate.update(query1, new Object[] {strTempPoNumber,poNumber,strSIteId,strEmpId,strOperationType,remarks});

		return result;
	}


	@Override
	public List<IndentCreationBean> ViewTempPo(String fromDate, String toDate,String tempPoNumber) {

		String query = "";
		List<Map<String, Object>> dbIndentDts = null;
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		IndentCreationBean indentObj = null; 

		try {
			//if part is for view indent receive details,else part is for view indent issue details
			//	template = new JdbcTemplate(DBConnection.getDbConnection());

			if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
				query = " SELECT DISTINCT (PO_NUMBER),INDENT_NO,SIC.SITEWISE_INDENT_NO,PO_DATE,SED.EMP_NAME,SITE_NAME,STPE.SITE_ID FROM   SUMADHURA_TEMP_PO_ENTRY STPE,SUMADHURA_EMPLOYEE_DETAILS SED ,SITE S,SUMADHURA_INDENT_CREATION SIC WHERE STPE.PO_ENTRY_USER_ID=SED.EMP_ID AND STPE.PO_STATUS='A' and S.SITE_ID = STPE.SITE_ID and TRUNC(STPE.PO_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy') and SIC.INDENT_CREATION_ID = INDENT_NO";

				//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
			} else if (StringUtils.isNotBlank(fromDate)) {
				query = "SELECT DISTINCT (PO_NUMBER),INDENT_NO,SIC.SITEWISE_INDENT_NO,PO_DATE,SED.EMP_NAME,SITE_NAME,STPE.SITE_ID FROM   SUMADHURA_TEMP_PO_ENTRY STPE,SUMADHURA_EMPLOYEE_DETAILS SED,SITE S,SUMADHURA_INDENT_CREATION SIC WHERE STPE.PO_ENTRY_USER_ID=SED.EMP_ID AND STPE.PO_STATUS='A' and S.SITE_ID = STPE.SITE_ID and TRUNC(STPE.PO_DATE) =TO_DATE('"+fromDate+"', 'dd-MM-yy') and SIC.INDENT_CREATION_ID = INDENT_NO ";



			} else if(StringUtils.isNotBlank(toDate)) {
				query = "SELECT DISTINCT (PO_NUMBER),INDENT_NO,SIC.SITEWISE_INDENT_NO,PO_DATE,SED.EMP_NAME,SITE_NAME,STPE.SITE_ID FROM   SUMADHURA_TEMP_PO_ENTRY STPE,SUMADHURA_EMPLOYEE_DETAILS SED,SITE S,SUMADHURA_INDENT_CREATION SIC WHERE STPE.PO_ENTRY_USER_ID=SED.EMP_ID AND STPE.PO_STATUS='A' and S.SITE_ID = STPE.SITE_ID and TRUNC(STPE.PO_DATE)  =TO_DATE('"+toDate+"', 'dd-MM-yy') and SIC.INDENT_CREATION_ID = INDENT_NO";
			}
			else if(StringUtils.isNotBlank(tempPoNumber)) {
				query = "SELECT DISTINCT (PO_NUMBER),INDENT_NO,SIC.SITEWISE_INDENT_NO,PO_DATE,SED.EMP_NAME,SITE_NAME,STPE.SITE_ID FROM   SUMADHURA_TEMP_PO_ENTRY STPE,SUMADHURA_EMPLOYEE_DETAILS SED,SITE S,SUMADHURA_INDENT_CREATION SIC WHERE STPE.PO_ENTRY_USER_ID=SED.EMP_ID AND STPE.PO_STATUS='A' and S.SITE_ID = STPE.SITE_ID and STPE.PO_NUMBER='"+tempPoNumber+"' and SIC.INDENT_CREATION_ID = INDENT_NO";
			}



			dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{});

			for(Map<String, Object> prods : dbIndentDts) {
				indentObj = new IndentCreationBean();

				indentObj.setPonumber(prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString());

				//	indentObj.setStrRequiredDate(prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString());
				indentObj.setToEmpName(prods.get("EMP_NAME")==null ? "" : prods.get("EMP_NAME").toString());
				indentObj.setIndentNumber(Integer.parseInt(prods.get("INDENT_NO")==null ? "" : prods.get("INDENT_NO").toString()));
				indentObj.setSiteName(prods.get("SITE_NAME")==null ? "0" : prods.get("SITE_NAME").toString());
				indentObj.setSiteId(Integer.parseInt(prods.get("SITE_ID")==null ? "0" : prods.get("SITE_ID").toString()));
				indentObj.setSiteWiseIndentNo(Integer.parseInt(prods.get("SITEWISE_INDENT_NO")==null ? "" : prods.get("SITEWISE_INDENT_NO").toString()));
				String date=prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString();
				if (StringUtils.isNotBlank(date)) {
					date = DateUtil.dateConversion(date);
				} else {
					date = "";
				}
				indentObj.setStrScheduleDate(date);

				list.add(indentObj);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//.info("Exception Occured Inside getViewGrnDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			//	template = null;
			dbIndentDts = null;
		}
		return list;
	}

	@Override
	public List<Map<String, Object>> getListOfActivePOs(){

		List<Map<String, Object>> poList = null;
		String sql="select SPE.PO_NUMBER,VD.VENDOR_NAME,SPE.INDENT_NO,SIC.SITEWISE_INDENT_NO,S.SITE_NAME,SPE.PO_DATE,SPE.SITE_ID "
			+ " from SUMADHURA_PO_ENTRY SPE,VENDOR_DETAILS VD,SITE S,SUMADHURA_INDENT_CREATION SIC "
			+ " where SPE.VENDOR_ID = VD.VENDOR_ID AND SPE.SITE_ID = S.SITE_ID AND SPE.PO_STATUS = 'A' AND SPE.INDENT_NO=SIC.INDENT_CREATION_ID";

		poList = jdbcTemplate.queryForList(sql, new Object[] {});
		return poList;

	}
	@Override
	public int updatePOEntryDetails(ProductDetails productDetails)
	{

		String query =  "update SUMADHURA_PO_ENTRY_DETAILS set VENDOR_PRODUCT_DESC=?,PRODUCT_ID = ? ,SUB_PRODUCT_ID = ? ,CHILD_PRODUCT_ID = ? ,MEASUR_MNT_ID = ? ,PO_QTY = ? ,PRICE = ? ,BASIC_AMOUNT = ? ,DISCOUNT = ? ,AMOUNT_AFTER_DISCOUNT = ? ,TAX = ? ,TAX_AMOUNT = ? ,AMOUNT_AFTER_TAX = ? ,HSN_CODE = ? ,OTHER_CHARGES = ? ,TAX_ON_OTHER_TRANSPORT_CHG = ? ,OTHER_CHARGES_AFTER_TAX = ? ,TOTAL_AMOUNT = ? where PO_ENTRY_DETAILS_ID = ? ";

		int result = jdbcTemplate.update(query, new Object[] {
				productDetails.getChildProductCustDisc(),
				productDetails.getProductId(),
				productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),
				productDetails.getMeasurementId(),
				productDetails.getQuantity(),productDetails.getPricePerUnit(),productDetails.getBasicAmt(),
				productDetails.getStrDiscount(),productDetails.getStrAmtAfterDiscount(),
				productDetails.getTax(),productDetails.getTaxAmount(),productDetails.getAmountAfterTax(),
				productDetails.getHsnCode(),
				productDetails.getOtherOrTransportCharges1(),productDetails.getTaxOnOtherOrTransportCharges1(),productDetails.getOtherOrTransportChargesAfterTax1(),
				productDetails.getTotalAmount(),
				productDetails.getPoEntryDetailsId()


		});
		return result;
	}

	@Override
	public int updatePOTransportChargesDetails(TransportChargesDto transportChargesDto,int id){

		String query =  "update SUMADHURA_PO_TRNS_O_CHRGS_DTLS set TRANSPORT_ID = ? ,TRANSPORT_AMOUNT = ? ,"
			+ " TRANSPORT_GST_PERCENTAGE = ? ,TRANSPORT_GST_AMOUNT = ? ,TOTAL_AMOUNT_AFTER_GST_TAX = ? "
			+ " where ID = ? ";

		int result = jdbcTemplate.update(query, new Object[] {

				transportChargesDto.getTransportId(),
				transportChargesDto.getTransportAmount(),
				transportChargesDto.getTransportGSTPercentage(),
				transportChargesDto.getTransportGSTAmount(),
				transportChargesDto.getTotalAmountAfterGSTTax(),
				id
		});


		return result;
	}



	@Override
	public int getPoEnterSeqNoByPONumber(String poNumber,String toSite) {
		String query  = "select PO_ENTRY_ID from  SUMADHURA_PO_ENTRY where PO_NUMBER = ? and SITE_ID = ? ";
		return jdbcTemplate.queryForInt(query, new Object[] {poNumber,toSite});

	}



	@Override
	public int deletePOEntryDetails(String poEntryDetailsId) {
		String query =  "DELETE FROM SUMADHURA_PO_ENTRY_DETAILS WHERE PO_ENTRY_DETAILS_ID = ? ";
		return jdbcTemplate.update(query, new Object[] {poEntryDetailsId});
	}



	@Override
	public int updatePOIntiatedQuantityInPDTable(String indentCreationDetailsId, String quantity) {
		String query =  "update SUM_PURCHASE_DEPT_INDENT_PROSS set PO_INTIATED_QUANTITY = PO_INTIATED_QUANTITY-?,STATUS='A'  where INDENT_CREATION_DETAILS_ID = ? ";
		return jdbcTemplate.update(query, new Object[] {quantity,indentCreationDetailsId});
	}



	@Override
	public int deletePOTransportChargesDetails(int poTransChrgsDtlsSeqNo) {
		String query =  "DELETE FROM SUMADHURA_PO_TRNS_O_CHRGS_DTLS WHERE ID = ? ";
		return jdbcTemplate.update(query, new Object[] {poTransChrgsDtlsSeqNo});
	}



	@Override
	public List<IndentCreationBean> getDeletedProductDetailsLists(int indentNumber) {
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		List<Map<String, Object>> dbIndentDts = null;

		String query = "SELECT P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,"
			+ " SICHD.ACTUAL_PRODCT_ID,SICHD.ACTUAL_SUB_PRODCT_ID,SICHD.ACTUAL_CHILD_PRODCT_ID,SICHD.ACTUAL_MEASURMENT_ID,"
			+ " SICHD.ACTUAL_QUANTITY,SICHD.REMARKS,SED.EMP_NAME FROM SUMADHURA_INDENT_CHANGED_DTLS SICHD, PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST,SUMADHURA_EMPLOYEE_DETAILS SED "
			+ " WHERE SICHD.ACTUAL_PRODCT_ID=P.PRODUCT_ID AND SICHD.ACTUAL_SUB_PRODCT_ID=SP.SUB_PRODUCT_ID AND SICHD.ACTUAL_CHILD_PRODCT_ID=CP.CHILD_PRODUCT_ID "
			+ " AND SICHD.ACTUAL_MEASURMENT_ID=MST.MEASUREMENT_ID AND SICHD.INDENT_CREATION_ID = ? AND SICHD.INDENT_CHANGE_ACTION = 'D' AND SICHD.EMP_ID = SED.EMP_ID";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
		int sno = 50;
		for(Map<String, Object> prods : dbIndentDts) {
			IndentCreationBean indentCreationBean = new IndentCreationBean();
			sno++;
			indentCreationBean.setStrSerialNumber(String.valueOf(sno));
			String prodId = prods.get("ACTUAL_PRODCT_ID")==null ? "" :   prods.get("ACTUAL_PRODCT_ID").toString();
			String subProductId = prods.get("ACTUAL_SUB_PRODCT_ID")==null ? "" :   prods.get("ACTUAL_SUB_PRODCT_ID").toString();
			String childProdId = prods.get("ACTUAL_CHILD_PRODCT_ID")==null ? "" :   prods.get("ACTUAL_CHILD_PRODCT_ID").toString();
			String measurementId = prods.get("ACTUAL_MEASURMENT_ID")==null ? "" :   prods.get("ACTUAL_MEASURMENT_ID").toString();

			indentCreationBean.setProductId1(prodId);
			indentCreationBean.setSubProductId1(subProductId);
			indentCreationBean.setChildProductId1(childProdId);
			indentCreationBean.setUnitsOfMeasurementId1(measurementId);
			indentCreationBean.setProduct1(prods.get("PRODUCT_NAME")==null ? "" :   prods.get("PRODUCT_NAME").toString());
			indentCreationBean.setSubProduct1(prods.get("SUB_PRODUCT_NAME")==null ? "" :   prods.get("SUB_PRODUCT_NAME").toString());
			indentCreationBean.setChildProduct1(prods.get("CHILD_PRODUCT_NAME")==null ? "" :   prods.get("CHILD_PRODUCT_NAME").toString());
			indentCreationBean.setUnitsOfMeasurement1(prods.get("MEASUREMENT_NAME")==null ? "" :   prods.get("MEASUREMENT_NAME").toString());
			indentCreationBean.setRequiredQuantity1(prods.get("ACTUAL_QUANTITY")==null ? "" :   prods.get("ACTUAL_QUANTITY").toString());
			String employee = prods.get("EMP_NAME")==null ? "" :   prods.get("EMP_NAME").toString();
			String remarks = prods.get("REMARKS")==null ? "0" :   prods.get("REMARKS").toString();
			indentCreationBean.setRemarks1(employee+" : "+remarks);


			list.add(indentCreationBean);
		}	
		return list;

	}



	@Override
	public String getStateNameForTermsAndConditions(String site_id) {
		String Query = "select STATE from VENDOR_DETAILS where VENDOR_ID = '"+site_id+"'"; 
		String result = jdbcTemplate.queryForObject(Query, String.class);
		return result;

	}


	public int getPoInfinityNumberGenerator(String serviceState){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String infinityNumber = "select max(INFINITY_NUMBER) from SUMADHURA_HO_WISE_PO_NUMBER where SERVICE_NAME='"+serviceState+"'";

		int result = jdbcTemplate.queryForInt(infinityNumber);

		return result+1;
	}


	public int getPoYearWiseNumberGenerator(String serviceState){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String yearWiseNumber = "select max(YEARWISE_NUMBER) from SUMADHURA_HO_WISE_PO_NUMBER where SERVICE_NAME='"+serviceState+"'";

		int result = jdbcTemplate.queryForInt(yearWiseNumber);

		return result+1;
	}
	public int getUpdatePoNumberGeneratorHeadOfficeWise(int infinityNumber,int yearWiseNumber,String serviceName){

		String query = "update SUMADHURA_HO_WISE_PO_NUMBER set INFINITY_NUMBER = ?,YEARWISE_NUMBER=? where SERVICE_NAME = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				infinityNumber,yearWiseNumber,serviceName
		});
		return result;
	}
	/*public int getUpdatePoNumberGeneratorHeadOfficeWise(int infinityNumber,int yearWiseNumber,String serviceName){

		String query = "update SUM_HEAD_OFFICE_WISE_PO_NUMBER set INFINITY_NUMBER = ?,YEARWISE_NUMBER=? where SERVICE_NAME = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				infinityNumber,yearWiseNumber,"PO_TELANGANA"
		});
		return result;
	}*/

	/*	
	public int getUpdatePoNumberGeneratorForKarnataka(int infinityNumber,int yearWiseNumber){

		String query = "update SUM_HEAD_OFFICE_WISE_PO_NUMBER set INFINITY_NUMBER = ?,YEARWISE_NUMBER=? where SERVICE_NAME = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				infinityNumber,yearWiseNumber,"PO_KARNATAKA"
		});
		return result;
	}*/

	public int getUpdateStateWisePoNumber(int siteWise_Number,int stateYearWisePoNum,String strSiteId){

		String query = "update SUMADHURA_SITE_WISE_PO_NUMBER set SITE_WISE_NUMBER = ?,YEARWISE_NUMBER=? where SITE_ID = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				siteWise_Number,stateYearWisePoNum,strSiteId
		});
		return result;
	}

	public int getStateWisePoNumber(String strSiteId){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String infinityNumber = "select max(SITE_WISE_NUMBER) from SUMADHURA_SITE_WISE_PO_NUMBER";

		int result = jdbcTemplate.queryForInt(infinityNumber);

		return result+1;
	}

	public int getStateWiseYearPo_Number(String SiteId){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String infinityNumber = "select max(YEARWISE_NUMBER) from SUMADHURA_SITE_WISE_PO_NUMBER";

		int result = jdbcTemplate.queryForInt(infinityNumber);

		return result+1;
	}

	public int getHeadOfficeInfinitMaxId(String poState){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String intSeqNum = "select INFINITY_NUMBER from SUMADHURA_HO_WISE_PO_NUMBER where SERVICE_NAME='"+poState+"' ";

		int result = jdbcTemplate.queryForInt(intSeqNum);

		return result;
	}

	public String getSiteAddress(String siteId) {
		String query = "SELECT ADDRESS FROM VENDOR_DETAILS where VENDOR_ID ='"+siteId+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return result;

	}




	public static void main(String [] args){
		Calendar cal = Calendar.getInstance();
		String currentYearYY = new SimpleDateFormat("YY").format(cal.getTime());
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH)+1;
		String strFinacialYear = "";
		if(currentMonth <=3){
			strFinacialYear = (currentYear-1)+"-"+currentYearYY;
		}else{
			strFinacialYear = currentYear+"-"+(Integer.parseInt(currentYearYY)+1);
		}




		//System.out.println(strFinacialYear);

	}



	@Override
	public int getSiteWiseIndentNo(int indentNumber) {
		String query = "select SITEWISE_INDENT_NO from SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID = ? ";
		int result = 0;
		try {
			result = jdbcTemplate.queryForInt(query, new Object[] {indentNumber});
		} catch (EmptyResultDataAccessException e) {
			result = 0;
		}
		return result;
	}
	
	public String getPoCreatedEmpName(String userId){
		List<Map<String, Object>> dbEmpDts = null;
		String strEmpName="";
		String strEmpEmailId="";
		String strMobiloeNumber="";
		String strResponse="";
		String query="select EMP_NAME,EMP_EMAIL,MOBILE_NUMBER from SUMADHURA_EMPLOYEE_DETAILS SED WHERE EMP_ID=? ";
		dbEmpDts = jdbcTemplate.queryForList(query, new Object[] {userId});
		for(Map<String, Object> prods : dbEmpDts) {
			strEmpName=prods.get("EMP_NAME")==null ? "" :   prods.get("EMP_NAME").toString();
			strEmpEmailId=prods.get("EMP_EMAIL")==null ? "" :   prods.get("EMP_EMAIL").toString();
			strMobiloeNumber=prods.get("MOBILE_NUMBER")==null ? "-" :   prods.get("MOBILE_NUMBER").toString();
			
			strResponse=strEmpName+","+strEmpEmailId+","+strMobiloeNumber;
			
		}
		
	return strResponse;
	
	}
	
	public String getPoCreatedEmpId(String tempPoNumber){
		String Query = "select PO_CREATE_APPROVE_EMP_ID from SUMADHURA_PO_CRT_APPRL_DTLS where OPERATION_TYPE='C' and TEMP_PO_NUMBER='"+tempPoNumber+"'"; 
		String result = jdbcTemplate.queryForObject(Query, String.class);
		return result;
		
	
		
	}
	
	public int productWiseInactiveInPurchaseTable(String indentCtreationDetailsId,String typeOfPurchase) {
		String query = "UPDATE SUM_PURCHASE_DEPT_INDENT_PROSS set STATUS = 'I',TYPE_OF_PURCHASE='"+typeOfPurchase+"' "
			+ " where INDENT_CREATION_DETAILS_ID =? ";
		int result = jdbcTemplate.update(query, new Object[] {indentCtreationDetailsId});
		return result;

	}
	
	
	public List<IndentCreationBean> purchasePrintIndent(int indentNumber) {
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		List<Map<String, Object>> dbIndentDts = null;
		List<Map<String, Object>> IndentDts = null;
		int sno=0;
		String strCreateDate="";

		String query = "SELECT INDENT_CREATION_DETAILS_ID FROM SUMADHURA_INDENT_CREATION_DTLS WHERE INDENT_CREATION_ID =?";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
		
		for(Map<String, Object> prods : dbIndentDts) {
			IndentCreationBean indentCreationBean = new IndentCreationBean();
			String indentCreationDetailsId=prods.get("INDENT_CREATION_DETAILS_ID")==null ? "" :   prods.get("INDENT_CREATION_DETAILS_ID").toString();
			
			String sql = "select (CP.NAME)AS CHILDPRODUCT,SP.NAME,(M.NAME)AS MEASURE,SICD.REMARKS,SPDIP.PENDING_QUANTIY,SICD.AVAIL_QUANTITY_AT_CREATION "
						+" from SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP,CHILD_PRODUCT CP,SUB_PRODUCT SP,MEASUREMENT M,SUMADHURA_INDENT_CREATION_DTLS SICD "
						+" where  SPDIP.SUB_PRODUCT_ID=SP.SUB_PRODUCT_ID AND SPDIP.CHILD_PRODUCT_ID=CP.CHILD_PRODUCT_ID AND SPDIP.MEASUREMENT_ID=M.MEASUREMENT_ID "
						+" AND SICD.INDENT_CREATION_DETAILS_ID=SPDIP.INDENT_CREATION_DETAILS_ID AND SICD.INDENT_CREATION_DETAILS_ID=? ";

			IndentDts = jdbcTemplate.queryForList(sql, new Object[] {indentCreationDetailsId});
			for(Map<String, Object> prod : IndentDts) {
			sno++;
			indentCreationBean.setStrSerialNumber(String.valueOf(sno));
			indentCreationBean.setSubProduct1(prod.get("NAME")==null ? "" :   prod.get("NAME").toString());
			indentCreationBean.setChildProduct1(prod.get("CHILDPRODUCT")==null ? "" :   prod.get("CHILDPRODUCT").toString());
			indentCreationBean.setUnitsOfMeasurement1(prod.get("MEASURE")==null ? "" :   prod.get("MEASURE").toString());
			String requiredQuantity=prod.get("PENDING_QUANTIY")==null ? "" :   prod.get("PENDING_QUANTIY").toString();
			String productAvailability=prod.get("AVAIL_QUANTITY_AT_CREATION")==null ? "" :   prod.get("AVAIL_QUANTITY_AT_CREATION").toString();
			
			
			double strRequiredQty=Double.parseDouble(requiredQuantity);
			double strProductAvail=Double.parseDouble(productAvailability);
			double strrequiredQuantity=0;
			if(strRequiredQty!=0){
			strrequiredQuantity=(strRequiredQty)+(strProductAvail);
			requiredQuantity=String.valueOf(strrequiredQuantity);

			
			indentCreationBean.setRequiredQuantity1(requiredQuantity);
			indentCreationBean.setProductAvailability(productAvailability);
			indentCreationBean.setOrderQuantity(strRequiredQty);
			indentCreationBean.setRemarks1(prod.get("REMARKS")==null ? "" :   prod.get("REMARKS").toString());
			IndentCreationBean icb = new IndentCreationBean();
			icb = cntlIndentrocss.getCreateAndRequiredDates(indentNumber);
			indentCreationBean.setStrRequiredDate(icb.getStrRequiredDate());
			strCreateDate = icb.getStrCreateDate();
			list.add(indentCreationBean);
	
			}	
		}	
		}
		return list;

	}

	@Override
	public int insertPurchaseDepttbl(int purchaseIndentProcessId,String sessionSiteId,String strUserId,ProductDetails productDetails)

	{



		
		String query = "INSERT INTO SUM_PURCHASE_DEPT_INDENT_PROSS(PURCHASE_DEPT_INDENT_PROSS_SEQ,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,MEASUREMENT_ID, "
					+" PURCHASE_DEPT_REQ_QUANTITY, ALLOCATED_QUANTITY, PENDING_QUANTIY, PO_INTIATED_QUANTITY,STATUS,INDENT_REQ_SITE_ID,REQ_RECEIVE_FROM,CREATION_DATE,"
					+ " INDENT_CREATION_DETAILS_ID,INDENT_REQ_QUANTITY)values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,sysdate,?,?) ";
		int result = jdbcTemplate.update(query, new Object[] {
				purchaseIndentProcessId,
				productDetails.getProductId(),productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),productDetails.getMeasurementId(),
				productDetails.getQuantity(),"0","0",productDetails.getQuantity(),"I",sessionSiteId,
				strUserId,productDetails.getIndentCreationDetailsId(),productDetails.getQuantity()

		});




		return result;
	}

	@Override
	public int insertIndentCreationtbl(ProductDetails productDetails,String indentCreationId) {
		String query = "INSERT INTO SUMADHURA_INDENT_CREATION_DTLS(INDENT_CREATION_DETAILS_ID,INDENT_CREATION_ID"+
		",PRODUCT_ID  , SUB_PRODUCT_ID ,CHILD_PRODUCT_ID ,MEASUREMENT_ID ,REQ_QUANTITY "+
		",priority,RECEIVE_QUANTITY,AVAIL_QUANTITY_AT_CREATION) "+
		"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
		int result = jdbcTemplate.update(query, new Object[] {
				productDetails.getIndentCreationDetailsId(),indentCreationId,
				productDetails.getProductId(),productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),productDetails.getMeasurementId(),productDetails.getQuantity(),
				
				null,"0","0"
				
		});
		return result;
	}
	
	public String  getpendingEmpId(String poNumber,String  user_Id)
	{
		List<Map<String, Object>> empList = null;
		String empId="";
		String query="select PO_CREATE_APPROVE_EMP_ID FROM SUMADHURA_PO_CRT_APPRL_DTLS  SPCAD where TEMP_PO_NUMBER='"+poNumber+"' "
						+" and OPERATION_TYPE  not in('CAN') order by PO_CREATION_APPROVAL_DTLS_ID  DESC";
		
		empList = jdbcTemplate.queryForList(query, new Object[] {});
		if(empList!= null){
			for(Map<String, Object> emp : empList) {


				empId=emp.get("PO_CREATE_APPROVE_EMP_ID").toString();
				
			/*********************************************operation for approval employee ids*******************************/
				if(user_Id.equals(empId)){
					
					continue;
				}else{
				break;
				}
				
			}
		}
		
		//String empId = jdbcTemplate.queryForObject(query, String.class);
		
	return empId;
	
	}
	
	public String  getpendingUserId(String temp_Po_Number)
	{
		String query="select PO_ENTRY_USER_ID from SUMADHURA_TEMP_PO_ENTRY where PO_NUMBER='"+temp_Po_Number+"' ";
		String userId = jdbcTemplate.queryForObject(query, String.class);
		
	return userId;
	
	}

	public int updateEmpId(String pendingEmpId,String temp_Po_Number)
	{

		String query =  "update SUMADHURA_TEMP_PO_ENTRY set TEMP_PO_PENDING_EMP_ID ='"+pendingEmpId+"',VIEWORCANCEL='CANCEL' where PO_NUMBER='"+temp_Po_Number+"' ";
		int result = jdbcTemplate.update(query, new Object[] {});
	
	return result;
	
}
	public List<ProductDetails> getListOfCancelPo(String userId){

		List<ProductDetails> poList = new ArrayList<ProductDetails>();
		ProductDetails indentObj=null;
		List<Map<String, Object>> dbIndentDts = null;
		String type_Of_Purchase="";
		String old_Po_Number="";
		String sql="select STPE.PO_NUMBER,STPE.PO_DATE,STPE.SITE_ID,SIC.SITEWISE_INDENT_NO,STPE.INDENT_NO,STPE.PREPARED_BY,STPE.OLD_PO_NUMBER from SUMADHURA_TEMP_PO_ENTRY STPE,"
				+" SUMADHURA_INDENT_CREATION SIC where VIEWORCANCEL='CANCEL' AND TEMP_PO_PENDING_EMP_ID= ? and PO_STATUS='A' AND STPE.INDENT_NO=SIC.INDENT_CREATION_ID ";

		dbIndentDts = jdbcTemplate.queryForList(sql, new Object[] {userId});
		for(Map<String, Object> prods : dbIndentDts) {
			indentObj = new ProductDetails();

			indentObj.setStrPONumber(prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString());
			//	indentObj.setStrInvoiceDate(prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString());
			indentObj.setPoDate(prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString());
			indentObj.setSite_Id(prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString());
			indentObj.setIndentNo((prods.get("INDENT_NO")==null ? "" : prods.get("INDENT_NO").toString()));
			indentObj.setSiteWiseIndentNo((prods.get("SITEWISE_INDENT_NO")==null ? "0" : prods.get("SITEWISE_INDENT_NO").toString()));
			//indentObj.setSiteWiseIndentNo(Integer.parseInt(prods.get("SITEWISE_INDENT_NO")==null ? "0" : prods.get("SITEWISE_INDENT_NO").toString()));
			type_Of_Purchase=(prods.get("PREPARED_BY")==null ? "" : prods.get("PREPARED_BY").toString());
			old_Po_Number=(prods.get("OLD_PO_NUMBER")==null ? "" : prods.get("OLD_PO_NUMBER").toString());
			//indentObj.setType_Of_Purchase
			if(type_Of_Purchase.equals("") && !old_Po_Number.equals("") || (type_Of_Purchase.equalsIgnoreCase("PURCHASE_DEPT") && !old_Po_Number.equals(""))){
				
				indentObj.setType_Of_purchase("REVISED_PO");
			}
			else if(type_Of_Purchase.equals("") || (type_Of_Purchase.equalsIgnoreCase("PURCHASE_DEPT") && old_Po_Number.equals(""))){
				
				indentObj.setType_Of_purchase("PURCHASE_DEPT_PO");
			} else{
				
				indentObj.setType_Of_purchase("SITELEVEL_PO");
			}
			poList.add(indentObj);

		}

		return poList;

	}
	
	@Override
	public List<ProductDetails> getViewCancelPoDetails(String poNumber, String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<ProductDetails> list = new ArrayList<ProductDetails>(); 
		List<Map<String, Object>> dbPODts = null;

		String query = "select VD.VENDOR_ID,VD.VENDOR_NAME,VD.GSIN_NUMBER,VD.ADDRESS,SPE.INDENT_NO,SIC.SITEWISE_INDENT_NO,SPE.PO_DATE,S.SITE_ID,S.SITE_NAME "
			+ " from SUMADHURA_TEMP_PO_ENTRY SPE,VENDOR_DETAILS VD,SITE S,SUMADHURA_INDENT_CREATION SIC "
			+ " where SPE.VENDOR_ID = VD.VENDOR_ID AND SPE.SITE_ID = S.SITE_ID "
			+ " AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' and SIC.INDENT_CREATION_ID = SPE.INDENT_NO";
		dbPODts = template.queryForList(query, new Object[]{});

		for(Map<String, Object> prods : dbPODts) {
			ProductDetails pd = new ProductDetails();
			pd.setVendorId(prods.get("VENDOR_ID") == null ? "" : prods.get("VENDOR_ID").toString());
			pd.setVendorName(prods.get("VENDOR_NAME") == null ? "" : prods.get("VENDOR_NAME").toString());
			pd.setStrGSTINNumber(prods.get("GSIN_NUMBER") == null ? "" : prods.get("GSIN_NUMBER").toString());
			pd.setVendorAddress(prods.get("ADDRESS") == null ? "" : prods.get("ADDRESS").toString());
			pd.setIndentNo(prods.get("INDENT_NO") == null ? "" : prods.get("INDENT_NO").toString());
			pd.setSiteWiseIndentNo(prods.get("SITEWISE_INDENT_NO") == null ? "0" : prods.get("SITEWISE_INDENT_NO").toString());
			pd.setSite_Id(prods.get("SITE_ID") == null ? "" : prods.get("SITE_ID").toString());
			pd.setSiteName(prods.get("SITE_NAME") == null ? "" : prods.get("SITE_NAME").toString());
			String poDate = prods.get("PO_DATE") == null ? "" : prods.get("PO_DATE").toString();
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			Date date = null;
			try {
				date = format.parse(poDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			poDate = new SimpleDateFormat("dd-MMM-yy").format(date);
			pd.setPoDate(poDate);
			list.add(pd);
		}
		return list;
	}
	@Override
	public List<ProductDetails> getProductDetailsListsForCancelPo(String poNumber,String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<ProductDetails> list = new ArrayList<ProductDetails>(); 
		List<Map<String, Object>> dbPODts = null;
		double doublePOTotalAmount = 0;
		double doubleTotalAmount = 0;

		String query = "SELECT P.PRODUCT_ID,SP.SUB_PRODUCT_ID,CP.CHILD_PRODUCT_ID,MST.MEASUREMENT_ID,"
		+ " P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,SPED.VENDOR_PRODUCT_DESC,"
		+ " SPED.PO_QTY,SPED.PRICE,SPED.BASIC_AMOUNT,"
		+ " SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,SPED.HSN_CODE,SPED.TAX,SPED.TAX_AMOUNT,"
		+ " SPED.AMOUNT_AFTER_TAX,SPED.OTHER_CHARGES,SPED.TAX_ON_OTHER_TRANSPORT_CHG,"
		+ " SPED.OTHER_CHARGES_AFTER_TAX,SPED.TOTAL_AMOUNT,SPED.INDENT_CREATION_DTLS_ID," +
		   "SPED.PO_ENTRY_DETAILS_ID,TAX_PERCENTAGE "
		+ " FROM SUMADHURA_TEMP_PO_ENTRY_DTLS SPED,SUMADHURA_TEMP_PO_ENTRY SPE,"
		+ " PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST,INDENT_GST INGST WHERE SPED.PRODUCT_ID = P.PRODUCT_ID "
		+ " AND SPED.SUB_PRODUCT_ID = SP.SUB_PRODUCT_ID AND "
		+ " SPED.CHILD_PRODUCT_ID = CP.CHILD_PRODUCT_ID AND "
		+ " SPED.MEASUR_MNT_ID = MST.MEASUREMENT_ID AND  INGST.TAX_ID = SPED.TAX and"
		+ " SPED.PO_ENTRY_ID = SPE.PO_ENTRY_ID AND SPE.PO_NUMBER = '"+poNumber+"' AND SPE.SITE_ID = '"+reqSiteId+"' order by SPED.INDENT_CREATION_DTLS_ID " ;
		//+ "AND PO_STATUS = 'A'";
	
		/*String query ="SELECT P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,"
					+" SPDIP.PRODUCT_ID,SPDIP.SUB_PRODUCT_ID,SPDIP.CHILD_PRODUCT_ID,SPDIP.MEASUREMENT_ID,SPED.PO_QTY,SPED.PRICE,SPED.BASIC_AMOUNT,"
					+" SPED.DISCOUNT,SPED.AMOUNT_AFTER_DISCOUNT,SPED.HSN_CODE,SPED.TAX,SPED.TAX_AMOUNT,SPED.AMOUNT_AFTER_TAX,SPED.OTHER_CHARGES,SPED.TAX_ON_OTHER_TRANSPORT_CHG,"
					+" SPED.OTHER_CHARGES_AFTER_TAX,SPED.TOTAL_AMOUNT,SPED.INDENT_CREATION_DTLS_ID,SPED.PO_ENTRY_DETAILS_ID, "
					+"(SELECT INGST.TAX_PERCENTAGE FROM INDENT_GST INGST WHERE INGST.TAX_ID = SPED.TAX) AS TAX_PERCENTAGE "
					+" FROM SUMADHURA_INDENT_CREATION SIC, SUMADHURA_INDENT_CREATION_DTLS SICD,"
					+" PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST,SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP "
					+" left outer join SUMADHURA_TEMP_PO_ENTRY_DTLS SPED on SPED.INDENT_CREATION_DTLS_ID=SPDIP.INDENT_CREATION_DETAILS_ID"
					+" WHERE SPDIP.PRODUCT_ID=P.PRODUCT_ID AND SPDIP.SUB_PRODUCT_ID=SP.SUB_PRODUCT_ID AND SPDIP.CHILD_PRODUCT_ID=CP.CHILD_PRODUCT_ID" 
					+" AND SPDIP.MEASUREMENT_ID=MST.MEASUREMENT_ID AND SPDIP.INDENT_CREATION_DETAILS_ID= SICD.INDENT_CREATION_DETAILS_ID  and SPDIP.STATUS='A' " 
					+" AND SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID AND SIC.INDENT_CREATION_ID ='"+poNumber+"' and SIC. SITE_ID ='"+reqSiteId+"' order by SICD.INDENT_CREATION_DETAILS_ID";
				*/
			
				
		int serialno = 0;
		dbPODts = template.queryForList(query, new Object[]{});
		
		for(Map<String, Object> prods : dbPODts) {
			ProductDetails pd = new ProductDetails();
			serialno++;
			pd.setSerialno(serialno);
			pd.setProductId(prods.get("PRODUCT_ID") == null ? "" : prods.get("PRODUCT_ID").toString());
			pd.setSub_ProductId(prods.get("SUB_PRODUCT_ID") == null ? "" : prods.get("SUB_PRODUCT_ID").toString());
			pd.setChild_ProductId(prods.get("CHILD_PRODUCT_ID") == null ? "" : prods.get("CHILD_PRODUCT_ID").toString());
			pd.setMeasurementId(prods.get("MEASUREMENT_ID") == null ? "" : prods.get("MEASUREMENT_ID").toString());
			pd.setProductName(prods.get("PRODUCT_NAME") == null ? "" : prods.get("PRODUCT_NAME").toString());
			pd.setSub_ProductName(prods.get("SUB_PRODUCT_NAME") == null ? "" : prods.get("SUB_PRODUCT_NAME").toString());
			pd.setChild_ProductName(prods.get("CHILD_PRODUCT_NAME") == null ? "" : prods.get("CHILD_PRODUCT_NAME").toString());
			pd.setMeasurementName(prods.get("MEASUREMENT_NAME") == null ? "" : prods.get("MEASUREMENT_NAME").toString());
			pd.setRequiredQuantity(prods.get("PO_QTY") == null ? "0" : prods.get("PO_QTY").toString());
			pd.setPrice(prods.get("PRICE") == null ? " " : prods.get("PRICE").toString());
			pd.setBasicAmt(prods.get("BASIC_AMOUNT") == null ? "0" : prods.get("BASIC_AMOUNT").toString());
			pd.setStrDiscount(prods.get("DISCOUNT") == null ? " " : prods.get("DISCOUNT").toString());
			pd.setStrAmtAfterDiscount(prods.get("AMOUNT_AFTER_DISCOUNT") == null ? " " : prods.get("AMOUNT_AFTER_DISCOUNT").toString());
			pd.setHsnCode(prods.get("HSN_CODE") == null ? " " : prods.get("HSN_CODE").toString());
			pd.setChildProductCustDisc(prods.get("VENDOR_PRODUCT_DESC") == null ? "-" : prods.get("VENDOR_PRODUCT_DESC").toString());
			String taxId = prods.get("TAX") == null ? " " : prods.get("TAX").toString();
			//String query1 = "select TAX_PERCENTAGE from INDENT_GST where TAX_ID = "+taxId+ " ";
		//	String taxValue = template.queryForObject(query1,String.class);
			String taxValue = prods.get("TAX_PERCENTAGE") == null ? " " : prods.get("TAX_PERCENTAGE").toString();
			
			
			pd.setTaxId(taxId);
			pd.setTax(taxValue);
			pd.setTaxAmount(prods.get("TAX_AMOUNT") == null ? "" : prods.get("TAX_AMOUNT").toString());
			pd.setAmountAfterTax(prods.get("AMOUNT_AFTER_TAX") == null ? "" : prods.get("AMOUNT_AFTER_TAX").toString());
			pd.setOthercharges1(prods.get("OTHER_CHARGES") == null ? "" : prods.get("OTHER_CHARGES").toString());
			pd.setTaxonothertranportcharge1(prods.get("TAX_ON_OTHER_TRANSPORT_CHG") == null ? "" : prods.get("TAX_ON_OTHER_TRANSPORT_CHG").toString());
			pd.setOtherchargesaftertax1(prods.get("OTHER_CHARGES_AFTER_TAX") == null ? "" : prods.get("OTHER_CHARGES_AFTER_TAX").toString());
			
			
			pd.setTotalAmount(prods.get("TOTAL_AMOUNT") == null ? "" : prods.get("TOTAL_AMOUNT").toString());
			pd.setIndentCreationDetailsId(prods.get("INDENT_CREATION_DTLS_ID") == null ? "" : prods.get("INDENT_CREATION_DTLS_ID").toString());
			pd.setPoEntryDetailsId(prods.get("PO_ENTRY_DETAILS_ID") == null ? "" : prods.get("PO_ENTRY_DETAILS_ID").toString());
			
		//	doubleTotalAmount = Double.valueOf(prods.get("TOTAL_AMOUNT") == null ? "0" : prods.get("TOTAL_AMOUNT").toString());
		//	doublePOTotalAmount = doublePOTotalAmount+doubleTotalAmount;
			
			
			
			list.add(pd);
		}
		
		
	
		return list;
	}
	
	@Override
	public List<ProductDetails> getTransChrgsDtlsForCancelPo(String poNumber,String reqSiteId) {
		JdbcTemplate template = null;
		try {
			template = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<ProductDetails> list = new ArrayList<ProductDetails>(); 
		List<Map<String, Object>> dbTransDts = null;

		String query = "select SPTOCD.ID,SPTOCD.TRANSPORT_ID,STOCM.CHARGE_NAME,SPTOCD.TRANSPORT_GST_PERCENTAGE,IG.TAX_PERCENTAGE,SPTOCD.TRANSPORT_GST_AMOUNT,"
			+ " SPTOCD.TOTAL_AMOUNT_AFTER_GST_TAX,SPTOCD.TRANSPORT_AMOUNT from SUMADHURA_TEMP_PO_TRNS_O_CHRGS  SPTOCD, "
			+ " SUMADHURA_TRNS_OTHR_CHRGS_MST STOCM,INDENT_GST IG,SUMADHURA_TEMP_PO_ENTRY SPE where  SPTOCD.TRANSPORT_ID = STOCM.CHARGE_ID and "
			+ " IG.TAX_ID = SPTOCD.TRANSPORT_GST_PERCENTAGE and SPE.PO_ENTRY_ID = SPTOCD.PO_NUMBER and SPE.PO_NUMBER = ? and SPE.SITE_ID = ? ";
		dbTransDts = template.queryForList(query, new Object[]{poNumber,reqSiteId});
		int sno = 0;
		for(Map<String, Object> prods : dbTransDts) {
			ProductDetails pd = new ProductDetails();
			sno++;
			pd.setStrSerialNumber(String.valueOf(sno));
			pd.setConveyanceId1(prods.get("TRANSPORT_ID") == null ? "" : prods.get("TRANSPORT_ID").toString());
			pd.setConveyance1(prods.get("CHARGE_NAME") == null ? "" : prods.get("CHARGE_NAME").toString());
			pd.setConveyanceAmount1(prods.get("TRANSPORT_AMOUNT") == null ? "" : prods.get("TRANSPORT_AMOUNT").toString());
			pd.setGSTTaxId1(prods.get("TRANSPORT_GST_PERCENTAGE") == null ? "" : prods.get("TRANSPORT_GST_PERCENTAGE").toString());
			pd.setGSTTax1(prods.get("TAX_PERCENTAGE") == null ? "" : prods.get("TAX_PERCENTAGE").toString());
			pd.setGSTAmount1(prods.get("TRANSPORT_GST_AMOUNT") == null ? "" : prods.get("TRANSPORT_GST_AMOUNT").toString());
			pd.setAmountAfterTaxx1(prods.get("TOTAL_AMOUNT_AFTER_GST_TAX") == null ? "" : prods.get("TOTAL_AMOUNT_AFTER_GST_TAX").toString());
			pd.setPoTransChrgsDtlsSeqNo(prods.get("ID") == null ? "" : prods.get("ID").toString());

			list.add(pd);
		}
		return list;

	}
	
	@Override
	public int getPoEnterSeqNoByTempPONumber(String poNumber,String toSite) {
		String query  = "select PO_ENTRY_ID from  SUMADHURA_TEMP_PO_ENTRY where PO_NUMBER = ? and SITE_ID = ? ";
		return jdbcTemplate.queryForInt(query, new Object[] {poNumber,toSite});

	}

	@Override
	public int updateTempPOEntryDetails(ProductDetails productDetails)
	{

		String query =  "update SUMADHURA_TEMP_PO_ENTRY_DTLS set VENDOR_PRODUCT_DESC=? ,PD_PRODUCT_DESC=?, PRODUCT_ID = ? ,SUB_PRODUCT_ID = ? ,CHILD_PRODUCT_ID = ? ,MEASUR_MNT_ID = ? ,PO_QTY = ? ,PRICE = ? ,BASIC_AMOUNT = ? ,DISCOUNT = ? ,AMOUNT_AFTER_DISCOUNT = ? ,TAX = ? ,TAX_AMOUNT = ? ,AMOUNT_AFTER_TAX = ? ,HSN_CODE = ? ,OTHER_CHARGES = ? ,TAX_ON_OTHER_TRANSPORT_CHG = ? ,OTHER_CHARGES_AFTER_TAX = ? ,TOTAL_AMOUNT = ? where PO_ENTRY_DETAILS_ID = ? ";

		int result = jdbcTemplate.update(query, new Object[] {
				productDetails.getChildProductCustDisc(),
				productDetails.getChild_ProductName(),
				productDetails.getProductId(),
				productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),
				productDetails.getMeasurementId(),
				productDetails.getQuantity(),productDetails.getPricePerUnit(),productDetails.getBasicAmt(),
				productDetails.getStrDiscount(),productDetails.getStrAmtAfterDiscount(),
				productDetails.getTax(),productDetails.getTaxAmount(),productDetails.getAmountAfterTax(),
				productDetails.getHsnCode(),
				productDetails.getOtherOrTransportCharges1(),productDetails.getTaxOnOtherOrTransportCharges1(),productDetails.getOtherOrTransportChargesAfterTax1(),
				productDetails.getTotalAmount(),
				productDetails.getPoEntryDetailsId()


		});
		return result;
	}
	
	@Override
	public int insertTempPOTransportDetails(int poTransChrgsSeqNo, ProductDetails productDetails, TransportChargesDto transportChargesDto,String poNumber) {
		String query = "INSERT INTO SUMADHURA_TEMP_PO_TRNS_O_CHRGS(ID,TRANSPORT_ID,TRANSPORT_GST_PERCENTAGE,TRANSPORT_GST_AMOUNT,"
			+ "TOTAL_AMOUNT_AFTER_GST_TAX,DATE_AND_TIME,TRANSPORT_AMOUNT,SITE_ID,PO_NUMBER,INDENT_NUMBER) "
			+ "values( ?, ?, ?, ?, ?, sysdate, ?, ?, ?, ?)";

		int result = jdbcTemplate.update(query, new Object[] {
				poTransChrgsSeqNo,
				transportChargesDto.getTransportId(),
				transportChargesDto.getTransportGSTPercentage(),
				transportChargesDto.getTransportGSTAmount(),
				transportChargesDto.getTotalAmountAfterGSTTax(),
				transportChargesDto.getTransportAmount(),
				productDetails.getSite_Id(),
				poNumber,
				productDetails.getIndentNo()
		});
		return result;

	}
	
	@Override
	public int updateTempPOTransportChargesDetails(TransportChargesDto transportChargesDto,int id){

		String query =  "update SUMADHURA_TEMP_PO_TRNS_O_CHRGS set TRANSPORT_ID = ? ,TRANSPORT_AMOUNT = ? ,"
			+ " TRANSPORT_GST_PERCENTAGE = ? ,TRANSPORT_GST_AMOUNT = ? ,TOTAL_AMOUNT_AFTER_GST_TAX = ? "
			+ " where ID = ? ";

		int result = jdbcTemplate.update(query, new Object[] {

				transportChargesDto.getTransportId(),
				transportChargesDto.getTransportAmount(),
				transportChargesDto.getTransportGSTPercentage(),
				transportChargesDto.getTransportGSTAmount(),
				transportChargesDto.getTotalAmountAfterGSTTax(),
				id
		});


		return result;
	}
	
	@Override
	public int deleteTempPOTransportChargesDetails(int poTransChrgsDtlsSeqNo) {
		String query =  "DELETE FROM SUMADHURA_TEMP_PO_TRNS_O_CHRGS WHERE ID = ? ";
		return jdbcTemplate.update(query, new Object[] {poTransChrgsDtlsSeqNo});
	}
	
	public int deleteTempPOEntryDetails(String poEntryDetailsId) {
		String query =  "DELETE FROM SUMADHURA_TEMP_PO_ENTRY_DTLS WHERE PO_ENTRY_DETAILS_ID = ? ";
		return jdbcTemplate.update(query, new Object[] {poEntryDetailsId});
	}
	
	@Override
	public int updateTempPOQuantityDetails(String indentCreationDetailsId, String quantity,String strQuantity) {
		
		double tempQuan=0.0;
		tempQuan=Double.parseDouble(strQuantity)-Double.parseDouble(quantity);
		
		
		if(tempQuan<=0){
			
			//tempQuan=Math.abs(tempQuan);
			tempQuan=Double.parseDouble(new DecimalFormat("##.##").format(Math.abs(tempQuan)));
			String query =  "update SUM_PURCHASE_DEPT_INDENT_PROSS set PO_INTIATED_QUANTITY = PO_INTIATED_QUANTITY+?  where INDENT_CREATION_DETAILS_ID = ? ";
			return jdbcTemplate.update(query, new Object[] {tempQuan,indentCreationDetailsId});
			
		}else{
		String query =  "update SUM_PURCHASE_DEPT_INDENT_PROSS set PO_INTIATED_QUANTITY = PO_INTIATED_QUANTITY-?,STATUS='A'  where INDENT_CREATION_DETAILS_ID = ? ";
		return jdbcTemplate.update(query, new Object[] {tempQuan,indentCreationDetailsId});
	
		}
		
		
		}
	
	
	public int updateTempPOVendorDetails(String vendorId,String poNumber,String ccEmailId,String subject,String isUpdate)
	{
	
		int result =0;
		if(isUpdate.equalsIgnoreCase("true")){
		String query =  "update SUMADHURA_PO_ENTRY set VENDOR_ID=? where PO_STATUS='A' and PO_NUMBER = ?";

		 result = jdbcTemplate.update(query, new Object[] {vendorId,poNumber
		
					});
		}else{
		
			String query =  "update SUMADHURA_TEMP_PO_ENTRY set VENDOR_ID=?,CC_EMAIL_ID=?,SUBJECT=? where PO_STATUS='A' and PO_NUMBER = ?";

			 result = jdbcTemplate.update(query, new Object[] {vendorId,ccEmailId,subject,poNumber
			 });
			
		}
		return result;
	}
	
	public int updateTempPoVieworCancel(String temp_Po_Number,String siteId)
	{

		String query =  "update SUMADHURA_TEMP_PO_ENTRY set VIEWORCANCEL ='MODIFIED' WHERE VIEWORCANCEL='CANCEL' AND PO_NUMBER='"+temp_Po_Number+"' AND SITE_ID= '"+siteId+"'";
		int result = jdbcTemplate.update(query, new Object[] {});
	
	return result;
	
}
	
	public String tempPoSubProducts(String prodId, String indentNumber, String reqSiteId) {
		StringBuffer sb = null;
		List<Map<String, Object>> dbSubProductsList = null;	

		log.debug("Product Id = "+prodId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT SPDIP.SUB_PRODUCT_ID, SP.NAME FROM SUB_PRODUCT SP,SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP,SUMADHURA_INDENT_CREATION SIC,"
							+" SUMADHURA_INDENT_CREATION_DTLS SICD WHERE SPDIP.STATUS = 'A' AND SPDIP.SUB_PRODUCT_ID=SP.SUB_PRODUCT_ID AND SIC.INDENT_CREATION_ID ='"+indentNumber+"' AND SIC. SITE_ID ='"+reqSiteId+"'"
							+" and SPDIP.PRODUCT_ID='"+prodId+"' AND SPDIP.INDENT_CREATION_DETAILS_ID= SICD.INDENT_CREATION_DETAILS_ID  AND SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID";
		log.debug("Query to fetch subproduct = "+subProdsQry);

		dbSubProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{});
		
		System.out.println("the list is"+dbSubProductsList);

		for(Map<String, Object> subProds : dbSubProductsList) {
			sb = sb.append(String.valueOf(subProds.get("SUB_PRODUCT_ID"))+"_"+String.valueOf(subProds.get("NAME"))+"|");
		}		
		return sb.toString();
	}
	
	
	public String tempPoChildProducts(String subProdId, String indentNumber, String reqSiteId) {
		StringBuffer sb = null;
		List<Map<String, Object>> dbSubProductsList = null;	

		log.debug("Product Id = "+subProdId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT SPDIP.CHILD_PRODUCT_ID, CP.NAME,SPDIP.PURCHASE_DEPT_REQ_QUANTITY,SPDIP.PO_INTIATED_QUANTITY,SICD.INDENT_CREATION_DETAILS_ID,(SPDIP.PENDING_QUANTIY-PO_INTIATED_QUANTITY) as PENDING_QUANTIY"
							+" FROM CHILD_PRODUCT CP,SUM_PURCHASE_DEPT_INDENT_PROSS SPDIP,SUMADHURA_INDENT_CREATION SIC,"
							+" SUMADHURA_INDENT_CREATION_DTLS SICD WHERE SPDIP.STATUS = 'A' AND SPDIP.CHILD_PRODUCT_ID=CP.CHILD_PRODUCT_ID" 
							+" AND SIC.INDENT_CREATION_ID ='"+indentNumber+"' AND SIC. SITE_ID ='"+reqSiteId+"' AND SPDIP.INDENT_CREATION_DETAILS_ID= SICD.INDENT_CREATION_DETAILS_ID and SPDIP.SUB_PRODUCT_ID='"+subProdId+"' AND SICD.INDENT_CREATION_ID = SIC.INDENT_CREATION_ID";
		log.debug("Query to fetch subproduct = "+subProdsQry);

		dbSubProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{});

		for(Map<String, Object> subProds : dbSubProductsList) {
			sb = sb.append(String.valueOf(subProds.get("CHILD_PRODUCT_ID"))+"_"+String.valueOf(subProds.get("NAME"))+"|"+String.valueOf(subProds.get("PURCHASE_DEPT_REQ_QUANTITY"))
							+"|"+String.valueOf(subProds.get("PO_INTIATED_QUANTITY"))+"|"+String.valueOf(subProds.get("INDENT_CREATION_DETAILS_ID"))+"|"+String.valueOf(subProds.get("PENDING_QUANTIY"))+"|");
		}		
		return sb.toString();
	}
	
	@Override
	public int insertTempPOEntryDetails(ProductDetails productDetails,int poEntrySeqNo)
	{
		String query = "INSERT INTO SUMADHURA_TEMP_PO_ENTRY_DTLS(PO_ENTRY_DETAILS_ID,PO_ENTRY_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,"+
		"MEASUR_MNT_ID, PO_QTY,ENTRY_DATE,PRICE,BASIC_AMOUNT,TAX,TAX_AMOUNT,AMOUNT_AFTER_TAX,OTHER_CHARGES,OTHER_CHARGES_AFTER_TAX,TOTAL_AMOUNT,HSN_CODE,TAX_ON_OTHER_TRANSPORT_CHG,DISCOUNT,AMOUNT_AFTER_DISCOUNT,INDENT_CREATION_DTLS_ID,VENDOR_PRODUCT_DESC,PD_PRODUCT_DESC"
		+ ") values(SUMADHURA_T_PO_ENTRY_DTLS_SEQ.nextval, ?, ?, ?, ?, ?, ?,sysdate, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

		int result = jdbcTemplate.update(query, new Object[] {
				poEntrySeqNo,
				productDetails.getProductId(),productDetails.getSub_ProductId(),
				productDetails.getChild_ProductId(),productDetails.getMeasurementId(),
				productDetails.getQuantity(),productDetails.getPricePerUnit(),productDetails.getBasicAmt(),
				productDetails.getTax(),
				productDetails.getTaxAmount(),productDetails.getAmountAfterTax(),
				productDetails.getOtherOrTransportCharges1(),productDetails.getOtherOrTransportChargesAfterTax1(),
				productDetails.getTotalAmount(),productDetails.getHsnCode(),productDetails.getTaxOnOtherOrTransportCharges1(),
				productDetails.getStrDiscount(),productDetails.getStrAmtAfterDiscount(),
				productDetails.getIndentCreationDetailsId(),productDetails.getChildProductCustDisc(),productDetails.getChild_ProductName()

		});
		return result;
	}
	
	public String  getPoInitiateQuan(String indentCreationDetailsId)
	{
		List<Map<String, Object>> productList = null;

		
		
		String  poinitiated_Quan="";
		String  request_Quan="";
		String response="";
		String query = "select PO_INTIATED_QUANTITY,PURCHASE_DEPT_REQ_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS WHERE STATUS='A' AND INDENT_CREATION_DETAILS_ID= ?";

		productList = jdbcTemplate.queryForList(query, new Object[] {indentCreationDetailsId});
		try{

			if(productList!= null){
				for(Map<String, Object> list : productList) {


					poinitiated_Quan=(list.get("PO_INTIATED_QUANTITY")== null ? "0" : list.get("PO_INTIATED_QUANTITY").toString());
					request_Quan=(list.get("PURCHASE_DEPT_REQ_QUANTITY")== null ? "0" : list.get("PURCHASE_DEPT_REQ_QUANTITY").toString());
					response=poinitiated_Quan+"|"+request_Quan;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
			
		return response;
		}
	
	public List<String> getTempTermsAndConditions(String poNumber,String isRevised,String reqSiteId){
		
		
		List<Map<String, Object>> termList = null;
		List<String> listOfTermsAndConditions = new ArrayList<String>();
	
		if(isRevised.equalsIgnoreCase("true")){
			
			int poEntrySeqNumber =getPoEnterSeqNoByPONumber(poNumber,reqSiteId
					);
			String sql1="SELECT TERMS_CONDITION_DESC FROM  SUMADHURA_PD_TERMS_CONDITIONS WHERE PO_ENTRY_ID=?";
			termList = jdbcTemplate.queryForList(sql1, new Object[] {poEntrySeqNumber});
			
		}else{
		String sql1="SELECT TERMS_CONDITION_DESC FROM  SUMADHURA_TEMP_PO_TERMS_COND WHERE PO_NUMBER=?";
		termList = jdbcTemplate.queryForList(sql1, new Object[] {poNumber});
		}
	//System.out.println("the list size is "+termList.size());
	if (null != termList && termList.size() > 0) {
		for (Map<?, ?> GetTransportChargesDetails : termList) {

			String termscondition = GetTransportChargesDetails.get("TERMS_CONDITION_DESC") == null ? "" : GetTransportChargesDetails.get("TERMS_CONDITION_DESC").toString();


			listOfTermsAndConditions.add(String.valueOf(termscondition));

		}
	}

	return listOfTermsAndConditions;
	}
	
	public int deleteTemppoTermsAdnConditions(String poNumber,String isUpdated) {
		String query ="";
		if(isUpdated.equalsIgnoreCase("true")){
		 query =  "DELETE FROM SUMADHURA_PD_TERMS_CONDITIONS WHERE PO_ENTRY_ID = ? ";
			
		}else{
		 query =  "DELETE FROM SUMADHURA_TEMP_PO_TERMS_COND WHERE PO_NUMBER = ? ";
		
		}
		return jdbcTemplate.update(query, new Object[] {poNumber});
		
	}
	
	public String  getCancelPoComments(String  poNumber) {


		List<Map<String, Object>> getcommentDtls = null;
		String strEmployeName = "";
		String strComments = "";
		String StrCancelPoComments = "";

		String query = "select PURPOSE,SED.EMP_NAME from SUMADHURA_PO_CRT_APPRL_DTLS SPCAD , SUMADHURA_EMPLOYEE_DETAILS SED "
				+ " where SED.EMP_ID = SPCAD.PO_CREATE_APPROVE_EMP_ID and TEMP_PO_NUMBER = ? AND SPCAD.OPERATION_TYPE='CAN'";
		getcommentDtls = jdbcTemplate.queryForList(query, new Object[] {poNumber});

		if(getcommentDtls != null && getcommentDtls.size() > 0){
			for(Map<String, Object> prods : getcommentDtls) {

				strEmployeName = prods.get("EMP_NAME")==null ? "" : prods.get("EMP_NAME").toString();
				strComments = prods.get("PURPOSE")==null ? "-" : prods.get("PURPOSE").toString();
				
				if((strEmployeName!=null && strComments!=null) && (!strEmployeName.equals("") && !strComments.equals(""))){
				
					StrCancelPoComments +=  strEmployeName + " :  "+strComments +"   ,";
				}

			}
			if(StrCancelPoComments!=null && !StrCancelPoComments.equals("")){
				StrCancelPoComments =  StrCancelPoComments.substring(0,StrCancelPoComments.length()-1);
			}
		
		}

		return StrCancelPoComments;

	}
	
	@Override
	public String getTempPOSubject(String poNumber) {
		
		String result="";
		
	String Query = "select SUBJECT from SUMADHURA_TEMP_PO_ENTRY WHERE PO_NUMBER='"+poNumber+"'"; 
		 result = jdbcTemplate.queryForObject(Query, String.class);
		
			return result;

	}
	@Override	
public String getTempPoCCEmails(String poNumber) {
		
		String value="";
		
	String Query = "select CC_EMAIL_ID from SUMADHURA_TEMP_PO_ENTRY WHERE PO_NUMBER='"+poNumber+"'"; 
		 value = jdbcTemplate.queryForObject(Query, String.class);
		
			return value;

	}
	@Override
	public int getRevisionNumber(String editPoNumber){

		//String intSeqNum = "select  SUMADHURA_PO_ENTRY_SEQ.nextval from dual";

		String intSeqNum = "select REVISION from SUMADHURA_PO_ENTRY where PO_NUMBER=?";

		int result = jdbcTemplate.queryForInt(intSeqNum, new Object[] {editPoNumber});

		return result;
	}
	public int inactiveOldPo(String old_Po_Number)
	{

		String query =  "update SUMADHURA_PO_ENTRY set PO_STATUS ='I' where PO_NUMBER ='"+old_Po_Number+"' ";

		int result = jdbcTemplate.update(query, new Object[] {
				
		});
		return result;
	}
	@Override
	public double getRequestedQuantityInPurchaseTable(String indentCreationDetailsId) {
		String query = "select PURCHASE_DEPT_REQ_QUANTITY from SUM_PURCHASE_DEPT_INDENT_PROSS where INDENT_CREATION_DETAILS_ID = '"+indentCreationDetailsId+"'";
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return Double.valueOf(result);
	}
	public int updateAccPayment(String old_Po_Number,String new_Po_Number)
	{

		String query =  "update ACC_PAYMENT set PO_NUMBER ='"+new_Po_Number+"' where PO_NUMBER ='"+old_Po_Number+"' ";

		int result = jdbcTemplate.update(query, new Object[] {
				
		});
		return result;
	}
	/*public int updatePurchasetblForRevision(String indentCreationDetailsId,String poIntiatedQuantity,String status)
	{

		String query =  "update SUM_PURCHASE_DEPT_INDENT_PROSS set PO_INTIATED_QUANTITY ='"+poIntiatedQuantity+"',STATUS='"+status+"' where INDENT_CREATION_DETAILS_ID = ?";

		int result = jdbcTemplate.update(query, new Object[] {indentCreationDetailsId
				
		});
		return result;
	}*/
	
	
	@Override
	public int checkIOndentCreationtbl(String indentNumber) {
		int result=0;
		String status="";
		List<Map<String, Object>> dbIndentDts = null;
		String query = "  select STATUS from SUMADHURA_INDENT_CREATION WHERE INDENT_CREATION_ID = ? ";

				dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
				for(Map<String, Object> prods : dbIndentDts) {


					status=prods.get("STATUS")==null ? "0" :   prods.get("STATUS").toString();
					
		
	}
	
	if(status=="I"){
		String query1 = "  update SUMADHURA_INDENT_CREATION set STATUS='A'  WHERE INDENT_CREATION_ID = ? ";	
		 result = jdbcTemplate.update(query1, new Object[] {});
	}
	return result;
	}
	
	public String getSiteLevelPoNumber(String site_Id) {
		List<Map<String, Object>> productList = null;
		String total_Records="";
		String current_Records="";
		String result_Records="";
		
		String query = "SELECT TOTAL_NO_RECORDS,CURRENT_YEAR_PO FROM SUMADHURA_SITE_LEVEL_PO_NUM where SITE_ID = ?";
		productList = jdbcTemplate.queryForList(query, new Object[] {site_Id}); 
		try{

			if(productList!= null){
				for(Map<String, Object> list : productList) {
					total_Records=(list.get("TOTAL_NO_RECORDS")== null ? "0" : list.get("TOTAL_NO_RECORDS").toString());
					current_Records=(list.get("CURRENT_YEAR_PO")== null ? "0" : list.get("CURRENT_YEAR_PO").toString());
					result_Records=total_Records+"@@"+current_Records;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result_Records;

	}
	
	
	public int insertSiteLevelIndentData(int site_Id,String user_Id,int indent_Number,String siteWiseIndent) {
		String query = "INSERT INTO SUMADHURA_INDENT_CREATION(INDENT_CREATION_ID, create_date, site_id ,INDENT_CREATE_EMP_ID ,schedule_date ,Pending_emp_id ,pendind_dept_id ,status,REQUIRED_DATE,TEMPPASS,SITEWISE_INDENT_NO) "+
		"VALUES(?, sysdate ,? ,? ,sysdate ,? ,? ,? ,sysdate ,?, ?)";
		int result = jdbcTemplate.update(query, new Object[] {
				indent_Number,site_Id,user_Id,"-","-",
				"A","0",siteWiseIndent });
		return result;
	}

	public int updateSiteLeveltbl(String site_Id,int total_Records,int current_Records){ //siteLevel CreatePO Page

		String query = "update SUMADHURA_SITE_LEVEL_PO_NUM set TOTAL_NO_RECORDS = ?,CURRENT_YEAR_PO=? where SITE_ID ='"+site_Id+"'";
		int result = jdbcTemplate.update(query, new Object[] {total_Records,current_Records});
		return result;
	}
	
	
	
	/*@Override
	public String getVendorId(String reqSiteName) {
		String query = "SELECT VENDOR_ID FROM VENDOR_DETAILS where SITE_NAME = '"+reqSiteName+"'";
		int result = jdbcTemplate.queryForInt(query);  
		return result;
	}
	*/
	
	
//request.setAttribute("listOfTermsAndConditions", listOfTermsAndConditions);

	
	
	/*@Override
	public Map<String, String> TempPoloadProds() {

		Map<String, String> products = null;
		List<Map<String, Object>> dbProductsList = null;

		products = new HashMap<String, String>();

		String prodsQry = "SELECT PRODUCT_ID, NAME FROM PRODUCT WHERE STATUS = 'A' ";
		log.debug("Query to fetch product = "+prodsQry);

		dbProductsList = jdbcTemplate.queryForList(prodsQry, new Object[]{});

		for(Map<String, Object> prods : dbProductsList) {
			products.put(String.valueOf(prods.get("PRODUCT_ID")), String.valueOf(prods.get("NAME")));
		}
		return  printMap(products);
	}
	*/
	
}