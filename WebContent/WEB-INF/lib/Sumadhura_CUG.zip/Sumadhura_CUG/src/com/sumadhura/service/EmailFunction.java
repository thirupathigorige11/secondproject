package com.sumadhura.service;

import java.lang.reflect.Array;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.PaymentBean;
import com.sumadhura.bean.VendorDetails;
import com.sumadhura.bean.userDetails;
import com.sumadhura.dto.IndentCreationDetailsDto;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.util.AESDecrypt;
import com.sumadhura.util.UIProperties;
import com.sumadhura.util.ValidateParams;

//@Controller
public class EmailFunction extends UIProperties{

	// @Autowired
	// private SalesReport sr;
	// @Autowired
	// private SalesReportDetails srdtls;

	private static final String SMTP_HOST_NAME = "smtp.gmail.com";
	private static final String SMTP_PORT = "465";
	//	private static final String emailMsgTxt = "Closing balance Schedular is running failed, Please contact with support team on urgent basis";
	//	private static final String emailSubjectTxt = "Closing balance schedular running failed";
	//	private static final String emailFromAddress = "sumadhura5949@gmail.com";
	private static final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
	//	private static final String[] sendTo = { "pavan45662@gmail.com", "sumadhura5949@gmail.com","vericherlav@gmail.com" };

	public  void sendEmail(String emailBodyMsgText,String emailSubjectText,String emailFromAddress,String [] emailToAddress,String[] ccTo,String strIndentSiteId) throws Exception {

		// Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		//	TestEmailFunction sendMailThroughJava = new TestEmailFunction();

		String strUserName  = ""; String strPassword = "";


		if(strIndentSiteId != null && !strIndentSiteId.equals("")){
			if(strIndentSiteId.equals("102")){
				strUserName = validateParams.getProperty(strIndentSiteId+"_USERNAME");
				strPassword = validateParams.getProperty(strIndentSiteId+"_PASSWORD");
			}else{
				strUserName = validateParams.getProperty("KARNATAKA_USERNAME");
				strPassword = validateParams.getProperty("KARNATAKA_PASSWORD");
			}
		}else{
			strUserName = validateParams.getProperty("OTHER_USERNAME");
			strPassword = validateParams.getProperty("OTHER_PASSWORD");
		}
		sendSSLMessage(emailToAddress, emailSubjectText,
				emailBodyMsgText, emailFromAddress, ccTo, strUserName, strPassword);
		System.out.println("Sucessfully sent mail to all Users");
	}

	public  void sendSSLMessage(String recipients[], String subject,
			String message, String from, String ccRecipients[],final String strUserName,final String strPassword ) throws MessagingException {
		boolean debug = true;

		Properties props = new Properties();
		props.put("mail.smtp.host", SMTP_HOST_NAME);
		props.put("mail.smtp.auth", "true");
		props.put("mail.debug", "true");
		props.put("mail.smtp.port", SMTP_PORT);
		props.put("mail.smtp.socketFactory.port", SMTP_PORT);
		props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.put("mail.smtp.socketFactory.fallback", "false");
		props.put("mail.smtp.starttls.enable","true"); 

		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				//return new PasswordAuthentication("jobsintbdb@gmail.com", "amaravadhi1");
				//System.out.println("mail authenticator ...................."+strUserName);
				return new PasswordAuthentication("purchase.sumadhura@gmail.com", "sumadhura_5949");
			}
		});

		session.setDebug(debug);

		Message msg = new MimeMessage(session);
		InternetAddress addressFrom = new InternetAddress(from);
		msg.setFrom(addressFrom);
		// String fileName="c:/text/name";
		//System.out.println("ccRecipients length: "+ccRecipients.length);
		//System.out.println("-----------------");
		//System.out.print("To Email: ");
		for (int i = 0; i < recipients.length; i++) {
			if(i!=0){
				//System.out.print(",");
			}	
			//System.out.print(recipients[i]);
		}
		//System.out.println();
		//	System.out.print("cc Emails: ");
		for (int i = 0; i < ccRecipients.length; i++) {
			if(i!=0){

				//System.out.print(",");

			}	
			//System.out.print(">>"+ccRecipients[i]+"<<");
		}
		//System.out.println();
		//	System.out.println("-----------------");
		InternetAddress[] addressTo = new InternetAddress[recipients.length];
		String strToEmailId = "";
		for (int i = 0; i < recipients.length; i++) {


			strToEmailId = recipients[i];


			if(strToEmailId != null && !strToEmailId.equals("") && !strToEmailId.equals(" ")){

				addressTo[i] = new InternetAddress(strToEmailId);
			}

		}
		boolean there_is_no_EmailTo_address = false;
		//System.out.println("recipients.length: "+recipients.length);
		if(recipients.length==0){
			there_is_no_EmailTo_address = true;
		}
		else if(recipients.length!=0){
			if(recipients[0] == null){
				there_is_no_EmailTo_address = true;
			}
			else{
				msg.setRecipients(Message.RecipientType.TO, addressTo);  //vendor mail id
			}
		}

		if(ccRecipients.length>0){


			InternetAddress[] addressCC = new InternetAddress[ccRecipients.length];
			String strccToEmailId = "";
			for (int i = 0; i < ccRecipients.length; i++) {


				strccToEmailId = ccRecipients[i];


				if(strccToEmailId != null && !strccToEmailId.equals("") && !strccToEmailId.equals(" ")){

					addressCC[i] = new InternetAddress(strccToEmailId);
				}
			}

			//if(!ccRecipients[0].equals("")){
			/*InternetAddress[] addressCC = new InternetAddress[ccRecipients.length];
				for (int i = 0; i < addressCC.length; i++) {
					addressCC[i] = new InternetAddress(ccRecipients[i]);
				}*/
			//pruchase deprtment and specific person
			if(there_is_no_EmailTo_address){
				msg.setRecipients(Message.RecipientType.TO, addressCC);
			}else{
				msg.setRecipients(Message.RecipientType.CC, addressCC);
			}
			//}
		}

		// Setting the Subject and Content Type

		BodyPart messageBodyPart = new MimeBodyPart();

		// Now set the actual message
		messageBodyPart.setText("vinod this is for you");

		// Create a multipar message
		Multipart multipart = new MimeMultipart();

		multipart.addBodyPart(messageBodyPart);
		messageBodyPart = new MimeBodyPart();
		multipart.addBodyPart(messageBodyPart);

		msg.setSubject(subject);
		msg.setContent(multipart);
		msg.setContent(message, "text/html");
		Transport.send(msg);

	}



	public  void  sendIndentCreationApprovalMail(String strApproverName,int strIndentNumber,String strIndentFrom,
			String strIndentSite,String strIndentCreationDate,String [] emailToAddress ){

		try{

			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();

			//String emailFromAddress = "jobsintbdb@gmai.com";

			String emailSubjectText = "Indent Process Request";

			String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div style='font-family: Calibri;font-size:14px;' class=\"greting1\">Dear "+strApproverName+"</div><br> <div style='font-family: Calibri;font-size:14px;' class=\"greting2\">Greetings!!!</div><br>"
				+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">You have a indent for Approval !!!</div><br></div> "
				+ "<table class=\"table\" class=\"table-bordered\"style=\"width:898px;margin:6px auto;border:0;border-spacing:0;font-family: Calibri;border:1px solid #000;\">"
				+ "<tbody><tr class=\"bckcolor\" style=\"background: #b4d4e3;height:20px;border:1px solid #000;\"> <td  class=\"text-left\">Indent Number </td> "
				+ "<td  class=\"text-left\"> Indent From </td> <td  class=\"text-left\">Indent Site</td> "
				+ " <td  class=\"text-left\">Date</td></tr>  <tr><td  class=\"text-left\"><span class=\"contentBold\">"+strIndentNumber+"</span> "
				+ " </td>  <td  class=\"text-left\"><span class=\"contentBold\">"+strIndentFrom+"</span></td> <td   class=\"text-left\">"+strIndentSite+" </td>"
				+ "  <td   class=\"text-left\">"+strIndentCreationDate+"<span class=\"contentBold\"></span></td> </tr></tbody></table><div>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>Arun Kumar B A | Billing Engineer</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
				+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
				+ "	<div><div>T:  91 7022009206 |  E: billingengineer@sumadhuragroup.com </div></div>  </div></body></html>";

			sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress, emailToAddress, new String[0],"");


			//public static void sendEmail(String emailBodyMsgText,String emailSubjectText,String emailFromAddress,String [] emailToAddress) throws Exception {





		}catch(Exception e){
			e.printStackTrace();
		}
	}


	//ravi writing code 2


	public  void  sendIndentCreationApprovalMailDetails(String strApproverName,int strIndentNumber,String strIndentFrom,
			String strIndentSite,String strIndentCreationDate,String strScheduleDate,String [] emailToAddress,List<IndentCreationDetailsDto> listProductDetails, IndentCreationDto indentCreationDto,String strIndentLevelComments, List<IndentCreationBean> listProductChangesList, int siteWiseIndentNo,int getLocalPort){
		//List<IndentCreationDetailsDto> list=indentCreationDetailsDto;
		int count=1;
		String strRemarks="";
		String productDetails="";
		String url="";
		// List<IndentCreationDetailsDto> listProductDetails = new ArrayList<IndentCreationDetailsDto>();

		// indentCreationDetailsDto = new IndentCreationDetailsDto();
		try{
			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();

			//String emailFromAddress = "jobsintbdb@gmai.com";

			String emailSubjectText = "Indent Process Request";


			String ApproveUrl = validateParams.getProperty("MAIL_APPROVE_URL") == null ? "" : validateParams.getProperty("MAIL_APPROVE_URL").toString();
			String RejectUrl = validateParams.getProperty("MAIL_REJECT_URL") == null ? "" : validateParams.getProperty("MAIL_REJECT_URL").toString();
			String EditAndApproveUrl = validateParams.getProperty("MAIL_EDIT_AND_APPROVE_URL") == null ? "" : validateParams.getProperty("MAIL_EDIT_AND_APPROVE_URL").toString();


			//	int getLocalPort = request.getLocalPort();
			/*ApplicationContext ApproveUrl = null;
			ApplicationContext RejectUrl = null;
			ApplicationContext EditAndApproveUrl = null;*/

			if(getLocalPort == 8078){ //local machine
				ApproveUrl = "http://129.154.74.18:8078/Sumadhura_UAT/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&noofRowsTobeProcessed="+listProductDetails.size()+"&operationtype=Approve'";

				RejectUrl="http://129.154.74.18:8078/Sumadhura_UAT/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&operationtype=Reject";

				EditAndApproveUrl="http://129.154.74.18:8078/Sumadhura_UAT/index.jsp?IndentApproval=";
				url="http://localhost:8027/Sumadhura/";
			}
			else if(getLocalPort == 8079){ //CUG
				ApproveUrl = "http://129.154.74.18:8078/Sumadhura_CUG/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&noofRowsTobeProcessed="+listProductDetails.size()+"&operationtype=Approve'";

				RejectUrl="http://129.154.74.18:8078/Sumadhura_CUG/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&operationtype=Reject";

				EditAndApproveUrl="http://129.154.74.18:8078/Sumadhura_CUG/index.jsp?IndentApproval=";
				url="http://129.154.74.18:8081/Sumadhura/";

			}
			else if(getLocalPort == 80){ //LIVE
				ApproveUrl = "http://129.154.74.18/Sumadhura/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&noofRowsTobeProcessed="+listProductDetails.size()+"&operationtype=Approve'";

				RejectUrl="http://129.154.74.18/Sumadhura/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&operationtype=Reject";

				EditAndApproveUrl="http://129.154.74.18/Sumadhura/index.jsp?IndentApproval=";

				url="http://129.154.74.18/Sumadhura/";

			}



			String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div class=\"greting1\">Dear "+strApproverName+"</div><br> <div class=\"greting2\">Greetings!!!</div><br>"
				+ " <div class=\"greting3\">You have a indent for Approval !!!</div><br>"
				+ "<div> <span style='font-size: 14px;margin-right: 110px;padding: 0px 10px 10px 0px;'class=\"greting4\">Indent No"+"<span style=' margin-left: 31px;'> : "+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'> "+siteWiseIndentNo+"</span>" 
				+ "<span style='font-size: 14px;font-family: Calibri;margin-right: 100px;padding: 201px;' class=\"greting4\">Schedule Date"+"<span style=' margin-left: 10px;'>:"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'> "+strScheduleDate+"</span>"
				/*+ " <span style='font-size: 14px;font-family: Calibri;padding: 186px;' class=\"greting4\">Indent From"+"<span style=' margin-left: 10px;'>: "+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'>"+strIndentFrom+"</span> </div>"*/

				+ " <div style='margin-top: 20px;margin-bottom: 20px;'><span style='font-size: 14px;font-family: Calibri;margin-right: 110px;padding: 0px 10px 10px 0px;' class=\"greting4\">Indent From"+"<span style=' margin-left: 21px;'>:"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 57px;'>"+strIndentFrom+".</span> "
				+ "<span style='font-size: 14px;font-family: Calibri;margin-right: 100px;padding: 201px;' class=\"greting4\">Indent TO"+"<span style=' margin-left: 22px;'>:"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'> "+strApproverName+"</span>"
				/*				+ " <div style='margin-top: 20px;margin-bottom: 20px;'><span style='font-size: 14px;font-family: Calibri;margin-right: 110px;padding: 0px 10px 10px 0px;' class=\"greting4\">Indent TO"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'>"+strApproverName+".</span> "
				+ " <span style='font-size: 14px;font-family: Calibri;padding: 180px;' class=\"greting4\">Required Date"+"<span style=' margin-left: 10px;'>:"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'>"+strIndentCreationDate+"</span></div>"
				 */				+ " <div style='margin-top: 20px;margin-bottom: 20px;'><span style='font-size: 14px;font-family: Calibri;margin-right: 110px;padding: 0px 10px 10px 0px;' class=\"greting4\">Required Date"+"<span style=' margin-left: 10px;'>:"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 57px;'>"+strIndentCreationDate+".</span> "
				 + "<span style='font-size: 14px;font-family: Calibri;margin-right: 100px;padding: 201px;' class=\"greting4\">Indent Site"+"<span style=' margin-left: 22px;'>:"+"<span style='font-weight: bold;font-size: 16px;    margin-left: 50px;'> "+strIndentSite+"</span>"

				 + "<table class=\"table\" class=\"table-bordered\"style=\"width:898px;margin:26px auto;border:0;border-spacing:0;font-family: Calibri;border:1px solid #000;\">"
				 + "<tbody><tr class=\"bckcolor\" style=\"background: #b4d4e3;height:20px;border:1px solid #000;\">"
				 + "<td  class=\"text-left\">S.No</td> <td  class=\"text-left\">Product</td> "
				 + " <td  class=\"text-left\">Sub Product</td><td  class=\"text-left\">Child Product</td>"
				 + "<td  class=\"text-left\">Unit of Measurement</td>"
				 +"<td  class=\"text-left\">Quantity</td>"
				 +"<td  class=\"text-left\">Remarks</td></tr>";

			for(int i=0;i<listProductDetails.size();i++){
				//	System.out.println("---->"+listProductDetails.get(i).getProdName());

				String strdetailedRemarks = "";
				strRemarks=listProductDetails.get(i).getRemarks();//.toString();
				if(strRemarks!=null){
					if(strRemarks.contains("@@@")){
						String strRemarksArr[] = strRemarks.split("@@@");

						for(int j =0 ; j< strRemarksArr.length;j++){

							strdetailedRemarks += " "+(j+1)+". "+strRemarksArr [j];

						}
						strRemarks = strdetailedRemarks;
					}	
				}
				productDetails=productDetails+"<tr><td  class=\"text-left\"><span class=\"contentBold\">"+count+"</span></td>"
				+"<td  class=\"text-left\"><span class=\"contentBold\">"+listProductDetails.get(i).getProdName()+"</span></td>"
				+"<td  class=\"text-left\"><span class=\"contentBold\">"+listProductDetails.get(i).getSubProdName()+"</span></td>"
				+"<td  class=\"text-left\"><span class=\"contentBold\">"+listProductDetails.get(i).getChildProdName()+"</span></td>"
				+"<td  class=\"text-left\"><span class=\"contentBold\">"+listProductDetails.get(i).getMeasurementName()+"</span></td>"
				+"<td  class=\"text-left\"><span class=\"contentBold\">"+listProductDetails.get(i).getRequiredQuantity()+"</span></td>"
				+"<td  class=\"text-left\"><span class=\"contentBold\">"+strRemarks+"</span></td></tr>";

				count++;

			}

			String strEditComments = "";
			if(listProductChangesList != null){

				for(int i =0 ;i< listProductChangesList.size();i++ ){

					IndentCreationBean objIndentCreationBean = listProductChangesList.get(i);
					strEditComments += objIndentCreationBean.getMaterialEditComment()+"<br>";
				}
			}

			String Enddetails1="</tbody></table>" +
			" <div style='font-size: 14px;font-family: Calibri;margin-right: 14px;'><span class='' style='font-weight:bold'>Approved Comments:</span></br><span style='d;margin-left: 17px;'>"+strIndentLevelComments+"</span></div><br>" +
			" <div style='font-size: 14px;font-family: Calibri;position: absolute;margin-top: 14px;'><span  style='font-weight:bold;'>Product Modification Details:</div><br>"+
			strEditComments+"</span>" +
			"<div class='col-sm-2 pt-10' style='margin-top: 34px;margin-left: 352px;'>";



			String Buttons    ="<form action='"+ApproveUrl+"' method='POST'>"
			/*+ "<span>Leave your comment : </span><input type='textarea' name='comment' plaholder='please leave a comment' 'style=' margin-top: 20px; style='font-weight:bold' />"*/
			+ "<input type='hidden' name='indentNumber' value='"+strIndentNumber+"' />"
			+ "<input type='hidden' name='portNo' value='"+getLocalPort+"' />"
			+ "<input type='hidden' name='siteId' value='"+indentCreationDto.getSiteId()+"' />"
			+ "<input type='hidden' name='userId' value='"+indentCreationDto.getPendingEmpId()+"' />"
			+ "<input type='hidden' name='tempPass' value='"+indentCreationDto.getTempPass()+"' />"
			+ "<input type='hidden' name='noofRowsTobeProcessed' value='"+listProductDetails.size()+"' />"


			+"<a href='"+url+"IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&noofRowsTobeProcessed="+listProductDetails.size()+"&operationtype=Approve' style='float: left;display:inline;width:130px;height:31px;background:#b4d4e3;text-align: center;padding-top: 8px;'>Approve</a>"
			//+ "<input type='submit' class='btn btn-primary' value='Approve' id='saveBtnId'  style='float: left;display:inline;width:130px;height:31px;background:#b4d4e3;margin-bottom: -28px;margin-top: -28px;'>"
			+ "</form>"

			+ "<form action='"+RejectUrl+"' method='POST'>"
			+ "<input type='hidden' name='indentNumber' value='"+strIndentNumber+"' />"
			+ "<input type='hidden' name='portNo' value='"+getLocalPort+"' />"
			+ "<input type='hidden' name='siteId' value='"+indentCreationDto.getSiteId()+"' />"
			+ "<input type='hidden' name='userId' value='"+indentCreationDto.getPendingEmpId()+"' />"
			+ "<input type='hidden' name='tempPass' value='"+indentCreationDto.getTempPass()+"' />"

			+"<a href='"+url+"IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&portNo="+getLocalPort+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"&operationtype=Reject' style='float: left;margin-left: 28px;display:inline;margin-top: -34px;width:130px;height:31px;background:#b4d4e3;text-align: center;padding-top: 8px;'>Reject</a>"
			//+"<input type='submit' class='btn btn-primary myclass' value='Reject' id='saveBtnId' style='float: left;margin-left: 28px;display:inline;margin-top: -34px;width:130px;height:31px;background:#b4d4e3;'>"
			+ "</form>"

			+ "<form action='"+EditAndApproveUrl+strIndentNumber+"' method='POST'>"

			+"<input type='submit' class='btn btn-primary' value='Edit & Approve' id='saveBtnId' style='display:inline;margin-left: 28px;width:130px;height:38px;background: #b4d4e3;margin-left: -181px;'>"
			+ "</form>";

			String Enddetails2="</div></body></html>";

			//	String link = "<a href='http://localhost:8081/Sumadhura/IndentApprovalRejectMailFunction.jsp?indentNumber="+strIndentNumber+"&siteId="+indentCreationDto.getSiteId()+"&userId="+indentCreationDto.getPendingEmpId()+"&tempPass="+indentCreationDto.getTempPass()+"'>check link</a>";

			if(indentCreationDto.getPendingEmpId().equals("-"))
			{
				emailBodyMsgTxt=emailBodyMsgTxt+productDetails+Enddetails1+Enddetails2;
			}
			else{
				emailBodyMsgTxt=emailBodyMsgTxt+productDetails+Enddetails1+Buttons+Enddetails2;
			}


			if(!emailToAddress.equals("")){

				sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress, emailToAddress, new String[0],"");
			}
			//System.out.println("IP Address: "+InetAddress.getLocalHost().getHostAddress());
			//public static void sendEmail(String emailBodyMsgText,String emailSubjectText,String emailFromAddress,String [] emailToAddress) throws Exception {





		}catch(Exception e){
			e.printStackTrace();
		}
	}




	public  void  sendMailToVendor(String strIndentRaised,int strIndentNumber,String strIndentFrom,
			String strIndentSite,String strIndentCreationDate,String [] emailToAddress ,VendorDetails vendorDetails ,
			String indentCreationDetailsIdForenquiry,String address,int siteWiseIndentNo,String strIndentSiteId,String sendEnquiryEmpDetails,int getLocalPort){

		try{

			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();
			String VendorLoginUrl  = validateParams.getProperty("VENDOR_LOGIN_URL") == null ? "" : validateParams.getProperty("VENDOR_LOGIN_URL").toString();

			if(getLocalPort == 8078){

				VendorLoginUrl="http://129.154.74.18:8078/Sumadhura_UAT/vendorloginsubmit.spring";

			}else if(getLocalPort == 8079){
				VendorLoginUrl="http://129.154.74.18:8079/Sumadhura_CUG/vendorloginsubmit.spring";

			}else if(getLocalPort == 80){

				VendorLoginUrl="http://129.154.74.18/Sumadhura/vendorloginsubmit.spring";

			}

			/*if(InetAddress.getLocalHost().getHostAddress().equals("192.168.1.104"))
			{
				VendorLoginUrl=VendorLoginUrl.replace("localhost:8032","117.213.180.168");
			}
			else if(InetAddress.getLocalHost().getHostAddress().equals("129.154.74.18"))
			{
				VendorLoginUrl=VendorLoginUrl.replace("localhost:8032","129.154.74.18");
			}
			else
			{
				VendorLoginUrl=VendorLoginUrl.replace("localhost:8032","localhost:8032");
			}
			 *///String emailFromAddress = "jobsintbdb@gmai.com";

			//	VendorLoginUrl="http://129.154.74.18/Sumadhura/vendorloginsubmit.spring";

			//VendorLoginUrl="http://localhost:8081/Sumadhura/vendorlogin.spring";

			String emailSubjectText = "Indent Process Request";

			String data[] = sendEnquiryEmpDetails.split(",");
			String strEmpName=data[0];
			String strEmpEmailId=data[1];
			String strMobiloeNumber=data[2];


			AESDecrypt encrypt=new AESDecrypt();


			String userDate = "indentNumber="+strIndentNumber+"$$$vendordata="+vendorDetails.getVendor_name()+"@@"+vendorDetails.getGsin_number()+"@@"+vendorDetails.getAddress()+"@@"+vendorDetails.getVendor_Id()+
			"$$$uname="+vendorDetails.getVendor_Id()+"$$$pass="+vendorDetails.getVendor_Pass()+"$$$indentCreationDetailsIdForenquiry="+indentCreationDetailsIdForenquiry+"$$$address="+address;

			String strEncryptionData =encrypt.encrypt("AMARAVADHIS12345",userDate);

			String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div style='font-family: Calibri;font-size:14px;'class=\"greting1\">Dear Vendor</div><br> <div style='font-family: Calibri;font-size:14px;' class=\"greting2\">Greetings!!!</div><br>"
				+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">Please login and fill the enquiry form!!!</div><br></div> "

				+ "<table class=\"table\" class=\"table-bordered\"style=\"width:898px;margin:6px auto;border:0;border-spacing:0;font-family: Calibri;border:1px solid #000;\">"
				+ "<tbody><tr class=\"bckcolor\" style=\"background: #b4d4e3;height:20px;border:1px solid #000;\"> <td  class=\"text-left\">Sitewise Indent Number </td> "
				+ "<td  class=\"text-left\"> Indent From </td> <td  class=\"text-left\">Indent Site</td> "
				+ " <td  class=\"text-left\">Date</td></tr>  <tr><td  class=\"text-left\"><span class=\"contentBold\">"+siteWiseIndentNo+"</span> "
				+ " </td>  <td  class=\"text-left\"><span class=\"contentBold\">"+strIndentFrom+"</span></td> <td   class=\"text-left\">"+strIndentRaised+" </td>"
				+ "  <td   class=\"text-left\">"+strIndentCreationDate+"<span class=\"contentBold\"></span></td> </tr></tbody></table>"
				+ "<div>"
				/*+ "<b style='display: block;margin-top:30px;margin-bottom:20px;color:blue;'>Your username: "+"<span style='color:red;'>"+vendorDetails.getVendor_Id()+"</span>"+"</b><br>"
				+ "<b style='color:blue;'>Your password: "+"<span style='color:red;'>" + vendorDetails.getVendor_Pass()+"</span>"+"</b>"
				 */
				+ "<form method='POST' action='"+VendorLoginUrl+"' />"
				+ "<input type='hidden' name='indentNumber' value='"+strIndentNumber+"' />"
				+ "<input type='hidden' name='vendordata' value='"+vendorDetails.getVendor_name()+"@@"+vendorDetails.getGsin_number()+"@@"+vendorDetails.getAddress()+"@@"+vendorDetails.getVendor_Id()+"' />"
				+ "<input type='hidden' name='uname' value='"+vendorDetails.getVendor_Id()+"' />"
				+ "<input type='hidden' name='pass' value='"+vendorDetails.getVendor_Pass()+"' />"
				+"<input type='hidden' name='submitButton' value='true' />"
				+ "<input type='hidden' name='indentCreationDetailsIdForenquiry' value='"+indentCreationDetailsIdForenquiry+"' />"
				+ "<input type='hidden' name='address' value='"+address+"' />"
				+ "<input type='submit' value='Click to login'style=\"background: #b4d4e3;width: 158px;height: 29px;margin-left: 423px;margin-top: 50px;\" />"	
				+ "</form>"





				+ "	   <a href='"+VendorLoginUrl+"?data="+strEncryptionData+"'>click this link</a>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>"+strEmpName+"</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
				+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
				+ "	<div><div>T:"+strMobiloeNumber+"|  E:"+strEmpEmailId+"</div></div>  </div></body></html>";

			sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress, emailToAddress, new String[0],strIndentSiteId);


			//public static void sendEmail(String emailBodyMsgText,String emailSubjectText,String emailFromAddress,String [] emailToAddress) throws Exception {





		}catch(Exception e){
			e.printStackTrace();
		}
	}


	public  void  sendMailToVendorForPO(String strIndentRaised,int strIndentNumber,String strIndentFrom,
			String strIndentSite,String strIndentCreationDate,String [] emailToAddress ,VendorDetails vendorDetails ,
			String poNumber, String[] ccTo,String subject,String poCreatedEmpName,int getLocalPort){

		String url="";

		try{

			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();
			String VendorLoginUrl  = validateParams.getProperty("VENDOR_LOGIN_URL") == null ? "" : validateParams.getProperty("VENDOR_LOGIN_URL").toString();
			if(getLocalPort == 8078){

				VendorLoginUrl="http://129.154.74.18:8078/Sumadhura_UAT/showPODetailsToVendor.spring?poNumber="+poNumber;
				url="http://129.154.74.18:8078/Sumadhura_UAT/showPODetailsToVendor.spring";

			}else if(getLocalPort == 8079){
				VendorLoginUrl="http://129.154.74.18:8079/Sumadhura_CUG/showPODetailsToVendor.spring?poNumber="+poNumber;
				url="http://129.154.74.18:8079/Sumadhura_CUG/showPODetailsToVendor.spring";

			}else if(getLocalPort == 80){

				VendorLoginUrl="http://129.154.74.18/Sumadhura/showPODetailsToVendor.spring?poNumber="+poNumber;
				url="http://129.154.74.18/Sumadhura/showPODetailsToVendor.spring";
			}

			/*if(InetAddress.getLocalHost().getHostAddress().equals("192.168.1.104"))
			{
				VendorLoginUrl=VendorLoginUrl.replace("localhost:8032","117.213.180.168");
			}
			else if(InetAddress.getLocalHost().getHostAddress().equals("129.154.74.18"))
			{
				VendorLoginUrl=VendorLoginUrl.replace("localhost:8032","129.154.74.18");
			}
			else
			{
				VendorLoginUrl=VendorLoginUrl.replace("localhost:8032","localhost:8032");
			}
			 *///String emailFromAddress = "jobsintbdb@gmai.com";

			//	VendorLoginUrl="http://129.154.74.18/Sumadhura/showPODetailsToVendor.spring?poNumber="+poNumber;

			//VendorLoginUrl="http://localhost:8081/Sumadhura/showPODetailsToVendor.spring?poNumber="+poNumber;
			String emailSubjectText = "";
			if(subject==null || subject.equals("")){
				emailSubjectText = "Indent Process Request";
			}
			else{
				emailSubjectText = subject;
			}

			String data[] = poCreatedEmpName.split(",");
			String strEmpName=data[0];
			String strEmpEmailId=data[1];
			String strMobiloeNumber=data[2];
			//	String vendorId=vendorDetails.getVendor_Id();

			//System.out.println("email site id....."+strIndentFrom);
			AESDecrypt encrypt=new AESDecrypt();


			String userData="poNumber="+poNumber+"&indentSiteId="+strIndentFrom;

			String strEncryptionData =encrypt.encrypt("AMARAVADHIS12345",userData);
			strEncryptionData =  strEncryptionData.replaceAll("[\\t\\n\\r]+","");

			String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div style='font-family: Calibri;font-size:14px;'class=\"greting1\">Dear Vendor</div><br> <div style='font-family: Calibri;font-size:14px;' class=\"greting2\">Greetings!!!</div><br>"
				+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">You have one PO, for more details click below Button</div><br></div> "

				+ "<div>"

				+ "<form method='POST' action='"+VendorLoginUrl+"' />"
				+ "<input type='hidden' name='poNumber' value='"+poNumber+"' />"
				+ "<input type='hidden' name='indentSiteId' value='"+strIndentFrom+"' />"

				+"<input type='hidden' name='submitButton' value='true' />"
				+ "<input type='submit' value='Click Here'style=\"background: #b4d4e3;width: 158px;height: 29px;margin-left: 423px;margin-top: 50px;\" />"	
				+ "</form>"

				+ "  <a href='"+url+"?data="+strEncryptionData+"'>click this link</a>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>"+strEmpName+"</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
				+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
				+ "	<div><div>T:"+strMobiloeNumber+"|  E:"+strEmpEmailId+"</div></div>  </div></body></html>";


			sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress, emailToAddress, ccTo,strIndentFrom);


			//public static void sendEmail(String emailBodyMsgText,String emailSubjectText,String emailFromAddress,String [] emailToAddress) throws Exception {





		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public  void  sendOtpToUser(String [] emailToAddress,String password,int rand_Num){
		String subject="";

		try{

			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();
			String emailSubjectText = "";
			if(subject==null || subject.equals("")){
				emailSubjectText = "Hello User New OTP";

				String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
					+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
					+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
					+ "<div style='font-family: Calibri;font-size:14px;'class=\"greting1\">Dear User</div><br> <div style='font-family: Calibri;font-size:14px;' class=\"greting2\">Greetings!!!</div><br>"
					+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">You have New OTP</div><br></div> New OTP:"+rand_Num
					+ "<form>"
					+ "<input type='hidden' name='password' value='"+password+"' />"
					+ "<input type='hidden' name='rand_Num' value='"+rand_Num+"' />"
					+ "</form>"

					//+ "<a href='http://localhost:8081/Sumadhura/vendorlogin.spring?indentNumber="+strIndentNumber+"&vendordata="+vendorDetails.getVendor_name()+"@@"+vendorDetails.getGsin_number()+"@@"+vendorDetails.getAddress()+"@@"+vendorDetails.getVendor_Id()+"'>click this link</a>"
					+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
					+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
					+ " <div>Arun Kumar B A | Billing Engineer</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
					+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
					+ "	<div><div>T:  91 7022009206 |  E: billingengineer@sumadhuragroup.com </div></div>  </div></body></html>";



				sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress,emailToAddress,new String[0],"");
			}



		}catch(Exception e){
			e.printStackTrace();
		}


	}


	public  void  sendEnquiryFormFillMailToPurchaseDept( String[] ccTo, String siteWiseIndentNo, String vendorName, String siteName){


		try{

			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();
			String emailSubjectText = "";

			emailSubjectText = "Successfully Details Submit By Vendor ";

			String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div style='font-family: Calibri;font-size:14px;'class=\"greting1\">Dear User</div><br> <div style='font-family: Calibri;font-size:14px;' class=\"greting2\">Greetings!!!</div><br>"
				+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">Successfully Submit By Vendor Data"

				+ "<table class=\"table\" class=\"table-bordered\"style=\"width:898px;margin:6px auto;border:0;border-spacing:0;font-family: Calibri;border:1px solid #000;\">"
				+ "<tbody><tr class=\"bckcolor\" style=\"background: #b4d4e3;height:20px;border:1px solid #000;\"> <td  class=\"text-left\">Sitewise Indent Number </td> "
				+ "<td  class=\"text-left\">Indent Site</td> "
				+ " <td  class=\"text-left\">Vendor</td></tr>  <tr><td  class=\"text-left\"><span class=\"contentBold\">"+siteWiseIndentNo+"</span>  </td> "
				+ " <td   class=\"text-left\">"+siteName+" </td>"
				+ "  <td   class=\"text-left\">"+vendorName+"<span class=\"contentBold\"></span></td> </tr></tbody></table>"

				+ "</div><br></div>" 
				+ "<form>"


				+ "</form>"

				//+ "<a href='http://localhost:8081/Sumadhura/vendorlogin.spring?indentNumber="+strIndentNumber+"&vendordata="+vendorDetails.getVendor_name()+"@@"+vendorDetails.getGsin_number()+"@@"+vendorDetails.getAddress()+"@@"+vendorDetails.getVendor_Id()+"'>click this link</a>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>Arun Kumar B A | Billing Engineer</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
				+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
				+ "	<div><div>T:  91 7022009206 |  E: billingengineer@sumadhuragroup.com </div></div>  </div></body></html>";



			sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress,new String[0],ccTo,"");




		}catch(Exception e){
			e.printStackTrace();
		}


	}




	public  void  sendMailToClosedIndents( String[] ccTo,userDetails objUserDetails ){


		try{

			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();
			String emailSubjectText = "";

			emailSubjectText = "Indent Closed";

			String emailBodyMsgTxt = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div style='font-family: Calibri;font-size:14px;'class=\"greting1\">Dear User</div><br> <div style='font-family: Calibri;font-size:14px;' class=\"greting2\">Greetings!!!</div><br>"
				+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">Dear User, "+objUserDetails.getStrMesage()+"</div><br></div>" 
				+ "<form>"


				+ "</form>"

				//+ "<a href='http://localhost:8081/Sumadhura/vendorlogin.spring?indentNumber="+strIndentNumber+"&vendordata="+vendorDetails.getVendor_name()+"@@"+vendorDetails.getGsin_number()+"@@"+vendorDetails.getAddress()+"@@"+vendorDetails.getVendor_Id()+"'>click this link</a>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>"+objUserDetails.getUserName()+"</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
				+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
				+ "	<div><div>T:  91 "+objUserDetails.getMobileNo()+" |  E: "+objUserDetails.getEmailId()+" </div></div>  </div></body></html>";



			sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress,new String[0],ccTo,"");




		}catch(Exception e){
			e.printStackTrace();
		}


	}

	/**************************************************************************************************************/
	/***********************************         PAYMENT MODULE           *****************************************/
	/**************************************************************************************************************/



	public void sendPaymentInitiatedMail(List<PaymentBean> successDataListToMail, String[] emailToAddress, int getLocalPort, String strSiteId, String pendingEmpId){

		try {
			String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();

			/* if more than one Payments are came for approval,  groupOfPaymentDetailsId is combination of 
			 * all paymentDetailsId 's seperated with comma(,)  */
			String groupOfPaymentDetailsId = ""; 
			for(PaymentBean successData : successDataListToMail){
				groupOfPaymentDetailsId+=String.valueOf(successData.getIntPaymentDetailsId())+",";
			}
			if(StringUtils.isNotBlank(groupOfPaymentDetailsId)){
				groupOfPaymentDetailsId = groupOfPaymentDetailsId.substring(0,groupOfPaymentDetailsId.length()-1);
			}

			String url="";
			String ApproveUrl = validateParams.getProperty("MAIL_APPROVE_URL") == null ? "" : validateParams.getProperty("MAIL_APPROVE_URL").toString();
			String RejectUrl = validateParams.getProperty("MAIL_REJECT_URL") == null ? "" : validateParams.getProperty("MAIL_REJECT_URL").toString();
			String EditAndApproveUrl = validateParams.getProperty("MAIL_EDIT_AND_APPROVE_URL") == null ? "" : validateParams.getProperty("MAIL_EDIT_AND_APPROVE_URL").toString();

			if(getLocalPort == 8078){ //local machine
				ApproveUrl = "http://129.154.74.18:8078/Sumadhura_UAT/PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Approve'";

				RejectUrl="http://129.154.74.18:8078/Sumadhura_UAT/PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Reject";

				EditAndApproveUrl="http://129.154.74.18:8078/Sumadhura_UAT/index.jsp?IndentApproval=";
				url="http://localhost:8027/Sumadhura/";
			}
			else if(getLocalPort == 8079){ //CUG
				ApproveUrl = "http://129.154.74.18:8079/Sumadhura_CUG/PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Approve'";

				RejectUrl="http://129.154.74.18:8079/Sumadhura_CUG/PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Reject";

				EditAndApproveUrl="http://129.154.74.18:8079/Sumadhura_CUG/index.jsp?IndentApproval=";
				url="http://129.154.74.18:8079/Sumadhura_CUG/";

			}
			else if(getLocalPort == 80){ //LIVE
				ApproveUrl = "http://129.154.74.18/Sumadhura/PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Approve'";

				RejectUrl="http://129.154.74.18/Sumadhura/PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Reject";

				EditAndApproveUrl="http://129.154.74.18/Sumadhura/index.jsp?IndentApproval=";

				url="http://129.154.74.18/Sumadhura/";

			}
			String emailSubjectText = "Payment For Approval";
			//String emailBodyMsgTxt = "Payment Initiated Successfully."+"<br>";
			//emailToAddress = new String[]{"rafi341@yahoo.com","mrafi@amaravadhis.com"};//
			String emailBodyMsgTxt = "";
			String header = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+"<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
				+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
				+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
				+ "<div style='font-family: Calibri;font-size:14px;' class=\"greting1\">Dear Sir,</div><br> "
				+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">You have a payment(s) request for approval</div><br></div> ";

			/****************************************************/		
			String tableData = "<div class=\"table-responsive\"> <table class=\"table\" class=\"table-bordered\"style=\"width:898px;margin:6px auto;border:0;border-spacing:0;font-family: Calibri;border:1px solid #000;\">"
				+ "<tbody><tr class=\"bckcolor\" style=\"background: #b4d4e3;height:20px;border:1px solid #000;\"> <td  class=\"text-left\">PaymentDetails Id </td> "
				+ "<td  class=\"text-left\"> PO Number </td> <td  class=\"text-left\">Invoice No</td> <td  class=\"text-left\">Requested Amount</td> "
				+ " <td  class=\"text-left\">Vendor</td></tr> ";


			for(PaymentBean successData : successDataListToMail){
				tableData+= " <tr><td  class=\"text-left\"><span class=\"contentBold\">"+successData.getIntPaymentDetailsId()+"</span> </td> "
				+ "  <td  class=\"text-left\"><span class=\"contentBold\">"+successData.getStrPONo()+"</span></td> <td   class=\"text-left\">"+successData.getStrInvoiceNo()+" </td>"
				+ "  <td   class=\"text-left\">"+successData.getDoubleAmountToBeReleased()+" </td><td   class=\"text-left\">"+successData.getStrVendorName()+"<span class=\"contentBold\"></span></td> </tr>";

				/*emailBodyMsgTxt=emailBodyMsgTxt+"<br> PaymentDetailsId: "+successData.getIntPaymentDetailsId()+", "+(StringUtils.isNotBlank(successData.getStrInvoiceNo())?("InvoiceNumber: "+successData.getStrInvoiceNo()):("PONumber: "+successData.getStrPONo()))+", Requested Amount: "+successData.getDoubleAmountToBeReleased();*/
			}

			/*emailBodyMsgTxt=emailBodyMsgTxt+ "</tbody></table><div>"
						+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
						+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
						+ " <div>Arun Kumar B A | Billing Engineer</div><div>Sumadhura Infracon Pvt. Ltd | Web: www.sumadhuragroup.com</div>"
						+ "<div><div>No. 43, C.K.B Plaza, 2nd Floor, Marathahalli, Bengaluru, Karnataka. India. 560037.</div></div>"
						+ "	<div><div>T:  91 7022009206 |  E: billingengineer@sumadhuragroup.com </div></div>  </div></body></html>";
			 */
			tableData+="</tbody></table></div><br><br><br><br>";
			/****************************************************/

			String Buttons    ="<div class='col-md-12 text-center center-block'> <form action='"+ApproveUrl+"' method='POST'>"
			/*+ "<span>Leave your comment : </span><input type='textarea' name='comment' plaholder='please leave a comment' 'style=' margin-top: 20px; style='font-weight:bold' />"*/
			+ "<input type='hidden' name='paymentDetailsId' value='"+groupOfPaymentDetailsId+"' />"
			+ "<input type='hidden' name='portNo' value='"+getLocalPort+"' />"
			+ "<input type='hidden' name='siteId' value='"+strSiteId+"' />"
			+ "<input type='hidden' name='userId' value='"+pendingEmpId+"' />"


			+"<div class='col-xs-4'>"+"<a href='"+url+"PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Approve' class='btn btn-primary approve-btn-mail'style='width:75px;padding:6px;background-color:#337ab7;color:#fff;float:left;margin-right:5px;margin-left:5px;border-radius:5px;text-align:center;'>Approve</a>"+"</div>"
			//+ "<input type='submit' class='btn btn-primary' value='Approve' id='saveBtnId'  style='float: left;display:inline;width:130px;height:31px;background:#b4d4e3;margin-bottom: -28px;margin-top: -28px;'>"
			+ "</form>"

			+ "<form action='"+RejectUrl+"' method='POST'>"
			+ "<input type='hidden' name='paymentDetailsId' value='"+groupOfPaymentDetailsId+"' />"
			+ "<input type='hidden' name='portNo' value='"+getLocalPort+"' />"
			+ "<input type='hidden' name='siteId' value='"+strSiteId+"' />"
			+ "<input type='hidden' name='userId' value='"+pendingEmpId+"' />"

			+"<div class='col-xs-4'>"+"<a href='"+url+"PaymentApprovalRejectMailFunction.jsp?paymentDetailsId="+groupOfPaymentDetailsId+"&portNo="+getLocalPort+"&siteId="+strSiteId+"&userId="+pendingEmpId+"&operationtype=Reject' class='btn btn-primary reject-btn-mail' style='width:65px;padding:6px;background-color:#337ab7;color:#fff;float:left;margin-right:5px;margin-left:5px;border-radius:5px;text-align:center;'>Reject</a>"+"</div>"
			//+"<input type='submit' class='btn btn-primary myclass' value='Reject' id='saveBtnId' style='float: left;margin-left: 28px;display:inline;margin-top: -34px;width:130px;height:31px;background:#b4d4e3;'>"
			+ "</form>"

			+ "<form action='"+url+"' method='POST'>"

			+"<div class='col-xs-4'>"+"<input type='submit' class='btn btn-primary editandapprove' value='Edit & Approve' id='saveBtnId' style='width:110px;padding:6px;background-color:#337ab7;color:#fff;float:left;margin-left:5px;border:1px solid #337ab7;border-radius:5px;text-align:center;height:28px;'>"+ "</div>"
			+ "</form>"+"</div>";

			/****************************************************/

			String footer = "<div>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>Sumadhura Infracon Private Limited</div>"
				+" </div></body></html>";

			emailBodyMsgTxt = header+tableData+Buttons+footer;
			sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress, emailToAddress, new String[0],"");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		}
		
//reject Mail
public void paymentRejectedMail(List<PaymentBean> successDataListToMail, String[] emailToAddress){
			
			try {
				String emailFromAddress  = validateParams.getProperty("EMAILFROMADDRESS") == null ? "" : validateParams.getProperty("EMAILFROMADDRESS").toString();
				
				String emailSubjectText = "Payment Rejected";
				//String emailBodyMsgTxt = "Payment Initiated Successfully."+"<br>";
				//emailToAddress = new String[]{"rafi341@yahoo.com","mrafi@amaravadhis.com"};//
				String emailBodyMsgTxt = "";
				String header = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
						+"<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
						+ "<title>Email Format</title><style> table tr td{ border:1px solid #000; height:29px; } </style> "
						+ "</head> <body> <div class=\"desc-icon-box\" style=\"margin-top: 29px; font-family: Calibri;\"> "
						+ "<div style='font-family: Calibri;font-size:14px;' class=\"greting1\">Dear Sir,</div><br> "
						+ " <div style='font-family: Calibri;font-size:14px;' class=\"greting3\">Account Department Rejected this payment(s) </div><br></div> ";
						
				/****************************************************/		
				String tableData = "<div class=\"table-responsive\"> <table class=\"table\" class=\"table-bordered\"style=\"width:898px;margin:6px auto;border:0;border-spacing:0;font-family: Calibri;border:1px solid #000;\">"
						+ "<tbody><tr class=\"bckcolor\" style=\"background: #b4d4e3;height:20px;border:1px solid #000;\"> <td  class=\"text-left\">PaymentDetails Id </td> "
						+ "<td  class=\"text-left\"> PO Number </td> <td  class=\"text-left\">Invoice No</td> <td  class=\"text-left\">Requested Amount</td> "
						+ " <td  class=\"text-left\">Vendor</td></tr> ";
						
						
				for(PaymentBean successData : successDataListToMail){
					tableData+= " <tr><td  class=\"text-left\"><span class=\"contentBold\">"+successData.getIntPaymentDetailsId()+"</span> </td> "
							+ "  <td  class=\"text-left\"><span class=\"contentBold\">"+successData.getStrPONo()+"</span></td> <td   class=\"text-left\">"+successData.getStrInvoiceNo()+" </td>"
							+ "  <td   class=\"text-left\">"+successData.getDoubleAmountToBeReleased()+" </td><td   class=\"text-left\">"+successData.getStrVendorName()+"<span class=\"contentBold\"></span></td> </tr>";
									
				}
				
				tableData+="</tbody></table></div><br><br><br><br>";
				/****************************************************/
				
				String footer = "<div>"
				+ "<img  class=\"text-img\" style=\"margin-left: 179 !important;	float: left;position: relative;margin-left: 178px;bottom: -26px;right: -38px;\" src=\"cid:my-image-id\"  />"
				+ "</div><div class=\"footer-section\" style=\"margin-left: 29px;margin-top: 101px;font-family: Calibri;\">"
				+ " <div>Sumadhura Infracon Private Limited</div>"
				+" </div></body></html>";
		
				emailBodyMsgTxt = header+tableData+footer;
				sendEmail(emailBodyMsgTxt, emailSubjectText, emailFromAddress, emailToAddress, new String[0],"");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}


	//========================================================================================================================================		
	public static void main(String [] args) throws Exception {

		// Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		//TestEmailFunction sendMailThroughJava = new TestEmailFunction();

		String [] emailToAddress = {};
		String emailSubjectText = "";
		String emailBodyMsgText = "";
		String emailFromAddress = "";
		String [] ccTo = {};

		/*sendSSLMessage(emailToAddress, emailSubjectText,
				emailBodyMsgText, emailFromAddress,ccTo,"","");*/


		System.out.println("Sucessfully sent mail to all Users");
	}
}