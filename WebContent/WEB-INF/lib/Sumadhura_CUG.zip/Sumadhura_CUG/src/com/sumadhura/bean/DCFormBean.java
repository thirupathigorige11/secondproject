//old

package com.sumadhura.bean;



public class DCFormBean {
	private String state;
	private String poNo;
	private String expireDate1;
	private String poDate;
	private String eWayBillNo;
	private String vehileNo;
	private String receivedDate;
	private String DCNumber;
	private String DCDate;
	private String VendorName;
	private String GSTINNumber;
	private String VendorAddress;
	private String transporterName;
	private String SubProduct1;
	private String ChildProduct1;
	private String UnitsOfMeasurement1;
	private String Quantity1;
	private String ProductAvailability1;
	private String Price1;
	private String BasicAmount1;
	private String Tax1;
	private String HSNCode1;
	private String TaxAmount1;
	private String AmountAfterTaxId1;
	
	private String AmountAfterTax1;
	private String OtherOrTransportCharges1;
	private String TaxOnOtherOrTransportCharges1;
	private String OtherOrTransportChargesAfterTax1;
	private String TotalAmount1;
	private String OtherCharges;
	private String Note;
	private String GSTTax1;
	private String ConveyanceAmount1;
	private String GSTAmount1;
	private String TransportInvoice1;
	private String Conveyance1;
	private String TransportChargesAmountAfterTax1;
	
	
	
	
	
	public String getAmountAfterTaxId1() {
		return AmountAfterTaxId1;
	}
	public void setAmountAfterTaxId1(String amountAfterTaxId1) {
		AmountAfterTaxId1 = amountAfterTaxId1;
	}
	
	public String getTransportChargesAmountAfterTax1() {
		return TransportChargesAmountAfterTax1;
	}
	public void setTransportChargesAmountAfterTax1(
			String transportChargesAmountAfterTax1) {
		TransportChargesAmountAfterTax1 = transportChargesAmountAfterTax1;
	}
	public String getConveyance1() {
		return Conveyance1;
	}
	public void setConveyance1(String conveyance1) {
		Conveyance1 = conveyance1;
	}
	public String getGSTTax1() {
		return GSTTax1;
	}
	public String getConveyanceAmount1() {
		return ConveyanceAmount1;
	}
	public void setConveyanceAmount1(String conveyanceAmount1) {
		ConveyanceAmount1 = conveyanceAmount1;
	}
	public String getGSTAmount1() {
		return GSTAmount1;
	}
	public void setGSTAmount1(String gSTAmount1) {
		GSTAmount1 = gSTAmount1;
	}
	public String getTransportInvoice1() {
		return TransportInvoice1;
	}
	public void setTransportInvoice1(String transportInvoice1) {
		TransportInvoice1 = transportInvoice1;
	}
	public void setGSTTax1(String gSTTax1) {
		GSTTax1 = gSTTax1;
	}
	public String getVendorAddress() {
		return VendorAddress;
	}
	public void setVendorAddress(String vendorAddress) {
		VendorAddress = vendorAddress;
	}
	public String getGSTINNumber() {
		return GSTINNumber;
	}
	public void setGSTINNumber(String gSTINNumber) {
		GSTINNumber = gSTINNumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPoNo() {
		return poNo;
	}
	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}
	
	public String getExpireDate1() {
		return expireDate1;
	}
	public void setExpireDate1(String expireDate1) {
		this.expireDate1 = expireDate1;
	}
	public String getPoDate() {
		return poDate;
	}
	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}
	public String geteWayBillNo() {
		return eWayBillNo;
	}
	public void seteWayBillNo(String eWayBillNo) {
		this.eWayBillNo = eWayBillNo;
	}
	public String getVehileNo() {
		return vehileNo;
	}
	public void setVehileNo(String vehileNo) {
		this.vehileNo = vehileNo;
	}
	public String getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}
	public String getDCNumber() {
		return DCNumber;
	}
	public void setDCNumber(String dCNumber) {
		DCNumber = dCNumber;
	}
	public String getDCDate() {
		return DCDate;
	}
	public void setDCDate(String dCDate) {
		DCDate = dCDate;
	}
	public String getVendorName() {
		return VendorName;
	}
	public void setVendorName(String vendorName) {
		VendorName = vendorName;
	}
	public String getTransporterName() {
		return transporterName;
	}
	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}
	public String getSubProduct1() {
		return SubProduct1;
	}
	public void setSubProduct1(String subProduct1) {
		SubProduct1 = subProduct1;
	}
	public String getChildProduct1() {
		return ChildProduct1;
	}
	public void setChildProduct1(String childProduct1) {
		ChildProduct1 = childProduct1;
	}
	public String getUnitsOfMeasurement1() {
		return UnitsOfMeasurement1;
	}
	public void setUnitsOfMeasurement1(String unitsOfMeasurement1) {
		UnitsOfMeasurement1 = unitsOfMeasurement1;
	}
	public String getQuantity1() {
		return Quantity1;
	}
	public void setQuantity1(String quantity1) {
		Quantity1 = quantity1;
	}
	public String getProductAvailability1() {
		return ProductAvailability1;
	}
	public void setProductAvailability1(String productAvailability1) {
		ProductAvailability1 = productAvailability1;
	}
	public String getPrice1() {
		return Price1;
	}
	public void setPrice1(String price1) {
		Price1 = price1;
	}
	public String getBasicAmount1() {
		return BasicAmount1;
	}
	public void setBasicAmount1(String basicAmount1) {
		BasicAmount1 = basicAmount1;
	}
	public String getTax1() {
		return Tax1;
	}
	public void setTax1(String tax1) {
		Tax1 = tax1;
	}
	public String getHSNCode1() {
		return HSNCode1;
	}
	public void setHSNCode1(String hSNCode1) {
		HSNCode1 = hSNCode1;
	}
	public String getTaxAmount1() {
		return TaxAmount1;
	}
	public void setTaxAmount1(String taxAmount1) {
		TaxAmount1 = taxAmount1;
	}
	public String getAmountAfterTax1() {
		return AmountAfterTax1;
	}
	public void setAmountAfterTax1(String amountAfterTax1) {
		AmountAfterTax1 = amountAfterTax1;
	}
	public String getOtherOrTransportCharges1() {
		return OtherOrTransportCharges1;
	}
	public void setOtherOrTransportCharges1(String otherOrTransportCharges1) {
		OtherOrTransportCharges1 = otherOrTransportCharges1;
	}
	public String getTaxOnOtherOrTransportCharges1() {
		return TaxOnOtherOrTransportCharges1;
	}
	public void setTaxOnOtherOrTransportCharges1(
			String taxOnOtherOrTransportCharges1) {
		TaxOnOtherOrTransportCharges1 = taxOnOtherOrTransportCharges1;
	}
	public String getOtherOrTransportChargesAfterTax1() {
		return OtherOrTransportChargesAfterTax1;
	}
	public void setOtherOrTransportChargesAfterTax1(
			String otherOrTransportChargesAfterTax1) {
		OtherOrTransportChargesAfterTax1 = otherOrTransportChargesAfterTax1;
	}
	public String getTotalAmount1() {
		return TotalAmount1;
	}
	public void setTotalAmount1(String totalAmount1) {
		TotalAmount1 = totalAmount1;
	}
	public String getOtherCharges() {
		return OtherCharges;
	}
	public void setOtherCharges(String otherCharges) {
		OtherCharges = otherCharges;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	
}

