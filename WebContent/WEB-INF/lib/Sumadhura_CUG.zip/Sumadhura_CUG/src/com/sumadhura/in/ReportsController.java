package com.sumadhura.in;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.ibm.wsdl.util.StringUtils;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.userDetails;
import com.sumadhura.dto.PriceMasterDTO;
import com.sumadhura.service.ReportsService;
import com.sumadhura.transdao.IndentAvailabulityDao;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.util.CheckSessionValidation;
import com.sumadhura.util.CommonUtilities;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Controller
/**
 * 
 * @author Aniket Chavan
 * @since 5/31/2018 4:24
 * @category Generatring Reports
 *
 */
public class ReportsController {
	@Autowired
	private IndentAvailabulityDao dao;

	@Autowired
	private UtilDao utilDao;

	@Autowired
	@Qualifier("guiReportService")
	ReportsService reportsService;

	@Autowired
	CommonUtilities objCommonUtilities;

	/**
	 * @author Aniket Chavan
	 * @param request
	 * @since 04-may-2018
	 * @return
	 */
	@RequestMapping(value = "/productstock.spring", method = RequestMethod.GET)
	public @ResponseBody String getProductStockDetailAndPrice(HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		System.out.println("GUIReportsController.getProductStockDetailAndPrice()");
		String siteId = (String) CheckSessionValidation.validateUserSession(mav,
				session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));
		String productDetail = null;
		try {
			productDetail = reportsService.getProdcutsDetail(siteId);
			int PRETTY_PRINT_INDENT_FACTOR = 4;
			JSONObject xmlJSONObj = XML.toJSONObject(productDetail);
			productDetail = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
			System.out.println(productDetail);

		} catch (JSONException je) {
			System.out.println(je.toString());
		}

		System.out.println("ProductDetail Json " + productDetail);
		// productDetail =
		// "{\"xml\":{\"ProductList\":{\"Products\":{\"Assets\":\"1000\",\"BlockWork\":\"12000\",\"Plastering\":\"8000\"}},\"SubProductList\":{\"Products\":{\"Assets\":{\"BatchingPlant\":\"10000\",\"vibrator\":\"50000\"},\"BlockWork\":{\"Brick\":\"20000\",\"HelloWBrick\":\"60000\"},\"Plastering\":{\"cement\":\"20000\"}}},\"ChildProductList\":{\"Products\":{\"Assets\":{\"BatchingPlant\":\"10000\",\"vibrator\":\"50000\",\"Shoeshinemachine\":\"50000\"},\"BlockWork\":{\"Brick\":\"20000\",\"HelloWBrick\":\"60000\",\"FlyAshBlock\":\"60000\"},\"Plastering\":{\"cement\":\"20000\"}}}}}";

		return productDetail;
	}

	/**
	 * @author Aniket Chavan
	 * @param request
	 * @since 04-may-2018
	 * @return
	 */
	@RequestMapping(value = "/getSiteWiseCumulativeStock.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getSiteWiseCumulativeStock(HttpServletRequest request) {
		HttpSession session = request.getSession(true);
		ModelAndView mav = new ModelAndView();
		String userid = "0";
		try {
			userid = (String) CheckSessionValidation.validateUserSession(mav,
					session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));
			if (!userid.equals("0")) {
				List<Map<String, Object>> totalProductList = utilDao.getTotalProducts();

				List<Map<String, Object>> allSitesList = utilDao.getAllSites();
				request.setAttribute("SEARCHTYPE", "ADMIN");
				System.out.println("SearchType is admin");

				request.setAttribute("allSitesList", allSitesList);
				request.setAttribute("totalProductsList", totalProductList);
				mav.setViewName("reports/CumulativeStock");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails audit = new SaveAuditLogDetails();
		// String
		// indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id = String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0", user_id, "View Cumulative Stock Viewed", "success", site_id1);

		return mav;
	}

	@RequestMapping("/ViewCumulativeStockList.spring")
	public String getCumulativeStockDetails(HttpServletRequest request, HttpServletResponse response) throws Exception {

		System.out.println("central view controller");

		String strProduct = request.getParameter("combobox_Product") == null ? ""
				: request.getParameter("combobox_Product").toString();
		String strSubProduct = request.getParameter("combobox_SubProduct") == null ? ""
				: request.getParameter("combobox_SubProduct").toString();
		String strChildProduct = request.getParameter("combobox_ChildProduct") == null ? ""
				: request.getParameter("combobox_ChildProduct").toString();

		String userid = "0";
		String strProductId = "";
		String strSubProductId = "";
		String strChildProductId = "";
		String cumulativeStock = "";

		String fromDate = request.getParameter("fromDate");
		String toDate = request.getParameter("toDate");

		if (strProduct.contains("@@")) {

			String productArr[] = strProduct.split("@@");

			if (productArr != null && productArr.length >= 1) {
				strProductId = productArr[0].trim();
			}
		}

		if (strSubProduct.contains("@@")) {

			String productArr[] = strSubProduct.split("@@");

			if (productArr != null && productArr.length >= 1) {
				strSubProductId = productArr[0].trim();
			}
		}

		if (strChildProduct.contains("@@")) {

			String productArr[] = strChildProduct.split("@@");

			if (productArr != null && productArr.length >= 1) {
				strChildProductId = productArr[0].trim();
			}
		}
		String strSiteId = "";

		HttpSession session = request.getSession(true);
		// strSiteId = session.getAttribute("SiteId") == null ? "" :
		// session.getAttribute("SiteId").toString();
		String note = UIProperties.validateParams.getProperty("CUM_" + strSiteId);

		request.setAttribute("note", note);
		// String strAdminUserId = validateParams.getProperty("AdminId");
		strSiteId = request.getParameter("dropdown_SiteId") == null ? "" : request.getParameter("dropdown_SiteId");
		if (!strSiteId.equals("")) {
			request.setAttribute("SEARCHTYPE", "ADMIN");
		} else if (strSiteId.equals("")) {
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		}
		System.out.println("Indent Avaliable controller product id " + strProductId + "  sub product id child"
				+ strSubProductId + " child product id " + strChildProductId + " site id" + strSiteId);

		List<ProductDetails> productList = dao.getCumulativeProductList(strProductId, strSubProductId,
				strChildProductId, strSiteId, fromDate, toDate);
		request.setAttribute("fromDate", fromDate);
		request.setAttribute("toDate", toDate);
		request.setAttribute("strSiteId", strSiteId);

		if (productList.size() > 0) {

			request.setAttribute("productList", productList);
			cumulativeStock = "reports/CumulativeStockView";

		} else {

			request.setAttribute("message1", "No Stock Available With This Product");
			cumulativeStock = "response";
		}

		SaveAuditLogDetails audit = new SaveAuditLogDetails();
		// String
		// indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id = String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0", user_id, "View cumulative Stock clicked submit", "success", site_id1);

		return cumulativeStock;

	}

	@RequestMapping("/CumulativeStock.spring")
	public ModelAndView getCumulativeStock(HttpServletRequest request, userDetails userDts, HttpSession session) {

		ModelAndView mav = new ModelAndView();
		String userid = "0";
		try {
			userid = (String) CheckSessionValidation.validateUserSession(mav,
					session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));
			if (!userid.equals("0")) {
				List<Map<String, Object>> totalProductList = utilDao.getTotalProducts();

				// List<Map<String, Object>> allSitesList =
				// utilDao.getAllSites();

				// request.setAttribute("allSitesList", allSitesList);
				request.setAttribute("totalProductsList", totalProductList);
				mav.setViewName("reports/CumulativeStock");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails audit = new SaveAuditLogDetails();
		// String
		// indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id = String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0", user_id, "View Cumulative Stock Viewed", "success", site_id1);
		return mav;
	}

	@RequestMapping(value = "/priceMasterSiteWise.spring", method = RequestMethod.GET)
	public ModelAndView getPriceMasterSiteWise(HttpServletRequest request, HttpSession session) {
		System.out.println("ReportsController.getProductPriceListDetail()");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("reports/PriceMaster");
		try {
			request.setAttribute("SEARCHTYPE", "ADMIN");
			List<Map<String, Object>> allSitesList = utilDao.getAllSites();
			mav.addObject("allSitesList", allSitesList);
			String siteId = (String) CheckSessionValidation.validateUserSession(mav,
					session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));

			// List<Map<String, Object>> childProductList =
			// utilDao.loadAllChildProducts(null);
			// request.setAttribute("childProductList", childProductList);
			System.out.println("ReportsController.getProductPriceListDetail() executed");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mav;
	}

	/**
	 * @param request
	 * @param session
	 * @description this method will give you the last 3 months data
	 * @return
	 */
	@RequestMapping(value = "/ViewThreeMonthProductPrice.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getUpdatdProductPriceList(HttpServletRequest request, HttpSession session) {
		System.out.println("ReportsController.getProductPriceList()");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("reports/PriceMaster");

		String strSiteId = request.getParameter("dropdown_SiteId") == null ? ""
				: request.getParameter("dropdown_SiteId");
		String childProdName = request.getParameter("childProdName") == null ? ""
				: request.getParameter("childProdName");
		System.out.println("Child product id ViewThreeMonthProductPrice\t" + childProdName);

		request.setAttribute("SEARCHTYPE", "ADMIN");
		List<Map<String, Object>> allSitesList = utilDao.getAllSites();
		mav.addObject("allSitesList", allSitesList);
		if (!strSiteId.equals("")) {
			request.setAttribute("selectBoxOption", strSiteId);
		} else if (strSiteId.equals("")) {
			
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			
		}
		Set<PriceMasterDTO> childPriceListBySite = reportsService.getProductPriceListBySite(strSiteId, childProdName);
		request.setAttribute("tempSiteId", strSiteId);

		if (childPriceListBySite != null && childPriceListBySite.size() > 0) {
			request.setAttribute("showGrid", "true");
			request.setAttribute("ShowDataTable1", "false");
		} else {
			mav.addObject("succMessage", "The above  Data Not Available");
		}
		mav.addObject("childPriceListBySite", childPriceListBySite);
		// request.setAttribute("childPriceListBySite", childPriceListBySite);
		return mav;
	}

	@RequestMapping(value = "/loadAllSites.spring", method = RequestMethod.GET)
	public @ResponseBody String loadAllSites(HttpServletResponse response, HttpServletRequest request,
			HttpSession session) {
		System.out.println("ReportsController.loadAllSites()");
		List<Map<String, Object>> allSitesList = utilDao.getAllSites();
		Gson gson = new Gson();
		String allSites = gson.toJson(allSitesList);
		System.out.println(allSites);
		return allSites;
	}

	@RequestMapping(value = "/loadChildProductLatestPriceNames.spring", method = RequestMethod.GET)
	public @ResponseBody String loadChildProductLatestPrice(HttpServletResponse response, HttpServletRequest request,
			HttpSession session) {
		System.out.println("ReportsController.loadChildProductLatestPrice()");
		// response.setContentType("application/json");
		String resp = "";
		try {
			String prodName = request.getParameter("prodName");
			System.out.println(prodName);
			List<String> childProductList = reportsService.loadAllChildProducts(prodName);
			Gson gson = new Gson();
			resp = gson.toJson(childProductList);
			System.out.println(resp);
			return resp;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resp;
	}

	// getProductDetails
	@RequestMapping(value = "/getProductDetails.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getLastThreeMonthsPriceMasterDetail(HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView();

		System.out.println("ReportsController.getChildProductDetail()");
		String CHILD_PRODUCT_ID = request.getParameter("CHILD_PRODUCT_ID");
		String NAME = request.getParameter("NAME");
		String PRICE_ID = request.getParameter("PRICE_ID");
		String site_id = request.getParameter("SITE_ID");
		String childProductId = CHILD_PRODUCT_ID == null ? "" : CHILD_PRODUCT_ID.toString();
		String prodName = NAME == null ? "" : NAME.toString();
		String priceId = PRICE_ID == null ? "" : PRICE_ID.toString();
		System.out.println(childProductId);
		System.out.println(prodName);
		System.out.println(priceId);
		System.out.println("Site is " + site_id);
		List<Map<String, Object>> allSitesList = utilDao.getAllSites();

		request.setAttribute("allSitesList", allSitesList);
		try {
			Map<String, Collection<PriceMasterDTO>> lastThreeMonthsPriceMasterDetail = reportsService
					.getLastThreeMonthPriceMasterDetail(childProductId, prodName, priceId, site_id);
			System.out.println(lastThreeMonthsPriceMasterDetail.isEmpty());

			if (lastThreeMonthsPriceMasterDetail != null && lastThreeMonthsPriceMasterDetail.size() > 0) {
				request.setAttribute("showGrid", "true");
				List<PriceMasterDTO> firstMonthData = (List<PriceMasterDTO>) lastThreeMonthsPriceMasterDetail
						.get("firstMonth");
				List<PriceMasterDTO> secondMonthData = (List<PriceMasterDTO>) lastThreeMonthsPriceMasterDetail
						.get("secondMonth");
				List<PriceMasterDTO> thirdMonthData = (List<PriceMasterDTO>) lastThreeMonthsPriceMasterDetail
						.get("thirdMonth");
				int forRowSpan = 0;
				if (firstMonthData.size() == 0 && secondMonthData.size() == 0 && thirdMonthData.size() == 0) {
					System.out.println("the product detail is empty..");
					mav.setViewName("reports/viewPastMonthsChildProductPriceDetails");
					request.setAttribute("SEARCHTYPE", "ADMIN");

					mav.addObject("succMessage",
							"Selected child product data not available from the last three months.");
					request.setAttribute("showGrid", "false");
					return mav;
				}

				int firstMonthDataSize = firstMonthData.size();
				int secondMonthDataSize = secondMonthData.size();
				int thirdMonthDataSize = thirdMonthData.size();
				if (firstMonthDataSize >= secondMonthDataSize && firstMonthDataSize >= thirdMonthDataSize) {
					System.out.println("First number is largest. ");
					forRowSpan = firstMonthDataSize;
				} else if (secondMonthDataSize >= firstMonthDataSize && secondMonthDataSize >= thirdMonthDataSize) {
					System.out.println("Second number is largest.");
					forRowSpan = secondMonthDataSize;
				} else if (thirdMonthDataSize >= firstMonthDataSize && thirdMonthDataSize >= secondMonthDataSize) {
					System.out.println("Third number is largest.");
					forRowSpan = thirdMonthDataSize;
				} else
					System.out.println("Entered numbers are not distinct.");

				mav.addObject("firstMonth", firstMonthData);
				mav.addObject("secondMonth", secondMonthData);
				mav.addObject("thirdMonth", thirdMonthData);
				mav.addObject("rowSpanCol", forRowSpan);

				System.out.println(forRowSpan);
				System.out.println(firstMonthData);
				mav.addObject("childProductListDetailById", lastThreeMonthsPriceMasterDetail);
			}
		} catch (Exception e) {
			request.setAttribute("allSitesList", allSitesList);
			mav.setViewName("reports/PriceMaster");
			mav.addObject("succMessage", "Data Not Available for this product");
			e.printStackTrace();
		}
		mav.setViewName("reports/viewPastMonthsChildProductPriceDetails");
		System.out.println("ReportsController.getChildProductDetail() executed");
		return mav;
	}

	@RequestMapping(value = "/GuiReports.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public String GuiReports() {
		return "reports/BIReports";
	}

	
	/**
	 * @description this method id for getting the total requested amount location wise
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/purchaseReport.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String requestedAmountReports(HttpServletRequest request, HttpSession session) {
		System.out.println("ReportsController.requestedAmountReports()");
		String response = "";
		String tillDatePaymentReq = "7";
		String siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		if (siteId.equals("") || siteId == null) {
			response = "redirect:/index";
			return response;
		}
		try {
			String reportData = reportsService.getRequestedAmountReportBySite(siteId, tillDatePaymentReq);
			if (reportData != null)
				if (reportData.length() == 0 || reportData.isEmpty()) {
					response = "No requested amount present in this week.";
				}
			try {
				int PRETTY_PRINT_INDENT_FACTOR = 4;
				JSONObject xmlJSONObj = XML.toJSONObject(reportData);
				response = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
				
			} catch (JSONException je) {
				System.out.println(je.toString());
			}
			System.out.println("Requested Amount Data\t" + response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	public static void main(String[] args) {

		String s = "";
		System.out.println(s.length());
		System.exit(0);
		int PRETTY_PRINT_INDENT_FACTOR = 4;
		String productDetail = new Gson().toJson(
				"{\"xml\": { \"label\": [ { \"name\": \"10-11-2018\", \"Hyderabad\": \"30\", \"Banglore\": \"20\" }, { \"name\": \"11-11-2018\", \"Hyderabad\": \"40\", \"Banglore\": \"20\" },{ \"11-12-2018\": \"ww\", \"Hyderabad\": \"40\", \"Banglore\": \"20\" },{ \"11-12-2018\": \"ww\", \"Hyderabad\": \"40\", \"Banglore\": \"20\" },{ \"11-12-2018\": \"ww\", \"Hyderabad\": \"40\", \"Banglore\": \"20\" },{ \"11-12-2018\": \"ww\", \"Hyderabad\": \"40\", \"Banglore\": \"20\" } ]}}");

		System.out.println(productDetail);
		String xmlData = "<root><element><Country>United States</Country><CustomerId>1</CustomerId><Name>John Hammond</Name><Orders><element><Freight>32.38</Freight><OrderId>10248</OrderId><ShipCountry>France</ShipCountry></element><element><Freight>12.43</Freight><OrderId>10249</OrderId><ShipCountry>Japan</ShipCountry></element><element><Freight>66.35</Freight><OrderId>10250</OrderId><ShipCountry>Russia</ShipCountry></element></Orders></element>"
				+ "<element><Country>India</Country><CustomerId>2</CustomerId><Name>Mudassar Khan</Name><Orders><element><Freight>77.0</Freight><OrderId>10266</OrderId><ShipCountry>Argentina</ShipCountry></element><element><Freight>101.12</Freight><OrderId>10267</OrderId><ShipCountry>Australia</ShipCountry></element><element><Freight>11.61</Freight><OrderId>10268</OrderId><ShipCountry>Germany</ShipCountry></element></Orders></element></root>";
		try {
			JSONObject xmlJSONObj = XML.toJSONObject(xmlData);
			String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
			System.out.println(jsonPrettyPrintString);
		} catch (JSONException je) {
			System.out.println(je.toString());
		}

	}
}
