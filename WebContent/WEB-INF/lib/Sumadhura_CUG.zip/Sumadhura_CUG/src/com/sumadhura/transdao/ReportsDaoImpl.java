package com.sumadhura.transdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.sumadhura.dto.PriceMasterDTO;
import com.sumadhura.util.DBConnection;

/**
 * 
 * @author Aniket Chavan
 * @since 5/31/2018 4:24
 * @category Generatring Reports
 *
 */
@Repository("guireportdao")
public class ReportsDaoImpl implements ReportsDao {

	@Autowired(required = true)
	private JdbcTemplate jdbcTemplate;

	private static final String QUERY_FOR_PRODUCT_DETAIL = "select sum(ival.total_amount) as  sumOfPrice,pd.product_id,pd.name from SUMADHURA_PRICE_LIST ival left join product pd on ival.product_id=pd.product_id  group by pd.name,pd.product_id";
	private static final String QUERY_FOR_CHILD_PRODUCT_PRICE_LIST = "select ospl.CHILD_PRODUCT_ID,max(to_char(ospl.CREATED_DATE,'dd-MON-yy hh:MM:ss')), ROUND(TO_CHAR(AMOUNT_PER_UNIT_BEFORE_TAXES),2) as AMOUNT_PER_UNIT_BEFORE_TAXES, ROUND(TO_CHAR(AMOUNT_PER_UNIT_AFTER_TAXES),2) as AMOUNT_PER_UNIT_AFTER_TAXES ,BASIC_AMOUNT ,CP.NAME,mmt.name as MEASUREMENT_NAME,ospl.PRICE_ID from SUMADHURA_PRICE_LIST ospl ,CHILD_PRODUCT CP,MEASUREMENT mmt where ospl.CHILD_PRODUCT_ID=cp.CHILD_PRODUCT_ID and mmt.MEASUREMENT_ID=ospl.UNITS_OF_MEASUREMENT and ospl.site_id=? and ospl.CREATED_DATE = (select max(CREATED_DATE) from SUMADHURA_PRICE_LIST ispl where ispl.CHILD_PRODUCT_ID = ospl.CHILD_PRODUCT_ID and ispl.site_id= ?) group by ospl.CHILD_PRODUCT_ID,ospl.CREATED_DATE,AMOUNT_PER_UNIT_BEFORE_TAXES,BASIC_AMOUNT,CP.NAME,mmt.name, AMOUNT_PER_UNIT_AFTER_TAXES,ospl.PRICE_ID ORDER BY OSPL.CHILD_PRODUCT_ID,OSPL.CREATED_DATE,OSPL.PRICE_ID DESC";
	private static final String QUERY_FOR_CHILD_PRODUCT_PRICE_BY_ID = "select SPL.price_id,cp.CHILD_PRODUCT_ID,(cp.NAME),mmt.name as MEASUREMENT_NAME,ROUND(TO_CHAR(SPL.AMOUNT_PER_UNIT_BEFORE_TAXES),2)as  AMOUNT_PER_UNIT_BEFORE_TAXES ,  ROUND(TO_CHAR(SPL.AMOUNT_PER_UNIT_AFTER_TAXES),2) as AMOUNT_PER_UNIT_AFTER_TAXES,SPL.AVAILABLE_QUANTITY, NVL(ROUND(TO_CHAR(SPL.BASIC_AMOUNT),2), '0.0') as BASIC_AMOUNT,        NVL(ROUND(TO_CHAR(SPL.TOTAL_AMOUNT),2), '0.0') as TOTAL_AMOUNT,NVL(SPL.AMOUNT_AFTER_TAX, SPL.BASIC_AMOUNT) as AMOUNT_AFTER_TAX,to_char(SPL.created_date,'MONyy') as createdDate,SPL.site_id         from  CHILD_PRODUCT cp,SUMADHURA_PRICE_LIST SPL,MEASUREMENT mmt     where  SPL.CHILD_PRODUCT_ID=cp.CHILD_PRODUCT_ID and mmt.MEASUREMENT_ID=SPL.UNITS_OF_MEASUREMENT  AND SPL.CHILD_PRODUCT_ID=?     and SPL.site_id=? and SPL.created_date between to_char(trunc(add_months(sysdate,-2)) - (to_number(to_char(sysdate,'DD')) -1),'dd-MON-yy') and sysdate order by SPL.child_product_id ,SPL.created_date";

	/**
	 * @author Aniket Chavan
	 * @description here we will get all quantity based on product name
	 */

	@Override
	public String getAllProductsDetail(final String siteId) {
		System.out.println("GUIReportsDaoImpl.getAllProductsDetail()");
		String queryForProductPriceDetails = "select pd.product_id,pd.name,sum(ROUND(NVL(spl.AMOUNT_AFTER_TAX,0),2)) as  sumOfPrice from SUMADHURA_PRICE_LIST spl  join product pd on spl.product_id=pd.product_id and spl.site_id=? and spl.status='A'  group by pd.name,pd.product_id order by pd.product_id ";
		final String queryForSubProductPriceDetails = "select spd.SUB_PRODUCT_ID,spd.name,sum(ROUND(NVL(spl.AMOUNT_AFTER_TAX,0),2)) as  sumOfPrice from SUMADHURA_PRICE_LIST spl  join SUB_PRODUCT spd on spl.SUB_PRODUCT_ID=spd.SUB_PRODUCT_ID and spl.status='A' and spl.product_id=? and spl.site_id=?  group by spd.SUB_PRODUCT_ID,spd.name order by spd.SUB_PRODUCT_ID desc";
		final String queryForChildProductPriceDetails = "select cpd.CHILD_PRODUCT_ID, cpd.SUB_PRODUCT_ID,cpd.name,sum(ROUND(NVL(spl.AMOUNT_AFTER_TAX,0),2)) as  sumOfPrice from SUMADHURA_PRICE_LIST spl  join CHILD_PRODUCT cpd on spl.CHILD_PRODUCT_ID=cpd.CHILD_PRODUCT_ID and spl.status='A' and spl.product_id=? and spl.site_id=?  group by cpd.SUB_PRODUCT_ID,cpd.CHILD_PRODUCT_ID,cpd.name order by cpd.SUB_PRODUCT_ID desc";
		Object[] obj = { siteId };

		final StringBuffer xmlData = new StringBuffer();

		final StringBuffer bufferChildProd = new StringBuffer();
		final StringBuffer bufferSubProd = new StringBuffer();

		List<PriceMasterDTO> productList = jdbcTemplate.query(queryForProductPriceDetails, obj,
				new ResultSetExtractor<List<PriceMasterDTO>>() {
			List<PriceMasterDTO> mainProdList = new ArrayList<PriceMasterDTO>();
			StringBuffer bufferMainProd = new StringBuffer();

			@Override
			public List<PriceMasterDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
				xmlData.append("<xml>");
				bufferMainProd.append("<ProductList>");
				bufferMainProd.append("<Products>");

						while (rs.next()) {
							String product_id = rs.getString("product_id");
							String product_name = rs.getString("name");
							String productPrice = rs.getString("sumOfPrice");
							PriceMasterDTO mainProductList = new PriceMasterDTO();
							String replacedname = product_name.trim().replace(" ", "_");
							mainProductList.setChild_product_id(product_id);
							mainProductList.setChild_product_name(replacedname);
							mainProductList.setAmount_after_tax(productPrice);
							if (Integer.valueOf((int) Math.round(Double.valueOf(productPrice))) > 0) {
								bufferMainProd
										.append("<" + replacedname + ">" + productPrice + "</" + replacedname + ">");
							}

							// one List and return it
							mainProdList.add(mainProductList);
						} // while loop
						bufferMainProd.append("</Products>");
						bufferMainProd.append("</ProductList>");
						xmlData.append(bufferMainProd);
						return mainProdList;

			}
		});

		bufferChildProd.append("<ChildProductList>");
		bufferChildProd.append("<Products>");
		bufferSubProd.append("<SubProductList>");
		bufferSubProd.append("<Products>");

		for (PriceMasterDTO priceMasterDTO : productList) {
			String product_id = priceMasterDTO.getChild_product_id();
			final String product_name = priceMasterDTO.getChild_product_name();
			Object[] obData = { product_id, siteId };
			jdbcTemplate.query(queryForSubProductPriceDetails, obData, new ResultSetExtractor<List<PriceMasterDTO>>() {

				@Override
				public List<PriceMasterDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
					bufferSubProd.append("<" + product_name + ">");
					while (rs.next()) {
						String sub_product_id = rs.getString("SUB_PRODUCT_ID");
						String product_name = rs.getString("name");
						String productPrice = rs.getString("sumOfPrice");
						PriceMasterDTO dto = new PriceMasterDTO();

						String replacedProductName = product_name.trim().replace(":", "_").replace("%", "_")
								.replace("&", "_").replace("+", "_").replace("=", "_").replace("'", "_")
								.replace(",", "_").replace(".", "_").replace("\"", "_").replace(" ", "_")
								.replace("/", "").replace("(", "_").replace(")", "_");
						dto.setChild_product_id(sub_product_id);
						dto.setChild_product_name(product_name);
						dto.setAmount_after_tax(productPrice);
						if (Integer.valueOf((int) Math.round(Double.valueOf(productPrice))) > 0) {
							bufferSubProd.append(
									"<" + replacedProductName + ">" + productPrice + "</" + replacedProductName + ">");
						}
					}
					bufferSubProd.append("</" + product_name + ">");

					// xmlData.append(bufferSubProd);
					return null;
				}
			});// Sub Products fetching code

			jdbcTemplate.query(queryForChildProductPriceDetails, obData,
					new ResultSetExtractor<List<PriceMasterDTO>>() {
						public boolean isLeadingDigit(final String value) {
							final char c = value.charAt(0);
							return (c >= '0' && c <= '9');
						}

						@Override
						public List<PriceMasterDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
							bufferChildProd.append("<" + product_name + ">");
							while (rs.next()) {
								String child_product_id = rs.getString("CHILD_PRODUCT_ID");
								String product_name = rs.getString("name");
								if (isLeadingDigit(product_name)) {
									product_name = "_" + product_name;
								}

								String replacedProductName = product_name.trim().replace(":", "_").replace("%", "_")
										.replace("&", "_").replace("+", "_").replace("=", "_").replace("'", "_")
										.replace(",", "_").replace(".", "_").replace("\"", "_").replace(" ", "_")
										.replace("/", "").replace("(", "_").replace(")", "_");
								String productPrice = rs.getString("sumOfPrice");
								PriceMasterDTO dto = new PriceMasterDTO();
								dto.setChild_product_id(child_product_id);
								dto.setChild_product_name(product_name);
								dto.setAmount_after_tax(productPrice);
								if (Integer.valueOf((int) Math.round(Double.valueOf(productPrice))) > 0) {

									bufferChildProd.append(" <" + replacedProductName + ">" + productPrice + " </"
											+ replacedProductName + ">");
								}
							}
							bufferChildProd.append("</" + product_name + ">");
							return null;
						}
					});// Child product fetching code
		}
		bufferChildProd.append("</Products>");
		bufferChildProd.append("</ChildProductList>");
		bufferSubProd.append("</Products>");
		bufferSubProd.append("</SubProductList>");
		xmlData.append(bufferSubProd);
		xmlData.append(bufferChildProd);

		xmlData.append("</xml>");

		return xmlData.toString();
	}

	class ClassForProductPriceList implements ResultSetExtractor<Set<PriceMasterDTO>> {

		@Override
		public Set<PriceMasterDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
			Set<PriceMasterDTO> latestChildProdPriceData = new HashSet<PriceMasterDTO>();

			while (rs.next()) {
				String price_id = rs.getString("PRICE_ID");
				String child_product_id = rs.getString("CHILD_PRODUCT_ID");
				String name = rs.getString("NAME");
				String amount_per_unit_before_taxes = rs.getString("AMOUNT_PER_UNIT_BEFORE_TAXES");
				String amount_per_unit_after_taxes = rs.getString("AMOUNT_PER_UNIT_AFTER_TAXES");
				String measurement_name = rs.getString("MEASUREMENT_NAME");
				latestChildProdPriceData.add(new PriceMasterDTO(price_id == null ? "" : price_id.toString(),
						child_product_id == null ? "" : child_product_id.toString(),
						name == null ? "" : name.toString(),
						measurement_name == null ? "" : measurement_name.toString(),
						amount_per_unit_before_taxes == null ? "" : amount_per_unit_before_taxes.toString(),
						amount_per_unit_after_taxes == null ? "" : amount_per_unit_after_taxes.toString(), null, null,
						null, null, null, null, null));
			}

			return latestChildProdPriceData;
		}

	}

	@Override
	public Set<PriceMasterDTO> getProductPriceListBySite(String siteId, String childProdName) {
		System.out.println("ReportsDaoImpl.getProductPriceListBySite( ) " + siteId);
		
		Set<PriceMasterDTO> latestChildProdPriceData = null;
		try {
			if (!(childProdName.length() == 0)) {
				System.out.println(childProdName+" IN DAO");
		/*	String	childProdID=jdbcTemplate.queryForObject("SELECT CHILD_PRODUCT_ID FROM CHILD_PRODUCT WHERE  STATUS = 'A' and lower(NAME) like lower('"+childProdName.trim()+"%') ", String.class);
				System.out.println("Got Child Prod Id "+childProdName);
		*/		Object[] objData = { siteId,siteId};
				latestChildProdPriceData = jdbcTemplate.query("select ospl.CHILD_PRODUCT_ID,max(to_char(ospl.CREATED_DATE,'dd-MON-yy hh:MM:ss')), ROUND(TO_CHAR(AMOUNT_PER_UNIT_BEFORE_TAXES),2) as AMOUNT_PER_UNIT_BEFORE_TAXES, ROUND(TO_CHAR(AMOUNT_PER_UNIT_AFTER_TAXES),2) as AMOUNT_PER_UNIT_AFTER_TAXES ,BASIC_AMOUNT ,CP.NAME,mmt.name as MEASUREMENT_NAME,ospl.PRICE_ID from SUMADHURA_PRICE_LIST ospl ,CHILD_PRODUCT CP,MEASUREMENT mmt where ospl.CHILD_PRODUCT_ID=cp.CHILD_PRODUCT_ID and mmt.MEASUREMENT_ID=ospl.UNITS_OF_MEASUREMENT and ospl.site_id=?   and lower(CP.NAME)=lower('"+childProdName+"')  and ospl.CREATED_DATE = (select max(CREATED_DATE) from SUMADHURA_PRICE_LIST ispl where ispl.CHILD_PRODUCT_ID = ospl.CHILD_PRODUCT_ID and ispl.site_id=?) group by ospl.CHILD_PRODUCT_ID,ospl.CREATED_DATE,AMOUNT_PER_UNIT_BEFORE_TAXES,BASIC_AMOUNT,CP.NAME,mmt.name,  AMOUNT_PER_UNIT_AFTER_TAXES,ospl.PRICE_ID ORDER BY OSPL.CHILD_PRODUCT_ID,OSPL.CREATED_DATE,OSPL.PRICE_ID DESC", objData, new ClassForProductPriceList());
			} else {
				Object[] objData1 = { siteId,siteId };
				latestChildProdPriceData = jdbcTemplate.query(QUERY_FOR_CHILD_PRODUCT_PRICE_LIST, objData1,
						new ClassForProductPriceList());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return latestChildProdPriceData;
	}

	// this class for extracting data from resultset
	static class LastThreeMonthsDataExtractor implements ResultSetExtractor<Set<PriceMasterDTO>> {
		static {
			System.out.println("ReportsDaoImpl.LastThreeMonthsDataExtractor.LastThreeMonthsDataExtractor()");
		}

		public LastThreeMonthsDataExtractor() {
			System.out.println("ReportsDaoImpl.LastThreeMonthsDataExtractor.LastThreeMonthsDataExtractor()");
		}

		@Override
		public Set<PriceMasterDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
			Set<PriceMasterDTO> threeMonthsData = new HashSet<PriceMasterDTO>();
			String price_id, child_product_id, name, measurement_name, amount_per_unit_before_taxes,
			amount_per_unit_after_taxes, available_quantity, basic_amount, total_amount, amount_after_tax,
			createddate, site_id;
			while (rs.next()) {

				price_id = rs.getString("PRICE_ID");
				child_product_id = rs.getString("CHILD_PRODUCT_ID");
				name = rs.getString("NAME");
				measurement_name = rs.getString("MEASUREMENT_NAME");
				amount_per_unit_before_taxes = rs.getString("AMOUNT_PER_UNIT_BEFORE_TAXES");
				amount_per_unit_after_taxes = rs.getString("AMOUNT_PER_UNIT_AFTER_TAXES");
				available_quantity = rs.getString("AVAILABLE_QUANTITY");
				basic_amount = rs.getString("BASIC_AMOUNT");
				total_amount = rs.getString("TOTAL_AMOUNT");
				amount_after_tax = rs.getString("AMOUNT_AFTER_TAX");
				createddate = rs.getString("createdDate");
				site_id = rs.getString("SITE_ID");
				threeMonthsData.add(new PriceMasterDTO(price_id == null ? "" : price_id.toString(),
						child_product_id == null ? "" : child_product_id.toString(),
								name == null ? "" : name.toString(),
										measurement_name == null ? "" : measurement_name.toString(),
												amount_per_unit_before_taxes == null ? "" : amount_per_unit_before_taxes.toString(),
														amount_per_unit_after_taxes == null ? "" : amount_per_unit_after_taxes.toString(),
																available_quantity == null ? "" : available_quantity.toString(),
																		basic_amount == null ? "" : basic_amount.toString(),
																				total_amount == null ? "" : total_amount.toString(),
																						amount_after_tax == null ? "" : amount_after_tax.toString(),
																								createddate == null ? "" : createddate.toString(), site_id == null ? "" : site_id.toString(),
																										null));
			}

			return threeMonthsData;
		}
	}

	@Override
	public Set<PriceMasterDTO> getLastThreeMonthPriceMasterDetail(String childProductId, String prodName,
			String priceId, String site_id) {
		System.out.println("ReportsDaoImpl.getChildProductDetailById() " + site_id + "\t" + childProductId);

		Object[] obj = { childProductId, site_id };

		Set<PriceMasterDTO> lastThreeMonthsData = null;
		if (prodName != null) {
			lastThreeMonthsData = jdbcTemplate.query(QUERY_FOR_CHILD_PRODUCT_PRICE_BY_ID, obj,
					new LastThreeMonthsDataExtractor());
		} else {
			System.out.println(prodName);
			lastThreeMonthsData = jdbcTemplate.query(
					"select SPL.price_id,cp.CHILD_PRODUCT_ID,(cp.NAME),mmt.name as MEASUREMENT_NAME,ROUND(TO_CHAR(SPL.AMOUNT_PER_UNIT_BEFORE_TAXES),2)as  AMOUNT_PER_UNIT_BEFORE_TAXES ,  ROUND(TO_CHAR(SPL.AMOUNT_PER_UNIT_AFTER_TAXES),2) as AMOUNT_PER_UNIT_AFTER_TAXES,SPL.AVAILABLE_QUANTITY, NVL(ROUND(TO_CHAR(SPL.BASIC_AMOUNT),2), '0.0') as BASIC_AMOUNT,        NVL(ROUND(TO_CHAR(SPL.TOTAL_AMOUNT),2), '0.0') as TOTAL_AMOUNT,NVL(SPL.AMOUNT_AFTER_TAX, SPL.BASIC_AMOUNT) as AMOUNT_AFTER_TAX,to_char(SPL.created_date,'MONyy') as createdDate,SPL.site_id         from  CHILD_PRODUCT cp,SUMADHURA_PRICE_LIST SPL,MEASUREMENT mmt     where  SPL.CHILD_PRODUCT_ID=cp.CHILD_PRODUCT_ID and mmt.MEASUREMENT_ID=SPL.UNITS_OF_MEASUREMENT "
					+ "AND SPL.CHILD_PRODUCT_ID=?     and SPL.site_id=? and SPL.created_date between to_char(trunc(add_months(sysdate,-5)) - (to_number(to_char(sysdate,'DD')) -1),'dd-MON-yy') and to_char(trunc(add_months(sysdate,-2)) - (to_number(to_char(sysdate,'DD')) -1),'dd-MON-yy')  order by SPL.child_product_id ,SPL.created_date",
					obj, new LastThreeMonthsDataExtractor());
		}

		System.out.println("Size is : and " + lastThreeMonthsData.size());
		return lastThreeMonthsData;
	}

	@Override
	public String getRequestedAmountReportBySite(String siteId, String tillDatePaymentReq) {
		String queryForRequestedAmountReport = "SELECT SUM(ATPT.REQ_AMOUNT) TOTAL_REQUESTED_AMT,to_char(ATPT.PAYMENT_REQ_DATE,'DD-mm-yy') AS REQUESTED_DATE,S.ADDRESS from ACC_TEMP_PAYMENT_TRANSACTIONS ATPT,ACC_PAYMENT_DTLS ACD,ACC_PAYMENT AC,SITE S where ATPT.PAYMENT_DETAILS_ID=ACD.PAYMENT_DETAILS_ID AND AC.PAYMENT_ID=ACD.PAYMENT_ID AND S.SITE_ID=AC.SITE_ID  "
				+ "AND  ATPT.PAYMENT_REQ_DATE BETWEEN ATPT.PAYMENT_REQ_DATE  and SYSDATE+" + 5
				+ " group by ATPT.PAYMENT_REQ_DATE, to_char(ATPT.PAYMENT_REQ_DATE,'DD-mm-yy'), S.ADDRESS order by ATPT.PAYMENT_REQ_DATE";

		String queryForLocation = "SELECT MAX(S.SITE_ID),S.ADDRESS FROM SITE S,ACC_PAYMENT AC WHERE AC.SITE_ID=S.SITE_ID GROUP BY S.ADDRESS";

		final StringBuffer xmlreqAMTRpt = new StringBuffer();
		
		xmlreqAMTRpt.append("<xml>");
	
		List<Map<String, Object>> locations = jdbcTemplate.queryForList(queryForLocation);

		List<Map<String, Object>> paymentRequestData = jdbcTemplate.queryForList(queryForRequestedAmountReport);
		//
		for (int i = 0; i < paymentRequestData.size(); i++) {
			List<String> locationNames = new ArrayList<String>();
		
			xmlreqAMTRpt.append("<label>");
			Map<String, Object> firstRecord = paymentRequestData.get(i);
			String requested_date = String.valueOf(firstRecord.get("REQUESTED_DATE"));
			String location_name = String.valueOf(firstRecord.get("ADDRESS"));
			locationNames.add(location_name);
			String total_requested_amt = String.valueOf(firstRecord.get("TOTAL_REQUESTED_AMT"));
			
			xmlreqAMTRpt.append("<name>" + requested_date.toString() + "</name>");
			xmlreqAMTRpt.append("<" + location_name + ">" + total_requested_amt + "</" + location_name + ">");
			for (int j = i + 1; j < paymentRequestData.size(); j++) {
				Map<String, Object> secondRecord = paymentRequestData.get(j);
				String next_requested_date = String.valueOf(secondRecord.get("REQUESTED_DATE"));
				// this if condition is for if the current date and next date is
				// same or not if same add in same object 
				if (requested_date.equals(next_requested_date)) {
					String next_total_requested_amt = String.valueOf(secondRecord.get("TOTAL_REQUESTED_AMT"));
					String next_location_name = String.valueOf(secondRecord.get("ADDRESS"));
					locationNames.add(next_location_name);
					xmlreqAMTRpt.append("<" + next_location_name + ">" + next_total_requested_amt + "</"
							+ next_location_name + ">");
					i++;
				} else {
					break;
				}
			}
			// this for loop is for if the current location and location if
			// added don't add it again and which is not added add it in same
			// object but with value 0.0
			for (Map<String, Object> map : locations) {
				String site_address = String.valueOf(map.get("ADDRESS"));
				if(!locationNames.contains(site_address)){
					xmlreqAMTRpt.append("<" + site_address + ">0.0</"+ site_address + ">");
				}
			}
			xmlreqAMTRpt.append("</label>");
		} // For Loop
	
		xmlreqAMTRpt.append("</xml>");
		System.out.println(xmlreqAMTRpt);

		return xmlreqAMTRpt.toString();
	}

	@Override
	public List<String> loadAllChildProducts(String prodName) {
		System.out.println(prodName+"in DAO");
		String childProdQuery = "SELECT NAME FROM CHILD_PRODUCT WHERE  STATUS = 'A' and lower(NAME) like lower('"+prodName+"%') and rownum <10 ORDER BY NAME ASC";
		
		List<String> childProdData = jdbcTemplate.query(childProdQuery, new ResultSetExtractor<List<String>>() {

			@Override
			public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<String> list = new ArrayList<String>();
				while (rs.next()) {
					list.add(rs.getString(1));
				}
				return list;
			}
		});
		return childProdData;
	}
}
