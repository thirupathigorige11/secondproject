package com.sumadhura.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.dto.IndentCreationDto;

public interface PurchaseDepartmentIndentrocessService {



	public List<IndentCreationBean> getAllPurchaseIndents();

	public List<Map<String,Object>> getAllProducts();





	public List<IndentCreationBean> getIndentCreationDetailsLists(int indentNumber);





	public void printIndent(Model model, HttpServletRequest request, int site_id, String user_id);

	public List<ProductDetails> createPO(Model model, HttpServletRequest request,HttpSession session);

	public List<Map<String, Object>> sendenquiry(Model model, HttpServletRequest request, int site_id, String user_id,String siteId);


	public  List<Map<String, Object>> sendenquiry2(Model model, HttpServletRequest request, int site_id, String user_id,String siteName);


	public String SavePoDetails(Model model, HttpServletRequest request,HttpSession session,String strFinacialYear);

	public List<ProductDetails> loadCreatePOPage(Model model, HttpServletRequest request);

	public List<ProductDetails> getIndentsProductWise(String product, String subProduct, String childProduct);

	public List<IndentCreationDto> getPendingIndents(String user_id, String site_id);

	public String SaveEnquiryForm(Model model, HttpServletRequest request, HttpSession session);

	public boolean getVendorPasswordInDB(String uname,int indentNumber, String pass);

	public List<Map<String, Object>> getComparisionDtls(HttpServletRequest request,HttpSession session);
	public List<IndentCreationBean> getAllSitePurchaseIndents(String site);

	public List<ProductDetails> getTermsAndConditions(String site_id);
	public List<IndentCreationBean> ViewPoPendingforApproval(String fromDate, String toDate, String siteId,String tempPoNumber);
	public String getDetailsforPoApproval(String poNumber, String siteId,HttpServletRequest request);
	public String SavePoApproveDetails(String poNumber, String siteId,String userId,HttpServletRequest request,String isCancelTempPo);
	public String RejectPoDetails(HttpSession session,HttpServletRequest request);
	public List<ProductDetails> getQuatationProductDetails(HttpServletRequest request,HttpSession session);
	public List<ProductDetails> getQuatationDetails(HttpServletRequest request);

	public String closeIndent(Model model, HttpServletRequest request, int site_id, String user_id,
			String siteId);

	public List<ProductDetails> getProductDetailsLists(String indentNo, String vendorName,HttpServletRequest request,String CheckVal); //check val : tempPO(cancel) or not (it is using in create PO and CancelPo

	public String getSiteIdByPONumber(String poNumber);
	public List<IndentCreationBean> ViewTempPo(String fromDate, String toDate,String tempPoNumber);

	public List<ProductDetails> combinedDetailsChildProductWise(List<ProductDetails> indentDetails);

	public List<Map<String, Object>> getListOfActivePOs();

	public String editAndSaveUpdatePO(Model model, HttpServletRequest request, HttpSession session);
	public List<ProductDetails> getProductDetailsListsForQuatation(String indentNo, String vendorName,HttpServletRequest request);

	public String getDefaultCCEmails(String site_id);

	public int getSiteWiseIndentNo(int indentNumber);
	public void printIndentForPurchase(Model model, HttpServletRequest request, int site_id, String user_id);
	public String CancelPo(HttpSession session,HttpServletRequest request,String temp_Po_Number,String user_id,String siteId);
	public List<ProductDetails> getListOfCancelPo(String userId);
	public List<ProductDetails> getViewCancelPoDetails(String poNumber, String reqSiteId);
	public List<ProductDetails> getProductDetailsListsForCancelPo(String poNumber,String reqSiteId);
	public List<ProductDetails> getTransChrgsDtlsForCancelPo(String poNumber,String reqSiteId);
	public String updateTempPoPage(Model model, HttpServletRequest request,HttpSession session);
	public String tempPoSubProducts(String prodId,String indentNumber,String reqSiteId);
	public String tempPoChildProducts(String subProdId,String indentNumber,String reqSiteId);
	public List<String> getTempTermsAndConditions(String poNumber,String isRevised,String siteId);
	public String  getCancelPoComments(String poNumber);
	public String getTempPOSubject(String poNumber);
	public String getTempPoCCEmails(String poNumber);
	public String getNoOfRowsForUpdatePO(Model model, HttpServletRequest request,HttpSession session);
	public int insertSiteLevelIndentData(int site_Id,String user_Id,int indent_Number,String siteWiseIndent);
	
	//public Map<String, String> TempPoloadProds();

}
