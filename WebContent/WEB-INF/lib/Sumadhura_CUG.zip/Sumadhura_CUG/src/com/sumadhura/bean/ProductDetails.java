package com.sumadhura.bean;

public class ProductDetails {

	private String productId;
	private String productName;
	private String sub_ProductId;
	private String sub_ProductName;
	private String child_ProductId;
	private String child_ProductName;
	private String measurementName;
	private String measurementId;
	private String site_Id;
	private String quantity;
	private String amount;
	private String PricePerUnit;
	private String basicAmt;
	private String recivedQty;
	private String issuedQty;
	private String siteName;
	private String strSerialNumber;
	private String strIndentId;
	private String strProjectName;
	private String vendorName;
	private String vendorId;
	private String strGSTINNumber;
	private int serialno;
	private String price;
	private String vendorAddress;
	private String poIntiatedQuantity;
	private String requiredQuantity;
	private String vendormentionquan;
	private String othercharges1;
	private String otherchargesaftertax1;
	private String taxonothertranportcharge1;
	private String hsnCode;
	private String pricePerUnitBeforeTax;
	private String tax;
	private String taxAmount;
	private String amountAfterTax;
	private String totalAmount;
	private String strPONumber;
	private String userId;
	private String poNumber;
	private int poEntrySeqNumber;
	private int poEntryId;
	private int PoNumber1;
	private String dcNumber;
	private String invoiceNumber;
	private String siteWiseIndentNo;
	private String purchasedeptRequestReceiveQuantity;
	private String versionNo;
	private String refferenceNo;
	private String strPoPrintRefdate;
	
	
	
	
	

	private String purchaseDeptIndentProcessSeqId;
	
	private String strDiscount;
	private String strAmtAfterDiscount;
	private String IndentNo;
	
	private String pendingQuantity;
	private String requestQantity;;
	private String lastissuedDate;
	private String finalamtdiv;
	private Double OtherOrTransportCharges1;
	private Double TaxOnOtherOrTransportCharges1;
	private Double OtherOrTransportChargesAfterTax1;
	private Double TotalAmount1;
	private Double OtherCharges;
	private String ConveyanceId1;
	private String Conveyance1;
	private String ConveyanceAmount1;
	private String GSTTaxId1;
	private String GSTTax1;
	private String GSTAmount1;
	private String AmountAfterTaxx1;
	private String TransportInvoice1;
	
	private String strTermsConditionId;
	private String strTermsConditionName;
	private int intSerialNumber;
	
	private String childProductCustDisc;
	private String indentCreationDetailsId;
	private String poDate;
	


	private String enquiryFormDetailsId;
	private String subject;
	private String billingAddress;
	private String taxId;
	private String productBatchData;
	private String poEntryDetailsId;
	private String poTransChrgsDtlsSeqNo;
	private double actualQuantity;
	private double issuedQuantity;
	private double currentQuantity;
	private String outIssue;
	private String ccEmail;
	private int revision_Number;
	private String edit_Po_Number;
	private String strCreateDate;
	private String preparedBy;
	private String type_Of_purchase;
	
	
	

	public String getType_Of_purchase() {
		return type_Of_purchase;
	}

	public void setType_Of_purchase(String type_Of_purchase) {
		this.type_Of_purchase = type_Of_purchase;
	}

	public String getPreparedBy() {
		return preparedBy;
	}

	public void setPreparedBy(String preparedBy) {
		this.preparedBy = preparedBy;
	}

	public String getStrCreateDate() {
		return strCreateDate;
	}

	public void setStrCreateDate(String strCreateDate) {
		this.strCreateDate = strCreateDate;
	}

	public int getRevision_Number() {
		return revision_Number;
	}

	public void setRevision_Number(int revision_Number) {
		this.revision_Number = revision_Number;
	}

	public String getEdit_Po_Number() {
		return edit_Po_Number;
	}

	public void setEdit_Po_Number(String edit_Po_Number) {
		this.edit_Po_Number = edit_Po_Number;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getRefferenceNo() {
		return refferenceNo;
	}

	public void setRefferenceNo(String refferenceNo) {
		this.refferenceNo = refferenceNo;
	}

	public String getStrPoPrintRefdate() {
		return strPoPrintRefdate;
	}

	public void setStrPoPrintRefdate(String strPoPrintRefdate) {
		this.strPoPrintRefdate = strPoPrintRefdate;
	}

	public String getPurchasedeptRequestReceiveQuantity() {
		return purchasedeptRequestReceiveQuantity;
	}

	public void setPurchasedeptRequestReceiveQuantity(
			String purchasedeptRequestReceiveQuantity) {
		this.purchasedeptRequestReceiveQuantity = purchasedeptRequestReceiveQuantity;
	}

	public String getSiteWiseIndentNo() {
		return siteWiseIndentNo;
	}

	public void setSiteWiseIndentNo(String siteWiseIndentNo) {
		this.siteWiseIndentNo = siteWiseIndentNo;
	}

	public String getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(String dcNumber) {
		this.dcNumber = dcNumber;
	}

	

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public int getPoNumber1() {
		return PoNumber1;
	}

	public void setPoNumber1(int poNumber1) {
		PoNumber1 = poNumber1;
	}

	public int getPoEntryId() {
		return poEntryId;
	}

	public void setPoEntryId(int poEntryId) {
		this.poEntryId = poEntryId;
	}
	
		public String getCcEmail() {
		return ccEmail;
	}

	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}

		public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}
	
	
		public String getOutIssue() {
		return outIssue;
	}

	public void setOutIssue(String outIssue) {
		this.outIssue = outIssue;
	}

		public double getActualQuantity() {
		return actualQuantity;
	}

	public void setActualQuantity(double actualQuantity) {
		this.actualQuantity = actualQuantity;
	}

	public double getIssuedQuantity() {
		return issuedQuantity;
	}

	public void setIssuedQuantity(double issuedQuantity) {
		this.issuedQuantity = issuedQuantity;
	}

	public double getCurrentQuantity() {
		return currentQuantity;
	}

	public void setCurrentQuantity(double currentQuantity) {
		this.currentQuantity = currentQuantity;
	}

	
	
	
	
	public String getPoTransChrgsDtlsSeqNo() {
		return poTransChrgsDtlsSeqNo;
	}

	public void setPoTransChrgsDtlsSeqNo(String poTransChrgsDtlsSeqNo) {
		this.poTransChrgsDtlsSeqNo = poTransChrgsDtlsSeqNo;
	}

	public String getPoEntryDetailsId() {
		return poEntryDetailsId;
	}

	public void setPoEntryDetailsId(String poEntryDetailsId) {
		this.poEntryDetailsId = poEntryDetailsId;
	}

	public String getGSTTaxId1() {
		return GSTTaxId1;
	}

	public void setGSTTaxId1(String gSTTaxId1) {
		GSTTaxId1 = gSTTaxId1;
	}

	public String getConveyanceId1() {
		return ConveyanceId1;
	}

	public void setConveyanceId1(String conveyanceId1) {
		ConveyanceId1 = conveyanceId1;
	}

	public String getProductBatchData() {
		return productBatchData;
	}

	public void setProductBatchData(String productBatchData) {
		this.productBatchData = productBatchData;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public int getSerialno() {
		return serialno;
	}

	public void setSerialno(int serialno) {
		this.serialno = serialno;
	}

	public String getOthercharges1() {
		return othercharges1;
	}

	public void setOthercharges1(String othercharges1) {
		this.othercharges1 = othercharges1;
	}

	public String getOtherchargesaftertax1() {
		return otherchargesaftertax1;
	}

	public void setOtherchargesaftertax1(String otherchargesaftertax1) {
		this.otherchargesaftertax1 = otherchargesaftertax1;
	}

	public String getTaxonothertranportcharge1() {
		return taxonothertranportcharge1;
	}

	public void setTaxonothertranportcharge1(String taxonothertranportcharge1) {
		this.taxonothertranportcharge1 = taxonothertranportcharge1;
	}

	
	
	public String getPoIntiatedQuantity() {
		return poIntiatedQuantity;
	}

	public String getVendormentionquan() {
		return vendormentionquan;
	}

	public void setVendormentionquan(String vendormentionquan) {
		this.vendormentionquan = vendormentionquan;
	}

	public void setPoIntiatedQuantity(String poIntiatedQuantity) {
		this.poIntiatedQuantity = poIntiatedQuantity;
	}

	public String getRequiredQuantity() {
		return requiredQuantity;
	}

	public void setRequiredQuantity(String requiredQuantity) {
		this.requiredQuantity = requiredQuantity;
	}


	
	
	public String getFinalamtdiv() {
		return finalamtdiv;
	}

	public void setFinalamtdiv(String finalamtdiv) {
		this.finalamtdiv = finalamtdiv;
	}

	
	
	

	public String getEnquiryFormDetailsId() {
		return enquiryFormDetailsId;
	}

	public void setEnquiryFormDetailsId(String enquiryFormDetailsId) {
		this.enquiryFormDetailsId = enquiryFormDetailsId;
	}

	public String getIndentCreationDetailsId() {
		return indentCreationDetailsId;
	}

	public void setIndentCreationDetailsId(String indentCreationDetailsId) {
		this.indentCreationDetailsId = indentCreationDetailsId;
	}

	public String getChildProductCustDisc() {
		return childProductCustDisc;
	}

	public void setChildProductCustDisc(String childProductCustDisc) {
		this.childProductCustDisc = childProductCustDisc;
	}

	public String getStrTermsConditionId() {
		return strTermsConditionId;
	}

	public void setStrTermsConditionId(String strTermsConditionId) {
		this.strTermsConditionId = strTermsConditionId;
	}

	public String getStrTermsConditionName() {
		return strTermsConditionName;
	}

	public void setStrTermsConditionName(String strTermsConditionName) {
		this.strTermsConditionName = strTermsConditionName;
	}

	public int getIntSerialNumber() {
		return intSerialNumber;
	}

	public void setIntSerialNumber(int intSerialNumber) {
		this.intSerialNumber = intSerialNumber;
	}

	

	public Double getOtherOrTransportCharges1() {
		return OtherOrTransportCharges1;
	}

	public void setOtherOrTransportCharges1(Double otherOrTransportCharges1) {
		OtherOrTransportCharges1 = otherOrTransportCharges1;
	}

	public Double getTaxOnOtherOrTransportCharges1() {
		return TaxOnOtherOrTransportCharges1;
	}

	public void setTaxOnOtherOrTransportCharges1(
			Double taxOnOtherOrTransportCharges1) {
		TaxOnOtherOrTransportCharges1 = taxOnOtherOrTransportCharges1;
	}

	public Double getOtherOrTransportChargesAfterTax1() {
		return OtherOrTransportChargesAfterTax1;
	}

	public void setOtherOrTransportChargesAfterTax1(
			Double otherOrTransportChargesAfterTax1) {
		OtherOrTransportChargesAfterTax1 = otherOrTransportChargesAfterTax1;
	}

	public Double getTotalAmount1() {
		return TotalAmount1;
	}

	public void setTotalAmount1(Double totalAmount1) {
		TotalAmount1 = totalAmount1;
	}

	public Double getOtherCharges() {
		return OtherCharges;
	}

	public void setOtherCharges(Double otherCharges) {
		OtherCharges = otherCharges;
	}

	public String getConveyance1() {
		return Conveyance1;
	}

	public void setConveyance1(String conveyance1) {
		Conveyance1 = conveyance1;
	}

	public String getConveyanceAmount1() {
		return ConveyanceAmount1;
	}

	public void setConveyanceAmount1(String conveyanceAmount1) {
		ConveyanceAmount1 = conveyanceAmount1;
	}

	public String getGSTTax1() {
		return GSTTax1;
	}

	public void setGSTTax1(String gSTTax1) {
		GSTTax1 = gSTTax1;
	}

	public String getGSTAmount1() {
		return GSTAmount1;
	}

	public void setGSTAmount1(String gSTAmount1) {
		GSTAmount1 = gSTAmount1;
	}

	public String getAmountAfterTaxx1() {
		return AmountAfterTaxx1;
	}

	public void setAmountAfterTaxx1(String amountAfterTaxx1) {
		AmountAfterTaxx1 = amountAfterTaxx1;
	}

	public String getTransportInvoice1() {
		return TransportInvoice1;
	}

	public void setTransportInvoice1(String transportInvoice1) {
		TransportInvoice1 = transportInvoice1;
	}

	public String getLastissuedDate() {
		return lastissuedDate;
	}

	public void setLastissuedDate(String lastissuedDate) {
		this.lastissuedDate = lastissuedDate;
	}

	public String getRequestQantity() {
		return requestQantity;
	}

	public void setRequestQantity(String requestQantity) {
		this.requestQantity = requestQantity;
	}

	public String getPendingQuantity() {
		return pendingQuantity;
	}

	public void setPendingQuantity(String pendingQuantity) {
		this.pendingQuantity = pendingQuantity;
	}

	public String getIndentNo() {
		return IndentNo;
	}

	public void setIndentNo(String indentNo) {
		IndentNo = indentNo;
	}

	public String getStrDiscount() {
		return strDiscount;
	}

	public void setStrDiscount(String strDiscount) {
		this.strDiscount = strDiscount;
	}

	public String getStrAmtAfterDiscount() {
		return strAmtAfterDiscount;
	}

	public void setStrAmtAfterDiscount(String strAmtAfterDiscount) {
		this.strAmtAfterDiscount = strAmtAfterDiscount;
	}

	public String getPurchaseDeptIndentProcessSeqId() {
		return purchaseDeptIndentProcessSeqId;
	}

	public void setPurchaseDeptIndentProcessSeqId(String purchaseDeptIndentProcessSeqId) {
		this.purchaseDeptIndentProcessSeqId = purchaseDeptIndentProcessSeqId;
	}

	

	public int getPoEntrySeqNumber() {
		return poEntrySeqNumber;
	}

	public void setPoEntrySeqNumber(int poEntrySeqNumber) {
		this.poEntrySeqNumber = poEntrySeqNumber;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getStrPONumber() {
		return strPONumber;
	}

	public void setStrPONumber(String strPONumber) {
		this.strPONumber = strPONumber;
	}

	public String getHsnCode() {
		return hsnCode;
	}

	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}

	public String getPricePerUnitBeforeTax() {
		return pricePerUnitBeforeTax;
	}

	public void setPricePerUnitBeforeTax(String pricePerUnitBeforeTax) {
		this.pricePerUnitBeforeTax = pricePerUnitBeforeTax;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(String taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getAmountAfterTax() {
		return amountAfterTax;
	}

	public void setAmountAfterTax(String amountAfterTax) {
		this.amountAfterTax = amountAfterTax;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getStrGSTINNumber() {
		return strGSTINNumber;
	}

	public void setStrGSTINNumber(String strGSTINNumber) {
		this.strGSTINNumber = strGSTINNumber;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public String getStrProjectName() {
		return strProjectName;
	}

	public void setStrProjectName(String strProjectName) {
		this.strProjectName = strProjectName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getStrIndentId() {
		return strIndentId;
	}

	public void setStrIndentId(String strIndentId) {
		this.strIndentId = strIndentId;
	}

	public String getStrSerialNumber() {
		return strSerialNumber;
	}

	public void setStrSerialNumber(String strSerialNumber) {
		this.strSerialNumber = strSerialNumber;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	private String date;
	
	public String getIssuedQty() {
		return issuedQty;
	}

	public void setIssuedQty(String issuedQty) {
		this.issuedQty = issuedQty;
	}

	public String getRecivedQty() {
		return recivedQty;
	}

	public void setRecivedQty(String recivedQty) {
		this.recivedQty = recivedQty;
	}

	public String getBasicAmt() {
		return basicAmt;
	}

	public void setBasicAmt(String basicAmt) {
		this.basicAmt = basicAmt;
	}

	public String getPricePerUnit() {
		return PricePerUnit;
	}

	public void setPricePerUnit(String pricePerUnit) {
		PricePerUnit = pricePerUnit;
	}

	private String strOtherSiteQtyDtls;
	
	
	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getStrOtherSiteQtyDtls() {
		return strOtherSiteQtyDtls;
	}

	public void setStrOtherSiteQtyDtls(String strOtherSiteQtyDtls) {
		this.strOtherSiteQtyDtls = strOtherSiteQtyDtls;
	}

	

	public String getSite_Id() {
		return site_Id;
	}

	public void setSite_Id(String site_Id) {
		this.site_Id = site_Id;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSub_ProductName() {
		return sub_ProductName;
	}

	public void setSub_ProductName(String sub_ProductName) {
		this.sub_ProductName = sub_ProductName;
	}

	public String getSub_ProductId() {
		return sub_ProductId;
	}

	public void setSub_ProductId(String sub_ProductId) {
		this.sub_ProductId = sub_ProductId;
	}

	

	public String getMeasurementName() {
		return measurementName;
	}

	public void setMeasurementName(String measurementName) {
		this.measurementName = measurementName;
	}

	public String getMeasurementId() {
		return measurementId;
	}

	public void setMeasurementId(String measurementId) {
		this.measurementId = measurementId;
	}

	public String getChild_ProductId() {
		return child_ProductId;
	}

	public void setChild_ProductId(String child_ProductId) {
		this.child_ProductId = child_ProductId;
	}

	public String getChild_ProductName() {
		return child_ProductName;
	}

	public void setChild_ProductName(String child_ProductName) {
		this.child_ProductName = child_ProductName;
	}

}
