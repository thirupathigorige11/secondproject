package com.sumadhura.transdao;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.PaymentBean;
import com.sumadhura.bean.PaymentModesBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.VendorDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.PaymentDto;
import com.sumadhura.util.DBConnection;
import com.sumadhura.util.DateUtil;
import com.sumadhura.util.UIProperties;

@Repository
public class PaymentProcessDaoImpl extends UIProperties implements PaymentProcessDao{


	@Autowired(required = true)
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate){
		this.jdbcTemplate = jdbcTemplate;							//Rafi
	}
	
	
	@Override
	public List<PaymentBean> getInvoiceDetails(String fromDate, String toDate, String siteId,String vendorId,String invoiceNumber) {

		String query = "";
		String frontQuery = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		String total="";
		List<Map<String, Object>> dbInvoiceList = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean objPaymentBean = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			if(siteId.equals("All")){

				query = " SELECT DISTINCT AP.PAYMENT_ID,AP.INVOICE_NUMBER,SCN.CREDIT_NOTE_NUMBER,SCN.CREDIT_TOTAL_AMOUNT,IE.INVOICE_ID,"
						+ "IE.INDENT_ENTRY_ID,IE.RECEIVED_OR_ISSUED_DATE,IE.INVOICE_DATE, VD.VENDOR_NAME,VD.VENDOR_ID,AVSD.SECURITY_DEPOSIT_AMOUNT,IE.PO_ID,"
						+ "IE.PODATE ,AP.PAYMENT_DONE_UPTO,AP.PAYMENT_REQ_UPTO,IE.TOTAL_AMOUNT,IE.DC_NUMBER, "
						+ "(select sum(SPED.TOTAL_AMOUNT) from SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE where SPE.PO_ENTRY_ID = SPED.PO_ENTRY_ID and SPE.PO_NUMBER = IE.PO_ID ) as PO_TOTAL_AMOUNT   "
						+ ",(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT "
						+ "FROM  VENDOR_DETAILS VD ,INDENT_ENTRY IE  "
						+ "LEFT OUTER JOIN ACC_PAYMENT AP on (AP.INVOICE_NUMBER = IE.INVOICE_ID) and AP.VENDOR_ID = IE.VENDOR_ID and AP.SITE_ID = IE.SITE_ID "
						+ "LEFT OUTER JOIN SUMADHURA_CREDIT_NOTE SCN on SCN.INDENT_ENTRY_NUMBER = IE.INDENT_ENTRY_ID "
						+ "LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = IE.VENDOR_ID AND AVSD.SITE_ID = IE.SITE_ID AND AVSD.STATUS = 'A' "
						+ "LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = IE.PO_ID "
						+ "WHERE   IE.VENDOR_ID=VD.VENDOR_ID  AND IE.INDENT_TYPE='IN'   "
						+ "and (AP.STATUS='A' or AP.STATUS IS NULL)  ";

			}else{

				query = " SELECT DISTINCT AP.PAYMENT_ID,AP.INVOICE_NUMBER,SCN.CREDIT_NOTE_NUMBER,SCN.CREDIT_TOTAL_AMOUNT,IE.INVOICE_ID,"
						+ "IE.INDENT_ENTRY_ID,S.SITE_NAME,S.SITE_ID,IE.RECEIVED_OR_ISSUED_DATE, IE.INVOICE_DATE, VD.VENDOR_NAME,VD.VENDOR_ID,AVSD.SECURITY_DEPOSIT_AMOUNT,IE.PO_ID,"
						+ "IE.PODATE ,AP.PAYMENT_DONE_UPTO,AP.PAYMENT_REQ_UPTO,IE.TOTAL_AMOUNT,IE.DC_NUMBER, "
						+ "(select sum(SPED.TOTAL_AMOUNT) from SUMADHURA_PO_ENTRY_DETAILS SPED,SUMADHURA_PO_ENTRY SPE where SPE.PO_ENTRY_ID = SPED.PO_ENTRY_ID and SPE.PO_NUMBER = IE.PO_ID ) as PO_TOTAL_AMOUNT   "
						+ ",(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT "
						+ "FROM  VENDOR_DETAILS VD , SITE S ,INDENT_ENTRY IE "
						+ "LEFT OUTER JOIN ACC_PAYMENT AP on (AP.INVOICE_NUMBER = IE.INVOICE_ID) and AP.VENDOR_ID = IE.VENDOR_ID and AP.SITE_ID = IE.SITE_ID "
						+ "LEFT OUTER JOIN SUMADHURA_CREDIT_NOTE SCN on SCN.INDENT_ENTRY_NUMBER = IE.INDENT_ENTRY_ID "
						+ "LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = IE.VENDOR_ID AND AVSD.SITE_ID = IE.SITE_ID AND AVSD.STATUS = 'A' "
						+ "LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = IE.PO_ID "
						+ "WHERE   IE.VENDOR_ID=VD.VENDOR_ID AND IE.SITE_ID = S.SITE_ID  AND IE.INDENT_TYPE='IN' AND  IE.SITE_ID='"+siteId+"'  "
						+ "and (AP.STATUS='A' or AP.STATUS IS NULL)  ";

			}
			
			if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
				query = query + "  AND TRUNC(IE.INVOICE_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
				//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
			} else if (StringUtils.isNotBlank(fromDate)) {
				query = query + "  AND TRUNC(IE.INVOICE_DATE)  >=TO_DATE('"+fromDate+"', 'dd-MM-yy')";
			} else if(StringUtils.isNotBlank(toDate)) {
				query = query + "  AND TRUNC(IE.INVOICE_DATE)  <=TO_DATE('"+toDate+"', 'dd-MM-yy')";
			}
			
			if(StringUtils.isNotBlank(vendorId)){
				query = query+" and IE.VENDOR_ID='"+vendorId+"'";
			}
			if(StringUtils.isNotBlank(invoiceNumber)){
				query = query+" and IE.INVOICE_ID='"+invoiceNumber+"'";
			}
			
			query = query+" order by IE.INVOICE_DATE asc ";

			dbInvoiceList = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			for(Map<String, Object> invoices : dbInvoiceList) {
				serialNo++;
				objPaymentBean = new PaymentBean();
				objPaymentBean.setIntSerialNo(serialNo);
				String invoiceId = invoices.get("INVOICE_ID")==null ? "" : invoices.get("INVOICE_ID").toString();
				objPaymentBean.setStrInvoiceNo(invoiceId);
				objPaymentBean.setStrInvoiceNoInAP(invoices.get("INVOICE_NUMBER")==null ? "" : invoices.get("INVOICE_NUMBER").toString());
				objPaymentBean.setStrCreditNoteNumber(invoices.get("CREDIT_NOTE_NUMBER")==null ? "" : invoices.get("CREDIT_NOTE_NUMBER").toString());
				//String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
				String vendorName = invoices.get("VENDOR_NAME")==null ? "" : invoices.get("VENDOR_NAME").toString();
				objPaymentBean.setStrVendorName(vendorName);
				objPaymentBean.setStrVendorId(invoices.get("VENDOR_ID")==null ? "" : invoices.get("VENDOR_ID").toString());
				//String receviedDate=prods.get("RECEVED_DATE")==null ? "" : prods.get("RECEVED_DATE").toString();
				//String poDate = prods.get("PODATE")==null ? "" : prods.get("PODATE").toString();
				//String strIndentEntryId = prods.get("INDENT_ENTRY_ID")==null ? "" : prods.get("INDENT_ENTRY_ID").toString();
				//String strSiteId = prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString();



				
				objPaymentBean.setIntPaymentId(Integer.valueOf(invoices.get("PAYMENT_ID")==null ? "0" : invoices.get("PAYMENT_ID").toString()));
				    
				String invoiceDate = invoices.get("INVOICE_DATE")==null ? "" : invoices.get("INVOICE_DATE").toString();
				String receivedDate = invoices.get("RECEIVED_OR_ISSUED_DATE")==null ? "" : invoices.get("RECEIVED_OR_ISSUED_DATE").toString();
				
				objPaymentBean.setStrPODate(invoices.get("PODATE")==null ? "" : invoices.get("PODATE").toString());
				String site_id = invoices.get("SITE_ID")==null ? "" : invoices.get("SITE_ID").toString();
				objPaymentBean.setStrSiteId(site_id);
				objPaymentBean.setStrSiteName(invoices.get("SITE_NAME")==null ? "" : invoices.get("SITE_NAME").toString());
				objPaymentBean.setStrPONo(invoices.get("PO_ID")==null ? "" : invoices.get("PO_ID").toString());
			    objPaymentBean.setDoubleInvoiceAmount(Math.round(Double.valueOf(invoices.get("TOTAL_AMOUNT")==null ? "0" : invoices.get("TOTAL_AMOUNT").toString())));
			    objPaymentBean.setDoublePOTotalAmount(Math.round(Double.valueOf(invoices.get("PO_TOTAL_AMOUNT")==null ? "0" : invoices.get("PO_TOTAL_AMOUNT").toString())));
			    objPaymentBean.setDoublePaymentDoneUpto(Double.valueOf(invoices.get("PAYMENT_DONE_UPTO")==null ? "0" : invoices.get("PAYMENT_DONE_UPTO").toString()));
			    objPaymentBean.setDoublePaymentRequestedUpto(Double.valueOf(invoices.get("PAYMENT_REQ_UPTO")==null ? "0" : invoices.get("PAYMENT_REQ_UPTO").toString()));
			    String strIndentEntryId = invoices.get("INDENT_ENTRY_ID")==null ? "0" : invoices.get("INDENT_ENTRY_ID").toString();
			    objPaymentBean.setIntIndentEntryId(Integer.parseInt(strIndentEntryId));
			    objPaymentBean.setDoubleCreditTotalAmount(Double.valueOf(invoices.get("CREDIT_TOTAL_AMOUNT")==null ? "0" : invoices.get("CREDIT_TOTAL_AMOUNT").toString()));
			    objPaymentBean.setDoubleSecurityDeposit(Double.valueOf(invoices.get("SECURITY_DEPOSIT_AMOUNT")==null ? "0" : invoices.get("SECURITY_DEPOSIT_AMOUNT").toString()));
			    objPaymentBean.setDoublePOAdvancePayment(Double.valueOf(invoices.get("REMAINING_AMOUNT")==null ? "0" : invoices.get("REMAINING_AMOUNT").toString()));
			    
			    SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
				
			    try{
			    	
			    	if(!invoiceDate.equals("")){
			    		Date invoice_date = dt.parse(invoiceDate);
			    		invoiceDate = dt1.format(invoice_date);
			    		}
			    	if(!receivedDate.equals("")){
			    		Date received_date = dt.parse(receivedDate);
			    		receivedDate = dt1.format(received_date);
			    		}
					
				}catch(Exception e){
					e.printStackTrace();
				}
			    objPaymentBean.setStrInvoiceDate(invoiceDate);
			    objPaymentBean.setStrInvoiceReceivedDate(receivedDate);
			    /*** display image ***/
			    for(int i=0;i<3;i++){
			    String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
				File f = new File(rootFilePath+site_id+"/"+vendorName+"_"+invoiceId+"_"+strIndentEntryId+"_Part"+i+".jpg");

				if(f.exists()){
					
					objPaymentBean.setHasImage(true);break;
					/*DataInputStream dis = new DataIn;putStream(new FileInputStream(f));
					byte[] barray = new byte[(int) f.length()];
					dis.readFully(barray); 
					byte[] encodeBase64 = Base64.encodeBase64(barray);
					String base64Encoded = new String(encodeBase64, "UTF-8");
					switch(i){
					case 0: objPaymentBean.setInvoiceImage0(base64Encoded);break;
					case 1: objPaymentBean.setInvoiceImage1(base64Encoded);break;
					case 2: objPaymentBean.setInvoiceImage2(base64Encoded);break;
					case 3: objPaymentBean.setInvoiceImage3(base64Encoded);break;
					}*/
					
					
				}
			    }
			    /**** END ***/
			    list.add(objPaymentBean);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			objPaymentBean = null; 
			template = null;
			
		}
		return list;
	}
	@Override
	public List<PaymentBean> getPODetails(String fromDate, String toDate, String siteId,String vendorId,String poNumber) {

		String query = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		String total="";
		List<Map<String, Object>> dbPOsList = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean objPaymentBean = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());
			
			if(siteId.equals("998")){

				query = "SELECT DISTINCT AP.PAYMENT_ID,SPE.PO_NUMBER,SPE.PO_ENTRY_ID,S.SITE_NAME,S.SITE_ID,SPE.PO_DATE, VD.VENDOR_NAME,VD.VENDOR_ID,AAPP.PAID_AMOUNT,AP.PAYMENT_REQ_UPTO,"
						  + "(select sum(SPED.TOTAL_AMOUNT) from SUMADHURA_PO_ENTRY_DETAILS SPED where SPE.PO_ENTRY_ID = SPED.PO_ENTRY_ID ) as TOTAL_AMOUNT,AVSD.SECURITY_DEPOSIT_AMOUNT  "
						  + "FROM  VENDOR_DETAILS VD , SITE S , SUMADHURA_PO_ENTRY SPE LEFT OUTER JOIN ACC_PAYMENT AP on AP.PO_NUMBER = SPE.PO_NUMBER and AP.VENDOR_ID = SPE.VENDOR_ID and AP.SITE_ID = SPE.SITE_ID "
						  + " LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = SPE.VENDOR_ID AND AVSD.SITE_ID = SPE.SITE_ID AND AVSD.STATUS = 'A' "
						  + " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on SPE.PO_NUMBER = AAPP.PO_NUMBER  "
						  + " WHERE   SPE.VENDOR_ID=VD.VENDOR_ID AND SPE.SITE_ID = S.SITE_ID  "
						  + " and (AP.STATUS='A' or AP.STATUS IS NULL)  and SPE.PO_STATUS = 'A' ";
			
			}else{
				query = "SELECT DISTINCT AP.PAYMENT_ID,SPE.PO_NUMBER,SPE.PO_ENTRY_ID,S.SITE_NAME,S.SITE_ID,SPE.PO_DATE, VD.VENDOR_NAME,VD.VENDOR_ID,AAPP.PAID_AMOUNT,AP.PAYMENT_REQ_UPTO,"
								  + "(select sum(SPED.TOTAL_AMOUNT) from SUMADHURA_PO_ENTRY_DETAILS SPED where SPE.PO_ENTRY_ID = SPED.PO_ENTRY_ID ) as TOTAL_AMOUNT,AVSD.SECURITY_DEPOSIT_AMOUNT  "
								  + "FROM  VENDOR_DETAILS VD , SITE S , SUMADHURA_PO_ENTRY SPE LEFT OUTER JOIN ACC_PAYMENT AP on AP.PO_NUMBER = SPE.PO_NUMBER and AP.VENDOR_ID = SPE.VENDOR_ID and AP.SITE_ID = SPE.SITE_ID "
								  + " LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = SPE.VENDOR_ID AND AVSD.SITE_ID = SPE.SITE_ID AND AVSD.STATUS = 'A' "
								  + " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on SPE.PO_NUMBER = AAPP.PO_NUMBER  "
								  + " WHERE   SPE.VENDOR_ID=VD.VENDOR_ID AND SPE.SITE_ID = S.SITE_ID  AND   SPE.SITE_ID='"+siteId+"'  "
								  + " and (AP.STATUS='A' or AP.STATUS IS NULL)  and SPE.PO_STATUS = 'A' ";
			}
			
			if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
				query = query + " AND TRUNC(SPE.PO_DATE) BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
				//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
			} else if (StringUtils.isNotBlank(fromDate)) {
				query = query + " AND TRUNC(SPE.PO_DATE) >=TO_DATE('"+fromDate+"', 'dd-MM-yy')";
			} else if(StringUtils.isNotBlank(toDate)) {
				query = query + " AND TRUNC(SPE.PO_DATE) <=TO_DATE('"+toDate+"', 'dd-MM-yy')";
			}
			
			if(StringUtils.isNotBlank(vendorId)){
				query = query+" and SPE.VENDOR_ID='"+vendorId+"'";
			}
			
			if(StringUtils.isNotBlank(poNumber)){
				query = query+" and SPE.PO_NUMBER='"+poNumber+"'";
			}

			query = query+" order by SPE.PO_DATE asc ";

			dbPOsList = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			for(Map<String, Object> po : dbPOsList) {
				serialNo++;
				objPaymentBean = new PaymentBean();
				objPaymentBean.setIntSerialNo(serialNo);
				objPaymentBean.setStrPONo(po.get("PO_NUMBER")==null ? "" : po.get("PO_NUMBER").toString());
				String poDate = po.get("PO_DATE")==null ? "" : po.get("PO_DATE").toString();
				objPaymentBean.setDoublePOTotalAmount(Math.round(Double.valueOf(po.get("TOTAL_AMOUNT")==null ? "0" : po.get("TOTAL_AMOUNT").toString())));
				
				objPaymentBean.setStrVendorName(po.get("VENDOR_NAME")==null ? "" : po.get("VENDOR_NAME").toString());
				objPaymentBean.setStrVendorId(po.get("VENDOR_ID")==null ? "" : po.get("VENDOR_ID").toString());
				
				objPaymentBean.setStrSiteId(po.get("SITE_ID")==null ? "" : po.get("SITE_ID").toString());
				objPaymentBean.setStrSiteName(po.get("SITE_NAME")==null ? "" : po.get("SITE_NAME").toString());
				
				objPaymentBean.setIntPaymentId(Integer.valueOf(po.get("PAYMENT_ID")==null ? "0" : po.get("PAYMENT_ID").toString()));
				objPaymentBean.setDoublePaymentDoneUpto(Double.valueOf(po.get("PAID_AMOUNT")==null ? "0" : po.get("PAID_AMOUNT").toString()));
			    objPaymentBean.setDoublePaymentRequestedUpto(Double.valueOf(po.get("PAYMENT_REQ_UPTO")==null ? "0" : po.get("PAYMENT_REQ_UPTO").toString()));
			    objPaymentBean.setDoubleSecurityDeposit(Double.valueOf(po.get("SECURITY_DEPOSIT_AMOUNT")==null ? "0" : po.get("SECURITY_DEPOSIT_AMOUNT").toString()));
			    
			    SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    try{
			    	Date po_date = null;
			    	if(!poDate.equals("")){po_date = dt.parse(poDate);}
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					if(po_date!=null){poDate = dt1.format(po_date);}
				}catch(Exception e){
					e.printStackTrace();
				}
			    objPaymentBean.setStrPODate(poDate);
				list.add(objPaymentBean);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			objPaymentBean = null; 
			template = null;
			
		}
		return list;
	}
	
	@Override
	public int saveOrUpdePaymentTable(PaymentDto objPaymentDto,int PaymentId){

		int count = 0;

		if( objPaymentDto.getIntPaymentId() > 0)
		{
			String invoiceNoInAccPaymentTable = objPaymentDto.getStrInvoiceNoInAP(); 
			if(invoiceNoInAccPaymentTable==null||invoiceNoInAccPaymentTable.equals("")){
				String query = "update ACC_PAYMENT set INVOICE_NUMBER = ?, INVOICE_AMOUNT = ?,"
						+ "INVOICE_DATE = ?,INVOICE_RECEIVED_DATE = ?, UPDATED_DATE =sysdate , " +
						"PAYMENT_REQ_UPTO = PAYMENT_REQ_UPTO+?,REMARKS = ?,INDENT_ENTRY_ID=?,CREDIT_TOTAL_AMOUNT=?,CREDIT_NOTE_NUMBER=? where PAYMENT_ID = ? ";

						count = jdbcTemplate.update(query, new Object[] {objPaymentDto.getStrInvoiceNo(),
								objPaymentDto.getDoubleInvoiceAmount(),
								DateUtil.convertToJavaDateFormat(objPaymentDto.getStrInvoiceDate()),
								DateUtil.convertToJavaDateFormat(objPaymentDto.getStrInvoiceReceivedDate()),
								objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getDoubleAdjustAmountFromAdvance(),
								objPaymentDto.getStrRemarks(), 
								String.valueOf(objPaymentDto.getIntIndentEntryId()),
								objPaymentDto.getDoubleCreditTotalAmount(),
								objPaymentDto.getStrCreditNoteNumber(),
								objPaymentDto.getIntPaymentId()


						});
			}else{
			String query = "update ACC_PAYMENT set  UPDATED_DATE =sysdate , " +
			"PAYMENT_REQ_UPTO = PAYMENT_REQ_UPTO+?,REMARKS = ? where PAYMENT_ID = ? ";

			count = jdbcTemplate.update(query, new Object[] {

					objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getDoubleAdjustAmountFromAdvance(),objPaymentDto.getStrRemarks(),  objPaymentDto.getIntPaymentId()


			});
			}


		}else{
			/* checking in ACC_PAYMENT is there any row with current PO_NUMBER with empty INVOICE_NUMBER */
			int poPaymentId = 0;
			String getPoPaymentIdQry = "select AP.PAYMENT_ID from ACC_PAYMENT AP where AP.PO_NUMBER = ? "
					+ "and AP.VENDOR_ID = ? and AP.SITE_ID = ? and AP.INVOICE_NUMBER IS NULL";
			try {
				poPaymentId = jdbcTemplate.queryForInt(getPoPaymentIdQry,new Object[] {
						objPaymentDto.getStrPONo(),objPaymentDto.getStrVendorId(),objPaymentDto.getStrSiteId()});
			} catch (EmptyResultDataAccessException e) {
				poPaymentId = 0;
			}
			/* if there is a row then update it*/
			if(poPaymentId>0){
				String query = "update ACC_PAYMENT set INVOICE_NUMBER = ?, INVOICE_AMOUNT = ?,"
						+ "INVOICE_DATE = ?,INVOICE_RECEIVED_DATE = ?, UPDATED_DATE =sysdate , " +
						"PAYMENT_REQ_UPTO = PAYMENT_REQ_UPTO+?,REMARKS = ?,INDENT_ENTRY_ID=?,CREDIT_TOTAL_AMOUNT=?,CREDIT_NOTE_NUMBER=? where PAYMENT_ID = ? ";

				count = jdbcTemplate.update(query, new Object[] {objPaymentDto.getStrInvoiceNo(),
						objPaymentDto.getDoubleInvoiceAmount(),
						DateUtil.convertToJavaDateFormat(objPaymentDto.getStrInvoiceDate()),
						DateUtil.convertToJavaDateFormat(objPaymentDto.getStrInvoiceReceivedDate()),
						objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getDoubleAdjustAmountFromAdvance(),
						objPaymentDto.getStrRemarks(), 
						String.valueOf(objPaymentDto.getIntIndentEntryId()),
						objPaymentDto.getDoubleCreditTotalAmount(),
						objPaymentDto.getStrCreditNoteNumber(),
						poPaymentId


				});
			}
			/* else insert a new row */
			else{
				String query = "insert into ACC_PAYMENT(PAYMENT_ID,INVOICE_NUMBER,INVOICE_AMOUNT " +
						",SITE_ID,CREATED_DATE, PAYMENT_DONE_UPTO, DC_NUMBER, PAYMENT_REQ_UPTO, STATUS, " +
						" REMARKS, VENDOR_ID, PO_NUMBER,PO_AMOUNT,INVOICE_DATE,PO_DATE,DC_DATE,INVOICE_RECEIVED_DATE,INDENT_ENTRY_ID,CREDIT_TOTAL_AMOUNT,CREDIT_NOTE_NUMBER) " +
						"values(?,?,?,?,SYSDATE,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				count = jdbcTemplate.update(query, new Object[] {
						PaymentId,
						objPaymentDto.getStrInvoiceNo(),objPaymentDto.getDoubleInvoiceAmount(),
						objPaymentDto.getStrSiteId(),objPaymentDto.getDoublePaymentDoneUpto(),
						objPaymentDto.getStrDCNo(),objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getDoubleAdjustAmountFromAdvance(),
						"A",objPaymentDto.getStrRemarks(),objPaymentDto.getStrVendorId(),
						objPaymentDto.getStrPONo(),objPaymentDto.getDoublePOAmount(),
						DateUtil.convertToJavaDateFormat(objPaymentDto.getStrInvoiceDate()),
						DateUtil.convertToJavaDateFormat(objPaymentDto.getStrPODate()),
						DateUtil.convertToJavaDateFormat(objPaymentDto.getStrDCDate()),
						DateUtil.convertToJavaDateFormat(objPaymentDto.getStrInvoiceReceivedDate()),
						String.valueOf(objPaymentDto.getIntIndentEntryId()),
						objPaymentDto.getDoubleCreditTotalAmount(),
						objPaymentDto.getStrCreditNoteNumber(),
				});


			}

		}

		return count;

	}
	
	@Override
	public int savePaymentProcessDtlsTable(PaymentDto objPaymentDto,int intPaymentId,int paymentEntrySeqId){

		int count = 0;
		int count1 = 0;
		
			String query = "insert into ACC_PAYMENT_DTLS(PAYMENT_DETAILS_ID,PAYMENT_ID,REQ_AMOUNT,REQUEST_PENDING_EMP_ID," +
					       "STATUS,PAYMENT_TYPE, "+
                           "PAYMENT_REQ_DATE,REMARKS,SITEWISE_PAYMENT_NO,CREATION_DATE,ADJUST_AMOUNT_FROM_ADVANCE)values(?,?,?,?,?,?,?,?,?,sysdate,?)";

			count = jdbcTemplate.update(query, new Object[] {
					paymentEntrySeqId,
					intPaymentId,objPaymentDto.getDoubleAmountToBeReleased(),
					objPaymentDto.getStrPendingEmpId(),"A",objPaymentDto.getPaymentType(),
					objPaymentDto.getStrPaymentReqDate(),objPaymentDto.getStrRemarks(),
					objPaymentDto.getIntSiteWisePaymentId(),
					objPaymentDto.getDoubleAdjustAmountFromAdvance()});

			
			
			String query1 = "update ACC_ADVANCE_PAYMENT_PO set INTIATED_AMOUNT=INTIATED_AMOUNT+? where PO_NUMBER = ? ";

					count1 = jdbcTemplate.update(query1, new Object[] {
							objPaymentDto.getDoubleAdjustAmountFromAdvance(),
							objPaymentDto.getStrPONo()
					});
					
					
		return count;

	}
	
	@Override
	public int savePaymentApproveRejectTable(PaymentDto objPaymentDto,int intPaymentId,int intPaymentDetailsId){

		int count = 0;

		
			String query = "insert into ACC_SITE_APPR_REJECT_DTLS(PAYMENT_APROV_REJECT_SEQ,PAYMENT_ID,EMP_ID,STATUS," +
					"REMARKS,PAYMENT_DETAILS_ID,SITE_ID,CREATED_DATE,OPERATION_TYPE)values" +
					"(PAYMENT_APPROVE_REJECT_SEQ_ID.nextval,?,?,?,?,?,?,sysdate,?)";

			count = jdbcTemplate.update(query, new Object[] {
					intPaymentId,objPaymentDto.getStrEmployeeId(),"A",objPaymentDto.getStrRemarks(),
					intPaymentDetailsId,objPaymentDto.getStrSiteId(),"C"});

		return count;

	}
	
	
	@Override
	public int getPaymentId()
	{
		int paymentId = 0;

		String query = "select PAYMENT_SEQ_ID.nextval from dual";

		paymentId = jdbcTemplate.queryForInt(query);


		return paymentId;

	}
	
	@Override
	public int getIntPaymentTransactionId()
	{
		int paymentId = 0;

		String query = "select ACC_PMT_TRANSACTIONS_SEQ.nextval from dual";

		paymentId = jdbcTemplate.queryForInt(query);


		return paymentId;

	}
	
	@Override
	public int getPaymentDetailsId()
	{
		int enquiryFormSeqId = 0;

		String query = "select PAYMENT_ENTRY_DTLS_SEQ_ID.nextval from dual";

		enquiryFormSeqId = jdbcTemplate.queryForInt(query);


		return enquiryFormSeqId;

	}
	
	@Override
	public List<PaymentBean> getPaymentApprovalDetails(String siteId, String user_id){

		String query = "";
		JdbcTemplate template = null;
		double invoiceAmount=0.0;
		double poAmount=0.0;
		List<Map<String, Object>> dbIndentDts = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean indentObj = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

		
				if (siteId.equals("998")) {
					query = "select DISTINCT(AP.INVOICE_NUMBER),VD.VENDOR_NAME,AP.INVOICE_AMOUNT,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,AP.SITE_ID,AP.INVOICE_DATE,AP.INVOICE_RECEIVED_DATE,APD.REQ_AMOUNT,"
							+" APD.PAYMENT_REQ_DATE,APD.REMARKS,APD.PAYMENT_DETAILS_ID,APD.PAYMENT_ID,VD.VENDOR_ID,AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.INDENT_ENTRY_ID,AVSD.SECURITY_DEPOSIT_AMOUNT,APD.PAYMENT_TYPE,AP.PAYMENT_REQ_UPTO,AP.PAYMENT_DONE_UPTO " 
							+" ,(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT ,APD.ADJUST_AMOUNT_FROM_ADVANCE "
							+ " FROM VENDOR_DETAILS VD,ACC_PAYMENT_DTLS APD,ACC_PAYMENT AP " 
							+" LEFT OUTER JOIN SUMADHURA_PO_ENTRY SPE on ( AP.PO_NUMBER = SPE.PO_NUMBER and AP.VENDOR_ID=SPE.VENDOR_ID) "
							+"  LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = AP.VENDOR_ID AND AVSD.SITE_ID = AP.SITE_ID AND AVSD.STATUS = 'A' "
							+ " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = AP.PO_NUMBER "
							+ " WHERE AP.PAYMENT_ID=APD.PAYMENT_ID and APD.STATUS='A'  AND AP.VENDOR_ID=VD.VENDOR_ID "  
							+" AND APD.REQUEST_PENDING_EMP_ID = '"+user_id+"'"
							+" order by VD.VENDOR_NAME asc, APD.PAYMENT_REQ_DATE asc ";
				}
				else{
					query = "select DISTINCT(AP.INVOICE_NUMBER),VD.VENDOR_NAME,AP.INVOICE_AMOUNT,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,AP.SITE_ID,AP.INVOICE_DATE,AP.INVOICE_RECEIVED_DATE,APD.REQ_AMOUNT,"
							+" APD.PAYMENT_REQ_DATE,APD.REMARKS,APD.PAYMENT_DETAILS_ID,APD.PAYMENT_ID,VD.VENDOR_ID,AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.INDENT_ENTRY_ID,AVSD.SECURITY_DEPOSIT_AMOUNT,APD.PAYMENT_TYPE,AP.PAYMENT_REQ_UPTO,AP.PAYMENT_DONE_UPTO " 
							+" ,(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT ,APD.ADJUST_AMOUNT_FROM_ADVANCE "
							+ " FROM VENDOR_DETAILS VD,ACC_PAYMENT_DTLS APD,ACC_PAYMENT AP " 
							+" LEFT OUTER JOIN SUMADHURA_PO_ENTRY SPE on ( AP.PO_NUMBER = SPE.PO_NUMBER and AP.VENDOR_ID=SPE.VENDOR_ID) "
							+"  LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = AP.VENDOR_ID AND AVSD.SITE_ID = AP.SITE_ID AND AVSD.STATUS = 'A' "
							+ " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = AP.PO_NUMBER "
							+ " WHERE AP.PAYMENT_ID=APD.PAYMENT_ID and APD.STATUS='A' AND AP.SITE_ID='"+siteId+"' AND AP.VENDOR_ID=VD.VENDOR_ID "  
							+" AND APD.REQUEST_PENDING_EMP_ID = '"+user_id+"'"
							+" order by VD.VENDOR_NAME asc, APD.PAYMENT_REQ_DATE asc ";
					
				}
			dbIndentDts = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			int vendorGroupSerialNo = 0;
			String currentVendorId="-";
			List<PaymentBean> invoiceIdList = new ArrayList<PaymentBean>();
			List<String> poIdList = new ArrayList<String>();
			for(Map<String, Object> prods : dbIndentDts) {
				String vendorId = prods.get("VENDOR_ID")==null ? "" : prods.get("VENDOR_ID").toString();
				String vendorName = prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString();
				String invoiceId = prods.get("INVOICE_NUMBER")==null ? "" : prods.get("INVOICE_NUMBER").toString();
				invoiceAmount=Math.round(Double.parseDouble(prods.get("INVOICE_AMOUNT")==null ? "" : prods.get("INVOICE_AMOUNT").toString()));
				String poId = prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString();
				poAmount=Double.parseDouble(prods.get("PO_AMOUNT")==null ? "" : prods.get("PO_AMOUNT").toString());
				String reqAmount = prods.get("REQ_AMOUNT")==null ? "" : prods.get("REQ_AMOUNT").toString();
				String site_id = prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString();
				if(!currentVendorId.equals(vendorId))
				{
					vendorGroupSerialNo++;
					indentObj = new PaymentBean();
					indentObj.setStrVendorId(vendorId);
					indentObj.setStrVendorName(vendorName);
					indentObj.setVendorHeader(true);
					indentObj.setVendorGroupSerialNo(vendorGroupSerialNo);
					list.add(indentObj);
					currentVendorId=vendorId;
					
				}
				
				for(PaymentBean e:list){
					if(e.isVendorHeader()&&e.getStrVendorId().equals(vendorId)){
						e.setRequestedAmount(String.valueOf(Double.valueOf(e.getRequestedAmount()==null?"0":e.getRequestedAmount())+Double.valueOf(reqAmount)));
						/*if(!invoiceIdList.contains(invoiceId)){
							e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+invoiceAmount);
							invoiceIdList.add(invoiceId);
						}
						if(!poIdList.contains(poId)){
							e.setDoublePOTotalAmount(e.getDoublePOTotalAmount()+poAmount);
							poIdList.add(poId);
						}*/
						if(StringUtils.isBlank(invoiceId)){
							if(!poIdList.contains(poId)){
								e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+poAmount);
								poIdList.add(poId);
							}
						}
						else if(!isInvoiceIdListContainsinvoiceId(invoiceIdList,invoiceId,vendorId,site_id)){
							e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+invoiceAmount);
							PaymentBean obj = new PaymentBean();
							obj.setStrInvoiceNo(invoiceId);
							obj.setStrVendorId(vendorId);
							obj.setStrSiteId(site_id);
							invoiceIdList.add(obj);
						}
					}
				}
				
				serialNo++;
				indentObj = new PaymentBean();
				indentObj.setIntSerialNo(serialNo);
				indentObj.setVendorGroupSerialNo(vendorGroupSerialNo);
				indentObj.setStrInvoiceNo(prods.get("INVOICE_NUMBER")==null ? "" : prods.get("INVOICE_NUMBER").toString());
				String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
				indentObj.setStrVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
				indentObj.setStrVendorId(vendorId);
				
				poAmount=Math.round(Double.parseDouble(prods.get("PO_AMOUNT")==null ? "" : prods.get("PO_AMOUNT").toString()));
				indentObj.setRequestedAmount(reqAmount);
				String  paymentDate =(prods.get("PAYMENT_REQ_DATE")==null ? "" : prods.get("PAYMENT_REQ_DATE").toString());
				String receviedDate=prods.get("INVOICE_RECEIVED_DATE")==null ? "" : prods.get("INVOICE_RECEIVED_DATE").toString();
				String remarks = prods.get("REMARKS")==null ? "" : prods.get("REMARKS").toString();
				indentObj.setStrRemarks(StringEscapeUtils.escapeHtml(remarks));
				indentObj.setStrRemarksForView(StringEscapeUtils.escapeHtml(remarks.replace("@@@", ",")));
				indentObj.setIntPaymentId(Integer.parseInt(prods.get("PAYMENT_ID")==null ? "" : prods.get("PAYMENT_ID").toString()));
				indentObj.setIntPaymentDetailsId(Integer.parseInt(prods.get("PAYMENT_DETAILS_ID")==null ? "" : prods.get("PAYMENT_DETAILS_ID").toString()));
				indentObj.setStrSiteId(site_id);
				indentObj.setStrPONo(prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString());				
				String  poDate =(prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString());
				indentObj.setDoubleInvoiceAmount(invoiceAmount);
				indentObj.setDoublePOTotalAmount(poAmount);
				indentObj.setDoubleCreditTotalAmount(Double.valueOf(prods.get("CREDIT_TOTAL_AMOUNT")==null ? "0" : prods.get("CREDIT_TOTAL_AMOUNT").toString()));
				indentObj.setStrCreditNoteNumber(prods.get("CREDIT_NOTE_NUMBER")==null ? "" : prods.get("CREDIT_NOTE_NUMBER").toString());
				indentObj.setDoubleSecurityDeposit(Double.valueOf(prods.get("SECURITY_DEPOSIT_AMOUNT")==null ? "0" : prods.get("SECURITY_DEPOSIT_AMOUNT").toString()));
			    String strIndentEntryId = prods.get("INDENT_ENTRY_ID")==null ? "0" : prods.get("INDENT_ENTRY_ID").toString();
				indentObj.setIntIndentEntryId(Integer.parseInt(strIndentEntryId));
			    indentObj.setDoublePOAdvancePayment(Double.valueOf(prods.get("REMAINING_AMOUNT")==null ? "0" : prods.get("REMAINING_AMOUNT").toString()));
			    indentObj.setDoubleAdjustAmountFromAdvance(Double.valueOf(prods.get("ADJUST_AMOUNT_FROM_ADVANCE")==null ? "0" : prods.get("ADJUST_AMOUNT_FROM_ADVANCE").toString()));
			    indentObj.setPaymentType(prods.get("PAYMENT_TYPE")==null ? "" :   prods.get("PAYMENT_TYPE").toString());
			    indentObj.setDoublePaymentDoneUpto(Double.valueOf(prods.get("PAYMENT_DONE_UPTO")==null ? "0" : prods.get("PAYMENT_DONE_UPTO").toString()));
			    indentObj.setDoublePaymentRequestedUpto(Double.valueOf(prods.get("PAYMENT_REQ_UPTO")==null ? "0" : prods.get("PAYMENT_REQ_UPTO").toString()));
			    
			

				SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String convertreceive_time = "";
				
				try{
					
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");
					if(!receviedDate.equals("")){

					Date receive_date = dt.parse(receviedDate);
					receviedDate = dt1.format(receive_date);
					convertreceive_time = time1.format(receive_date);
					}
					if(!invoicedate.equals("")){

					Date invoice_date = dt.parse(invoicedate);
					invoicedate = dt1.format(invoice_date);
					}
					if(!poDate.equals("")){

						Date po_date = dt.parse(poDate);
						poDate = dt1.format(po_date);
						}
					
					if(!paymentDate.equals("")){

						Date payment_date = dt.parse(paymentDate);
						paymentDate = dt1.format(payment_date);
					}

					
					
					
				}
			
				catch(Exception e){
					e.printStackTrace();
				}
			
				indentObj.setStrInvoiceDate(invoicedate);
				indentObj.setStrReceiveDate(receviedDate);
			//	indentObj.setTime(convertreceive_time);
				indentObj.setRequestedDate(paymentDate);
				indentObj.setStrPODate(poDate);
				/*** display image ***/
			    for(int i=0;i<3;i++){
			    String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
				File f = new File(rootFilePath+site_id+"/"+vendorName+"_"+invoiceId+"_"+strIndentEntryId+"_Part"+i+".jpg");

				if(f.exists()){
					
					indentObj.setHasImage(true);break;
					/*DataInputStream dis = new DataInputStream(new FileInputStream(f));
					byte[] barray = new byte[(int) f.length()];
					dis.readFully(barray); 
					byte[] encodeBase64 = Base64.encodeBase64(barray);
					String base64Encoded = new String(encodeBase64, "UTF-8");
					switch(i){
					case 0: indentObj.setInvoiceImage0(base64Encoded);break;
					case 1: indentObj.setInvoiceImage1(base64Encoded);break;
					case 2: indentObj.setInvoiceImage2(base64Encoded);break;
					case 3: indentObj.setInvoiceImage3(base64Encoded);break;
					}*/
					
					
				}
			    }
			    /**** END ***/
				list.add(indentObj);
			}

		
		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;

	}
	
	
	@Override
	public List<PaymentBean> getAccDeptPaymentApprovalDetails(String siteId, String user_id){

		String query = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		double invoiceAmount=0.0;
		double poAmount=0.0;
		List<Map<String, Object>> dbIndentDts = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean indentObj = null;
		

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());
			//Because we changed dept id 997 to 997_B_1 & 997_H_1  , so we have to know which dept id is specifically.
			String  accDeptId = template.queryForObject("select DEPT_ID from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID = '"+user_id+"'", String.class);
			
		
				if (StringUtils.isNotBlank(siteId)) {
					query = " select ATPT.TEMP_PAYMENT_TRANSACTIONS_ID,ATPT.ACCOUNTS_DEPT_PMT_PROSS_ID,ATPT.PAYMENT_DETAILS_ID,ATPT.REQ_AMOUNT,ATPT.PAYMENT_TYPE,"
						   +" ATPT.PAYMENT_REQ_DATE,ATPT.PAYMENT_MODE,APM.NAME as PAYMENT_MODE_NAME,ATPT.UTR_CHQNO,ATPT.REMARKS,ATPT.SITEWISE_PAYMENT_NO,"
						   +"S.SITE_NAME,VD.VENDOR_NAME,AP.INVOICE_NUMBER,AP.INVOICE_AMOUNT,AP.PAYMENT_ID,AP.INVOICE_DATE,AP.INVOICE_RECEIVED_DATE,AP.PAYMENT_REQ_UPTO,AP.PAYMENT_DONE_UPTO,"
						   +"AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,"
						   +"AP.VENDOR_ID,AP.SITE_ID,AP.INDENT_ENTRY_ID,AVSD.SECURITY_DEPOSIT_AMOUNT  "  
						   + ",(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT ,ATPT.ADJUST_AMOUNT_FROM_ADVANCE,AADPP.CREATION_DATE  "
						   +"from ACC_TEMP_PAYMENT_TRANSACTIONS ATPT LEFT OUTER JOIN ACC_PAYMENT_MODES APM on APM.VALUE = ATPT.PAYMENT_MODE "
						   + ",ACC_ACCOUNTS_DEPT_PMT_PROSS AADPP,ACC_PAYMENT_DTLS APD,SITE S,VENDOR_DETAILS VD,"
						   +"ACC_PAYMENT AP "
						   + " LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = AP.VENDOR_ID AND AVSD.SITE_ID = AP.SITE_ID AND AVSD.STATUS = 'A'  "
						   + " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = AP.PO_NUMBER "
						   
						   +"where ATPT.status='A' and ATPT.REQUEST_PENDING_EMP_ID = '"+accDeptId+"' "
						   +"and AP.PAYMENT_ID = APD.PAYMENT_ID "
						   +"and APD.PAYMENT_DETAILS_ID = ATPT.PAYMENT_DETAILS_ID "
						   +"and S.SITE_ID = AP.SITE_ID "
						   +"and VD.VENDOR_ID = AP.VENDOR_ID  "
						   
						   +"and AADPP.ACCOUNTS_DEPT_PMT_PROSS_ID = ATPT.ACCOUNTS_DEPT_PMT_PROSS_ID  "
							+" order by VD.VENDOR_NAME asc, S.SITE_NAME asc, ATPT.PAYMENT_REQ_DATE asc ";
			dbIndentDts = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			int vendorGroupSerialNo = 0;
			String currentVendorId="-";
			String currentSiteId="-";
			List<PaymentBean> invoiceIdList = new ArrayList<PaymentBean>();
			List<String> poIdList = new ArrayList<String>();
			for(Map<String, Object> prods : dbIndentDts) {
				String invoiceId = prods.get("INVOICE_NUMBER")==null ? "" : prods.get("INVOICE_NUMBER").toString();
				String poId = prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString();
				invoiceAmount=Math.round(Double.parseDouble(prods.get("INVOICE_AMOUNT")==null ? "" : prods.get("INVOICE_AMOUNT").toString()));
				poAmount=Math.round(Double.parseDouble(prods.get("PO_AMOUNT")==null ? "" : prods.get("PO_AMOUNT").toString()));
				String vendorName = prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString();
				String vendorId = prods.get("VENDOR_ID")==null ? "" : prods.get("VENDOR_ID").toString();
				String reqAmount = prods.get("REQ_AMOUNT")==null ? "" : prods.get("REQ_AMOUNT").toString();
				String site_id = prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString();
				String site_name = prods.get("SITE_NAME")==null ? "" : prods.get("SITE_NAME").toString();
				if(!currentVendorId.equals(vendorId)||!currentSiteId.equals(site_id))
				{
					vendorGroupSerialNo++;
					indentObj = new PaymentBean();
					indentObj.setStrVendorId(vendorId);
					indentObj.setStrVendorName(vendorName);
					indentObj.setStrSiteId(site_id);
					indentObj.setStrSiteName(site_name);
					indentObj.setVendorHeader(true);
					indentObj.setVendorGroupSerialNo(vendorGroupSerialNo);
					list.add(indentObj);
					currentVendorId=vendorId;
					currentSiteId=site_id;
					
				}
				
				for(PaymentBean e:list){
					if(e.isVendorHeader()&&e.getStrVendorId().equals(vendorId)&&e.getStrSiteId().equals(site_id)){
						e.setIntNoofPaymentsVendorWise(e.getIntNoofPaymentsVendorWise()+1);
						e.setRequestedAmount(String.valueOf(Double.valueOf(e.getRequestedAmount()==null?"0":e.getRequestedAmount())+Double.valueOf(reqAmount)));
						if(StringUtils.isBlank(invoiceId)){
							if(!poIdList.contains(poId)){
								e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+poAmount);
								e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()+poAmount);
								poIdList.add(poId);
							}
						}
						else if(!isInvoiceIdListContainsinvoiceId(invoiceIdList,invoiceId,vendorId,site_id)){
							e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+invoiceAmount);
							e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()+invoiceAmount);
							PaymentBean obj = new PaymentBean();
							obj.setStrInvoiceNo(invoiceId);
							obj.setStrVendorId(vendorId);
							obj.setStrSiteId(site_id);
							invoiceIdList.add(obj);
						}
						/*if(!poIdList.contains(poId)){
							e.setDoublePOTotalAmount(e.getDoublePOTotalAmount()+poAmount);
							e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()+poAmount);
							poIdList.add(poId);
						}*/
						e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()-Double.valueOf(reqAmount));
						
					}
				}
				
				serialNo++;
				indentObj = new PaymentBean();
				indentObj.setIntSerialNo(serialNo);
				indentObj.setVendorGroupSerialNo(vendorGroupSerialNo);
				indentObj.setStrInvoiceNo(invoiceId);
				indentObj.setStrPONo(poId);
				String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
				String podate=prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString();
				indentObj.setStrVendorName(vendorName);
				indentObj.setStrVendorId(vendorId);
				indentObj.setStrSiteId(site_id);
				indentObj.setRequestedAmount(reqAmount);
				String  paymentReqDate =(prods.get("PAYMENT_REQ_DATE")==null ? "" : prods.get("PAYMENT_REQ_DATE").toString());
				String receviedDate=prods.get("INVOICE_RECEIVED_DATE")==null ? "" : prods.get("INVOICE_RECEIVED_DATE").toString();
				String remarks = prods.get("REMARKS")==null ? "" : prods.get("REMARKS").toString();
				indentObj.setStrRemarks(remarks);
				indentObj.setStrRemarksForView(remarks.replace("@@@", ","));
				indentObj.setIntPaymentId(Integer.parseInt(prods.get("PAYMENT_ID")==null ? "" : prods.get("PAYMENT_ID").toString()));
				indentObj.setIntPaymentDetailsId(Integer.parseInt(prods.get("PAYMENT_DETAILS_ID")==null ? "0" : prods.get("PAYMENT_DETAILS_ID").toString()));
				indentObj.setIntSiteWisePaymentId(Integer.parseInt(prods.get("SITEWISE_PAYMENT_NO")==null ? "0" : prods.get("SITEWISE_PAYMENT_NO").toString()));
				indentObj.setStrSiteName(site_name);
				indentObj.setPaymentType(prods.get("PAYMENT_TYPE")==null ? "" : prods.get("PAYMENT_TYPE").toString());
				String paymentMode = prods.get("PAYMENT_MODE")==null ? "" : prods.get("PAYMENT_MODE").toString();
				indentObj.setPaymentMode(paymentMode);
				if(StringUtils.isNotBlank(paymentMode)){
				indentObj.setPaymentModeName(prods.get("PAYMENT_MODE_NAME")==null ? "" : prods.get("PAYMENT_MODE_NAME").toString());
				}
				else{
					indentObj.setPaymentModeName("--SELECT--");
				}
				indentObj.setUtrChequeNo(prods.get("UTR_CHQNO")==null ? "" : prods.get("UTR_CHQNO").toString());
								
				indentObj.setDoubleInvoiceAmount(invoiceAmount);
				indentObj.setDoublePOTotalAmount(poAmount);
				
				indentObj.setIntTempPaymentTransactionId(Integer.parseInt(prods.get("TEMP_PAYMENT_TRANSACTIONS_ID")==null ? "" : prods.get("TEMP_PAYMENT_TRANSACTIONS_ID").toString()));
				indentObj.setIntAccDeptPaymentProcessId(Integer.parseInt(prods.get("ACCOUNTS_DEPT_PMT_PROSS_ID")==null ? "" : prods.get("ACCOUNTS_DEPT_PMT_PROSS_ID").toString()));
				indentObj.setDoubleCreditTotalAmount(Double.valueOf(prods.get("CREDIT_TOTAL_AMOUNT")==null ? "0" : prods.get("CREDIT_TOTAL_AMOUNT").toString()));
				indentObj.setStrCreditNoteNumber(prods.get("CREDIT_NOTE_NUMBER")==null ? "" : prods.get("CREDIT_NOTE_NUMBER").toString());
				indentObj.setDoubleSecurityDeposit(Double.valueOf(prods.get("SECURITY_DEPOSIT_AMOUNT")==null ? "0" : prods.get("SECURITY_DEPOSIT_AMOUNT").toString()));
				String strIndentEntryId = prods.get("INDENT_ENTRY_ID")==null ? "0" : prods.get("INDENT_ENTRY_ID").toString();
			    indentObj.setIntIndentEntryId(Integer.parseInt(strIndentEntryId));
			    indentObj.setDoublePOAdvancePayment(Double.valueOf(prods.get("REMAINING_AMOUNT")==null ? "0" : prods.get("REMAINING_AMOUNT").toString()));
			    indentObj.setDoubleAdjustAmountFromAdvance(Double.valueOf(prods.get("ADJUST_AMOUNT_FROM_ADVANCE")==null ? "0" : prods.get("ADJUST_AMOUNT_FROM_ADVANCE").toString()));
			    double paidAmount = Double.valueOf(prods.get("PAYMENT_DONE_UPTO")==null ? "0" : prods.get("PAYMENT_DONE_UPTO").toString());
			    indentObj.setDoublePaymentDoneUpto(paidAmount);
			    indentObj.setDoublePaymentRequestedUpto(Double.valueOf(prods.get("PAYMENT_REQ_UPTO")==null ? "0" : prods.get("PAYMENT_REQ_UPTO").toString()));
			    if(invoiceAmount==0.0){indentObj.setDoubleBalanceAmount(poAmount-paidAmount);}
			    else {indentObj.setDoubleBalanceAmount(invoiceAmount-paidAmount);}
			    String paymentRequestReceivedDate = prods.get("CREATION_DATE")==null ? "" : prods.get("CREATION_DATE").toString();
				

				SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				try{

					/*Date receive_date = dt.parse(receviedDate);*/
					
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat time1 = new SimpleDateFormat("hh:mm aa");
					if(!paymentReqDate.equals("")){

						Date p_date = dt.parse(paymentReqDate);
						paymentReqDate = dt1.format(p_date);
					}
					if(!podate.equals("")){
						Date po_date = dt.parse(podate);
						podate = dt1.format(po_date);
					}
					if(!invoicedate.equals("")){
						Date invoice_date = dt.parse(invoicedate);
						invoicedate = dt1.format(invoice_date);
					}
					if(!receviedDate.equals("")){
						Date recevied_Date = dt.parse(receviedDate);
						receviedDate = dt1.format(recevied_Date);
					}
					if(!paymentRequestReceivedDate.equals("")){

						Date paymentRequest_ReceivedDate = dt.parse(paymentRequestReceivedDate);
						paymentRequestReceivedDate = dt1.format(paymentRequest_ReceivedDate);
						paymentRequestReceivedDate +=" "+ time1.format(paymentRequest_ReceivedDate);
						}
				}
			
				catch(Exception e){
					e.printStackTrace();
				}
			
				indentObj.setStrInvoiceDate(invoicedate);
				indentObj.setStrPODate(podate);
				indentObj.setRequestedDate(paymentReqDate);
				indentObj.setStrInvoiceReceivedDate(receviedDate);
				indentObj.setStrPaymentRequestReceivedDate(paymentRequestReceivedDate);			
				/*** display image ***/
			    for(int i=0;i<3;i++){
			    String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
				File f = new File(rootFilePath+site_id+"/"+vendorName+"_"+invoiceId+"_"+strIndentEntryId+"_Part"+i+".jpg");

				if(f.exists()){
					
					indentObj.setHasImage(true);break;
					/*DataInputStream dis = new DataInputStream(new FileInputStream(f));
					byte[] barray = new byte[(int) f.length()];
					dis.readFully(barray); 
					byte[] encodeBase64 = Base64.encodeBase64(barray);
					String base64Encoded = new String(encodeBase64, "UTF-8");
					switch(i){
					case 0: indentObj.setInvoiceImage0(base64Encoded);break;
					case 1: indentObj.setInvoiceImage1(base64Encoded);break;
					case 2: indentObj.setInvoiceImage2(base64Encoded);break;
					case 3: indentObj.setInvoiceImage3(base64Encoded);break;
					}*/
					
					
				}
			    }
			    /**** END ***/
				list.add(indentObj);
			}

		}//if
		} catch (Exception ex) {
			ex.printStackTrace();
		  } finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;

}
	@Override
	public String getPendingEmpId(String strUserId){
		
		String pendingEmpId="";
		String query = "select APPROVER_EMP_ID FROM SUMADHURA_APPROVER_MAPPING_DTL SPAMD  WHERE  EMP_ID='"+strUserId+"'  and STATUS = 'A' AND MODULE_TYPE='PAYMENT'";
		pendingEmpId = jdbcTemplate.queryForObject(query, String.class);

		
		
		
		return pendingEmpId;
	}
	@Override
	public int  saveApprovalDetails(String paymentId,String strUserId,String comments,String paymentDetailsId,String site_id){
	
		int count=0;
		int returnValue=0;
		
		String query = "insert into ACC_SITE_APPR_REJECT_DTLS(PAYMENT_APROV_REJECT_SEQ,PAYMENT_ID,EMP_ID,OPERATION_TYPE,REMARKS,PAYMENT_DETAILS_ID,SITE_ID,CREATED_DATE,STATUS)values(PAYMENT_APPROVE_REJECT_SEQ_ID.nextval,"+Integer.parseInt(paymentId)+",'"+strUserId+"',"+"'A'"+",'"+comments+"',"+Integer.parseInt(paymentDetailsId)+",'"+site_id+"',sysdate,'A')";

 		count = jdbcTemplate.update(query, new Object[] {
				
				});
		/*if(count>0){
			
			String sql="update ACC_PAYMENT_DTLS set REQUEST_PENDING_EMP_ID = '"+pendingEmpId+"'  where STATUS ='A' and PAYMENT_DETAILS_ID=?";
			
			returnValue=jdbcTemplate.update(sql, new Object[]  {paymentDetailsId});
			
		}*/

	
	return count;
	
	
}
	@Override
	public int  saveRejectDetails(String paymentId,String strUserId,String comments,String paymentDetailsId,String site_id){
		
		int count=0;
		int returnValue=0;
		
		String query = "insert into ACC_SITE_APPR_REJECT_DTLS(PAYMENT_APROV_REJECT_SEQ,PAYMENT_ID,EMP_ID,OPERATION_TYPE,REMARKS,PAYMENT_DETAILS_ID,SITE_ID,CREATED_DATE)values(PAYMENT_APPROVE_REJECT_SEQ_ID.nextval,"+Integer.parseInt(paymentId)+",'"+strUserId+"','R','"+comments+"',"+Integer.parseInt(paymentDetailsId)+",'"+site_id+"',sysdate)";

		count = jdbcTemplate.update(query, new Object[] {});
		if(count>0){
			
			String sql="update ACC_PAYMENT_DTLS set STATUS = 'I'  where PAYMENT_DETAILS_ID=?";
			returnValue = jdbcTemplate.update(sql, new Object[]  {paymentDetailsId});
			
		}
		return returnValue;
	
	
}
	@Override
	public int saveChangedDetails(PaymentBean objPaymentBean,String paymentChangedType){
		
		int count=0;
		String query = "insert into ACC_SITE_PAYMENT_CHANGED_DTLS(PAYMENT_CHNG_DTLS_ID,PAYMENT_DETAILS_ID,ACTUAL_REQ_AMOUNT,CHANGED_REQ_AMOUNT,ACTUAL_PAYMENT_DATE,CHANGED_PAYMENT_DATE,CREATION_DATE,PAYMENT_CHANGE_ACTION,EMP_ID,REMARKS,ACTUAL_ADJUST_AMOUNT,CHANGED_ADJUST_AMOUNT)"
					+" values (PAYMENT_CHANGED_DTLS_SEQ.nextval,?,?,?,?,?,sysdate,?,?,?,?,?)";

		count = jdbcTemplate.update(query, new Object[] {
				objPaymentBean.getIntPaymentDetailsId(),objPaymentBean.getActualRequestedAmount(),
				objPaymentBean.getRequestedAmount(),objPaymentBean.getActualRequestedDate(),
				objPaymentBean.getRequestedDate(),paymentChangedType,objPaymentBean.getStrEmployeeId(),objPaymentBean.getStrRemarks(),
				objPaymentBean.getActualDoubleAdjustAmountFromAdvance(),objPaymentBean.getDoubleAdjustAmountFromAdvance()});
		
		return count;
		
	}
	@Override
	public int UpDatePaymentDetails(String paymentDetailsId,double changedAmount){
		
		String query="";
		int responseCount=0;
		
		query = "update ACC_PAYMENT_DTLS set REQ_AMOUNT = '"+changedAmount+"'  ,UPDATE_DATE=sysdate  where STATUS ='A' and PAYMENT_DETAILS_ID=?";
		responseCount = jdbcTemplate.update(query, new Object[]  {paymentDetailsId});
		
		return responseCount;
	}
	@Override
	public int updatePaymentDetailsAdjustAmount(String paymentDetailsId, double doubleAdjustAmountFromAdvance) {
		
		String query="";
		int responseCount=0;
		
		query = "update ACC_PAYMENT_DTLS set  ADJUST_AMOUNT_FROM_ADVANCE = '"+doubleAdjustAmountFromAdvance+"' ,UPDATE_DATE=sysdate  where STATUS ='A' and PAYMENT_DETAILS_ID=?";
		responseCount = jdbcTemplate.update(query, new Object[]  {paymentDetailsId});
		
		return responseCount;
	}
	
@Override
public String getDeptId(String strUserId){
		
		String pendingDeptId="";
		String query = "SELECT APPROVER_DEPT_ID FROM SUMADHURA_APPROVER_MAPPING_DTL where EMP_ID ='"+strUserId+"' AND MODULE_TYPE='PAYMENT'";
		pendingDeptId = jdbcTemplate.queryForObject(query, String.class);
	
		return pendingDeptId;
	}
@Override
public int updateRequestedPaymentEmpId(String paymentDetailsId,String pendingEmpId){
	
	String query="";
	int responseCount=0;
	
	query = "update ACC_PAYMENT_DTLS set REQUEST_PENDING_EMP_ID = '"+pendingEmpId+"'  where STATUS ='A' and PAYMENT_DETAILS_ID=?";
	responseCount = jdbcTemplate.update(query, new Object[]  {paymentDetailsId});

	return responseCount;
}
@Override
public int updateRequestedPaymentDeptId(String paymentDetailsId,String pendingDeptId){
	
	String query="";
	int responseCount=0;
	
	query = "update ACC_PAYMENT_DTLS set REQUEST_PENDING_DEPT_ID = '"+pendingDeptId+"', REQUEST_PENDING_EMP_ID = '-'  where STATUS ='A' and PAYMENT_DETAILS_ID=?";
	responseCount = jdbcTemplate.update(query, new Object[]  {paymentDetailsId});

	return responseCount;
}
@Override
public int updateRequestedPaymentDeptIdOnAccDeptReject(String paymentDetailsId,String pendingEmpId){
	
	String query="";
	int responseCount=0;
	// make payment pending at site 3rd level 
	/*query = "update ACC_PAYMENT_DTLS set REQUEST_PENDING_DEPT_ID = '-', REQUEST_PENDING_EMP_ID = '"+pendingEmpId+"'  where PAYMENT_DETAILS_ID=?";
	responseCount = jdbcTemplate.update(query, new Object[]  {paymentDetailsId});*/

	return responseCount;
}
@Override
public int updatePaymentDetailsDate(String paymentDetailsId,String  changedDate){
	
	String query="";
	int responseCount=0;
	
	query = "update ACC_PAYMENT_DTLS set PAYMENT_REQ_DATE = ? ,UPDATE_DATE=sysdate  where STATUS ='A' and PAYMENT_DETAILS_ID=?";
	responseCount = jdbcTemplate.update(query, new Object[]  {DateUtil.convertToJavaDateFormat(changedDate),Integer.parseInt(paymentDetailsId)});
	
	return responseCount;
}


@Override
public int getSiteWisePaymentNo(String site_id) {
	String query = "select max(SITEWISE_PAYMENT_NO) from ACC_PAYMENT_DTLS APD,ACC_PAYMENT AP where APD.PAYMENT_ID = AP.PAYMENT_ID and AP.SITE_ID = '"+site_id+"'";

	int value = jdbcTemplate.queryForInt(query);

	return value+1;
}

@Override//not completed
public int saveAccountsDeptTable(PaymentBean objPaymentBean){
	
	int count=0;
	String query = "insert into ACC_ACCOUNTS_DEPT_PMT_PROSS(ACCOUNTS_DEPT_PMT_PROSS_ID,ACCOUNT_DEPT_REQ_REC_AMOUNT,ALLOCATED_AMOUNT,PENDING_AMOUNT,PROCESS_INTIATE_AMOUNT,STATUS,PAYMENT_REQ_SITE_ID,REQ_RECEIVE_FROM,CREATION_DATE,PAYMENT_DETAILS_ID,ADJUST_AMOUNT_FROM_ADVANCE,ADJUST_INTIATE_AMOUNT)"
				+" values (ACCOUNTS_DEPT_PMT_PROSS_SEQ.nextval,?,?,?,?,?,?,?,sysdate,?,?,?)";

	count = jdbcTemplate.update(query, new Object[] {
			
			objPaymentBean.getRequestedAmount(),0,objPaymentBean.getRequestedAmount(),0,
			
			"A",objPaymentBean.getStrSiteId(),objPaymentBean.getStrEmployeeId(),
			
			objPaymentBean.getIntPaymentDetailsId(),objPaymentBean.getDoubleAdjustAmountFromAdvance(),0
	});
	
	return count;
	
}




	@Override
	public List<PaymentBean> getAccDeptPaymentPendingDetails(String strUserId) {
		
		//Because we changed dept id 997 to 997_B_1 & 997_H_1  , so we have to know which dept id is specifically.
		String  accDeptId = jdbcTemplate.queryForObject("select DEPT_ID from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID = '"+strUserId+"'", String.class);
		
		String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
		File f = null;
		
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		List<Map<String, Object>> paymentDtls = null;
		double invoiceAmount=0.0;
		double poAmount=0.0;
		int i = 0;

		String query = "select AP.INVOICE_NUMBER,AP.INVOICE_AMOUNT,AP.PAYMENT_DONE_UPTO,AP.INVOICE_DATE,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,VND.VENDOR_NAME,AVSD.SECURITY_DEPOSIT_AMOUNT ,AP.INVOICE_RECEIVED_DATE,AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.VENDOR_ID,AP.SITE_ID,AP.INDENT_ENTRY_ID,AP.PAYMENT_ID, "
					+ " APD.PAYMENT_REQ_DATE,APD.PAYMENT_DETAILS_ID,APD.SITEWISE_PAYMENT_NO,APD.PAYMENT_TYPE,S.SITE_NAME,AADPP.ACCOUNT_DEPT_REQ_REC_AMOUNT,AADPP.PROCESS_INTIATE_AMOUNT,APD.REMARKS ,AADPP.ACCOUNTS_DEPT_PMT_PROSS_ID,AADPP.CREATION_DATE,AADPP.REQ_RECEIVE_FROM,AADPP.PAYMENT_DETAILS_ID,AP.PAYMENT_DONE_UPTO,AP.PAYMENT_REQ_UPTO  "
					+ ",(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT ,AADPP.ADJUST_AMOUNT_FROM_ADVANCE,AADPP.ADJUST_INTIATE_AMOUNT  "
					+ " from VENDOR_DETAILS VND,SITE S ,ACC_PAYMENT_DTLS APD,ACC_ACCOUNTS_DEPT_PMT_PROSS AADPP," 
					+ " ACC_PAYMENT AP "
					+ " LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = AP.VENDOR_ID AND AVSD.SITE_ID = AP.SITE_ID AND AVSD.STATUS = 'A'  " 
					+ " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = AP.PO_NUMBER "
					+ " where APD.PAYMENT_ID = AP.PAYMENT_ID and  APD.PAYMENT_DETAILS_ID = AADPP.PAYMENT_DETAILS_ID "
					+ " and AP.VENDOR_ID = VND.VENDOR_ID " 
					+ " and AP.SITE_ID = S.SITE_ID and APD.REQUEST_PENDING_DEPT_ID = ? and AADPP.STATUS = 'A' "
		/*+ "and AADPP.ACCOUNT_DEPT_REQ_REC_AMOUNT > AADPP.PROCESS_INTIATE_AMOUNT";*/
					+" order by VND.VENDOR_NAME asc, S.SITE_NAME asc, APD.PAYMENT_REQ_DATE asc, AADPP.CREATION_DATE asc  ";
		paymentDtls = jdbcTemplate.queryForList(query, new Object[] {accDeptId});
		int vendorGroupSerialNo = 0;
		String currentVendorId="-";
		String currentSiteId="-";
		List<PaymentBean> invoiceIdList = new ArrayList<PaymentBean>();
		List<String> poIdList = new ArrayList<String>();
		for(Map<String, Object> paymentReqs : paymentDtls) {
			double reqRecAmount = Double.valueOf(paymentReqs.get("ACCOUNT_DEPT_REQ_REC_AMOUNT")==null ? "0" :   paymentReqs.get("ACCOUNT_DEPT_REQ_REC_AMOUNT").toString());
			double procIntiateAmount = Double.valueOf(paymentReqs.get("PROCESS_INTIATE_AMOUNT")==null ? "0" :   paymentReqs.get("PROCESS_INTIATE_AMOUNT").toString());
			if(reqRecAmount<=procIntiateAmount){continue;}
			double adjustAmountFromAdvance = Double.valueOf(paymentReqs.get("ADJUST_AMOUNT_FROM_ADVANCE")==null ? "0" : paymentReqs.get("ADJUST_AMOUNT_FROM_ADVANCE").toString());
			double adjustIntiateAmount = Double.valueOf(paymentReqs.get("ADJUST_INTIATE_AMOUNT")==null ? "0" : paymentReqs.get("ADJUST_INTIATE_AMOUNT").toString());
			i = i+1;
			String invoiceId = paymentReqs.get("INVOICE_NUMBER")==null ? "" : paymentReqs.get("INVOICE_NUMBER").toString();
			String poId = paymentReqs.get("PO_NUMBER")==null ? "" : paymentReqs.get("PO_NUMBER").toString();
			invoiceAmount=Math.round(Double.parseDouble(paymentReqs.get("INVOICE_AMOUNT")==null ? "" : paymentReqs.get("INVOICE_AMOUNT").toString()));
			poAmount=Math.round(Double.parseDouble(paymentReqs.get("PO_AMOUNT")==null ? "" : paymentReqs.get("PO_AMOUNT").toString()));
			String vendorName = paymentReqs.get("VENDOR_NAME")==null ? "" : paymentReqs.get("VENDOR_NAME").toString();
			String vendorId = paymentReqs.get("VENDOR_ID")==null ? "" : paymentReqs.get("VENDOR_ID").toString();
			double reqAmount = reqRecAmount-procIntiateAmount;
			String site_id = paymentReqs.get("SITE_ID")==null ? "" : paymentReqs.get("SITE_ID").toString();
			String site_name = paymentReqs.get("SITE_NAME")==null ? "" : paymentReqs.get("SITE_NAME").toString();
			if(!currentVendorId.equals(vendorId)||!currentSiteId.equals(site_id))
			{
				vendorGroupSerialNo++;
				PaymentBean indentObj = new PaymentBean();
				indentObj.setStrVendorId(vendorId);
				indentObj.setStrVendorName(vendorName);
				indentObj.setStrSiteId(site_id);
				indentObj.setStrSiteName(site_name);
				indentObj.setVendorHeader(true);
				indentObj.setVendorGroupSerialNo(vendorGroupSerialNo);
				list.add(indentObj);
				currentVendorId=vendorId;
				currentSiteId=site_id;
				
			}
			
			for(PaymentBean e:list){
				if(e.isVendorHeader()&&e.getStrVendorId().equals(vendorId)&&e.getStrSiteId().equals(site_id)){
					e.setIntNoofPaymentsVendorWise(e.getIntNoofPaymentsVendorWise()+1);
					e.setRequestedAmount(String.valueOf(Double.valueOf(e.getRequestedAmount()==null?"0":e.getRequestedAmount())+reqAmount));
					if(StringUtils.isBlank(invoiceId)){
						if(!poIdList.contains(poId)){
							e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+poAmount);
							e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()+poAmount);
							poIdList.add(poId);
						}
					}
					else if(!isInvoiceIdListContainsinvoiceId(invoiceIdList,invoiceId,vendorId,site_id)){
						e.setDoubleInvoiceAmount(e.getDoubleInvoiceAmount()+invoiceAmount);
						e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()+invoiceAmount);
						PaymentBean obj = new PaymentBean();
						obj.setStrInvoiceNo(invoiceId);
						obj.setStrVendorId(vendorId);
						obj.setStrSiteId(site_id);
						invoiceIdList.add(obj);
					}
					/*if(!poIdList.contains(poId)){
						e.setDoublePOTotalAmount(e.getDoublePOTotalAmount()+poAmount);
						e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()+poAmount);
						poIdList.add(poId);
					}*/
					e.setDoubleBalanceAmount(e.getDoubleBalanceAmount()-reqAmount);
					
				}
			}
			

			PaymentBean objPaymentBean = new PaymentBean();


			objPaymentBean.setVendorGroupSerialNo(vendorGroupSerialNo);
			objPaymentBean.setStrInvoiceNo(invoiceId);
			objPaymentBean.setDoubleInvoiceAmount(invoiceAmount);
			objPaymentBean.setDoublePaymentDoneUpto(Double.valueOf(paymentReqs.get("PAYMENT_DONE_UPTO")==null ? "0" : paymentReqs.get("PAYMENT_DONE_UPTO").toString()));
			objPaymentBean.setStrPONo(poId);
			String invoicedate = paymentReqs.get("INVOICE_DATE")==null ? "" :   paymentReqs.get("INVOICE_DATE").toString();
			objPaymentBean.setStrVendorName(vendorName);
			String receviedDate = paymentReqs.get("INVOICE_RECEIVED_DATE")==null ? "" :   paymentReqs.get("INVOICE_RECEIVED_DATE").toString();
			String paymentDate = paymentReqs.get("PAYMENT_REQ_DATE")==null ? "" :   paymentReqs.get("PAYMENT_REQ_DATE").toString();
			objPaymentBean.setIntSiteWisePaymentId(Integer.parseInt(paymentReqs.get("SITEWISE_PAYMENT_NO")==null ? "0" :   paymentReqs.get("SITEWISE_PAYMENT_NO").toString()));
			objPaymentBean.setStrSiteName(site_name);
			objPaymentBean.setDoubleAmountToBeReleased(reqRecAmount-procIntiateAmount);
			
			objPaymentBean.setPaymentType(paymentReqs.get("PAYMENT_TYPE")==null ? "" :   paymentReqs.get("PAYMENT_TYPE").toString());
			String remarks = paymentReqs.get("REMARKS")==null ? "" :   paymentReqs.get("REMARKS").toString();
			objPaymentBean.setStrRemarks(remarks);
			objPaymentBean.setStrRemarksForView(remarks.replace("@@@", ","));
			objPaymentBean.setIntPaymentId(Integer.parseInt(paymentReqs.get("PAYMENT_ID")==null ? "" :   paymentReqs.get("PAYMENT_ID").toString()));
			objPaymentBean.setIntPaymentDetailsId(Integer.parseInt(paymentReqs.get("PAYMENT_DETAILS_ID")==null ? "" :   paymentReqs.get("PAYMENT_DETAILS_ID").toString()));
			objPaymentBean.setIntAccDeptPaymentProcessId(Integer.parseInt(paymentReqs.get("ACCOUNTS_DEPT_PMT_PROSS_ID")==null ? "" :   paymentReqs.get("ACCOUNTS_DEPT_PMT_PROSS_ID").toString()));
			objPaymentBean.setIntSerialNo(i);
			objPaymentBean.setDoublePOTotalAmount(poAmount);
			String  poDate =(paymentReqs.get("PO_DATE")==null ? "" : paymentReqs.get("PO_DATE").toString());
			objPaymentBean.setDoubleCreditTotalAmount(Double.valueOf(paymentReqs.get("CREDIT_TOTAL_AMOUNT")==null ? "0" : paymentReqs.get("CREDIT_TOTAL_AMOUNT").toString()));
			objPaymentBean.setStrCreditNoteNumber(paymentReqs.get("CREDIT_NOTE_NUMBER")==null ? "" : paymentReqs.get("CREDIT_NOTE_NUMBER").toString());
			objPaymentBean.setDoubleSecurityDeposit(Double.valueOf(paymentReqs.get("SECURITY_DEPOSIT_AMOUNT")==null ? "0" : paymentReqs.get("SECURITY_DEPOSIT_AMOUNT").toString()));
		    objPaymentBean.setStrVendorId(vendorId);
			objPaymentBean.setStrSiteId(site_id);
			String strIndentEntryId = paymentReqs.get("INDENT_ENTRY_ID")==null ? "0" : paymentReqs.get("INDENT_ENTRY_ID").toString();
			objPaymentBean.setIntIndentEntryId(Integer.parseInt(strIndentEntryId));
			String paymentRequestReceivedDate = paymentReqs.get("CREATION_DATE")==null ? "" : paymentReqs.get("CREATION_DATE").toString();
			objPaymentBean.setDoublePOAdvancePayment(Double.valueOf(paymentReqs.get("REMAINING_AMOUNT")==null ? "0" : paymentReqs.get("REMAINING_AMOUNT").toString()));
			objPaymentBean.setDoublePaymentDoneUpto(Double.valueOf(paymentReqs.get("PAYMENT_DONE_UPTO")==null ? "0" : paymentReqs.get("PAYMENT_DONE_UPTO").toString()));
		    objPaymentBean.setDoublePaymentRequestedUpto(Double.valueOf(paymentReqs.get("PAYMENT_REQ_UPTO")==null ? "0" : paymentReqs.get("PAYMENT_REQ_UPTO").toString()));
		    objPaymentBean.setDoubleAdjustAmountFromAdvance(adjustAmountFromAdvance-adjustIntiateAmount);
		    objPaymentBean.setRequestReceiveFrom(paymentReqs.get("REQ_RECEIVE_FROM")==null ? "" : paymentReqs.get("REQ_RECEIVE_FROM").toString());
		    
			SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			try{
				
				SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
				SimpleDateFormat time1 = new SimpleDateFormat("hh:mm aa");
				
				if(!receviedDate.equals("")){

					Date receive_date = dt.parse(receviedDate);
					receviedDate = dt1.format(receive_date);
					}
				if(!invoicedate.equals("")){

				Date invoice_date = dt.parse(invoicedate);
				invoicedate = dt1.format(invoice_date);
				}
				if(!poDate.equals("")){

					Date po_date = dt.parse(poDate);
					poDate = dt1.format(po_date);
					}
				if(!paymentDate.equals("")){

					Date payment_date = dt.parse(paymentDate);
					paymentDate = dt1.format(payment_date);
				}
				if(!paymentRequestReceivedDate.equals("")){

					Date paymentRequest_ReceivedDate = dt.parse(paymentRequestReceivedDate);
					paymentRequestReceivedDate = dt1.format(paymentRequest_ReceivedDate);
					paymentRequestReceivedDate +=" "+ time1.format(paymentRequest_ReceivedDate);
					}
				
			}
		
			catch(Exception e){
				e.printStackTrace();
			}
		
			objPaymentBean.setStrInvoiceReceivedDate(receviedDate);
			objPaymentBean.setStrInvoiceDate(invoicedate);
			objPaymentBean.setStrPODate(poDate);
			objPaymentBean.setStrPaymentReqDate(paymentDate);
			objPaymentBean.setStrPaymentRequestReceivedDate(paymentRequestReceivedDate);			
			/*** display image ***/
			try{
		    for(int index=0;index<3;index++){
		    f = new File(rootFilePath+site_id+"/"+vendorName+"_"+invoiceId+"_"+strIndentEntryId+"_Part"+index+".jpg");

			if(f.exists()){
				
				objPaymentBean.setHasImage(true);break;
				/*DataInputStream dis = new DataInputStream(new FileInputStream(f));
				byte[] barray = new byte[(int) f.length()];
				dis.readFully(barray); 
				byte[] encodeBase64 = Base64.encodeBase64(barray);
				String base64Encoded = new String(encodeBase64, "UTF-8");
				switch(index){
				case 0: objPaymentBean.setInvoiceImage0(base64Encoded);break;
				case 1: objPaymentBean.setInvoiceImage1(base64Encoded);break;
				case 2: objPaymentBean.setInvoiceImage2(base64Encoded);break;
				case 3: objPaymentBean.setInvoiceImage3(base64Encoded);break;
				}
				dis.close();*/
				
				
			}
		    }
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
		    /**** END ***/
			list.add(objPaymentBean);
		}
		return list;
	}


	public int updateAccDeptPaymentProcsstbl(String strAccDeptProcessSeqId, String strPaymentDetailsId,String strPendingEmpId,double payingAmount,double processIntiateAmount,double doubleReqAmount) {


		double tatalProcessIntiateAmount = 0;
		String	query = "";
		int result = 0;
		tatalProcessIntiateAmount = payingAmount+tatalProcessIntiateAmount;


		if(tatalProcessIntiateAmount >doubleReqAmount){


			query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set STATUS= ?,PROCESS_INTIATE_AMOUNT = PROCESS_INTIATE_AMOUNT + '"+payingAmount+"' where ACCOUNTS_DEPT_PMT_PROSS_ID = ?";
			result = jdbcTemplate.update(query, new Object[] {"I",strAccDeptProcessSeqId});

		}else{

			query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set  PROCESS_INTIATE_AMOUNT = PROCESS_INTIATE_AMOUNT + '"+payingAmount+"' where ACCOUNTS_DEPT_PMT_PROSS_ID = ?";
			result = jdbcTemplate.update(query, new Object[] { strAccDeptProcessSeqId});

		}


		return result;

	}

	/*public int updatePaymentsDetailstbl(String strAccDeptProcessSeqId, double payingAmount,double processIntiateAmount,double doubleReqAmount) {

		double tatalProcessIntiateAmount = 0;
		String	query = "";
		int result = 0;
		tatalProcessIntiateAmount = payingAmount+tatalProcessIntiateAmount;


		if(tatalProcessIntiateAmount >doubleReqAmount){


			query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set STATUS= ?,PROCESS_INTIATE_AMOUNT = PROCESS_INTIATE_AMOUNT - '"+payingAmount+"' where ACCOUNTS_DEPT_PMT_PROSS_ID = ?";
			result = jdbcTemplate.update(query, new Object[] {"A",strAccDeptProcessSeqId});

		}else{

			query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set  PROCESS_INTIATE_AMOUNT = PROCESS_INTIATE_AMOUNT - '"+payingAmount+"' where ACCOUNTS_DEPT_PMT_PROSS_ID = ?";
			result = jdbcTemplate.update(query, new Object[] { strAccDeptProcessSeqId});

		}


		return result;

	}*/

	@Override
	public int getAccTempPaymentTransactionSeqNo()

	{
		int TempPaymentId = 0;

		String query = "select  ACC_TEMP_PMT_TRANSACTIONS_SEQ.nextval from dual";

		TempPaymentId = jdbcTemplate.queryForInt(query);
		
		return TempPaymentId;
	}

	
	@Override
	public int insertTempPaymentTransactionsTbl(PaymentDto objPaymentDto, int tempPaymentId)

	{



		


		String query = "INSERT INTO ACC_TEMP_PAYMENT_TRANSACTIONS(TEMP_PAYMENT_TRANSACTIONS_ID,ACCOUNTS_DEPT_PMT_PROSS_ID,PAYMENT_DETAILS_ID,REQ_AMOUNT,REQUEST_PENDING_EMP_ID,"+
		"STATUS,PAYMENT_TYPE,PAYMENT_REQ_DATE,PAYMENT_MODE,UTR_CHQNO,REMARKS,CREATION_DATE,SITEWISE_PAYMENT_NO,UPDATE_DATE,ADJUST_AMOUNT_FROM_ADVANCE)" +
		" values(? , ?, ?, ?, ?, ?, ?, ?,?,?,?,sysdate, ?,sysdate,?)";

		int result = jdbcTemplate.update(query, new Object[] {
				tempPaymentId,objPaymentDto.getIntAccDeptPaymentProcessId(),
				objPaymentDto.getIntPaymentDetailsId(),
				objPaymentDto.getDoubleAmountToBeReleased(),objPaymentDto.getStrPendingEmpId(),"A",
				objPaymentDto.getPaymentType(),
				DateUtil.convertToJavaDateFormat(objPaymentDto.getStrPaymentReqDate()),objPaymentDto.getPaymentMode(),
				objPaymentDto.getStrRefrenceNo(),objPaymentDto.getStrRemarks(),
				objPaymentDto.getIntSiteWisePaymentId(),
				objPaymentDto.getDoubleAdjustAmountFromAdvance()

				//	productDetails.getStrTermsConditionId()

		});




		return result;
	}


	@Override
	public String getApproverEmpIdInAccounts(String strEmpId) {

		List<Map<String, Object>> pendingEmpId = null;
		String strPendingEmpId = "";
		try {
			jdbcTemplate = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String query = "select APPROVER_EMP_ID,APPROVER_DEPT_ID from SUMADHURA_APPROVER_MAPPING_DTL where EMP_ID = ? and MODULE_TYPE = 'ACCOUNTS'";

		pendingEmpId = jdbcTemplate.queryForList(query, new Object[] {strEmpId});
		for(Map<String, Object> pendingEmployeeId : pendingEmpId) {




			strPendingEmpId = pendingEmployeeId.get("APPROVER_DEPT_ID")==null ? "" :   pendingEmployeeId.get("APPROVER_DEPT_ID").toString();
			
			if(StringUtils.isBlank(strPendingEmpId)){
			strPendingEmpId = pendingEmployeeId.get("APPROVER_EMP_ID")==null ? "" :   pendingEmployeeId.get("APPROVER_EMP_ID").toString();
			}
			
			if(StringUtils.isBlank(strPendingEmpId)||strPendingEmpId.equals("-")){
				throw new NullPointerException();
			}



		}
		return strPendingEmpId;
	}
	@Override
	public int updateAccDeptPaymentProcsstbl(PaymentDto objPaymentDto) {
		String query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set PROCESS_INTIATE_AMOUNT = PROCESS_INTIATE_AMOUNT+? ,"
				+ "ADJUST_INTIATE_AMOUNT = ADJUST_INTIATE_AMOUNT+? "
				+ "where ACCOUNTS_DEPT_PMT_PROSS_ID = ? ";

				int result = jdbcTemplate.update(query, new Object[] {
						objPaymentDto.getDoubleAmountToBeReleased(),objPaymentDto.getDoubleAdjustAmountFromAdvance(),
						objPaymentDto.getIntAccDeptPaymentProcessId()

						

				});
		return result;
	}
	@Override
	public int updateTempPaymentTransactionsTbl(PaymentDto objPaymentDto,String strPendingEmpId) {
		String query = "update ACC_TEMP_PAYMENT_TRANSACTIONS set REQUEST_PENDING_EMP_ID = ?,PAYMENT_MODE=?,UTR_CHQNO=?,ADJUST_AMOUNT_FROM_ADVANCE=?,REMARKS=? "
				+ "where TEMP_PAYMENT_TRANSACTIONS_ID = ? ";

				int result = jdbcTemplate.update(query, new Object[] {
						strPendingEmpId,
						objPaymentDto.getPaymentMode(),
						objPaymentDto.getUtrChequeNo(),
						objPaymentDto.getDoubleAdjustAmountFromAdvance(),
						objPaymentDto.getStrRemarks(),
						objPaymentDto.getIntTempPaymentTransactionId()
						

						//	productDetails.getStrTermsConditionId()

				});
		return result;
	}
	@Override
	public int insertPaymentTransactionsTbl(PaymentDto objPaymentDto,int intPaymentTransactionId) {
		
		String query = "INSERT INTO ACC_PAYMENT_TRANSACTIONS(PAYMENT_TRANSACTIONS_ID,PAYMENT_DETAILS_ID,PAYMENT_ID,PAID_AMOUNT,"
				+ "PAYMENT_TYPE,PAYMENT_MODE,UTR_CHQNO,REMARKS,CREATION_DATE,SITEWISE_PAYMENT_NO,TYPE_OF_PAYMENT_SETTLEMENT,UPDATION)" +
				" values(?, ?, ?, ?, ?, ?,?,?,sysdate, ?,?,?)";

				int result = jdbcTemplate.update(query, new Object[] {
						intPaymentTransactionId,
						objPaymentDto.getIntPaymentDetailsId(),objPaymentDto.getIntPaymentId(),
						objPaymentDto.getDoubleAmountToBeReleased(),
						objPaymentDto.getPaymentType(),
						objPaymentDto.getPaymentMode(),
						objPaymentDto.getUtrChequeNo(),objPaymentDto.getStrRemarks(),
						objPaymentDto.getIntSiteWisePaymentId(),
						"REGULAR",
						"A"

				});
		
		
				/********************************************************************/
				

		return result;
	}
	@Override
	public int insertPaymentTransactionsTblAdjust(PaymentDto objPaymentDto,int intPaymentTransactionId) {

			
			String query1 = "INSERT INTO ACC_PAYMENT_TRANSACTIONS(PAYMENT_TRANSACTIONS_ID,PAYMENT_DETAILS_ID,PAYMENT_ID,PAID_AMOUNT,"
							+ "PAYMENT_TYPE,PAYMENT_MODE,UTR_CHQNO,REMARKS,CREATION_DATE,SITEWISE_PAYMENT_NO,TYPE_OF_PAYMENT_SETTLEMENT)" +
							" values(?, ?, ?, ?, ?, ?,?,?,sysdate, ?,?)";

							int result1 = jdbcTemplate.update(query1, new Object[] {
									intPaymentTransactionId,
									objPaymentDto.getIntPaymentDetailsId(),objPaymentDto.getIntPaymentId(),
									objPaymentDto.getDoubleAdjustAmountFromAdvance(),
									objPaymentDto.getPaymentType(),
									objPaymentDto.getPaymentMode(),
									objPaymentDto.getUtrChequeNo(),objPaymentDto.getStrRemarks(),
									objPaymentDto.getIntSiteWisePaymentId(),
									"ADJUST"

							});
							return result1;
							
				
	}
	
	@Override
	public int updatePaymentReqUptoInAccPaymentTable(PaymentDto objPaymentDto) {
		int result1=0;
		if(objPaymentDto.getPaymentType().equals("ADVANCE")){
			//updating PAYMENT_REQ_UPTO in ACC_PAYMENT table
			String query1 = "update ACC_PAYMENT set PAYMENT_REQ_UPTO=PAYMENT_REQ_UPTO-? where PAYMENT_ID = ? ";

							result1 = jdbcTemplate.update(query1, new Object[] {
									objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getActualDoubleAdjustAmountFromAdvance(),
									objPaymentDto.getIntPaymentId()
									
							});
			
							
		}
		else if(objPaymentDto.getPaymentType().equals("DIRECT")){
		//updating PAYMENT_DONE_UPTO & PAYMENT_REQ_UPTO in ACC_PAYMENT table
			String query1 = "update ACC_PAYMENT set PAYMENT_DONE_UPTO=PAYMENT_DONE_UPTO+?,PAYMENT_REQ_UPTO=PAYMENT_REQ_UPTO-? where PAYMENT_ID = ? ";

							result1 = jdbcTemplate.update(query1, new Object[] {
						(objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getDoubleAdjustAmountFromAdvance()),
						objPaymentDto.getDoubleAmountToBeReleased()+objPaymentDto.getActualDoubleAdjustAmountFromAdvance(),
						objPaymentDto.getIntPaymentId()
						
				});	
		}
		return result1;
	}
	
	@Override
	public int insertPoHistory(PaymentDto objPaymentDto) {
		
				
					String query = "INSERT INTO ACC_PO_HISTORY(PO_NUMBER,PO_AMOUNT,ENTRY_DATE,PAID_AMOUNT)" +
							" values( ?, ?,sysdate, ?)";

							int result = jdbcTemplate.update(query, new Object[] {
									objPaymentDto.getStrPONo(),
									objPaymentDto.getDoublePOAmount(),
									objPaymentDto.getDoubleAmountToBeReleased()
									

							});
					
									
				
		return result;
	}
	@Override
	public int insertInvoiceHistory(PaymentDto objPaymentDto,int intPaymentTransactionId) {
		String query = "INSERT INTO ACC_INVOICE_HISTORY(INVOICE_NUMBER,INVOICE_AMOUNT,ENTRY_DATE,PAID_AMOUNT,PAYMENT_MODE,REF_NO,PAYMENT_TRANSACTIONS_ID)" +
				" values( ?,?,sysdate, ?,?,?,?)";

				int result = jdbcTemplate.update(query, new Object[] {
						objPaymentDto.getStrInvoiceNo(),
						objPaymentDto.getDoubleInvoiceAmount(),
						objPaymentDto.getDoubleAmountToBeReleased(),
						objPaymentDto.getPaymentMode(),
						objPaymentDto.getUtrChequeNo(),
						intPaymentTransactionId

				});
		
					
		return result;
	}
	@Override
	public int insertInvoiceHistoryAdjust(PaymentDto objPaymentDto,int intPaymentTransactionId) {
		
			String query1 = "INSERT INTO ACC_INVOICE_HISTORY(INVOICE_NUMBER,INVOICE_AMOUNT,ENTRY_DATE,PAID_AMOUNT,PAYMENT_MODE,REF_NO,PAYMENT_TRANSACTIONS_ID)" +
					" values( ?,?,sysdate, ?,?,?,?)";

					int result1 = jdbcTemplate.update(query1, new Object[] {
							objPaymentDto.getStrInvoiceNo(),
							objPaymentDto.getDoubleInvoiceAmount(),
							objPaymentDto.getDoubleAdjustAmountFromAdvance(),
							"PO_ADJUSTMENT",
							objPaymentDto.getStrPONo(),
							intPaymentTransactionId

					});
		
		return result1;
	}
	public List<PaymentBean> getViewPaymentDetails(String fromDate, String toDate, String vendorId) {

		String query = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		String total="";
		List<Map<String, Object>> dbPOsList = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean objPaymentBean = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			
				String frontQuery = "select APT.PAYMENT_ID,APT.PAYMENT_DETAILS_ID,APT.PAID_AMOUNT,AP.VENDOR_ID,VD.VENDOR_NAME,AP.INVOICE_NUMBER,AP.INVOICE_DATE,AP.PO_NUMBER,AP.PO_DATE,AP.INDENT_ENTRY_ID,AP.SITE_ID,S.SITE_NAME,APT.CREATION_DATE,APT.PAYMENT_DATE,APT.UTR_CHQNO,APT.REMARKS "
						+ "from ACC_PAYMENT_TRANSACTIONS APT,ACC_PAYMENT AP,VENDOR_DETAILS VD,SITE S "
						+ "where APT.PAYMENT_ID = AP.PAYMENT_ID and VD.VENDOR_ID = AP.VENDOR_ID and S.SITE_ID = AP.SITE_ID and APT.TYPE_OF_PAYMENT_SETTLEMENT = 'REGULAR' and TRUNC(APT.CREATION_DATE) ";
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = frontQuery + "  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = frontQuery + "  >=TO_DATE('"+fromDate+"', 'dd-MM-yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = frontQuery + "  <=TO_DATE('"+toDate+"', 'dd-MM-yy')";
				}
			
				if(StringUtils.isNotBlank(vendorId)){
					query = query+" and AP.VENDOR_ID='"+vendorId+"'";
				}
				


			dbPOsList = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			for(Map<String, Object> po : dbPOsList) {
				serialNo++;
				objPaymentBean = new PaymentBean();
				objPaymentBean.setIntSerialNo(serialNo);
				objPaymentBean.setStrPONo(po.get("PO_NUMBER")==null ? "" : po.get("PO_NUMBER").toString());
				objPaymentBean.setStrInvoiceNo(po.get("INVOICE_NUMBER")==null ? "" : po.get("INVOICE_NUMBER").toString());
				String poDate = po.get("PO_DATE")==null ? "" : po.get("PO_DATE").toString();
				String invoiceDate = po.get("INVOICE_DATE")==null ? "" : po.get("INVOICE_DATE").toString();
				String paymentDate = po.get("PAYMENT_DATE")==null ? "" : po.get("PAYMENT_DATE").toString();
				String creationDate = po.get("CREATION_DATE")==null ? "" : po.get("CREATION_DATE").toString();
				
				objPaymentBean.setDoublePaidAmount(Double.valueOf(po.get("PAID_AMOUNT")==null ? "0" : po.get("PAID_AMOUNT").toString()));
				
				objPaymentBean.setStrVendorName(po.get("VENDOR_NAME")==null ? "" : po.get("VENDOR_NAME").toString());
				objPaymentBean.setStrVendorId(po.get("VENDOR_ID")==null ? "" : po.get("VENDOR_ID").toString());
				
				objPaymentBean.setIntPaymentId(Integer.valueOf(po.get("PAYMENT_ID")==null ? "0" : po.get("PAYMENT_ID").toString()));
				objPaymentBean.setIntPaymentDetailsId(Integer.valueOf(po.get("PAYMENT_DETAILS_ID")==null ? "0" : po.get("PAYMENT_DETAILS_ID").toString()));
				objPaymentBean.setIntIndentEntryId(Integer.valueOf(po.get("INDENT_ENTRY_ID")==null ? "0" : po.get("INDENT_ENTRY_ID").toString()));
				objPaymentBean.setStrSiteId(po.get("SITE_ID")==null ? "0" : po.get("SITE_ID").toString());
				objPaymentBean.setStrSiteName(po.get("SITE_NAME")==null ? "0" : po.get("SITE_NAME").toString());
				objPaymentBean.setUtrChequeNo(po.get("UTR_CHQNO")==null ? "" : po.get("UTR_CHQNO").toString());
				String remarks = po.get("REMARKS")==null ? "" : po.get("REMARKS").toString();
				objPaymentBean.setStrRemarksForView(remarks.replace("@@@", ","));
				
			    SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
				try{
			    	if(!poDate.equals("")){
			    		Date po_date = dt.parse(poDate);
			    		poDate = dt1.format(po_date);
			    	}
			    	if(!invoiceDate.equals("")){
			    		Date invoice_Date = dt.parse(invoiceDate);
			    		invoiceDate = dt1.format(invoice_Date);
			    	}
			    	if(!paymentDate.equals("")){
			    		Date payment_Date = dt.parse(paymentDate);
			    		paymentDate = dt1.format(payment_Date);
			    	}
			    	if(!creationDate.equals("")){
			    		Date creation_Date = dt.parse(creationDate);
			    		creationDate = dt1.format(creation_Date);
			    	}
				}catch(Exception e){
					e.printStackTrace();
				}
			    objPaymentBean.setStrPODate(poDate);
			    objPaymentBean.setStrInvoiceDate(invoiceDate);
			    objPaymentBean.setStrPaymentDate(paymentDate);
			    objPaymentBean.setStrCreatedDate(creationDate);
				list.add(objPaymentBean);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			objPaymentBean = null; 
			template = null;
			
		}
		return list;
	}
	public List<PaymentBean> viewMyPayment(String fromDate, String toDate,String site_id, String user_id) {

		String query = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		String total="";
		List<Map<String, Object>> dbPOsList = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean objPaymentBean = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			
				/*String frontQuery = "select APD.CREATION_DATE,APD.PAYMENT_ID,AP.VENDOR_ID,VD.VENDOR_NAME,AP.INVOICE_NUMBER,"
						+ "AP.PO_NUMBER,APD.PAYMENT_DETAILS_ID,APD.REQUEST_PENDING_EMP_ID,APD.REQ_AMOUNT,APD.REQUEST_PENDING_DEPT_ID,"
						+ "ATPT.REQUEST_PENDING_EMP_ID as ACC_PENDING_EMP_ID,ATPT.REQ_AMOUNT as ACC_REQ_AMOUNT"
						+ ",SED.EMP_NAME,SDD.DEPT_NAME,ATPT.REMARKS,APD.REMARKS as APD_REMARKS,AP.INDENT_ENTRY_ID,AP.INVOICE_DATE,AP.SITE_ID  " 
						+ "from VENDOR_DETAILS VD,ACC_PAYMENT AP,ACC_PAYMENT_DTLS APD LEFT OUTER JOIN ACC_TEMP_PAYMENT_TRANSACTIONS ATPT on APD.PAYMENT_DETAILS_ID = ATPT.PAYMENT_DETAILS_ID "
						+ "LEFT OUTER JOIN SUMADHURA_EMPLOYEE_DETAILS SED on (SED.EMP_ID = APD.REQUEST_PENDING_EMP_ID or SED.EMP_ID = ATPT.REQUEST_PENDING_EMP_ID) "
						+ "LEFT OUTER JOIN SUMADHURA_DEPARTMENT_DETAILS SDD on SDD.DEPT_ID = APD.REQUEST_PENDING_DEPT_ID "
						+ "where AP.PAYMENT_ID = APD.PAYMENT_ID and AP.VENDOR_ID = VD.VENDOR_ID "
						+ "and (ATPT.REQUEST_PENDING_EMP_ID NOT IN ('VND') OR ATPT.REQUEST_PENDING_EMP_ID IS NULL) "
						+ "and TRUNC(APD.CREATION_DATE) ";*/
				String frontQuery = "select APD.CREATION_DATE,APD.PAYMENT_ID,AP.VENDOR_ID,VD.VENDOR_NAME,AP.INVOICE_NUMBER,"
						+ "AP.PO_NUMBER,APD.PAYMENT_DETAILS_ID,APD.REQUEST_PENDING_EMP_ID,APD.REQ_AMOUNT,APD.REQUEST_PENDING_DEPT_ID,"
						+ "ATPT.REQUEST_PENDING_EMP_ID as ACC_PENDING_EMP_ID,ATPT.REQ_AMOUNT as ACC_REQ_AMOUNT"
						+ ",SED.EMP_NAME,ATPT.REMARKS,APD.REMARKS as APD_REMARKS,AP.INDENT_ENTRY_ID,AP.INVOICE_DATE,AP.SITE_ID  " 
						+ "from VENDOR_DETAILS VD,ACC_PAYMENT AP,ACC_PAYMENT_DTLS APD LEFT OUTER JOIN ACC_TEMP_PAYMENT_TRANSACTIONS ATPT on APD.PAYMENT_DETAILS_ID = ATPT.PAYMENT_DETAILS_ID "
						+ "LEFT OUTER JOIN SUMADHURA_EMPLOYEE_DETAILS SED on SED.EMP_ID = APD.REQUEST_PENDING_EMP_ID "
						+ "where AP.PAYMENT_ID = APD.PAYMENT_ID and AP.VENDOR_ID = VD.VENDOR_ID "
						+ "and (ATPT.REQUEST_PENDING_EMP_ID NOT IN ('VND') OR ATPT.REQUEST_PENDING_EMP_ID IS NULL) "
						+ "and TRUNC(APD.CREATION_DATE) ";
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = frontQuery + "  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = frontQuery + "  >=TO_DATE('"+fromDate+"', 'dd-MM-yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = frontQuery + "  <=TO_DATE('"+toDate+"', 'dd-MM-yy')";
				}
			

			String accDeptId = validateParams.getProperty("ACCOUNTS_DEPT_ID") == null ? "" : validateParams.getProperty("ACCOUNTS_DEPT_ID").toString();

			if(!site_id.equals(accDeptId)&&!site_id.equals("998")){
				query = query + " and AP.SITE_ID = '"+site_id+"'";
			}
			else if(site_id.equals(accDeptId)){
				// this block of code for - to display payments as per AccountsDepartment is HYD or BANGLORE.
				/** take dept_id of login employee.
				 ** decide address hyd or banglore.
				 ** take list of sites in that address.
				 ** form a String using sites to pass into query.
				*/
				String dept_id = template.queryForObject("select DEPT_ID from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID = '"+user_id+"'", new Object[]{},String.class);
				String address = "";
				if(dept_id.contains("B")){
					address="BANGLORE";
				}
				else if(dept_id.contains("H")){
					address="HYD";
				}
				List<String> siteIdList = template.queryForList("select SITE_ID from SITE where ADDRESS = '"+address+"'", new Object[]{},String.class);
				if(siteIdList.size()>0){
					String groupOfSites = "";
					for(String site:siteIdList){
						groupOfSites +="'"+site+"',";
					}
					groupOfSites = groupOfSites.substring(0,groupOfSites.length()-1);
					query = query + " and AP.SITE_ID in("+groupOfSites+")";
				}
			}
			
			dbPOsList = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			for(Map<String, Object> po : dbPOsList) {
				serialNo++;
				objPaymentBean = new PaymentBean();
				objPaymentBean.setIntSerialNo(serialNo);
				objPaymentBean.setStrPONo(po.get("PO_NUMBER")==null ? "" : po.get("PO_NUMBER").toString());
				objPaymentBean.setStrInvoiceNo(po.get("INVOICE_NUMBER")==null ? "" : po.get("INVOICE_NUMBER").toString());
				String poDate = po.get("PO_DATE")==null ? "" : po.get("PO_DATE").toString();//not in query
				String invoiceDate = po.get("INVOICE_DATE")==null ? "" : po.get("INVOICE_DATE").toString();//not in query
				String createdDate = po.get("CREATION_DATE")==null ? "" : po.get("CREATION_DATE").toString();
				
				objPaymentBean.setStrVendorName(po.get("VENDOR_NAME")==null ? "" : po.get("VENDOR_NAME").toString());
				objPaymentBean.setStrVendorId(po.get("VENDOR_ID")==null ? "" : po.get("VENDOR_ID").toString());
				
				objPaymentBean.setIntIndentEntryId(Integer.valueOf(po.get("INDENT_ENTRY_ID")==null ? "" : po.get("INDENT_ENTRY_ID").toString()));
				objPaymentBean.setStrInvoiceDate(po.get("INVOICE_DATE")==null ? "" : po.get("INVOICE_DATE").toString());
				objPaymentBean.setStrSiteId(po.get("SITE_ID")==null ? "" : po.get("SITE_ID").toString());
				
				String remarks = po.get("REMARKS")==null ? "" : po.get("REMARKS").toString();
				if(StringUtils.isBlank(remarks)){
					remarks = po.get("APD_REMARKS")==null ? "" : po.get("APD_REMARKS").toString();
				}
				objPaymentBean.setStrRemarksForView(remarks.replace("@@@", ","));
				
				objPaymentBean.setIntPaymentId(Integer.valueOf(po.get("PAYMENT_ID")==null ? "0" : po.get("PAYMENT_ID").toString()));
				objPaymentBean.setIntPaymentDetailsId(Integer.valueOf(po.get("PAYMENT_DETAILS_ID")==null ? "0" : po.get("PAYMENT_DETAILS_ID").toString()));
				String pendingEmpId = po.get("REQUEST_PENDING_EMP_ID")==null ? "" : po.get("REQUEST_PENDING_EMP_ID").toString();
				String pendingEmpName = po.get("EMP_NAME")==null ? "" : po.get("EMP_NAME").toString();
				double reqAmount = Double.valueOf(po.get("REQ_AMOUNT")==null ? "0" : po.get("REQ_AMOUNT").toString());
				String pendingDeptId = po.get("REQUEST_PENDING_DEPT_ID")==null ? "" : po.get("REQUEST_PENDING_DEPT_ID").toString();
				String accPendingEmpId = po.get("ACC_PENDING_EMP_ID")==null ? "" : po.get("ACC_PENDING_EMP_ID").toString();
				double accTransactionAmount = Double.valueOf(po.get("ACC_REQ_AMOUNT")==null ? "0" : po.get("ACC_REQ_AMOUNT").toString());
				
				objPaymentBean.setDoubleAmountToBeReleased(reqAmount);
				objPaymentBean.setDoubleTransactionAmount(accTransactionAmount);
				objPaymentBean.setDoubleTransactionAmount(accTransactionAmount);
				if(StringUtils.isNotBlank(pendingEmpId) && !pendingEmpId.equals("-")){
					objPaymentBean.setStrPendingDeptName("SITE");
					objPaymentBean.setStrPendingEmpName(pendingEmpName);
				}
				else if(StringUtils.isNotBlank(pendingDeptId) && pendingDeptId.contains(accDeptId)){
					objPaymentBean.setStrPendingDeptName("Accounts Department");
					
					if(accPendingEmpId.contains("2")){
						objPaymentBean.setStrPendingEmpName("Second Level");
					}
					else if(accPendingEmpId.contains("3")){
						objPaymentBean.setStrPendingEmpName("Third Level");
					}
					else {
						objPaymentBean.setStrPendingEmpName("First Level");
					}
					
					/*objPaymentBean.setStrPendingEmpName(pendingEmpName);
					if(StringUtils.isBlank(pendingEmpName)){
						String query1 = "select SED.EMP_NAME from SUMADHURA_APPROVER_MAPPING_DTL SAMD join SUMADHURA_EMPLOYEE_DETAILS SED on SED.EMP_ID=SAMD.EMP_ID where SAMD.MODULE_TYPE = 'ACCOUNTS' and  SAMD.EMP_ID not in(select APPROVER_EMP_ID from SUMADHURA_APPROVER_MAPPING_DTL where MODULE_TYPE = 'ACCOUNTS')";
						try {
							pendingEmpName = template.queryForObject(query1, String.class);
						} catch (IncorrectResultSizeDataAccessException e) {
							pendingEmpName = "First Level";
							objPaymentBean.setStrPendingEmpName(pendingEmpName);
						}
						if(!pendingEmpName.equals("First Level")){
							objPaymentBean.setStrPendingEmpName(pendingEmpName);
						}
					}*/
					if(accPendingEmpId.equals("VND")){
						objPaymentBean.setStrPendingDeptName("VND");
						objPaymentBean.setStrPendingEmpName("VND");
					}
				}
				
				SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
				try{
			    	if(!poDate.equals("")){
			    		Date po_date = dt.parse(poDate);
			    		poDate = dt1.format(po_date);
			    	}
			    	if(!invoiceDate.equals("")){
			    		Date invoice_Date = dt.parse(invoiceDate);
			    		invoiceDate = dt1.format(invoice_Date);
			    	}
			    	if(!createdDate.equals("")){
			    		Date created_Date = dt.parse(createdDate);
			    		createdDate = dt1.format(created_Date);
			    	}
				}catch(Exception e){
					e.printStackTrace();
				}
			    objPaymentBean.setStrPODate(poDate);
			    objPaymentBean.setStrInvoiceDate(invoiceDate);
			    objPaymentBean.setStrCreatedDate(createdDate);
				list.add(objPaymentBean);
			}





		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			objPaymentBean = null; 
			template = null;
			
		}
		return list;
	}
	@Override
	public String getRemainingAmountInAdvance(String poNo){

		String remainingAmountInAdvance="";
		try{
			String query = "select REMAINING_AMOUNT-INTIATED_AMOUNT from ACC_ADVANCE_PAYMENT_PO where PO_NUMBER='"+poNo+"' ";
			remainingAmountInAdvance = jdbcTemplate.queryForObject(query, String.class);
		}catch(EmptyResultDataAccessException e){
			remainingAmountInAdvance = "0";
		}
		return remainingAmountInAdvance;
	}
	/*@Override
	public String getPaymentReqUpto(String poNo,String invoiceNo){
		
		String paymentReqAndDoneValues="";
		String query = "select REMAINING_AMOUNT-INTIATED_AMOUNT from ACC_ADVANCE_PAYMENT_PO where PO_NUMBER='"+poNo+"' ";
		paymentReqAndDoneValues = jdbcTemplate.queryForObject(query, String.class);
		return paymentReqAndDoneValues;
	}*/
	@Override
	public int updateReqUptoInAccPayment(String paymentId, String actualRequestedAmount,String changedRequestedAmount, double actualDoubleAdjustAmountFromAdvance, double doubleAdjustAmountFromAdvance) {
		int count=0;
		String query = "update ACC_PAYMENT set PAYMENT_REQ_UPTO=PAYMENT_REQ_UPTO-?+?-?+? where PAYMENT_ID=? ";
		count = jdbcTemplate.update(query, new Object[] {Double.valueOf(actualRequestedAmount),Double.valueOf(changedRequestedAmount),actualDoubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance,paymentId});

		return count;
	}
	@Override
	public int updateReqUptoInAccPaymentOnReject(String paymentId, String actualRequestedAmount, double actualDoubleAdjustAmountFromAdvance) {
		int count=0;
		String query = "update ACC_PAYMENT set PAYMENT_REQ_UPTO=PAYMENT_REQ_UPTO-?-? where PAYMENT_ID=? ";
		count = jdbcTemplate.update(query, new Object[] {Double.valueOf(actualRequestedAmount),actualDoubleAdjustAmountFromAdvance,paymentId});

		return count;
	}
	@Override
	public int updateIntiateAmountInAdvancePaymentPO(String poNo, double actualDoubleAdjustAmountFromAdvance,double doubleAdjustAmountFromAdvance) {
		int count=0;
		String query = "update ACC_ADVANCE_PAYMENT_PO set INTIATED_AMOUNT=INTIATED_AMOUNT-?+? where PO_NUMBER=? ";
		count = jdbcTemplate.update(query, new Object[] {actualDoubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance,poNo});

		return count;
	}
	@Override
	public int updateIntiateAmountInAdvancePaymentPOOnReject(String poNo, double actualDoubleAdjustAmountFromAdvance) {
		int count=0;
		String query = "update ACC_ADVANCE_PAYMENT_PO set INTIATED_AMOUNT=INTIATED_AMOUNT-? where PO_NUMBER=? ";
		count = jdbcTemplate.update(query, new Object[] {actualDoubleAdjustAmountFromAdvance,poNo});

		return count;
	}
	
	@Override
	public int insertPaidAmountInAdvancePaymentPoTable(PaymentDto objPaymentDto) {
		
		int result=0;
		String query = "select count(*) from ACC_ADVANCE_PAYMENT_PO where PO_NUMBER=? ";	
		int count = jdbcTemplate.queryForInt(query,objPaymentDto.getStrPONo());
		if(count==0){
		
		//inserting ACC_ADVANCE_PAYMENT_PO  table
			String query1 = "insert into ACC_ADVANCE_PAYMENT_PO(PO_NUMBER ,PO_AMOUNT ,PAID_AMOUNT ,ADJUSTED_AMOUNT,REMAINING_AMOUNT ,INTIATED_AMOUNT ) "
					+ " values(?,?,?,?,?,?)";

							result = jdbcTemplate.update(query1, new Object[] {
									objPaymentDto.getStrPONo(),objPaymentDto.getDoublePOAmount(),objPaymentDto.getDoubleAmountToBeReleased(),
									0.0,objPaymentDto.getDoubleAmountToBeReleased(),0.0
									
							});	
		}
		else{
			//updating ACC_ADVANCE_PAYMENT_PO  table
			String query2 = "update ACC_ADVANCE_PAYMENT_PO set PAID_AMOUNT=PAID_AMOUNT+? ,REMAINING_AMOUNT=REMAINING_AMOUNT+?  "
					+ " where PO_NUMBER = ?";

							result = jdbcTemplate.update(query2, new Object[] {
									objPaymentDto.getDoubleAmountToBeReleased(),objPaymentDto.getDoubleAmountToBeReleased(),
									objPaymentDto.getStrPONo()
									
							});	
		}
			
		
		
		return result;
	}
	
	@Override
	public int updateAdvancePaymentPoTable(String poNo, double doubleAdjustAmountFromAdvance) {
		int count=0;
		String query = "update ACC_ADVANCE_PAYMENT_PO set ADJUSTED_AMOUNT=ADJUSTED_AMOUNT+?, REMAINING_AMOUNT=REMAINING_AMOUNT-? ,INTIATED_AMOUNT=INTIATED_AMOUNT-?  where PO_NUMBER=? ";
		count = jdbcTemplate.update(query, new Object[] {doubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance,doubleAdjustAmountFromAdvance,poNo});

		
		
		return count;
	}
	@Override
	public String getLowerEmpIdInAccounts(String strEmpId) {
		String lowerEmpId="";
		String query =    "select distinct(DEPT_ID) from ("
						+ "select DEPT_ID from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID in ("
						+ "select EMP_ID from SUMADHURA_APPROVER_MAPPING_DTL where APPROVER_DEPT_ID in("
						+ "select DEPT_ID from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID= '"+strEmpId+"')))";
		lowerEmpId = jdbcTemplate.queryForObject(query, String.class);
		
		return lowerEmpId;
	}
	/*@Override
	public List<String> getPaymentInitiatorInAccounts() {
		List<String> paymentInitiator=new ArrayList<String>();
		List<Map<String, Object>> dbIndentDts = null;
		String query = "select EMP_ID from SUMADHURA_APPROVER_MAPPING_DTL where MODULE_TYPE = 'ACCOUNTS' and EMP_ID  not in (select APPROVER_EMP_ID from SUMADHURA_APPROVER_MAPPING_DTL where MODULE_TYPE = 'ACCOUNTS')";
		paymentInitiator = jdbcTemplate.queryForList(query, String.class);
		
		return paymentInitiator;
	}*/
	@Override
	public int revertPendingApprovalToLowerEmployee(String strLowerEmpId, int intTempPaymentTransactionId) {
		int count=0;
		String query = "update ACC_TEMP_PAYMENT_TRANSACTIONS set REQUEST_PENDING_EMP_ID=? where TEMP_PAYMENT_TRANSACTIONS_ID=? ";
		count = jdbcTemplate.update(query, new Object[] {strLowerEmpId,intTempPaymentTransactionId});

		
		
		return count;
	}
	@Override
	public int removeRowInAccTempPaymentTransactions(int intTempPaymentTransactionId) {
		int count=0;
		String query = "delete from ACC_TEMP_PAYMENT_TRANSACTIONS where TEMP_PAYMENT_TRANSACTIONS_ID=? ";
		count = jdbcTemplate.update(query, new Object[] {intTempPaymentTransactionId});

		
		
		return count;
	}
	@Override
	public int updateIntiateAmountInAccDeptPaymentProcesstbl(String requestedAmount, int intAccDeptPaymentProcessId,double actualDoubleAdjustAmountFromAdvance) {
		String query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set PROCESS_INTIATE_AMOUNT = PROCESS_INTIATE_AMOUNT-? ,"
				+ "ADJUST_INTIATE_AMOUNT = ADJUST_INTIATE_AMOUNT-? "
				+ "where ACCOUNTS_DEPT_PMT_PROSS_ID = ? ";

				int result = jdbcTemplate.update(query, new Object[] {
						requestedAmount,actualDoubleAdjustAmountFromAdvance, intAccDeptPaymentProcessId

				});
		return result;
	}
	
	@Override
	public int saveAccountsApproveRejectTable(PaymentDto objPaymentDto,int intAccDeptPaymentProcessId,int intTempPaymentTransactionId){

		int count = 0;

		
			String query = "insert into ACC_PMT_APPR_REJECT_DTLS(PAYMENT_APROV_REJECT_SEQ,ACCOUNTS_DEPT_PMT_PROSS_ID,EMP_ID,STATUS," +
					"REMARKS,TEMP_PAYMENT_TRANSACTIONS_ID,SITE_ID,CREATED_DATE,OPERATION_TYPE)values" +
					"(PMT_APPROVE_REJECT_SEQ_ID.nextval,?,?,?,?,?,?,sysdate,?)";

			count = jdbcTemplate.update(query, new Object[] {
					intAccDeptPaymentProcessId,objPaymentDto.getStrEmployeeId(),"A",objPaymentDto.getStrRemarks(),
					intTempPaymentTransactionId,objPaymentDto.getStrSiteId(),"C"});

		return count;

	}
	@Override
	public int  saveAccountApprovalDetails(int intAccDeptPaymentProcessId,String strUserId,String comments,int intTempPaymentTransactionId,String site_id){
	
		int count=0;
		
		String query = "insert into ACC_PMT_APPR_REJECT_DTLS(PAYMENT_APROV_REJECT_SEQ,ACCOUNTS_DEPT_PMT_PROSS_ID,EMP_ID,OPERATION_TYPE,REMARKS,TEMP_PAYMENT_TRANSACTIONS_ID,SITE_ID,CREATED_DATE,STATUS)values(PMT_APPROVE_REJECT_SEQ_ID.nextval,"+intAccDeptPaymentProcessId+",'"+strUserId+"',"+"'A'"+",'"+comments+"',"+intTempPaymentTransactionId+",'"+site_id+"',sysdate,'A')";
														
 		count = jdbcTemplate.update(query, new Object[] {
				
				});
		
	return count;
	
	
}
	
	@Override
	public int saveAccountRejectDetails(int intAccDeptPaymentProcessId, String strEmpId, String comments,
			int intTempPaymentTransactionId, String siteId) {	
		int count=0;
		
		String query = "insert into ACC_PMT_APPR_REJECT_DTLS(PAYMENT_APROV_REJECT_SEQ,ACCOUNTS_DEPT_PMT_PROSS_ID,EMP_ID,OPERATION_TYPE,REMARKS,TEMP_PAYMENT_TRANSACTIONS_ID,SITE_ID,CREATED_DATE,STATUS)values(PMT_APPROVE_REJECT_SEQ_ID.nextval,"+intAccDeptPaymentProcessId+",'"+strEmpId+"','R','"+comments+"',"+intTempPaymentTransactionId+",'"+siteId+"',sysdate,'A')";

		count = jdbcTemplate.update(query, new Object[] {});
		
		return count;
	
	
}
	@Override
	public int saveAccountChangedDetails(PaymentBean objPaymentBean,String paymentChangedType){
		
		int count=0;
		String query = "insert into ACC_PAYMENT_CHANGED_DTLS(PAYMENT_CHNG_DTLS_ID,TEMP_PAYMENT_TRANSACTIONS_ID,ACTUAL_ADJUST_AMOUNT,CHANGED_ADJUST_AMOUNT,ACTUAL_PAYMENT_MODE,CHANGED_PAYMENT_MODE,ACTUAL_REF_NO,CHANGED_REF_NO,CREATION_DATE,PAYMENT_CHANGE_ACTION,EMP_ID,REMARKS)"
					+" values (ACC_PAYMENT_CHANGED_DTLS_SEQ.nextval,?,?,?,?,?,?,?,sysdate,?,?,?)";

		count = jdbcTemplate.update(query, new Object[] {
				objPaymentBean.getIntTempPaymentTransactionId(),objPaymentBean.getActualDoubleAdjustAmountFromAdvance(),objPaymentBean.getDoubleAdjustAmountFromAdvance(),
				objPaymentBean.getActualPaymentMode(),objPaymentBean.getPaymentMode(),
				objPaymentBean.getActualUtrChequeNo(),objPaymentBean.getUtrChequeNo(),
				paymentChangedType,objPaymentBean.getStrEmployeeId(),objPaymentBean.getStrRemarks()
				});
		
		return count;
		
	}
	@Override
	public int removeRowInAccDeptPmtProcessTbl(int accDeptPmtProcessId) {
		int count=0;
		String query = "delete from ACC_ACCOUNTS_DEPT_PMT_PROSS where ACCOUNTS_DEPT_PMT_PROSS_ID = ?";
		
		count = jdbcTemplate.update(query, new Object[] {
				accDeptPmtProcessId
				});
		
		return count;
	}
	@Override
	public int setInactiveRowInAccDeptPmtProcessTbl(int accDeptPmtProcessId) {
		int count=0;
		
		String query = "update ACC_ACCOUNTS_DEPT_PMT_PROSS set STATUS='I'  where ACCOUNTS_DEPT_PMT_PROSS_ID = ?";
		count = jdbcTemplate.update(query, new Object[] {
				accDeptPmtProcessId
				});
		
		return count;
	}
	@Override
	public List<PaymentBean> getAccDeptPaymentDetailsToUpdate(String siteId, String user_id, String fromDate, String toDate){

		String query = "";
		String convertpodate = "";
		JdbcTemplate template = null;
		double invoiceAmount=0.0;
		double poAmount=0.0;
		List<Map<String, Object>> dbIndentDts = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean indentObj = null;
		

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

		
				if (StringUtils.isNotBlank(siteId)) {
					query = " select APT.PAYMENT_TRANSACTIONS_ID,APT.PAYMENT_DETAILS_ID,APT.PAID_AMOUNT,APT.PAYMENT_TYPE,"
							+"APT.PAYMENT_DATE,APT.PAYMENT_MODE,APT.UTR_CHQNO,APT.REMARKS,APT.SITEWISE_PAYMENT_NO,"
							+"S.SITE_NAME,VD.VENDOR_NAME,AP.INVOICE_NUMBER,AP.INVOICE_AMOUNT,AP.PAYMENT_ID,AP.INVOICE_DATE,AP.INVOICE_RECEIVED_DATE,AP.PAYMENT_REQ_UPTO,AP.PAYMENT_DONE_UPTO,"
							+"AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,"
							+"AP.VENDOR_ID,AP.SITE_ID,AP.INDENT_ENTRY_ID " 
							+"from ACC_PAYMENT_TRANSACTIONS APT,ACC_PAYMENT_DTLS APD,SITE S,VENDOR_DETAILS VD,"
							+"ACC_PAYMENT AP " 
							+"where  AP.PAYMENT_ID = APD.PAYMENT_ID " 
							+"and APD.PAYMENT_DETAILS_ID = APT.PAYMENT_DETAILS_ID " 
							+"and S.SITE_ID = AP.SITE_ID " 
							+"and VD.VENDOR_ID = AP.VENDOR_ID "
							+ "and APT.TYPE_OF_PAYMENT_SETTLEMENT = 'REGULAR'"
							+ "and APT.UPDATION = 'A'";
							
					if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
						query = query + " AND TRUNC(APT.CREATION_DATE) BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
						//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
					} else if (StringUtils.isNotBlank(fromDate)) {
						query = query + " AND TRUNC(APT.CREATION_DATE) >=TO_DATE('"+fromDate+"', 'dd-MM-yy')";
					} else if(StringUtils.isNotBlank(toDate)) {
						query = query + " AND TRUNC(APT.CREATION_DATE) <=TO_DATE('"+toDate+"', 'dd-MM-yy')";
					}
					
					// this block of code for - to display payments as per AccountsDepartment is HYD or BANGLORE.
					/** take dept_id of login employee.
					 ** decide address hyd or banglore.
					 ** take list of sites in that address.
					 ** form a String using sites to pass into query.
					 */
					String dept_id = template.queryForObject("select DEPT_ID from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID = '"+user_id+"'", new Object[]{},String.class);
					String address = "";
					if(dept_id.contains("B")){
						address="BANGLORE";
					}
					else if(dept_id.contains("H")){
						address="HYD";
					}
					List<String> siteIdList = template.queryForList("select SITE_ID from SITE where ADDRESS = '"+address+"'", new Object[]{},String.class);
					if(siteIdList.size()>0){
						String groupOfSites = "";
						for(String site:siteIdList){
							groupOfSites +="'"+site+"',";
						}
						groupOfSites = groupOfSites.substring(0,groupOfSites.length()-1);
						query = query + " and AP.SITE_ID in("+groupOfSites+")";
					}
					/***************************************/
					
					query = query +" order by APT.CREATION_DATE asc";

			dbIndentDts = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			for(Map<String, Object> prods : dbIndentDts) {
				serialNo++;
				indentObj = new PaymentBean();
				indentObj.setIntSerialNo(serialNo);
				indentObj.setStrInvoiceNo(prods.get("INVOICE_NUMBER")==null ? "" : prods.get("INVOICE_NUMBER").toString());
				indentObj.setStrPONo(prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString());
				String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
				String podate=prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString();
				indentObj.setStrVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
				indentObj.setStrVendorId(prods.get("VENDOR_ID")==null ? "" : prods.get("VENDOR_ID").toString());
				indentObj.setStrSiteId(prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString());
				invoiceAmount=Double.parseDouble(prods.get("INVOICE_AMOUNT")==null ? "" : prods.get("INVOICE_AMOUNT").toString());
				poAmount=Double.parseDouble(prods.get("PO_AMOUNT")==null ? "" : prods.get("PO_AMOUNT").toString());
				indentObj.setDoublePaidAmount(Double.parseDouble(prods.get("PAID_AMOUNT")==null ? "" : prods.get("PAID_AMOUNT").toString()));
				String  paymentDate =(prods.get("PAYMENT_DATE")==null ? "" : prods.get("PAYMENT_DATE").toString());
				String receviedDate=prods.get("INVOICE_RECEIVED_DATE")==null ? "" : prods.get("INVOICE_RECEIVED_DATE").toString();
				String remarks = prods.get("REMARKS")==null ? "" : prods.get("REMARKS").toString();
				indentObj.setStrRemarks(remarks);
				indentObj.setStrRemarksForView(remarks.replace("@@@", ","));
				indentObj.setIntPaymentId(Integer.parseInt(prods.get("PAYMENT_ID")==null ? "0" : prods.get("PAYMENT_ID").toString()));
				
				indentObj.setIntPaymentDetailsId(Integer.parseInt(prods.get("PAYMENT_DETAILS_ID")==null ? "0" : prods.get("PAYMENT_DETAILS_ID").toString()));
				indentObj.setIntSiteWisePaymentId(Integer.parseInt(prods.get("SITEWISE_PAYMENT_NO")==null ? "0" : prods.get("SITEWISE_PAYMENT_NO").toString()));
				indentObj.setStrSiteName(prods.get("SITE_NAME")==null ? "" : prods.get("SITE_NAME").toString());
				indentObj.setPaymentType(prods.get("PAYMENT_TYPE")==null ? "" : prods.get("PAYMENT_TYPE").toString());
				String paymentMode = prods.get("PAYMENT_MODE")==null ? "" : prods.get("PAYMENT_MODE").toString();
				indentObj.setPaymentMode(paymentMode);
				
				indentObj.setUtrChequeNo(prods.get("UTR_CHQNO")==null ? "" : prods.get("UTR_CHQNO").toString());
								
				indentObj.setDoubleInvoiceAmount(invoiceAmount);
				indentObj.setDoublePOTotalAmount(poAmount);
				
				indentObj.setIntPaymentTransactionId(Integer.parseInt(prods.get("PAYMENT_TRANSACTIONS_ID")==null ? "" : prods.get("PAYMENT_TRANSACTIONS_ID").toString()));
				
				indentObj.setDoubleCreditTotalAmount(Double.valueOf(prods.get("CREDIT_TOTAL_AMOUNT")==null ? "0" : prods.get("CREDIT_TOTAL_AMOUNT").toString()));
				indentObj.setStrCreditNoteNumber(prods.get("CREDIT_NOTE_NUMBER")==null ? "" : prods.get("CREDIT_NOTE_NUMBER").toString());
				
				indentObj.setIntIndentEntryId(Integer.parseInt(prods.get("INDENT_ENTRY_ID")==null ? "0" : prods.get("INDENT_ENTRY_ID").toString()));
			    
				
				indentObj.setDoublePaymentDoneUpto(Double.valueOf(prods.get("PAYMENT_DONE_UPTO")==null ? "0" : prods.get("PAYMENT_DONE_UPTO").toString()));
			    indentObj.setDoublePaymentRequestedUpto(Double.valueOf(prods.get("PAYMENT_REQ_UPTO")==null ? "0" : prods.get("PAYMENT_REQ_UPTO").toString()));
			    

				SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				try{

					/*Date receive_date = dt.parse(receviedDate);*/
					
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");
					if(!paymentDate.equals("")){

						Date p_date = dt.parse(paymentDate);
						paymentDate = dt1.format(p_date);
					}
					if(!podate.equals("")){
						Date po_date = dt.parse(podate);
						podate = dt1.format(po_date);
					}
					if(!invoicedate.equals("")){
						Date invoice_date = dt.parse(invoicedate);
						invoicedate = dt1.format(invoice_date);
					}
					if(!receviedDate.equals("")){
						Date recevied_Date = dt.parse(receviedDate);
						receviedDate = dt1.format(recevied_Date);
					}
				}
			
				catch(Exception e){
					e.printStackTrace();
				}
			
				indentObj.setStrInvoiceDate(invoicedate);
				indentObj.setStrPODate(podate);
				indentObj.setStrPaymentDate(paymentDate);
				indentObj.setStrInvoiceReceivedDate(receviedDate);
				list.add(indentObj);
			}

		}//if
		} catch (Exception ex) {
			ex.printStackTrace();
		  } finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;

}
	@Override
	public int updateRefNoInAccDeptTransaction(String strRefNo, int intPaymentTransactionId, String paymentMode,
			String paymentDate) {
		String query = "update ACC_PAYMENT_TRANSACTIONS set UTR_CHQNO = ?,PAYMENT_MODE = ?,PAYMENT_DATE = ?,UPDATION='I'  where PAYMENT_TRANSACTIONS_ID = ? ";

			int	count = jdbcTemplate.update(query, new Object[] {
					strRefNo, paymentMode, paymentDate, intPaymentTransactionId

				});
		return count;
	}
	@Override
	public int UpDatePaymentDetailsRemarks(String paymentDetailsId, String remarks) {
		String query="";
		int responseCount=0;
		
		query = "update ACC_PAYMENT_DTLS set REMARKS = '"+remarks+"'   where STATUS ='A' and PAYMENT_DETAILS_ID=?";
		responseCount = jdbcTemplate.update(query, new Object[]  {paymentDetailsId});
		
		return responseCount;
	}
	@Override
	public int setInactiveAccPaymentAfterCheck(int intPaymentId) {
		String query="";
		int responseCount=0;
		String query1="";
		List<Map<String, Object>> dbIndentDts = null;
		query1 = "select INVOICE_AMOUNT,PAYMENT_DONE_UPTO from ACC_PAYMENT  where  PAYMENT_ID=?";
		dbIndentDts = jdbcTemplate.queryForList(query1, new Object[]{intPaymentId});
		for(Map<String, Object> prods : dbIndentDts) {
			double invoiceAmount = Math.round(Double.valueOf(prods.get("INVOICE_AMOUNT")==null ? "" : prods.get("INVOICE_AMOUNT").toString()));
			double paymentDoneUpto = Double.valueOf(prods.get("PAYMENT_DONE_UPTO")==null ? "" : prods.get("PAYMENT_DONE_UPTO").toString());
		
			if(paymentDoneUpto>=invoiceAmount){


				query = "update ACC_PAYMENT set STATUS = 'I'   where  PAYMENT_ID=?";
				responseCount = jdbcTemplate.update(query, new Object[]  {intPaymentId});
			}
		}
		
		return responseCount;
	}
	@Override
	public int updateRefNoInInvoiceHistory(String strRefNo, String paymentMode, int intPaymentTransactionId) {
		String query = "update ACC_INVOICE_HISTORY set REF_NO = ?,PAYMENT_MODE = ?  where PAYMENT_TRANSACTIONS_ID = ? ";

		int	count = jdbcTemplate.update(query, new Object[] {
				strRefNo, paymentMode, intPaymentTransactionId

			});
		return count;
	}
	@Override
	public String[] getPaymentApproverEmailId(String strUserId) {
		List<String> emailList = new ArrayList<String>();
		List<Map<String, Object>> dbIndentDts = null;

		String query = "select SAMD.APPROVER_EMP_ID,SAMD.APPROVER_DEPT_ID FROM SUMADHURA_APPROVER_MAPPING_DTL SAMD "
				+"WHERE  SAMD.EMP_ID='"+strUserId+"'  and SAMD.STATUS = 'A' AND SAMD.MODULE_TYPE='PAYMENT'";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{});
		for(Map<String, Object> prods : dbIndentDts) {
			String approverEmpId = prods.get("APPROVER_EMP_ID")==null ? "" : prods.get("APPROVER_EMP_ID").toString();
			String approverDeptId = prods.get("APPROVER_DEPT_ID")==null ? "" : prods.get("APPROVER_DEPT_ID").toString();

			if(StringUtils.isNotBlank(approverEmpId)&&!approverEmpId.equals("-")){
				String query1 = " select SED.EMP_EMAIL from SUMADHURA_EMPLOYEE_DETAILS SED where SED.EMP_ID ='"+approverEmpId+"'";
				String empEmail = jdbcTemplate.queryForObject(query1, String.class);
				if(StringUtils.isNotBlank(empEmail)){
				if(empEmail.contains(",")){
					String[] emailArr= empEmail.split(",");
					for(String email:emailArr){
						emailList.add(email);
					}
				}
				else{emailList.add(empEmail);}
				}
			}
			else if(StringUtils.isNotBlank(approverEmpId)&&approverEmpId.equals("-")&&StringUtils.isNotBlank(approverDeptId)&&approverDeptId.equals("997")){
				List<Map<String, Object>> dbIndentDts2 = null;
				String query2 = "select SED.EMP_EMAIL  from SUMADHURA_EMPLOYEE_DETAILS SED where SED.DEPT_ID = '997'";
				dbIndentDts2 = jdbcTemplate.queryForList(query, new Object[]{});
				for(Map<String, Object> prods2 : dbIndentDts2) {
					String empEmail = prods2.get("EMP_EMAIL")==null ? "" : prods2.get("EMP_EMAIL").toString();
					if(StringUtils.isNotBlank(empEmail)){
					if(empEmail.contains(",")){
						String[] emailArr= empEmail.split(",");
						for(String email:emailArr){
							emailList.add(email);
						}
					}
					else{emailList.add(empEmail);}
					}
				}
			}
		}
		String[] emailArray = new String[emailList.size()];
		emailList.toArray(emailArray);
		return emailArray;
	}
	@Override
	public List<PaymentModesBean> getPaymentModes() {
		JdbcTemplate template = null;
		try {
			template  = new JdbcTemplate(DBConnection.getDbConnection());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Map<String, Object>> dbIndentDts = null;
		List<PaymentModesBean> list = new ArrayList<PaymentModesBean>();
		String query = "select NAME,VALUE from ACC_PAYMENT_MODES where STATUS='A' order by ID asc";
		dbIndentDts = template.queryForList(query, new Object[]{});
		for(Map<String, Object> prods : dbIndentDts) {
			PaymentModesBean objBean = new PaymentModesBean();
			objBean.setName(prods.get("NAME")==null ? "" : prods.get("NAME").toString());
			objBean.setValue(prods.get("VALUE")==null ? "" : prods.get("VALUE").toString());
			list.add(objBean);
		}
			
		return list;
	}
	@Override
	public VendorDetails getVendorAccountDetails(String vendorId) {
		List<Map<String, Object>> dbIndentDts = null;
		String query = "select VENDOR_NAME,EMP_EMAIL,BANK_ACC_NUMBER,ACC_HOLDER_NAME,BANK_NAME,IFSC_CODE from VENDOR_DETAILS  where  VENDOR_ID=?";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{vendorId});
		VendorDetails vd = new VendorDetails();
		for(Map<String, Object> prods : dbIndentDts) {
			vd.setVendor_name(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
			vd.setVendor_email(prods.get("EMP_EMAIL")==null ? "" : prods.get("EMP_EMAIL").toString());
			try {
				vd.setAcc_Number(Long.valueOf(prods.get("BANK_ACC_NUMBER")==null ? "0" : prods.get("BANK_ACC_NUMBER").toString()));
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
			vd.setAcc_Holder_Name(prods.get("ACC_HOLDER_NAME")==null ? "" : prods.get("ACC_HOLDER_NAME").toString());
			vd.setBank_name(prods.get("BANK_NAME")==null ? "" : prods.get("BANK_NAME").toString());
			vd.setIfsc_Code(prods.get("IFSC_CODE")==null ? "" : prods.get("IFSC_CODE").toString());
			break;
		}
		
		return vd;
	}
	
	/* FOR MAIL */
	@Override
	public List<PaymentBean> getPaymentApprovalDetailsForMail(String siteId, String user_id,String groupOfPaymentDetailsId){


		String query = "";
		JdbcTemplate template = null;
		double invoiceAmount=0.0;
		double poAmount=0.0;
		List<Map<String, Object>> dbIndentDts = null;
		List<PaymentBean> list = new ArrayList<PaymentBean>();
		PaymentBean indentObj = null; 

		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

		
				if (siteId.equals("998")) {
					query = "select DISTINCT(AP.INVOICE_NUMBER),VD.VENDOR_NAME,AP.INVOICE_AMOUNT,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,AP.SITE_ID,AP.INVOICE_DATE,AP.INVOICE_RECEIVED_DATE,APD.REQ_AMOUNT,"
							+" APD.PAYMENT_REQ_DATE,APD.REMARKS,APD.PAYMENT_DETAILS_ID,APD.PAYMENT_ID,VD.VENDOR_ID,AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.INDENT_ENTRY_ID,AVSD.SECURITY_DEPOSIT_AMOUNT,APD.PAYMENT_TYPE,AP.PAYMENT_REQ_UPTO,AP.PAYMENT_DONE_UPTO " 
							+" ,(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT ,APD.ADJUST_AMOUNT_FROM_ADVANCE "
							+ " FROM VENDOR_DETAILS VD,ACC_PAYMENT_DTLS APD,ACC_PAYMENT AP " 
							+" LEFT OUTER JOIN SUMADHURA_PO_ENTRY SPE on ( AP.PO_NUMBER = SPE.PO_NUMBER and AP.VENDOR_ID=SPE.VENDOR_ID) "
							+"  LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = AP.VENDOR_ID AND AVSD.SITE_ID = AP.SITE_ID AND AVSD.STATUS = 'A' "
							+ " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = AP.PO_NUMBER "
							+ " WHERE AP.PAYMENT_ID=APD.PAYMENT_ID and APD.STATUS='A'  AND AP.VENDOR_ID=VD.VENDOR_ID "  
							+" AND APD.REQUEST_PENDING_EMP_ID = '"+user_id+"'"
							+" AND APD.PAYMENT_DETAILS_ID in ("+groupOfPaymentDetailsId+") "
							+" order by VD.VENDOR_NAME asc, APD.PAYMENT_REQ_DATE asc ";
				}
				else{
					query = "select DISTINCT(AP.INVOICE_NUMBER),VD.VENDOR_NAME,AP.INVOICE_AMOUNT,AP.CREDIT_NOTE_NUMBER,AP.CREDIT_TOTAL_AMOUNT,AP.SITE_ID,AP.INVOICE_DATE,AP.INVOICE_RECEIVED_DATE,APD.REQ_AMOUNT,"
							+" APD.PAYMENT_REQ_DATE,APD.REMARKS,APD.PAYMENT_DETAILS_ID,APD.PAYMENT_ID,VD.VENDOR_ID,AP.PO_NUMBER,AP.PO_DATE,AP.PO_AMOUNT,AP.INDENT_ENTRY_ID,AVSD.SECURITY_DEPOSIT_AMOUNT,APD.PAYMENT_TYPE,AP.PAYMENT_REQ_UPTO,AP.PAYMENT_DONE_UPTO " 
							+" ,(AAPP.REMAINING_AMOUNT-AAPP.INTIATED_AMOUNT) as REMAINING_AMOUNT ,APD.ADJUST_AMOUNT_FROM_ADVANCE "
							+ " FROM VENDOR_DETAILS VD,ACC_PAYMENT_DTLS APD,ACC_PAYMENT AP " 
							+" LEFT OUTER JOIN SUMADHURA_PO_ENTRY SPE on ( AP.PO_NUMBER = SPE.PO_NUMBER and AP.VENDOR_ID=SPE.VENDOR_ID) "
							+"  LEFT OUTER JOIN ACC_VENDOR_SECURITY_DEPOSIT AVSD on AVSD.VENDOR_ID = AP.VENDOR_ID AND AVSD.SITE_ID = AP.SITE_ID AND AVSD.STATUS = 'A' "
							+ " LEFT OUTER JOIN ACC_ADVANCE_PAYMENT_PO AAPP on AAPP.PO_NUMBER = AP.PO_NUMBER "
							+ " WHERE AP.PAYMENT_ID=APD.PAYMENT_ID and APD.STATUS='A' AND AP.SITE_ID='"+siteId+"' AND AP.VENDOR_ID=VD.VENDOR_ID "  
							+" AND APD.REQUEST_PENDING_EMP_ID = '"+user_id+"'"
							+" AND APD.PAYMENT_DETAILS_ID in ("+groupOfPaymentDetailsId+") "
							+" order by VD.VENDOR_NAME asc, APD.PAYMENT_REQ_DATE asc ";
					
				}
			dbIndentDts = template.queryForList(query, new Object[]{});
			int serialNo = 0;
			List<String> invoiceIdList = new ArrayList<String>();
			List<String> poIdList = new ArrayList<String>();
			for(Map<String, Object> prods : dbIndentDts) {
				String vendorId = prods.get("VENDOR_ID")==null ? "" : prods.get("VENDOR_ID").toString();
				String vendorName = prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString();
				String invoiceId = prods.get("INVOICE_NUMBER")==null ? "" : prods.get("INVOICE_NUMBER").toString();
				invoiceAmount=Math.round(Double.parseDouble(prods.get("INVOICE_AMOUNT")==null ? "" : prods.get("INVOICE_AMOUNT").toString()));
				String poId = prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString();
				poAmount=Double.parseDouble(prods.get("PO_AMOUNT")==null ? "" : prods.get("PO_AMOUNT").toString());
				String reqAmount = prods.get("REQ_AMOUNT")==null ? "" : prods.get("REQ_AMOUNT").toString();
				
				serialNo++;
				indentObj = new PaymentBean();
				indentObj.setIntSerialNo(serialNo);
				indentObj.setStrInvoiceNo(prods.get("INVOICE_NUMBER")==null ? "" : prods.get("INVOICE_NUMBER").toString());
				String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
				indentObj.setStrVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
				indentObj.setStrVendorId(vendorId);
				
				poAmount=Math.round(Double.parseDouble(prods.get("PO_AMOUNT")==null ? "" : prods.get("PO_AMOUNT").toString()));
				indentObj.setRequestedAmount(reqAmount);
				String  paymentDate =(prods.get("PAYMENT_REQ_DATE")==null ? "" : prods.get("PAYMENT_REQ_DATE").toString());
				String receviedDate=prods.get("INVOICE_RECEIVED_DATE")==null ? "" : prods.get("INVOICE_RECEIVED_DATE").toString();
				String remarks = prods.get("REMARKS")==null ? "" : prods.get("REMARKS").toString();
				indentObj.setStrRemarks(StringEscapeUtils.escapeHtml(remarks));
				indentObj.setStrRemarksForView(StringEscapeUtils.escapeHtml(remarks.replace("@@@", ",")));
				indentObj.setIntPaymentId(Integer.parseInt(prods.get("PAYMENT_ID")==null ? "" : prods.get("PAYMENT_ID").toString()));
				indentObj.setIntPaymentDetailsId(Integer.parseInt(prods.get("PAYMENT_DETAILS_ID")==null ? "" : prods.get("PAYMENT_DETAILS_ID").toString()));
				indentObj.setStrSiteId(prods.get("SITE_ID")==null ? "" : prods.get("SITE_ID").toString());
				indentObj.setStrPONo(prods.get("PO_NUMBER")==null ? "" : prods.get("PO_NUMBER").toString());				
				String  poDate =(prods.get("PO_DATE")==null ? "" : prods.get("PO_DATE").toString());
				indentObj.setDoubleInvoiceAmount(invoiceAmount);
				indentObj.setDoublePOTotalAmount(poAmount);
				indentObj.setDoubleCreditTotalAmount(Double.valueOf(prods.get("CREDIT_TOTAL_AMOUNT")==null ? "0" : prods.get("CREDIT_TOTAL_AMOUNT").toString()));
				indentObj.setStrCreditNoteNumber(prods.get("CREDIT_NOTE_NUMBER")==null ? "" : prods.get("CREDIT_NOTE_NUMBER").toString());
				indentObj.setDoubleSecurityDeposit(Double.valueOf(prods.get("SECURITY_DEPOSIT_AMOUNT")==null ? "0" : prods.get("SECURITY_DEPOSIT_AMOUNT").toString()));
			    indentObj.setIntIndentEntryId(Integer.parseInt(prods.get("INDENT_ENTRY_ID")==null ? "0" : prods.get("INDENT_ENTRY_ID").toString()));
			    indentObj.setDoublePOAdvancePayment(Double.valueOf(prods.get("REMAINING_AMOUNT")==null ? "0" : prods.get("REMAINING_AMOUNT").toString()));
			    indentObj.setDoubleAdjustAmountFromAdvance(Double.valueOf(prods.get("ADJUST_AMOUNT_FROM_ADVANCE")==null ? "0" : prods.get("ADJUST_AMOUNT_FROM_ADVANCE").toString()));
			    indentObj.setPaymentType(prods.get("PAYMENT_TYPE")==null ? "" :   prods.get("PAYMENT_TYPE").toString());
			    indentObj.setDoublePaymentDoneUpto(Double.valueOf(prods.get("PAYMENT_DONE_UPTO")==null ? "0" : prods.get("PAYMENT_DONE_UPTO").toString()));
			    indentObj.setDoublePaymentRequestedUpto(Double.valueOf(prods.get("PAYMENT_REQ_UPTO")==null ? "0" : prods.get("PAYMENT_REQ_UPTO").toString()));
			    
			

				SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String convertreceive_time = "";
				
				try{
					
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");
					if(!receviedDate.equals("")){

					Date receive_date = dt.parse(receviedDate);
					receviedDate = dt1.format(receive_date);
					convertreceive_time = time1.format(receive_date);
					}
					if(!invoicedate.equals("")){

					Date invoice_date = dt.parse(invoicedate);
					invoicedate = dt1.format(invoice_date);
					}
					if(!poDate.equals("")){

						Date po_date = dt.parse(poDate);
						poDate = dt1.format(po_date);
						}
					
					if(!paymentDate.equals("")){

						Date payment_date = dt.parse(paymentDate);
						paymentDate = dt1.format(payment_date);
					}

					
					
					
				}
			
				catch(Exception e){
					e.printStackTrace();
				}
			
				indentObj.setStrInvoiceDate(invoicedate);
				indentObj.setStrReceiveDate(receviedDate);
			//	indentObj.setTime(convertreceive_time);
				indentObj.setRequestedDate(paymentDate);
				indentObj.setStrPODate(poDate);
				list.add(indentObj);
			}

		
		} catch (Exception ex) {
			ex.printStackTrace();
			//log.debug("Exception = "+ex.getMessage());
			//logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;

	
	}
	public boolean isInvoiceIdListContainsinvoiceId(List<PaymentBean> invoiceIdList,String invoiceId,String vendorId,String site_id){
		for(PaymentBean pb:invoiceIdList){
			if(pb.getStrInvoiceNo().equals(invoiceId)){
				if(pb.getStrVendorId().equals(vendorId)){
					if(pb.getStrSiteId().equals(site_id)){
						return true;
					}
				}	
			}
		}
		return false;

	}
	
	
	@Override
	public String[] getAllSiteLevelEmails(String siteId) {
		List<String> emailList = new ArrayList<String>();
		List<Map<String, Object>> dbIndentDts = null;

		String query = "select SED.EMP_EMAIL from SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_LOGIN SL WHERE SED.EMP_ID=SL.EMPLOYEEID AND SL.SITE_ID='"+siteId+"'";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[]{});
		for(Map<String, Object> prods : dbIndentDts) {
			String empEmail = prods.get("EMP_EMAIL")==null ? "" : prods.get("EMP_EMAIL").toString();
			if(StringUtils.isNotBlank(empEmail)){
				if(empEmail.contains(",")){
					String[] emailArr= empEmail.split(",");
					for(String email:emailArr){
						emailList.add(email);
					}
				}
				else{emailList.add(empEmail);}
			}

		}
		String[] emailArray = new String[emailList.size()];
		emailList.toArray(emailArray);
		return emailArray;
	}
}
