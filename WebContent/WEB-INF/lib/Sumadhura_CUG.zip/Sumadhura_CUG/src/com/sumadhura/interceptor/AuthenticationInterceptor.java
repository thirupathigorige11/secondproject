package com.sumadhura.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Component
public class AuthenticationInterceptor extends HandlerInterceptorAdapter {
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		final HttpSession session = request.getSession(false);
		String uri = request.getRequestURI();
		if (uri.endsWith("login.spring")) {
			return true;

		}
		else if(uri.endsWith("vendorloginsubmit.spring")) {
			return true;

		}else if(uri.endsWith("SaveEnquiryForm.spring")) {
			return true;

		}else if(uri.endsWith("approveIndentCreationFromMail.spring")) {
			return true;

		}else if(uri.endsWith("rejectIndentCreationFromMail.spring")) {
			return true;
			
		}else if(uri.endsWith("showPODetailsToVendor.spring")) {
			return true;
			
		}
		else if(uri.endsWith("forGetPassword.spring")) {
			return true;
			
		}
		else if(uri.endsWith("changeToNewPassword.spring")) {
			return true;
			
		}
		
		
		else if((session == null || session.isNew()) || (null==session.getAttribute("UserId"))){
			String context = request.getContextPath();
			response.sendRedirect("/Sumadhura/");
			return false;
		}else{
			
            return true;
        }  
	}
}