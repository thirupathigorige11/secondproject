package com.sumadhura.bean;

public class userDetails {
	private String uname, pass, userName;
	private String strSiteId;
	private String mobileNo;
	private String emailId;
	private String strMesage ;



	public String getStrMesage() {
		return strMesage;
	}

	public void setStrMesage(String strMesage) {
		this.strMesage = strMesage;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getStrSiteId() {
		return strSiteId;
	}

	public void setStrSiteId(String strSiteId) {
		this.strSiteId = strSiteId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

}
