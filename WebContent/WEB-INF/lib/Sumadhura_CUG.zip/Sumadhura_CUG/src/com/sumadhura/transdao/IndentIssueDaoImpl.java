package com.sumadhura.transdao;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sumadhura.bean.AuditLogDetailsBean;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.IndentIssueDto;
import com.sumadhura.dto.IndentIssueRequesterDto;
import com.sumadhura.util.DBConnection;
import com.sumadhura.util.DateUtil;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Repository
public class IndentIssueDaoImpl extends UIProperties  implements IndentIssueDao {

	static Logger log = Logger.getLogger(IndentIssueDaoImpl.class);

	@Autowired(required = true)
	private JdbcTemplate jdbcTemplate;

	public Map<String, String> loadProds() {

		Map<String, String> products = null;
		List<Map<String, Object>> dbProductsList = null;

		products = new HashMap<String, String>();

		String prodsQry = "SELECT PRODUCT_ID, NAME FROM PRODUCT WHERE STATUS = 'A'";
		log.debug("Query to fetch product = "+prodsQry);

		dbProductsList = jdbcTemplate.queryForList(prodsQry, new Object[]{});

		for(Map<String, Object> prods : dbProductsList) {
			products.put(String.valueOf(prods.get("PRODUCT_ID")), String.valueOf(prods.get("NAME")));
		}

		return printMap(products);
	}	

	public String loadSubProds(String prodId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbSubProductsList = null;		

		log.debug("Product Id = "+prodId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT SUB_PRODUCT_ID, NAME FROM SUB_PRODUCT WHERE PRODUCT_ID = ? AND STATUS = 'A' ORDER BY NAME ASC";
		log.debug("Query to fetch subproduct = "+subProdsQry);

		dbSubProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{prodId});

		for(Map<String, Object> subProds : dbSubProductsList) {
			sb = sb.append(String.valueOf(subProds.get("SUB_PRODUCT_ID"))+"_"+String.valueOf(subProds.get("NAME"))+"|");
		}

		return sb.toString();
	}





	public String loadChildProds(String subProductId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbChildProductsList = null;		

		log.debug("Sub Product Id = "+subProductId);

		sb = new StringBuffer();

		String subProdsQry = "SELECT CHILD_PRODUCT_ID, NAME FROM CHILD_PRODUCT WHERE SUB_PRODUCT_ID = ? AND STATUS = 'A' ORDER BY NAME ASC";
		log.debug("Query to fetch child product = "+subProdsQry);

		dbChildProductsList = jdbcTemplate.queryForList(subProdsQry, new Object[]{subProductId});

		for(Map<String, Object> childProds : dbChildProductsList) {
			sb = sb.append(String.valueOf(childProds.get("CHILD_PRODUCT_ID"))+"_"+String.valueOf(childProds.get("NAME"))+"|");
		}		
		return sb.toString();
	}

	public String loadIndentIssueMeasurements(String childProdId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbMeasurementsList = null;		

		log.debug("Child Product Id = "+childProdId);

		sb = new StringBuffer();

		String measurementsQry = "SELECT MEASUREMENT_ID, NAME FROM MEASUREMENT WHERE CHILD_PRODUCT_ID = ? and STATUS = ?";
		log.debug("Query to fetch measurement(s) = "+measurementsQry);

		dbMeasurementsList = jdbcTemplate.queryForList(measurementsQry, new Object[]{childProdId,"A"});

		for(Map<String, Object> measurements : dbMeasurementsList) {
			sb = sb.append(String.valueOf(measurements.get("MEASUREMENT_ID"))+"_"+String.valueOf(measurements.get("NAME"))+"|");
		}
		return sb.toString();
	}

	public int insertRequesterData(int indentEntryId, String userId, String siteId, IndentIssueRequesterDto iiReqDto) {

		int result = 0;

		Calendar cal1 = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
		
		
		String requesterQry = "INSERT INTO INDENT_ENTRY (INDENT_ENTRY_ID, USER_ID, SITE_ID, REQ_ID, RECEIVED_OR_ISSUED_DATE, REQUESTER_NAME, REQUESTER_ID, NOTE, INDENT_TYPE, SLIP_NUMBER,CONTRACTOR_NAME,ENTRY_DATE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,sysdate)";
		log.debug("Query for requester = "+requesterQry);

		result = jdbcTemplate.update(requesterQry, new Object[] {
				indentEntryId, 
				userId, 
				siteId, 
				iiReqDto.getReqId(), 
				iiReqDto.getReqDate()+" "+sdf.format(cal1.getTime()), 
				iiReqDto.getRequesterName(), 
				iiReqDto.getRequesterId(), 

				iiReqDto.getPurpose(), 
				"OUT",
				iiReqDto.getSlipNumber(),
				iiReqDto.getContractorName()
		}
		);
		log.debug("Result = "+result);			
		logger.info("IndentIssueDao --> insertRequestorData() --> Result = "+result);

		return result;
	}

	public int insertIndentIssueData(int indentEntrySeqNum, IndentIssueDto issueDto, String basicAmt, String quantity, String priceId, String userId, String siteId) {

		int result = 0;	
		AuditLogDetailsBean auditBean = null;
		Double totAmt = Double.parseDouble(basicAmt.replace(",", "").trim());
		Double qty = Double.parseDouble(quantity);
		Double perPiceAmt = totAmt*qty;
		String totalAmt = new DecimalFormat().format(perPiceAmt);
		//String indentIssueQry = "INSERT INTO INDENT_ENTRY_DETAILS (INDENT_ENTRY_DETAILS_ID, INDENT_ENTRY_ID, PRODUCT_ID, PRODUCT_NAME, SUB_PRODUCT_ID, SUB_PRODUCT_NAME, CHILD_PRODUCT_ID, CHILD_PRODUCT_NAME, ISSUED_QTY, MEASUR_MNT_ID, MEASUR_MNT_NAME, HSN_CODE, UORF, REMARKS, BLOCK_ID, FLOOR_ID, FLAT_ID, ENTRY_DATE,PRICE,TOTAL_AMOUNT, PRICE_ID) VALUES (INDENT_ENTRY_DETAILS_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate,?,?,?)";
		String indentIssueQry = "INSERT INTO INDENT_ENTRY_DETAILS (INDENT_ENTRY_DETAILS_ID, INDENT_ENTRY_ID, PRODUCT_ID, PRODUCT_NAME, SUB_PRODUCT_ID, SUB_PRODUCT_NAME, CHILD_PRODUCT_ID, CHILD_PRODUCT_NAME, ISSUED_QTY, MEASUR_MNT_ID, MEASUR_MNT_NAME, HSN_CODE, UORF, REMARKS, BLOCK_ID, FLOOR_ID, FLAT_ID, ENTRY_DATE, PRICE_ID) VALUES (INDENT_ENTRY_DETAILS_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate,?)";
		log.debug("Query for indent issue = "+indentIssueQry);

		result = jdbcTemplate.update(indentIssueQry, new Object[]{
				indentEntrySeqNum, 
				issueDto.getProdId(), 
				issueDto.getProdName(), 
				issueDto.getSubProdId(), 
				issueDto.getSubProdName(), 
				issueDto.getChildProdId(), 
				issueDto.getChildProdName(), 
				issueDto.getQuantity(), 
				issueDto.getMeasurementId(), 
				issueDto.getMeasurementName(), 
				issueDto.getHsnCd(),
				issueDto.getuOrF(),
				issueDto.getRemarks(), 
				issueDto.getBlockId(), 
				issueDto.getFloorId(), 
				issueDto.getFlatId(),
				//basicAmt,
				//totalAmt,
				priceId
		}
		);

		auditBean = new AuditLogDetailsBean();
		auditBean.setEntryDetailsId(String.valueOf(indentEntrySeqNum));
		auditBean.setLoginId(userId);
		auditBean.setOperationName("New Issue");
		auditBean.setStatus("Info");
		auditBean.setSiteId(siteId);
		/*new SaveAuditLogDetails().saveAuditLogDetails(auditBean);
		log.debug("Result = "+result);
		logger.info("IndentIssueDao --> insertIndentIssueData() --> Result = "+result);*/

		return result;
	}

	public int updateIndentAvalibility(IndentIssueDto indentIssuDto, String siteId) {
		List<Map<String, Object>> dbProductDetailsList = null;

		int result = 0;

		String availability_Id="";
		double issue_Form_Quantity=0.0;
		double quantity=0.0;
		String query="SELECT PRODUT_QTY,INDENT_AVAILABILITY_ID FROM INDENT_AVAILABILITY WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID=? AND CHILD_PRODUCT_ID=? AND MESURMENT_ID= ? AND SITE_ID=?  ";
		
		dbProductDetailsList = jdbcTemplate.queryForList(query, new Object[] {

				indentIssuDto.getProdId(), 
				indentIssuDto.getSubProdId(), 
				indentIssuDto.getChildProdId(), 
				indentIssuDto.getMeasurementId(), 
				siteId
		});
		if (null != dbProductDetailsList && dbProductDetailsList.size() > 0) {
			for (Map<String, Object> prods : dbProductDetailsList) {
				quantity = Double.parseDouble(prods.get("PRODUT_QTY") == null ? "" : prods.get("PRODUT_QTY").toString());
				availability_Id = (prods.get("INDENT_AVAILABILITY_ID") == null ? "" : prods.get("INDENT_AVAILABILITY_ID").toString());
			}
		}
		
		
		issue_Form_Quantity=Double.parseDouble(indentIssuDto.getQuantity());
		quantity=quantity-issue_Form_Quantity;
		
		String updateIndentAvalibilityQry ="UPDATE INDENT_AVAILABILITY SET PRODUT_QTY ='"+quantity+"' WHERE INDENT_AVAILABILITY_ID ='"+availability_Id+"'";
		log.debug("Query for update indent avalibility = "+updateIndentAvalibilityQry);

		result = jdbcTemplate.update(updateIndentAvalibilityQry, new Object[] {});
		log.debug("Result = "+result);
		logger.info("IndentIssueDao --> updateIndentAvalibility() --> Result = "+result);

		return result;
	}

	public void updateIndentAvalibilityWithNewIndent(IndentIssueDto indentIssuDto, String siteId) {

		int result = 0;

		String requesterQry = "INSERT INTO INDENT_AVAILABILITY (INDENT_AVAILABILITY_ID, PRODUCT_ID, SUB_PRODUCT_ID, CHILD_PRODUCT_ID, PRODUT_QTY, MESURMENT_ID, SITE_ID) VALUES (INDENT_AVAILABILITY_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?)";
		log.debug("Query for new indent entry in indent availability = "+requesterQry);

		result = jdbcTemplate.update(requesterQry, new Object[] {
				indentIssuDto.getProdId(), 
				indentIssuDto.getSubProdId(), 
				indentIssuDto.getChildProdId(), 
				indentIssuDto.getQuantity(), 
				indentIssuDto.getMeasurementId(),
				siteId
		}
		);
		log.debug("Result = "+result);			
		logger.info("IndentIssueDao --> updateIndentAvalibilityWithNewIndent() --> Result = "+result);
	}

	public int getIndentEntrySequenceNumber() {

		int indentEntrySeqNum = 0;

		indentEntrySeqNum = jdbcTemplate.queryForInt("SELECT INDENT_ENTRY_SEQ.NEXTVAL FROM DUAL");

		return indentEntrySeqNum;
	}

	@Override
	public String getProductAvailability(String prodId, String subProductId, String childProdId, String measurementId,String requesteddate,String siteId) {

		List<Map<String, Object>> dbProductAvailabilityList = null;	

		//start------------ user341 ---------


		String doConvert="no";
		String strConversionMeasurmentId  =  validateParams.getProperty(childProdId+"ID") == null ? "" : validateParams.getProperty(childProdId+"ID").toString();
		//System.out.println("strConversionMeasurmentId(in properties file): "+strConversionMeasurmentId);
	//	System.out.println("measurementId(at the time of user input): "+measurementId );
		if(!strConversionMeasurmentId.equals(measurementId)&&!strConversionMeasurmentId.equals(""))
		{

			measurementId=strConversionMeasurmentId;
			doConvert="yes";
		}

		//end-----------------------------------


		log.debug("Product Id = "+prodId+", Sub Product Id = "+subProductId+", Child Product Id = "+childProdId+", Measurement Id = "+measurementId+" and Site Id = "+siteId);
		//System.out.println("requesteddate"+requesteddate);
		String indentAvaQry = "SELECT  SUM(AVAILABLE_QUANTITY) FROM SUMADHURA_PRICE_LIST  WHERE PRODUCT_ID = ? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID = ? AND UNITS_OF_MEASUREMENT = ? AND SITE_ID = ? AND CREATED_DATE<= TO_DATE(?,'dd-MM-yy') and STATUS = 'A'";
		//log.debug("Query to fetch product availability = "+indentAvaQry);

		dbProductAvailabilityList = jdbcTemplate.queryForList(indentAvaQry, new Object[] {
				prodId,
				subProductId,
				childProdId,
				measurementId,siteId,requesteddate

		}
		);
		//System.out.println("dblist"+dbProductAvailabilityList);

		String qty = "";
		for(Map<String, Object> availableQuantity : dbProductAvailabilityList) {
			//String measurementName = getMeasurementName(measurementId);
			//qty = String.valueOf(availableQuantity.get("PRODUT_QTY")+" "+measurementName);
			qty = String.valueOf(availableQuantity.get("SUM(AVAILABLE_QUANTITY)"));
			//System.out.println("value"+qty);
			break;
		}

		//start--------- user341 ----------
		if(doConvert.equals("yes"))
		{
		
			String childCheck=validateParams.getProperty(childProdId+"AVAILQTYCALCULATION")== null ? "" : validateParams.getProperty(childProdId+"AVAILQTYCALCULATION").toString();
			/*if(qty!=null && !qty.equals("")){
				double i=Double.parseDouble(qty);
			}*/
			double i=Double.parseDouble(qty);
			String stractqty=validateParams.getProperty(childProdId+"ActualQuantity");
			Double actqty=Double.parseDouble(stractqty);
			if(childCheck.equalsIgnoreCase("Multiplication")){
				
			i=i*actqty;
			
			}else{
				//double i=Double.parseDouble(qty);
				//String stractqty=validateParams.getProperty(childProdId+"ActualQuantity");
				//System.out.println("String ActualQuantity:"+stractqty);
				//Double actqty=Double.parseDouble(stractqty);
				i=i/actqty;
				
			}

			
			qty=String.format( "%.2f", i );
		}
		//end--------------------------

		return qty;
	}



	@Override
	public Map<String, String> loadBlockDetails(String strSiteId) {

		Map<String, String> blocks = null;
		List<Map<String, Object>> dbBlocksList = null;

		blocks = new HashMap<String, String>();

		String blocksQry = "SELECT BLOCK_ID, NAME FROM BLOCK where SITE_ID = ?";
		log.debug("Query to fetch blocks = "+blocksQry);

		dbBlocksList = jdbcTemplate.queryForList(blocksQry, new Object[]{strSiteId});

		for(Map<String, Object> block : dbBlocksList) {
			blocks.put(String.valueOf(block.get("BLOCK_ID")), String.valueOf(block.get("NAME")));
		}
		return blocks;
	}



	@Override
	public String getProjectName(HttpSession session) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbSitesList = null;		

		String siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

		log.debug("Site Id = "+siteId);
		logger.info(siteId);

		sb = new StringBuffer();

		String siteNameQry = "SELECT SITE_NAME FROM SITE WHERE SITE_ID = ?";
		log.debug("Query to fetch site name = "+siteNameQry);

		dbSitesList = jdbcTemplate.queryForList(siteNameQry, new Object[]{siteId});

		for(Map<String, Object> siteName : dbSitesList) {
			sb = sb.append(String.valueOf(siteName.get("SITE_NAME")));
			break;
		}
		logger.info(sb.toString());
		return sb.toString();	
	}

	@Override
	public String getFloorDetails(String blockId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbFloorList = null;

		log.debug("Block Id = "+blockId);

		sb = new StringBuffer();

		String floorsQry = "SELECT FLOOR_ID, NAME FROM FLOOR WHERE BLOCK_ID = ?";
		log.debug("Query to fetch floors = "+floorsQry);

		dbFloorList = jdbcTemplate.queryForList(floorsQry, new Object[]{blockId});

		for(Map<String, Object> floors : dbFloorList) {
			sb = sb.append(String.valueOf(floors.get("FLOOR_ID"))+"@@"+String.valueOf(floors.get("NAME"))+"|");
		}
		return sb.toString();
	}

	@Override
	public String getFlatDetails(String floorId) {

		StringBuffer sb = null;
		List<Map<String, Object>> dbFlatsList = null;

		log.debug("Floor Id = "+floorId);

		sb = new StringBuffer();

		String flatsQry = "SELECT FLAT_ID, NAME FROM FLAT WHERE FLOOR_ID = ?";
		log.debug("Query to fetch flats = "+flatsQry);

		dbFlatsList = jdbcTemplate.queryForList(flatsQry, new Object[]{floorId});

		for(Map<String, Object> flats : dbFlatsList) {
			sb = sb.append(String.valueOf(flats.get("FLAT_ID"))+"@@"+String.valueOf(flats.get("NAME"))+"|");
		}
		return sb.toString();
	}

	public List<ViewIndentIssueDetailsBean> getViewIndentIssueDetails(String fromDate, String toDate, String siteId, String val) {

		String query = "";
		String strDCFormQuery = "";
		String strDCNumber = "";
		JdbcTemplate template = null;
		List<Map<String, Object>> dbIndentDts = null;
		List<ViewIndentIssueDetailsBean> list = new ArrayList<ViewIndentIssueDetailsBean>();
		ViewIndentIssueDetailsBean indentObj = null; 

		try {
			//if part is for view indent receive details,else part is for view indent issue details
			template = new JdbcTemplate(DBConnection.getDbConnection());
			if (StringUtils.isNotBlank(val)) {
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = "SELECT VD.VENDOR_NAME,IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME,IED.RECEVED_QTY, IE.INVOICE_ID,IED.MEASUR_MNT_NAME,IE.RECEIVED_OR_ISSUED_DATE,SED.EMP_NAME,IE.INVOICE_DATE,IE.TOTAL_AMOUNT,SPL.BASIC_AMOUNT,SPL.TAX_AMOUNT,SPL.OTHER_CHARGES_AFTER_TAX,(SPL.TOTAL_AMOUNT) as AFTER_TAX_TOTAL FROM INDENT_ENTRY IE,INDENT_ENTRY_DETAILS IED, VENDOR_DETAILS VD,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE IN ('IN','IND','INO') AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID  and IE.USER_ID = SED.EMP_ID and SPL.INDENT_ENTRY_DETAILS_ID = IED.INDENT_ENTRY_DETAILS_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = "SELECT VD.VENDOR_NAME,IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME,IED.RECEVED_QTY, IE.INVOICE_ID,IED.MEASUR_MNT_NAME,IE.RECEIVED_OR_ISSUED_DATE,SED.EMP_NAME,IE.INVOICE_DATE,IE.TOTAL_AMOUNT,SPL.BASIC_AMOUNT,SPL.TAX_AMOUNT,SPL.OTHER_CHARGES_AFTER_TAX,(SPL.TOTAL_AMOUNT) as AFTER_TAX_TOTAL FROM INDENT_ENTRY IE,INDENT_ENTRY_DETAILS IED, VENDOR_DETAILS VD,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE IN ('IN','IND','INO') AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID  and IE.USER_ID = SED.EMP_ID and SPL.INDENT_ENTRY_DETAILS_ID = IED.INDENT_ENTRY_DETAILS_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) >=TO_DATE('"+fromDate+"', 'dd-MM-yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = "SELECT VD.VENDOR_NAME,IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME,IED.RECEVED_QTY, IE.INVOICE_ID,IED.MEASUR_MNT_NAME,IE.RECEIVED_OR_ISSUED_DATE,SED.EMP_NAME,IE.INVOICE_DATE,IE.TOTAL_AMOUNT,SPL.BASIC_AMOUNT,SPL.TAX_AMOUNT,SPL.OTHER_CHARGES_AFTER_TAX,(SPL.TOTAL_AMOUNT) as AFTER_TAX_TOTAL FROM INDENT_ENTRY IE,INDENT_ENTRY_DETAILS IED, VENDOR_DETAILS VD,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE IN ('IN','IND','INO') AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID  and IE.USER_ID = SED.EMP_ID and SPL.INDENT_ENTRY_DETAILS_ID = IED.INDENT_ENTRY_DETAILS_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) <=TO_DATE('"+toDate+"', 'dd-MM-yy')";
 
 
				}


				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					strDCFormQuery = "SELECT VD.VENDOR_NAME,SED.EMP_NAME, DF.PRODUCT_NAME, DF.SUB_PRODUCT_NAME, DF.CHILD_PRODUCT_NAME, DF.RECEVED_QTY,IE.INVOICE_ID, DF.MEASUR_MNT_NAME,IE.RECEIVED_DATE as RECEIVED_OR_ISSUED_DATE,IE.DC_NUMBER,IE.INVOICE_DATE,IE.TOTAL_AMOUNT,SPL.BASIC_AMOUNT,SPL.TAX_AMOUNT,SPL.OTHER_CHARGES_AFTER_TAX,(SPL.TOTAL_AMOUNT) as AFTER_TAX_TOTAL FROM DC_ENTRY IE,DC_FORM DF, VENDOR_DETAILS VD,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL WHERE IE.DC_ENTRY_ID = DF.DC_ENTRY_ID  AND IE.SITE_ID='"+siteId+"'  AND IE.VENDOR_ID=VD.VENDOR_ID and IE.USER_ID = SED.EMP_ID and SPL.DC_FORM_ENTRY_ID = DF.DC_FORM_ID AND TRUNC(IE.RECEIVED_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy') and DF.STATUS='A'";
 
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					strDCFormQuery = " SELECT VD.VENDOR_NAME,SED.EMP_NAME, DF.PRODUCT_NAME, DF.SUB_PRODUCT_NAME, DF.CHILD_PRODUCT_NAME, DF.RECEVED_QTY,IE.INVOICE_ID, DF.MEASUR_MNT_NAME,IE.RECEIVED_DATE as RECEIVED_OR_ISSUED_DATE,IE.DC_NUMBER,IE.INVOICE_DATE,IE.TOTAL_AMOUNT,SPL.BASIC_AMOUNT,SPL.TAX_AMOUNT,SPL.OTHER_CHARGES_AFTER_TAX,(SPL.TOTAL_AMOUNT) as AFTER_TAX_TOTAL FROM DC_ENTRY IE,DC_FORM DF, VENDOR_DETAILS VD,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL WHERE IE.DC_ENTRY_ID = DF.DC_ENTRY_ID  AND IE.SITE_ID='"+siteId+"'  AND IE.VENDOR_ID=VD.VENDOR_ID and IE.USER_ID = SED.EMP_ID and SPL.DC_FORM_ENTRY_ID = DF.DC_FORM_ID AND TRUNC(IE.RECEIVED_DATE)  >= TO_DATE('"+fromDate+"','dd-MM-yy')  and DF.STATUS='A'";
				} else if(StringUtils.isNotBlank(toDate)) {
					strDCFormQuery = "SELECT VD.VENDOR_NAME,SED.EMP_NAME, DF.PRODUCT_NAME, DF.SUB_PRODUCT_NAME, DF.CHILD_PRODUCT_NAME, DF.RECEVED_QTY,IE.INVOICE_ID, DF.MEASUR_MNT_NAME,IE.RECEIVED_DATE as RECEIVED_OR_ISSUED_DATE,IE.DC_NUMBER,IE.INVOICE_DATE,IE.TOTAL_AMOUNT,SPL.BASIC_AMOUNT,SPL.TAX_AMOUNT,SPL.OTHER_CHARGES_AFTER_TAX,(SPL.TOTAL_AMOUNT) as AFTER_TAX_TOTAL FROM DC_ENTRY IE,DC_FORM DF, VENDOR_DETAILS VD,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL WHERE IE.DC_ENTRY_ID = DF.DC_ENTRY_ID  AND IE.SITE_ID='"+siteId+"'  AND IE.VENDOR_ID=VD.VENDOR_ID and IE.USER_ID = SED.EMP_ID and SPL.DC_FORM_ENTRY_ID = DF.DC_FORM_ID AND TRUNC(IE.RECEIVED_DATE)  <=  TO_DATE('"+toDate+"','dd-MM-yy') and DF.STATUS='A'";
				}

			} else {
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID,IE.ENTRY_DATE, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,B.BLOCK_ID FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD,BLOCK B WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND TRUNC(IE.ENTRY_DATE) BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					//query = "SELECT LD.USERNAME,IE.CONTRACTOR_NAME,IE.REQUESTER_NAME, IE.REQUESTER_ID,IE.ENTRY_DATE, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,B.NAME,IE.SLIP_NUMBER FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD,BLOCK B WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND  IED.BLOCK_ID = B.BLOCK_ID and IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND TRUNC(IE.ENTRY_DATE) BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					query = "SELECT IE.RECEIVED_OR_ISSUED_DATE,IE.CONTRACTOR_NAME,IE.REQUESTER_NAME, IE.REQUESTER_ID ,IE.ENTRY_DATE , IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,IE.SLIP_NUMBER,IE.TOTAL_AMOUNT,IED.MEASUR_MNT_NAME,IED.REMARKS,SED.EMP_NAME,SPL.AMOUNT_PER_UNIT_BEFORE_TAXES,SPL.TAX,B.NAME,(F.NAME)AS FLAT_NAME,(FR.NAME)AS FLOOR_NAME  FROM INDENT_ENTRY IE,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL,INDENT_ENTRY_DETAILS IED "
							+ "LEFT OUTER JOIN BLOCK B on B.BLOCK_ID=IED.BLOCK_ID " 
							+" LEFT OUTER JOIN FLAT F on F.FLAT_ID=IED.FLAT_ID AND F.FLOOR_ID=IED.FLOOR_ID "
							+ " LEFT OUTER JOIN FLOOR FR on FR.FLOOR_ID=IED.FLOOR_ID AND F.FLOOR_ID=IED.FLOOR_ID "
							+ " WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID and IE.USER_ID=SED.EMP_ID AND SPL.PRICE_ID=IED.PRICE_ID and IE.INDENT_TYPE IN ('OUT','OUTO') AND IE.SITE_ID='"+siteId+"' AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";

				} else if (StringUtils.isNotBlank(fromDate)) {
					//query = "SELECT LD.USERNAME, IE.CONTRACTOR_NAME,IE.REQUESTER_NAME, IE.REQUESTER_ID ,IE.ENTRY_DATE , IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,B.NAME,IE.SLIP_NUMBER FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD,BLOCK B WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND   IED.BLOCK_ID = B.BLOCK_ID and IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND  TRUNC(IE.ENTRY_DATE) = TO_DATE('"+fromDate+"', 'dd-MM-yy')";
					query = "SELECT IE.RECEIVED_OR_ISSUED_DATE,IE.CONTRACTOR_NAME,IE.REQUESTER_NAME, IE.REQUESTER_ID ,IE.ENTRY_DATE ,IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,IE.SLIP_NUMBER,IE.TOTAL_AMOUNT,IED.MEASUR_MNT_NAME,IED.REMARKS,SED.EMP_NAME,SPL.AMOUNT_PER_UNIT_BEFORE_TAXES,SPL.TAX,B.NAME,(F.NAME)AS FLAT_NAME,(FR.NAME)AS FLOOR_NAME  FROM INDENT_ENTRY IE,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL,INDENT_ENTRY_DETAILS IED "
							+ " LEFT OUTER JOIN BLOCK B on B.BLOCK_ID=IED.BLOCK_ID"
							+ " LEFT OUTER JOIN FLAT F on F.FLAT_ID=IED.FLAT_ID AND F.FLOOR_ID=IED.FLOOR_ID"
							+ " LEFT OUTER JOIN FLOOR FR on FR.FLOOR_ID=IED.FLOOR_ID AND F.FLOOR_ID=IED.FLOOR_ID "
							+ " WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID and IE.USER_ID=SED.EMP_ID AND SPL.PRICE_ID=IED.PRICE_ID and IE.INDENT_TYPE IN ('OUT','OUTO') AND IE.SITE_ID='"+siteId+"'  AND  TRUNC(IE.RECEIVED_OR_ISSUED_DATE) >= TO_DATE('"+fromDate+"', 'dd-MM-yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					//query = "SELECT LD.USERNAME, IE.CONTRACTOR_NAME,IE.REQUESTER_NAME, IE.REQUESTER_ID ,IE.ENTRY_DATE  , IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,B.NAME,IE.SLIP_NUMBER FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD,BLOCK B WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IED.BLOCK_ID = B.BLOCK_ID and IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND TRUNC(IE.ENTRY_DATE) = TO_DATE('"+toDate+"', 'dd-MM-yy')";
					query = "SELECT IE.RECEIVED_OR_ISSUED_DATE,IE.CONTRACTOR_NAME,IE.REQUESTER_NAME, IE.REQUESTER_ID ,IE.ENTRY_DATE , IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY,IE.SLIP_NUMBER,IE.TOTAL_AMOUNT,IED.MEASUR_MNT_NAME,IED.REMARKS,SED.EMP_NAME,SPL.AMOUNT_PER_UNIT_BEFORE_TAXES,SPL.TAX,B.NAME,(F.NAME)AS FLAT_NAME,(FR.NAME)AS FLOOR_NAME  FROM INDENT_ENTRY IE,SUMADHURA_EMPLOYEE_DETAILS SED,SUMADHURA_PRICE_LIST SPL,INDENT_ENTRY_DETAILS IED "
							+ " LEFT OUTER JOIN BLOCK B on B.BLOCK_ID=IED.BLOCK_ID"
							+ " LEFT OUTER JOIN FLAT F on F.FLAT_ID=IED.FLAT_ID AND F.FLOOR_ID=IED.FLOOR_ID"
							+ " LEFT OUTER JOIN FLOOR FR on FR.FLOOR_ID=IED.FLOOR_ID AND F.FLOOR_ID=IED.FLOOR_ID "
							+ " WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID and IE.USER_ID=SED.EMP_ID AND SPL.PRICE_ID=IED.PRICE_ID and IE.INDENT_TYPE IN ('OUT','OUTO') AND IE.SITE_ID='"+siteId+"'  AND  TRUNC(IE.RECEIVED_OR_ISSUED_DATE) <= TO_DATE('"+toDate+"', 'dd-MM-yy')";
				}
			}


			dbIndentDts = template.queryForList(query, new Object[]{});
			if (StringUtils.isNotBlank(val)) {
				for(Map<String, Object> prods : dbIndentDts) {
					indentObj = new ViewIndentIssueDetailsBean();
					indentObj.setVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
					indentObj.setUserId(prods.get("EMP_NAME")==null ? "" : prods.get("EMP_NAME").toString());
					indentObj.setRequesterName(prods.get("MEASUR_MNT_NAME")==null ? "" : prods.get("MEASUR_MNT_NAME").toString());
					indentObj.setRequesterId(prods.get("INVOICE_ID")==null ? "" : prods.get("INVOICE_ID").toString());
					indentObj.setStrInvoiceDate(prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString());
					indentObj.setProductName(prods.get("PRODUCT_NAME")==null ? "" : prods.get("PRODUCT_NAME").toString());
					indentObj.setSubProdName(prods.get("SUB_PRODUCT_NAME")==null ? "" : prods.get("SUB_PRODUCT_NAME").toString());
					indentObj.setChildProdName(prods.get("CHILD_PRODUCT_NAME")==null ? "" : prods.get("CHILD_PRODUCT_NAME").toString());
					indentObj.setIssueQTY(prods.get("RECEVED_QTY")==null ? "" : prods.get("RECEVED_QTY").toString());
					indentObj.setStrSlipNumber(prods.get("SLIP_NUMBER")==null ? "" : prods.get("SLIP_NUMBER").toString());
					
					indentObj.setBasicAmount(prods.get("BASIC_AMOUNT")==null ? "" : prods.get("BASIC_AMOUNT").toString());
					indentObj.setTaxAmount(prods.get("TAX_AMOUNT")==null ? "0" : prods.get("TAX_AMOUNT").toString());
					indentObj.setOtherCharges(prods.get("OTHER_CHARGES_AFTER_TAX")==null ? "0" : prods.get("OTHER_CHARGES_AFTER_TAX").toString());
					indentObj.setTotalAmt(prods.get("AFTER_TAX_TOTAL")==null ? "" : prods.get("AFTER_TAX_TOTAL").toString());
					
					
					
					
					double doubleTotalAmount = Double.valueOf(prods.get("TOTAL_AMOUNT")==null ? "" : prods.get("TOTAL_AMOUNT").toString());
					//int intTotalAmount  = (int)((doubleTotalAmount*100));
					//doubleTotalAmount	= ((double)intTotalAmount)/100;
					
					NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
					String doubleTotalAmnt=numberFormat.format(doubleTotalAmount);
					//String doubleTotalAmount = String.format("%,d", numberAsString);
				//	System.out.println("the total amount"+doubleTotalAmnt);
					
					indentObj.setStrTotalAmount(doubleTotalAmnt);


					String date=prods.get("RECEIVED_OR_ISSUED_DATE")==null ? "" : prods.get("RECEIVED_OR_ISSUED_DATE").toString();
					
					DateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					
					String convertreceive_time = "";
					
					try{

						Date receive_date = dt.parse(date);
					//	Date invoice_date = dt.parse(invoicedate);
						SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
						SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");
						date = dt1.format(receive_date);
						convertreceive_time = time1.format(receive_date);
					//	invoicedate = dt1.format(invoice_date);
					
					}
					catch(Exception e){
						e.printStackTrace();
					}
					indentObj.setTime(convertreceive_time);
					
				/*	if (StringUtils.isNotBlank(date)) {
						date = DateUtil.dateConversion(date);
					} else {
						date = "";
					}*/
					indentObj.setReceivedDate(date);

					list.add(indentObj);
				}
				dbIndentDts = template.queryForList(strDCFormQuery, new Object[]{});
				for(Map<String, Object> prods : dbIndentDts) {
					indentObj = new ViewIndentIssueDetailsBean();
					indentObj.setVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
					indentObj.setUserId(prods.get("USERNAME")==null ? "" : prods.get("USERNAME").toString());
					indentObj.setRequesterName(prods.get("MEASUR_MNT_NAME")==null ? "" : prods.get("MEASUR_MNT_NAME").toString());
					strDCNumber = prods.get("DC_NUMBER")==null ? "" : prods.get("DC_NUMBER").toString();
					indentObj.setRequesterId("DCNO_"+strDCNumber);
					indentObj.setProductName(prods.get("PRODUCT_NAME")==null ? "" : prods.get("PRODUCT_NAME").toString());
					indentObj.setSubProdName(prods.get("SUB_PRODUCT_NAME")==null ? "" : prods.get("SUB_PRODUCT_NAME").toString());
					indentObj.setChildProdName(prods.get("CHILD_PRODUCT_NAME")==null ? "" : prods.get("CHILD_PRODUCT_NAME").toString());
					indentObj.setIssueQTY(prods.get("RECEVED_QTY")==null ? "" : prods.get("RECEVED_QTY").toString());
					indentObj.setStrSlipNumber(prods.get("SLIP_NUMBER")==null ? "" : prods.get("SLIP_NUMBER").toString());
					
					indentObj.setBasicAmount(prods.get("BASIC_AMOUNT")==null ? "" : prods.get("BASIC_AMOUNT").toString());
					indentObj.setTaxAmount(prods.get("TAX_AMOUNT")==null ? "0" : prods.get("TAX_AMOUNT").toString());
					indentObj.setOtherCharges(prods.get("OTHER_CHARGES_AFTER_TAX")==null ? "0" : prods.get("OTHER_CHARGES_AFTER_TAX").toString());
					indentObj.setTotalAmt(prods.get("AFTER_TAX_TOTAL")==null ? "" : prods.get("AFTER_TAX_TOTAL").toString());
					
					
					double doubleTotalAmount = Double.valueOf(prods.get("TOTAL_AMOUNT")==null ? "" : prods.get("TOTAL_AMOUNT").toString());
					
					//int intTotalAmount  = (int)((doubleTotalAmount*100));
					//doubleTotalAmount	= ((double)intTotalAmount)/100;
					
					NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
					String doubleTotalAmnt=numberFormat.format(doubleTotalAmount);
					//String doubleTotalAmount = String.format("%,d", numberAsString);
					
					
					
					
					indentObj.setStrTotalAmount(doubleTotalAmnt);
					
					String date=prods.get("RECEIVED_OR_ISSUED_DATE")==null ? "" : prods.get("RECEIVED_OR_ISSUED_DATE").toString();
					
					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					
					String convertreceive_time = "";
					
					try{

						Date receive_date = dt.parse(date);
					//	Date invoice_date = dt.parse(invoicedate);
						SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
						SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");
						date = dt1.format(receive_date);
						convertreceive_time = time1.format(receive_date);
					//	invoicedate = dt1.format(invoice_date);
					
					}
					catch(Exception e){
						e.printStackTrace();
					}
					indentObj.setTime(convertreceive_time);

					
				/*	if (StringUtils.isNotBlank(date)) {
						date = DateUtil.dateConversion(date);
					} else {
						date = "";
					}*/
					indentObj.setReceivedDate(date);

					list.add(indentObj);
				}


			} else {
				for(Map<String, Object> prods : dbIndentDts) {
					indentObj = new ViewIndentIssueDetailsBean();
					indentObj.setUserId(prods.get("USERNAME")==null ? "" : prods.get("USERNAME").toString());
					indentObj.setRequesterName(prods.get("REQUESTER_NAME")==null ? "" : prods.get("REQUESTER_NAME").toString());
					indentObj.setRequesterId(prods.get("REQUESTER_ID")==null ? "" : prods.get("REQUESTER_ID").toString());
					indentObj.setProductName(prods.get("PRODUCT_NAME")==null ? "" : prods.get("PRODUCT_NAME").toString());
					indentObj.setSubProdName(prods.get("SUB_PRODUCT_NAME")==null ? "" : prods.get("SUB_PRODUCT_NAME").toString());
					indentObj.setChildProdName(prods.get("CHILD_PRODUCT_NAME")==null ? "" : prods.get("CHILD_PRODUCT_NAME").toString());
					indentObj.setBlock_Name(prods.get("NAME")==null ? "" : prods.get("NAME").toString());
					indentObj.setFloorId(prods.get("FLOOR_ID")==null ? "" : prods.get("FLOOR_ID").toString());
					double issueQuantity=Double.parseDouble(prods.get("ISSUED_QTY")==null ? "" : prods.get("ISSUED_QTY").toString());
				//	indentObj.setIssueQTY(prods.get("ISSUED_QTY")==null ? "" : prods.get("ISSUED_QTY").toString());
					indentObj.setStrSlipNumber(prods.get("SLIP_NUMBER")==null ? "" : prods.get("SLIP_NUMBER").toString());
					indentObj.setContractorName(prods.get("CONTRACTOR_NAME")==null ? "" : prods.get("CONTRACTOR_NAME").toString());
					indentObj.setStrTotalAmount(prods.get("TOTAL_AMOUNT")==null ? "" : prods.get("TOTAL_AMOUNT").toString());
					String date=prods.get("RECEIVED_OR_ISSUED_DATE")==null ? "" : prods.get("RECEIVED_OR_ISSUED_DATE").toString();
					indentObj.setMeasurementName(prods.get("MEASUR_MNT_NAME")==null ? "" : prods.get("MEASUR_MNT_NAME").toString());
					indentObj.setRemarks(prods.get("REMARKS")==null ? "-" : prods.get("REMARKS").toString());
					indentObj.setIssuerName(prods.get("EMP_NAME")==null ? "-" : prods.get("EMP_NAME").toString());
				//	indentObj.setBlock_Number(prods.get("BLOCK_ID")==null ? "-" : prods.get("BLOCK_ID").toString());
					indentObj.setFlat_Name(prods.get("FLAT_NAME")==null ? "-" : prods.get("FLAT_NAME").toString());
					indentObj.setFloor_Name(prods.get("FLOOR_NAME")==null ? "-" : prods.get("FLOOR_NAME").toString());
					
					
					double price=Double.parseDouble(prods.get("AMOUNT_PER_UNIT_BEFORE_TAXES")==null ? "0" : prods.get("AMOUNT_PER_UNIT_BEFORE_TAXES").toString());
					double tax=Double.parseDouble(prods.get("TAX")==null ? "0" : prods.get("TAX").toString());
					double basicAmt=(price)*(issueQuantity);
					String strBasicAmount = String.format ("%.2f", basicAmt);
					double basicAmount=Double.parseDouble(strBasicAmount);
					double taxAmt=basicAmount*(tax/100);
					double total=basicAmount+taxAmt;
					String strTotalAmt=String.format ("%.2f", total);
					String strIssueQuantity=String.valueOf(issueQuantity);
					indentObj.setIssueQTY(strIssueQuantity);
					indentObj.setBasicAmount(strBasicAmount);
					indentObj.setTotalAmt(strTotalAmt);
					
					
					//String doubleTotalAmount = String.format("%,d", numberAsString);
					
					
					
					
					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					
					String convertreceive_time = "";
					
					try{

						Date receive_date = dt.parse(date);
					//	Date invoice_date = dt.parse(invoicedate);
						SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
						SimpleDateFormat time1 = new SimpleDateFormat("HH:mm:ss");
						date = dt1.format(receive_date);
						convertreceive_time = time1.format(receive_date);
					//	invoicedate = dt1.format(invoice_date);
					
					}
					catch(Exception e){
						e.printStackTrace();
					}
					indentObj.setTime(convertreceive_time);

					
					
					
					/*if (StringUtils.isNotBlank(date)) {
						date = DateUtil.dateConversion(date);
					} else {
						date = "";
					}*/
					indentObj.setEntryDate(date);
					list.add(indentObj);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			log.debug("Exception = "+ex.getMessage());
			logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;
	}

	//29-07-17 written by Madhu start
	@Override
	public List<IndentIssueDto>  getPriceListDetails(IndentIssueDto issueDto, String siteId) {

		String sql = "";
		List<Map<String, Object>> dbProductsList = null;
		List<IndentIssueDto> allDetails = null;
		IndentIssueDto issueDetails = null;

		sql = "select * from( SELECT PRICE_ID, PRODUCT_ID, SUB_PRODUCT_ID, CHILD_PRODUCT_ID, AVAILABLE_QUANTITY, AMOUNT_PER_UNIT_AFTER_TAXES FROM SUMADHURA_PRICE_LIST WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID=? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND STATUS='A' AND TRUNC(CREATED_DATE) < to_date('"+issueDto.getDate()+"', 'dd-MM-yy')  ORDER BY CREATED_DATE ASC ) where  ROWNUM <=1";
		logger.info("Issue "+sql);
		dbProductsList = jdbcTemplate.queryForList(sql, new Object[] {issueDto.getProdId(),issueDto.getSubProdId(), issueDto.getChildProdId(), siteId});
		allDetails = new ArrayList<IndentIssueDto>();
		if (null == dbProductsList || dbProductsList.size() == 0){
			sql = "select * from( SELECT PRICE_ID, PRODUCT_ID, SUB_PRODUCT_ID, CHILD_PRODUCT_ID, AVAILABLE_QUANTITY, AMOUNT_PER_UNIT_AFTER_TAXES FROM SUMADHURA_PRICE_LIST WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID=? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND STATUS='A' AND TRUNC(CREATED_DATE) <= to_date('"+issueDto.getDate()+"', 'dd-MM-yy') ORDER BY CREATED_DATE ASC ) where  ROWNUM <=1 ";
			logger.info("Issue "+sql);
			dbProductsList = jdbcTemplate.queryForList(sql, new Object[] {issueDto.getProdId(),issueDto.getSubProdId(), issueDto.getChildProdId(), siteId});
		}
		for(Map<String, Object> prods : dbProductsList) {

			issueDetails = new IndentIssueDto();
			issueDetails.setPriceId(prods.get("PRICE_ID")==null ? "" : prods.get("PRICE_ID").toString());
			issueDetails.setProdId(prods.get("PRODUCT_ID")==null ? "" : prods.get("PRODUCT_ID").toString());
			issueDetails.setSubProdId(prods.get("SUB_PRODUCT_ID")==null ? "" : prods.get("SUB_PRODUCT_ID").toString());
			issueDetails.setChildProdId(prods.get("CHILD_PRODUCT_ID")==null ? "" : prods.get("CHILD_PRODUCT_ID").toString());
			issueDetails.setQuantity(prods.get("AVAILABLE_QUANTITY")==null ? "" : prods.get("AVAILABLE_QUANTITY").toString());
			issueDetails.setAmount(prods.get("AMOUNT_PER_UNIT_AFTER_TAXES")==null ? "" : prods.get("AMOUNT_PER_UNIT_AFTER_TAXES").toString());
			allDetails.add(issueDetails);
		}


		return allDetails;
	}

	@Override
	public List<IndentIssueDto>  getPriceListDetails(IndentIssueDto issueDto, String siteId, String All) {

		String sql = "";
		List<Map<String, Object>> dbProductsList = null;
		List<IndentIssueDto> allDetails = null;
		IndentIssueDto issueDetails = null;
		try {
			sql = "SELECT PRICE_ID, PRODUCT_ID, SUB_PRODUCT_ID, CHILD_PRODUCT_ID, AVAILABLE_QUANTITY, AMOUNT_PER_UNIT_AFTER_TAXES FROM SUMADHURA_PRICE_LIST WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID=? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND STATUS='A' ORDER BY CREATED_DATE,PRICE_ID ASC";

			dbProductsList = jdbcTemplate.queryForList(sql, new Object[] {issueDto.getProdId(),issueDto.getSubProdId(), issueDto.getChildProdId(), siteId});
			allDetails = new ArrayList<IndentIssueDto>();
			for(Map<String, Object> prods : dbProductsList) {
				issueDetails = new IndentIssueDto();
				issueDetails.setPriceId(prods.get("PRICE_ID")==null ? "" : prods.get("PRICE_ID").toString());
				issueDetails.setProdId(prods.get("PRODUCT_ID")==null ? "" : prods.get("PRODUCT_ID").toString());
				issueDetails.setSubProdId(prods.get("SUB_PRODUCT_ID")==null ? "" : prods.get("SUB_PRODUCT_ID").toString());
				issueDetails.setChildProdId(prods.get("CHILD_PRODUCT_ID")==null ? "" : prods.get("CHILD_PRODUCT_ID").toString());
				issueDetails.setQuantity(prods.get("AVAILABLE_QUANTITY")==null ? "" : prods.get("AVAILABLE_QUANTITY").toString());
				issueDetails.setAmount(prods.get("AMOUNT_PER_UNIT_AFTER_TAXES")==null ? "" : prods.get("AMOUNT_PER_UNIT_AFTER_TAXES").toString());
				allDetails.add(issueDetails);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return allDetails;
	}
	@Override
	public void updateIndentEntryAmountColumn(String basicAmt, String quantity, String indentId) {

		String totalAmt = new DecimalFormat().format(Double.valueOf(basicAmt));
		String query = "UPDATE INDENT_ENTRY SET TOTAL_AMOUNT=? WHERE INDENT_ENTRY_ID=? ";
		jdbcTemplate.update(query, new Object[] {totalAmt, indentId});
	}
	@Override
	public void updatePriceListDetails(String quantity, String status, String priceId) {

		String query = "UPDATE SUMADHURA_PRICE_LIST SET AVAILABLE_QUANTITY=?, STATUS=?,UPDATED_DATE=SYSDATE  WHERE PRICE_ID=? ";
		jdbcTemplate.update(query, new Object[] { quantity, status, priceId });

	}

	/*@Override
	public void updateSumadhuraPriceListIndentEntryDetailsId(String priceId, String indentEntryDetailsId) {

		String query = "UPDATE SUMADHURA_PRICE_LIST SET INDENT_ENTRY_DETAILS_ID=? WHERE PRICE_ID=? ";
		jdbcTemplate.update(query, new Object[] {indentEntryDetailsId, priceId });

	}*/
	public static <K, V> Map<K, V> printMap(Map<K, V> map) {
		Map<K, V> mapObje = new TreeMap<K, V>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			mapObje.put( entry.getKey(), entry.getValue());

		}

		return mapObje;
	}
	//29-07-17 written by Madhu end

	@Override
	public void updateIssueDetailsIntoSumadhuraCloseBalance(IndentIssueDto issueDto, String strSiteId, String priceId, Double IssueQty) {

		String query = "";
		Double quantity = 0.0;
		Double totalAmt = 0.0;
		Double totalAmtForOneQty = 0.0;

		List<Map<String, Object>> dbClosingBalancesList = null;

		query = "SELECT CLOSING_BALANCE_ID,QUANTITY, TOTAL_AMOUNT FROM SUMADHURA_CLOSING_BALANCE WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) = TO_DATE('"+ issueDto.getDate() + "', 'dd-MM-yy') AND ROWNUM <= 1 ORDER BY DATE_AND_TIME  DESC";
		dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), strSiteId, issueDto.getMeasurementId() });

		if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {

			logger.info("Indent Issue Close balance query " + query);
			logger.info("Indent Issue Close balance dbClosingBalancesList " + dbClosingBalancesList);
			logger.info("totalAmtForOneQty  " + totalAmtForOneQty);
			quantity = Double.valueOf(quantity - IssueQty);
			totalAmtForOneQty = (IssueQty * Double.valueOf(priceId));

			query = "UPDATE SUMADHURA_CLOSING_BALANCE SET QUANTITY=QUANTITY-'" + IssueQty + "', TOTAL_AMOUNT= TOTAL_AMOUNT-'" + totalAmtForOneQty + "' WHERE DATE_AND_TIME >= '" + issueDto.getDate() + "' AND PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ?";
			jdbcTemplate.update(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), strSiteId, issueDto.getMeasurementId() });

		} else {
			query = "SELECT CLOSING_BALANCE_ID,QUANTITY, TOTAL_AMOUNT FROM SUMADHURA_CLOSING_BALANCE WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) <= TO_DATE('" + issueDto.getDate() + "', 'dd-MM-yy') AND ROWNUM <= 1 ORDER BY DATE_AND_TIME  DESC";
			dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), strSiteId, issueDto.getMeasurementId() });
			if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {
				for (Map<String, Object> prods : dbClosingBalancesList) {

					quantity = Double.parseDouble(prods.get("QUANTITY") == null ? "" : prods.get("QUANTITY").toString());
					totalAmt = Double.parseDouble(prods.get("TOTAL_AMOUNT") == null ? "" : prods.get("TOTAL_AMOUNT").toString());
				}
				logger.info("Indent Issue Close balance query " + query);
				logger.info("Indent Issue Close balance dbClosingBalancesList " + dbClosingBalancesList);
				logger.info("totalAmtForOneQty  " + totalAmtForOneQty);
				quantity = Double.valueOf(quantity - IssueQty);
				totalAmtForOneQty = totalAmt - (IssueQty * Double.valueOf(priceId));

				query = "INSERT INTO SUMADHURA_CLOSING_BALANCE (CLOSING_BALANCE_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,MEASUREMENT_ID,QUANTITY,SITE,TOTAL_AMOUNT,DATE_AND_TIME) VALUES (SUMADHURA_CLOSING_BALANCE_SEQ.NEXTVAL,?, ?, ?, ?, ?,?,?,?)";
				jdbcTemplate.update(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), issueDto.getMeasurementId(), quantity, strSiteId, totalAmtForOneQty, issueDto.getDate() });

				query = "UPDATE SUMADHURA_CLOSING_BALANCE SET QUANTITY=QUANTITY-'" + IssueQty + "', TOTAL_AMOUNT= TOTAL_AMOUNT-'" + totalAmtForOneQty + "' WHERE DATE_AND_TIME > '" + issueDto.getDate() + "' AND PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE=? AND MEASUREMENT_ID = ?";
				jdbcTemplate.update(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), strSiteId, issueDto.getMeasurementId() });

			}
		}
	}

	@Override
	public void updateIssueDetailsSumadhuClosingBalByProduct(IndentIssueDto issueDto, String strSiteId, String priceId, Double IssueQty) {

		String query = "";
		Double quantity = 0.0;
		Double totalAmt = 0.0;
		Double totalAmtForOneQty = 0.0;

		List<Map<String, Object>> dbClosingBalancesList = null;

		Date today = new Date();                   
		@SuppressWarnings("deprecation")
		Date myDate = new Date(issueDto.getDate()+" 23:59:59");


		if (today.compareTo(myDate)>0) {

			query = "SELECT CLOSING_BAL_BY_PRODUCT_ID, QUANTITY, TOTAL_AMOUNT FROM SUMADHU_CLOSING_BAL_BY_PRODUCT WHERE PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ? AND TRUNC(DATE_AND_TIME) = TO_DATE('"+ issueDto.getDate() + "', 'dd-MM-yy') AND ROWNUM <= 1 ORDER BY DATE_AND_TIME  DESC";
			dbClosingBalancesList = jdbcTemplate.queryForList(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), strSiteId, issueDto.getMeasurementId() });

			if (null != dbClosingBalancesList && dbClosingBalancesList.size() > 0) {


				quantity = Double.valueOf(quantity - IssueQty);
				totalAmtForOneQty = (IssueQty * Double.valueOf(priceId));

				query = "UPDATE SUMADHU_CLOSING_BAL_BY_PRODUCT SET QUANTITY=QUANTITY-'" + IssueQty + "', TOTAL_AMOUNT= TOTAL_AMOUNT-'" + totalAmtForOneQty + "' WHERE DATE_AND_TIME >= '" + issueDto.getDate() + "' AND PRODUCT_ID=? AND SUB_PRODUCT_ID = ? AND CHILD_PRODUCT_ID=? AND SITE_ID=? AND MEASUREMENT_ID = ?";
				jdbcTemplate.update(query, new Object[] { issueDto.getProdId(), issueDto.getSubProdId(), issueDto.getChildProdId(), strSiteId, issueDto.getMeasurementId() });
			} 
		} 
	}
	public int getIssuesCount(String strSlipNo,String strSiteId,String strReqMonthStart,String strReqDate) {

		int intIssueCount = 0;

		String strSql = "select count(1) from  INDENT_ENTRY where SLIP_NUMBER = ? and SITE_ID = ? and ENTRY_DATE between ? and ?";

		intIssueCount = jdbcTemplate.queryForInt(strSql,new Object []{strSlipNo,strSiteId,strReqMonthStart,strReqDate});

		return intIssueCount;
	}

	public int getIssuesCount1(String strSlipNumber, String strSiteId, String strReqDate) {
		int indent_entry_id = 0;

		try{
			String strSql = "select INDENT_ENTRY_ID from  INDENT_ENTRY where SLIP_NUMBER = ? and SITE_ID = ?   and TRUNC(ENTRY_DATE) = to_date(?,'dd-MM-yy')";

			indent_entry_id = jdbcTemplate.queryForInt(strSql,new Object []{strSlipNumber,strSiteId,strReqDate});



		}catch(Exception e){
			indent_entry_id = 0;
			//e.printStackTrace();
		}
		return indent_entry_id;
	}


	@Override
	public String getContractorInfo(String contractorName) {
		//System.out.println("hai");
		StringBuffer sb = null;
		List<Map<String, Object>> dbContractorList = null;		


		contractorName = contractorName.replace("$$", "&");
		contractorName = contractorName.toUpperCase();

		//log.debug("Vendor Name = "+contractorName);

		sb = new StringBuffer();

		String contractorInfoQry = "SELECT CONTRACTOR_NAME FROM SUMADHURA_CONTRACTOR WHERE upper(CONTRACTOR_NAME) like '"+contractorName+"%' ";
	//	log.debug("Query to fetch contractor info = "+contractorInfoQry);

		dbContractorList = jdbcTemplate.queryForList(contractorInfoQry, new Object[]{});

		for(Map<String, Object> contractorInfo : dbContractorList) {
			sb = sb.append(String.valueOf(contractorInfo.get("CONTRACTOR_NAME")));
			sb = sb.append("@@");
		}	
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 2);
		}
		//System.out.println("Hai "+sb.toString());

		return sb.toString();
	}

	@Override
	public String getEmployerInfo(String employeeName) {
	//	System.out.println("in dao:"+employeeName);
		StringBuffer sb = null;
		List<Map<String, Object>> dbEmployeeList = null;		


		employeeName = employeeName.replace("$$", "&");
		employeeName = employeeName.toUpperCase();

		log.debug("Vendor Name = "+employeeName);

		sb = new StringBuffer();

		String contractorInfoQry = "SELECT EMP_NAME FROM SUMADHURA_EMPLOYEE_DETAILS WHERE upper(EMP_NAME) like '%"+employeeName+"%' ";
		log.debug("Query to fetch employee info = "+contractorInfoQry);

		dbEmployeeList = jdbcTemplate.queryForList(contractorInfoQry, new Object[]{});

		for(Map<String, Object> employeeInfo : dbEmployeeList) {
			sb = sb.append(String.valueOf(employeeInfo.get("EMP_NAME")));
			sb = sb.append("@@");
		}	
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 2);
		}
		//System.out.println("Hai "+sb.toString());
		
		return sb.toString();
	}
		
	public String getEmployerid(String employeeName) {
		
		//System.out.println("in dao:"+employeeName);
		StringBuffer sb = null;
		List<Map<String, Object>> dbEmployeeList = null;		

		
		employeeName = employeeName.replace("$$", "&");
		
		//log.debug("Vendor Name = "+employeeName);

		sb = new StringBuffer();

		String contractorInfoQry = "SELECT EMP_ID FROM SUMADHURA_EMPLOYEE_DETAILS WHERE EMP_NAME =? ";
		//log.debug("Query to fetch employee info = "+contractorInfoQry);

		dbEmployeeList = jdbcTemplate.queryForList(contractorInfoQry, new Object[]{employeeName});
	//	System.out.println("in dao resulted data"+dbEmployeeList);
		for(Map<String, Object> employeeInfo : dbEmployeeList) {
			sb = sb.append(String.valueOf(employeeInfo.get("EMP_ID")));
			sb = sb.append("@@");
		}	

		
		if (sb.length() > 0) {
			   sb.setLength(sb.length() - 2);
			}
		//System.out.println("Hai "+sb.toString());
		
		return sb.toString();
	}
	
public String getEmployerName(String employeeid) {
		
		//System.out.println("in dao:"+employeeid);
		StringBuffer sb = null;
		List<Map<String, Object>> dbEmployeeList = null;		

		
		employeeid = employeeid.replace("$$", "&");
		
		//log.debug("Vendor Name = "+employeeName);

		sb = new StringBuffer();

		String contractorInfoQry = "SELECT EMP_NAME FROM SUMADHURA_EMPLOYEE_DETAILS WHERE EMP_ID =? ";
		log.debug("Query to fetch employee info = "+contractorInfoQry);

		dbEmployeeList = jdbcTemplate.queryForList(contractorInfoQry, new Object[]{employeeid});
		//System.out.println("in dao resulted id data"+dbEmployeeList);
		for(Map<String, Object> employeeInfo : dbEmployeeList) {
			sb = sb.append(String.valueOf(employeeInfo.get("EMP_NAME")));
			sb = sb.append("@@");
		}	

		
		if (sb.length() > 0) {
			   sb.setLength(sb.length() - 2);
			}
		//System.out.println("Hai "+sb.toString());
		
		return sb.toString();
	}
	

	
	@Override
	public List<ViewIndentIssueDetailsBean> getViewInvoiceIssueDetails(String fromDate, String toDate, String siteId, String val) {

		String query = "";
		String strDCFormQuery = "";
		String strDCNumber = "";
		JdbcTemplate template = null;
		List<Map<String, Object>> dbIndentDts = null;
		List<ViewIndentIssueDetailsBean> list = new ArrayList<ViewIndentIssueDetailsBean>();
		ViewIndentIssueDetailsBean indentObj = null; 

		try {
			//if part is for view indent receive details,else part is for view indent issue details
			template = new JdbcTemplate(DBConnection.getDbConnection());
			/*
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = "SELECT VD.VENDOR_NAME, LD.USERNAME, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.RECEVED_QTY, IE.INVOICE_ID, IED.MEASUR_MNT_NAME,IE.RECEVED_DATE,IE.INVOICE_DATE,IE.TOTAL_AMOUNT FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD, VENDOR_DETAILS VD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.VENDOR_ID=VD.VENDOR_ID AND TRUNC(IE.RECEVED_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = "SELECT VD.VENDOR_NAME, LD.USERNAME, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.RECEVED_QTY, IE.INVOICE_ID, IED.MEASUR_MNT_NAME,IE.RECEVED_DATE,IE.INVOICE_DATE,IE.TOTAL_AMOUNT FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD, VENDOR_DETAILS VD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID AND LD.UNAME=IE.USER_ID AND TRUNC(IE.RECEVED_DATE) =TO_DATE('"+fromDate+"', 'dd-MM-yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = "SELECT VD.VENDOR_NAME, LD.USERNAME, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.RECEVED_QTY, IE.INVOICE_ID, IED.MEASUR_MNT_NAME,IE.RECEVED_DATE,IE.INVOICE_DATE,IE.TOTAL_AMOUNT FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD, VENDOR_DETAILS VD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID AND LD.UNAME=IE.USER_ID AND TRUNC(IE.RECEVED_DATE) =TO_DATE('"+toDate+"', 'dd-MM-yy')";
				}*/
				if (StringUtils.isNotBlank(fromDate) && StringUtils.isNotBlank(toDate)) {
					query = "SELECT DISTINCT IE.INVOICE_ID, IE.RECEIVED_OR_ISSUED_DATE,IE.INVOICE_DATE, VD.VENDOR_NAME FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD, VENDOR_DETAILS VD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"'  AND IE.VENDOR_ID=VD.VENDOR_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE)  BETWEEN TO_DATE('"+fromDate+"','dd-MM-yy') AND TO_DATE('"+toDate+"','dd-MM-yy')";
					//query = "SELECT LD.USERNAME, IE.REQUESTER_NAME, IE.REQUESTER_ID, IED.PRODUCT_NAME, IED.SUB_PRODUCT_NAME, IED.CHILD_PRODUCT_NAME, IED.ISSUED_QTY FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID AND IE.INDENT_TYPE='OUT' AND IE.SITE_ID='"+siteId+"' AND LD.UNAME=IE.USER_ID AND IE.ENTRY_DATE BETWEEN '"+fromDate+"' AND '"+toDate+"'";
				} else if (StringUtils.isNotBlank(fromDate)) {
					query = "SELECT DISTINCT IE.INVOICE_ID,IE.RECEIVED_OR_ISSUED_DATE, IE.INVOICE_DATE, VD.VENDOR_NAME FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD, VENDOR_DETAILS VD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) =TO_DATE('"+fromDate+"', 'dd-MM-yy')";
				} else if(StringUtils.isNotBlank(toDate)) {
					query = "SELECT DISTINCT IE.INVOICE_ID,IE.RECEIVED_OR_ISSUED_DATE, IE.INVOICE_DATE, VD.VENDOR_NAME FROM INDENT_ENTRY IE, INDENT_ENTRY_DETAILS IED, LOGIN_DUMMY LD, VENDOR_DETAILS VD WHERE IE.INDENT_ENTRY_ID = IED.INDENT_ENTRY_ID  AND IE.INDENT_TYPE='IN' AND IE.SITE_ID='"+siteId+"' AND IE.VENDOR_ID=VD.VENDOR_ID AND TRUNC(IE.RECEIVED_OR_ISSUED_DATE) =TO_DATE('"+toDate+"', 'dd-MM-yy')";
				}






			dbIndentDts = template.queryForList(query, new Object[]{});
			if (StringUtils.isNotBlank(val)) {
				for(Map<String, Object> prods : dbIndentDts) {
					indentObj = new ViewIndentIssueDetailsBean();

					indentObj.setRequesterId(prods.get("INVOICE_ID")==null ? "" : prods.get("INVOICE_ID").toString());
					String invoicedate=prods.get("INVOICE_DATE")==null ? "" : prods.get("INVOICE_DATE").toString();
					indentObj.setVendorName(prods.get("VENDOR_NAME")==null ? "" : prods.get("VENDOR_NAME").toString());
					String receviedDate=prods.get("RECEIVED_OR_ISSUED_DATE")==null ? "" : prods.get("RECEIVED_OR_ISSUED_DATE").toString();
					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					Date receive_date = dt.parse(receviedDate);
					Date invoice_date = dt.parse(invoicedate);
					SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat time1 = new SimpleDateFormat("hh:mm:ss");
					// System.out.println("Time: " + time1.format(receviedDate));
					String convertreceive_date=dt1.format(receive_date);
					String convertreceive_time=time1.format(receive_date);
					String convertinvoice_date=dt1.format(invoice_date);
					//System.out.println("the date is "+date2);
					
					indentObj.setStrInvoiceDate(convertinvoice_date);
					indentObj.setDate(convertreceive_date);
					indentObj.setTime(convertreceive_time);
					
				String date=prods.get("RECEIVED_OR_ISSUED_DATE")==null ? "" : prods.get("RECEIVED_OR_ISSUED_DATE").toString();
					if (StringUtils.isNotBlank(date)) {
						date = DateUtil.dateConversion(date);
					} else {
						date = "";
					}
					indentObj.setReceivedDate(date);
					
					String query1 = "select sum(TOTAL_AMOUNT) as SUM_TOTAL_AMOUNT from INDENT_ENTRY where INVOICE_ID = ?";
					List<Map<String, Object>> dbIndentDts1 = null;
					dbIndentDts1 = template.queryForList(query1, new Object[]{prods.get("INVOICE_ID").toString()});
					for(Map<String, Object> prods1 : dbIndentDts1) {
					indentObj.setStrTotalAmount(prods1.get("SUM_TOTAL_AMOUNT")==null ? "" : prods1.get("SUM_TOTAL_AMOUNT").toString());
					}
					list.add(indentObj);
				}



			} 

		} catch (Exception ex) {
			ex.printStackTrace();
			log.debug("Exception = "+ex.getMessage());
			logger.info("Exception Occured Inside getViewIndentIssueDetails() in IndentIssueDao class --"+ex.getMessage());
		} finally {
			query = "";
			indentObj = null; 
			template = null;
			dbIndentDts = null;
		}
		return list;
	}
	public static void main(String [] args){

		double doubleTotalAmount = 1.254;
		int intTotalAmount  = (int)((doubleTotalAmount*100));
		System.out.println("intTotalAmount "+intTotalAmount);
		
		System.out.println("(double)intTotalAmount) "+ (double)intTotalAmount);
		
		doubleTotalAmount = ((double)intTotalAmount)/100;
		
		System.out.println(doubleTotalAmount);
	}

}
