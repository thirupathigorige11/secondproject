package com.sumadhura.in;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.transdao.IndentIssueDaoImpl;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.util.CheckSessionValidation;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Controller
public class ViewIndentIssueDetailsController extends UIProperties {
	
	@Autowired
	private UtilDao utilDao;
	
	/**
	 * @author Aniket Chavan
	 * @param request
	 * @param session
	 * @since 04-may-2018
	 * @return
	 */
	@RequestMapping(value="/getSiteWiseIssueDetails.spring", method={RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getSiteWiseIssueDetails(HttpServletRequest request,HttpSession session){
		System.out.println("ViewIndentIssueDetailsController.getSiteWiseIssueDetails()");
		ModelAndView mav = new ModelAndView();
		String userid = "0";
		try {
			userid = (String) CheckSessionValidation.validateUserSession(mav,
					session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId"));
			if (!userid.equals("0")) {
				List<Map<String, Object>> allSitesList = utilDao.getAllSites();
				request.setAttribute("SEARCHTYPE", "ADMIN");
				System.out.println("SearchType is admin");
				request.setAttribute("allSitesList", allSitesList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			mav.setViewName("ViewIndentIssueDetails");
		}
		System.out.println("ViewIndentIssueDetailsController.getSiteWiseIssueDetails() executed..." );

		return mav;
	}
	
	
	@RequestMapping(value="viewIndentIssueDetails.spring", method={RequestMethod.GET, RequestMethod.POST})
	public ModelAndView viewIndentIssueDetails(HttpServletRequest request,HttpSession session) {
		
		ModelAndView model = null;
		
		try {
			model = new ModelAndView();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("ViewIndentIssueDetails");
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
	//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"View issue Details View","success",site_id);
		return model;
	}
	
	@RequestMapping(value ="getIndentViewDts.spring", method = { RequestMethod.POST})
	public ModelAndView getIndentViewDts(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		ModelAndView model = null;
		String response="";
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
				
				 session = request.getSession(false);
				//site_id = String.valueOf(session.getAttribute("SiteId"));
				//acp
				site_id = request.getParameter("dropdown_SiteId") == null ? "" : request.getParameter("dropdown_SiteId");
				if (!site_id.equals("")) {
					List<Map<String, Object>> allSitesList = utilDao.getAllSites();
					request.setAttribute("SEARCHTYPE", "ADMIN");
					System.out.println("SearchType is admin");
					request.setAttribute("allSitesList", allSitesList);
					System.out.println("IndentReceiveController.getIndentViewDts() DropDown value is not empty");
				} else if (site_id.equals("")) {
					System.out.println("IndentReceiveController.getIndentViewDts() DropDown value is empty");
					site_id =  session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				}
				//acp	
				
				System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
  				indentIssueData = new IndentIssueDaoImpl().getViewIndentIssueDetails(fromDate, toDate, site_id, "");
				
				
				if(indentIssueData != null && indentIssueData.size() >0){
					request.setAttribute("showGrid", "true");
					response="success";
				} else {
					model.addObject("succMessage","The above Dates Data Not Available");
					response="failure";
				}
			
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
			}
		} catch (Exception ex) {
			response="failure";
			ex.printStackTrace();
		} finally {
			model.addObject("indentIssueData",indentIssueData);
			model.addObject("fromDate",fromDate);
			model.addObject("toDate", toDate);
			model.setViewName("ViewIndentIssueDetails");
		}

		SaveAuditLogDetails audit=new SaveAuditLogDetails();
	//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		String user_id=String.valueOf(session.getAttribute("UserId"));
		String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		audit.auditLog("0",user_id,"View issue Details Clicked Submit",response,site_id1);
		
		return model;
	}

}
