package com.sumadhura.service;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.Model;

import com.sumadhura.bean.AuditLogDetailsBean;
import com.sumadhura.bean.GetInvoiceDetailsBean;
import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.VendorDetails;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.dto.TransportChargesDto;
import com.sumadhura.transdao.CentralSiteIndentProcessDao;
import com.sumadhura.transdao.IndentCreationDao;
import com.sumadhura.transdao.PurchaseDepartmentIndentProcessDao;
import com.sumadhura.util.CommonUtilities;
import com.sumadhura.util.NumberToWord;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;


@Service("purchaseDeptIndentrocess")
public class PurchaseDepartmentIndentrocessServiceImpl  extends UIProperties implements PurchaseDepartmentIndentrocessService  {



	@Autowired
	@Qualifier("purchaseDeptIndentrocessDao")
	PurchaseDepartmentIndentProcessDao objPurchaseDepartmentIndentProcessDao;

	@Autowired
	PlatformTransactionManager transactionManager;



	@Autowired
	CentralSiteIndentProcessDao cntlIndentrocss;

	@Autowired
	private IndentCreationDao icd;



	@Override
	public List<IndentCreationBean> getIndentCreationDetailsLists(int indentNumber) {
		List<IndentCreationBean> list = objPurchaseDepartmentIndentProcessDao.getIndentCreationDetailsLists(indentNumber);
		return list;
	}


	@Override
	public List<ProductDetails> createPO(Model model, HttpServletRequest request,HttpSession session)
	{
		//int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
		//System.out.println(indentNumber);
		//	List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		//TransactionDefinition def = new DefaultTransactionDefinition();
		//TransactionStatus status = transactionManager.getTransaction(def);
		//String strResponse = "failed";

		String vendorId = request.getParameter("vendorId1");
		String vendorName = request.getParameter("vendorName1");
		String strGSTINNumber = request.getParameter("strGSTINNumber1");
		String vendorAddress = request.getParameter("vendorAddress1");
		model.addAttribute("vendorId", vendorId);
		model.addAttribute("vendorName", vendorName);
		model.addAttribute("strGSTINNumber", strGSTINNumber);
		model.addAttribute("vendorAddress", vendorAddress);


		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		int sno = 0;

		/*	if(noofrows > 0){

				String strPONumber = request.getParameter("poNumber");
				String strVendorId = request.getParameter("vendorId");
				String siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				String userId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

				ProductDetails productDetails = new ProductDetails();


				int intPoEntrySeqNo = icd.getPoEnterSeqNo();

				productDetails.setUserId(userId);
				productDetails.setVendorId(strVendorId);
				productDetails.setSite_Id(siteId);
				productDetails.setPoNumber(strPONumber);
				productDetails.setPoEntrySeqNumber(intPoEntrySeqNo);


				icd.insertPOEntry(productDetails);*/


		//	productDetails = null; 

		List<ProductDetails> listProductDetails  =  new ArrayList<ProductDetails>();
		for(int num=1;num<=noofrows;num++){
			if(request.getParameter("checkboxname"+num)!=null)
			{

				String productId = request.getParameter("productId"+num);
				String subProductId = request.getParameter("subProductId"+num);
				String childProductId = request.getParameter("childProductId"+num);
				String productName = request.getParameter("product"+num);
				String subProductName = request.getParameter("subProduct"+num);
				String childProductName = request.getParameter("childProductPuchaseDeptDisc"+num);
				String setMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
				String setMeasurementName = request.getParameter("unitsOfMeasurement"+num);
				String strPending = request.getParameter("pendingQuantity"+num);
				//String strPoIntiatedQuantity = request.getParameter("poIntiatedQuantity"+num);
				String strPoIntiatedQuantity = request.getParameter("POPendingQuantity"+num);
				String purchaseDepartmentIndentProcessSeqId = request.getParameter("purchaseDepartmentIndentProcessSeqId"+num);
				String indentNo = request.getParameter("indentNumber");
				String requestQuantity = request.getParameter("strRequestQuantity"+num);
				String indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);

				ProductDetails productDetails = new ProductDetails();
				productDetails.setStrSerialNumber(String.valueOf(sno));
				productDetails.setProductId(productId);
				productDetails.setProductName(productName);
				productDetails.setSub_ProductId(subProductId);
				productDetails.setSub_ProductName(subProductName);
				productDetails.setChild_ProductId(childProductId);
				productDetails.setChild_ProductName(childProductName);
				productDetails.setMeasurementId(setMeasurementId);
				productDetails.setMeasurementName(setMeasurementName);
				//	productDetails.setQuantity(strPending);
				productDetails.setStrIndentId(indentNo);
				productDetails.setPurchaseDeptIndentProcessSeqId(purchaseDepartmentIndentProcessSeqId);
				productDetails.setQuantity(strPoIntiatedQuantity);
				productDetails.setRequestQantity(requestQuantity);

				productDetails.setPendingQuantity(strPending);
				productDetails.setIndentCreationDetailsId(indentCreationDetailsId);

				sno++;
				productDetails.setStrSerialNumber(String.valueOf(sno));
				listProductDetails.add(productDetails);

				/*boolean isAlreadyThere = false;
				for(int i=0;i<listProductDetails.size();i++)
				{
					if(listProductDetails.get(i).getChild_ProductName().equals(childProductName))
					{
						isAlreadyThere = true;
						int temp = Integer.parseInt(listProductDetails.get(i).getQuantity());
						temp+=Integer.parseInt(strPending);
						listProductDetails.get(i).setQuantity(String.valueOf(temp));
						//	listProductDetails.add(productDetails);
						break;
					}
				}
				if(!isAlreadyThere)
				{
					sno++;
					System.out.println("the java file serila no "+sno);
					productDetails.setStrSerialNumber(String.valueOf(sno));
					listProductDetails.add(productDetails);
				}*/




			}
		}

		return listProductDetails;	
	}

	@Override
	public  synchronized String SavePoDetails(Model model, HttpServletRequest request,HttpSession session,String strFinacialYear)
	{
		//int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
		//System.out.println(indentNumber);
		//	List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDIn_savePO, ");
		ProductDetails productDetails =null;
		String strResponse = "";
		String strPONumber = "";
		String strVendorId =""; 
		String strVendorAddress =""; 
		String strVendorName =""; 
		String vendorState =""; 
		String strVendorGSTIN =""; 
		String receiverState =""; 

		String strReceiverAddress =""; 
		String strReceiverName =""; 
		String strReceiverState =""; 
		String strReceiverGSTIN =""; 
		String strReceiverMobileNo = "";
		String strTableTwoDate = "";
		String strTableThreeData = "";
		String strIndentNo = "";
		String siteWiseIndentNo = "";
		String strUserId = "";
		String strSiteId = "";
		String strToSite;
		String CGST = "";
		String SGST = "";
		String IGST = "";
		Double percent = 0.0;
		Double CGSTAMT = 0.0;
		Double SGSTAMT = 0.0;
		Double IGSTAMT = 0.0;
		Double amt = 0.0;
		String finalamount="";
		String Conveyance="";
		String ConveyanceId="";
		String ConveyanceName="";
		String ConveyanceAmount="";
		String GSTTax="";
		String GSTTaxId="";
		String GSTAmount="";
		String AmountAfterTax="";
		String TransportInvoice="";
		char firstLetterChar=0;
		char secondLetterChar=0;
		String approvalEmpId="";
		int noofrows=0;
		String taxId="";
		double totalAmt=0.0;
		String subject="";
		//String subject="";
		String ccEmailId="";
		String contactPersonName="";
		String billingAddress="";
		String strIndentCreationDate="";
		String verifyState="";
		String tax1="";
		String strVendorMobilNo = "";
		String strLandLineNo = "";
		int poEntryId=0;
		String strEmail = "";
		int infinityNumber=0;
		int YearWiseNumber=0;
		String poState="";
		String siteWise_Number="";
		int intYearwisePONumber = 0;
		String stateYearWisePoNum="";
		int site_Wise_Ponumber=0;
		int site_Wise_Year_Ponumber=0;
		int infinity_Number=0;

		int intHOWiseYearwiseNumber = 0;;
		int intHOWiseInfinityNumber = 0;

		String siteWise_YearNumber = "";
		String strPoDate="";
		String strBillingAddressGSTIN = "";
		String strBillingCompanyName="";
		String editPonumber=""; 
		int revision_no=0;

		String serviceState=""; 
		String strReceiveSideContactPerson = "";
		String strReceiverLandLine = "";
		String siteName="";
		String sessionSiteId="";
		String indentCreation="";
		Map<String,String> objviewPOPageDataMap = new HashMap<String,String>();
		String version_no="";
		String refferenceNo="";
		String strPoPrintRefdate="";
		String recordcount = request.getParameter("numbeOfRowsToBeProcessed");
		String chargesRecordsCount1 =  request.getParameter("numbeOfChargesRowsToBeProcessed");
		String recordscount[]=recordcount.split("\\|");
		String isRevision="";
		int temprevision_no=0;
		String action="";
		int revisedPoEntryId=0;
		String isSiteLevelPo="";
		String preparedBy="";
		int total_Records =0;
		int current_Records=0;
		String hsnCode ="";
		String price ="";
		String basicAmount =""; 
		
		String taxAmount ="";
		String amountAfterTax =""; 
		String totalAmount ="";
		String quantity ="";
		String editStrQuantity ="";
		String tax ="";
		try{


			for(int i=1;i<=recordscount.length;i++){

				noofrows=i;
			}


			version_no=request.getAttribute("versionNo").toString();
			refferenceNo=request.getAttribute("refferenceNo").toString();

			strPoPrintRefdate=request.getAttribute("strPoPrintRefdate").toString();
			//	int row=Integer.parseInt(request.getParameter("addNewItemBtn"));
			strVendorId = request.getParameter("vendorId");
			siteName=request.getParameter("SiteName");
			//System.out.println("the vendor id is "+strVendorId);
			int sno = 0;
			List<String> listOfTermsAndConditions = new ArrayList<String>();
			if(noofrows > 0){
				session = request.getSession(true);
				strSiteId = request.getParameter("toSiteId") == null ? "" : request.getParameter("toSiteId").toString();
				strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();	
				sessionSiteId=session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

				strIndentNo = request.getParameter("indentNumber");
				siteWiseIndentNo = request.getParameter("siteWiseIndentNo");				
				subject = request.getParameter("subject");
				strToSite = request.getParameter("toSiteId") == null ? "" : request.getParameter("toSiteId").toString();
				strIndentCreationDate = request.getParameter("strCreationDate")== null ? "" : request.getParameter("strCreationDate").toString();
				
				/********************************************siteLevelPo start********************************************/
				if((strIndentCreationDate==null || strIndentCreationDate.equals("")) && (strSiteId==null || strSiteId.equals(""))){
					Date date = new Date();
					 strIndentCreationDate= new SimpleDateFormat("dd-MM-yyyy").format(date);
					 strSiteId=sessionSiteId;
					 isSiteLevelPo="true";
					 preparedBy=siteName;
					 
				}
				
				/****************************************************siteLevelPo end*********************************************/
				//	request.getParameter("vendorId");

				productDetails = new ProductDetails();


				List<Map<String, Object>> listVendorDtls =  objPurchaseDepartmentIndentProcessDao.getVendorOrSiteAddress(strVendorId);
				for(Map<String, Object> prods : listVendorDtls) {
					strVendorName = prods.get("VENDOR_NAME")==null ? "" :   prods.get("VENDOR_NAME").toString();
					strVendorAddress = prods.get("ADDRESS")==null ? "" :   prods.get("ADDRESS").toString();
					vendorState = prods.get("STATE")==null ? "" :   prods.get("STATE").toString();
					strVendorGSTIN = prods.get("GSIN_NUMBER")==null ? "" :   prods.get("GSIN_NUMBER").toString();
					contactPersonName = prods.get("VENDOR_CON_PER_NAME")==null ? "" :   prods.get("VENDOR_CON_PER_NAME").toString();
					strLandLineNo = prods.get("LANDLINE_NO")==null ? "" :   prods.get("LANDLINE_NO").toString();
					strVendorMobilNo = prods.get("MOBILE_NUMBER")==null ? "" :   prods.get("MOBILE_NUMBER").toString();
					strEmail = prods.get("EMP_EMAIL")==null ? " " :   prods.get("EMP_EMAIL").toString();

				}	

				if(!strVendorMobilNo.equals("")){
					contactPersonName = contactPersonName+" ( "+strVendorMobilNo;
				}if(!strLandLineNo.equals("")){
					contactPersonName = contactPersonName+","+strLandLineNo;
				}

				//contactPersonName = " Mr/Mrs : "+contactPersonName +" )";
				contactPersonName = contactPersonName +" )";
				//strVendorAddress = strVendorAddress;
				//System.out.println("the vendor gstn number"+strVendorGSTIN);

				//int  intSiteId = Integer.parseInt(siteId);
				List<Map<String, Object>> listReceiverDtls =  objPurchaseDepartmentIndentProcessDao.getVendorOrSiteAddress(strSiteId);//strToSite
				for(Map<String, Object> prods : listReceiverDtls) {
					strReceiverName = prods.get("VENDOR_NAME")==null ? "" :   prods.get("VENDOR_NAME").toString();
					strReceiverAddress = prods.get("ADDRESS")==null ? "" :   prods.get("ADDRESS").toString();
					strReceiverMobileNo = prods.get("MOBILE_NUMBER")==null ? "" :   prods.get("MOBILE_NUMBER").toString();
					strReceiverGSTIN = prods.get("GSIN_NUMBER")==null ? "" :   prods.get("GSIN_NUMBER").toString();
					receiverState = prods.get("STATE")==null ? "" :   prods.get("STATE").toString();
					strReceiveSideContactPerson = prods.get("VENDOR_CON_PER_NAME")==null ? " " :   prods.get("VENDOR_CON_PER_NAME").toString();
					strReceiverLandLine = prods.get("LANDLINE_NO")==null ? " " :   prods.get("LANDLINE_NO").toString();
				}	
				Date date =new java.sql.Date(System.currentTimeMillis());
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				strPoDate=dt1.format(date);


				//	objPurchaseDepartmentIndentProcessDao.saveTermsconditions(listOfTermsAndConditions);


				//termsAndConditionId = termsAndConditionId.substring(0, termsAndConditionId.length()-1);
				approvalEmpId=objPurchaseDepartmentIndentProcessDao.getTemproryuser(strUserId);

				editPonumber=request.getParameter("poNo") == null ? "" : request.getParameter("poNo").toString();
				if(approvalEmpId!=null && approvalEmpId.equals("VND")){
					
					if(isSiteLevelPo.equalsIgnoreCase("true")){ //for site Level po
						
						String site_Level_Po_Number=objPurchaseDepartmentIndentProcessDao.getSiteLevelPoNumber(sessionSiteId);
						String data[] = site_Level_Po_Number.split("@@");

						 total_Records =Integer.parseInt(data[0]);
						 current_Records=Integer.parseInt(data[1]);
						
						strPONumber="PO/SIPL/"+siteName+"/"+total_Records+"/"+strFinacialYear+"/"+current_Records;
						poEntryId = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNo();
						preparedBy=siteName;
						
					}else{
				
				/******************************************RevisedPostart**********************************************************/		
					if(editPonumber!=null && !editPonumber.equals("")){
					
					preparedBy="PURCHASE_DEPT";
					revision_no=objPurchaseDepartmentIndentProcessDao.getRevisionNumber(editPonumber);
					objPurchaseDepartmentIndentProcessDao.inactiveOldPo(editPonumber);
						String tempPoNumber=editPonumber;
						if(tempPoNumber.contains("R")){ 
							temprevision_no=revision_no+1;
							strPONumber=tempPoNumber.replace("R"+revision_no, "R"+temprevision_no);
							
						
						}else{
							temprevision_no=revision_no+1;
							strPONumber=tempPoNumber+"/R"+temprevision_no;
							
						}
						objPurchaseDepartmentIndentProcessDao.updateAccPayment(editPonumber,strPONumber);
						
					}
					
					/******************************************RevisedPoend**********************************************************/	
					else{
					
					preparedBy="PURCHASE_DEPT";
					if(receiverState.equalsIgnoreCase("Telangana")){


						poState =	validateParams.getProperty("PO_NUM_TELANGANA");


						intHOWiseYearwiseNumber = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNoOrMaxId("PO_SIPL"); //PO_TELANGANA changed to PO_SIPL because requirment is changed they want SIPL level
						intHOWiseInfinityNumber=objPurchaseDepartmentIndentProcessDao.getHeadOfficeInfinitMaxId("PO_SIPL");
						siteWise_Number=objPurchaseDepartmentIndentProcessDao.getSiteWisePoNumber(strSiteId);
						siteWise_YearNumber=objPurchaseDepartmentIndentProcessDao.getStateWiseYearPoNumber(strSiteId);

						strPONumber=poState+String.valueOf(intHOWiseYearwiseNumber)+"/"+siteWise_Number+"/"+strFinacialYear+"/"+siteWise_YearNumber;
						serviceState="PO_TELANGANA";

					}else{
						poState =	validateParams.getProperty("PO_NUM_KARNATAKA");
						intHOWiseYearwiseNumber  = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNoOrMaxId("PO_SIPL"); //PO_KARNATAKA changed to PO_SIPL because requirment is changed they want SIPL level
						intHOWiseInfinityNumber=objPurchaseDepartmentIndentProcessDao.getHeadOfficeInfinitMaxId("PO_SIPL");
						siteWise_Number=objPurchaseDepartmentIndentProcessDao.getSiteWisePoNumber(strSiteId);
						siteWise_YearNumber=objPurchaseDepartmentIndentProcessDao.getStateWiseYearPoNumber(strSiteId);
						strPONumber=poState+String.valueOf(intHOWiseYearwiseNumber)+"/"+siteWise_Number+"/"+strFinacialYear+"/"+siteWise_YearNumber;
						serviceState="PO_KARNATAKA";
					}

					}
					//	strPONumber = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNoOrMaxId();
					poEntryId = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNo();

					/*infinityNumber=	objPurchaseDepartmentIndentProcessDao.getPoInfinityNumberGenerator(serviceState);
					YearWiseNumber=objPurchaseDepartmentIndentProcessDao.getPoYearWiseNumberGenerator(serviceState);
					site_Wise_Ponumber=objPurchaseDepartmentIndentProcessDao.getStateWisePoNumber(strSiteId);
					site_Wise_Year_Ponumber=objPurchaseDepartmentIndentProcessDao.getStateWiseYearPo_Number(strSiteId);*/

				}
				}	else{
					if(isSiteLevelPo.equalsIgnoreCase("true")){
						
						preparedBy=siteName;
					}else 
					{
						preparedBy="PURCHASE_DEPT";
					}
					
					int intPONumber = objPurchaseDepartmentIndentProcessDao.getTempPoEnterSeqNoOrMaxId();
					strPONumber = String.valueOf(intPONumber);
					//preparedBy="PURCHASE_DEPT";
				}


				if(receiverState.equalsIgnoreCase("Telangana")){

					billingAddress=	validateParams.getProperty("BILLING_ADDRESSS_HYDERABAD");
					strBillingAddressGSTIN = validateParams.getProperty("GSTIN_HYDERABAD");
					strBillingCompanyName=validateParams.getProperty("BILLING_NAME");
				}else{

					billingAddress=	validateParams.getProperty("BILLING_ADDRESSS_BENGALORE");
					strBillingAddressGSTIN = validateParams.getProperty("GSTIN_BENGALORE");
					strBillingCompanyName=validateParams.getProperty("BILLING_NAME");

				}


				productDetails.setUserId(strUserId);
				productDetails.setVendorId(strVendorId);
				productDetails.setSite_Id(strSiteId);
				productDetails.setIndentNo(strIndentNo);
				productDetails.setPoNumber(strPONumber);
				productDetails.setSubject(subject);
				productDetails.setBillingAddress(billingAddress);
				productDetails.setPoEntryId(poEntryId);
				productDetails.setVersionNo(version_no);
				productDetails.setRefferenceNo(refferenceNo);
				productDetails.setStrPoPrintRefdate(strPoPrintRefdate);
				productDetails.setEdit_Po_Number(editPonumber);
				productDetails.setRevision_Number(temprevision_no);
				productDetails.setPreparedBy(preparedBy);
				//productDetails.setStrTermsConditionId(termsAndConditionId);
				WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , PONumber:"+strPONumber);


				ccEmailId=request.getParameter("ccEmailId");


				int result=0;
				if(approvalEmpId!=null && approvalEmpId.equals("VND")){

					result=objPurchaseDepartmentIndentProcessDao.insertPOEntry(productDetails);
				}
				//	listProductDetails.add(productDetails);
				else{
					result=objPurchaseDepartmentIndentProcessDao.insertTempPOEntry(productDetails,approvalEmpId,ccEmailId,subject);
				}
				//System.out.println("the query exccuted"+result);

				int acceptTermsAndConditionTotal = Integer.parseInt(request.getParameter("countOftermsandCondsfeilds"));
				String termsAndCondition = "";
				int val=0;
				for(int i=1;i<=acceptTermsAndConditionTotal;i++){



					termsAndCondition =  request.getParameter("termsAndCond"+i);

					if(termsAndCondition!= null && !termsAndCondition.equals("")){

						//termsAndConditionId += termsAndConditionId;
						if(approvalEmpId!=null && approvalEmpId.equals("VND")){

							val=objPurchaseDepartmentIndentProcessDao.saveTermsconditions(termsAndCondition,poEntryId,strVendorId,strIndentNo);

						}else{

							val=objPurchaseDepartmentIndentProcessDao.saveTempTermsconditions(termsAndCondition,strPONumber,strVendorId,strIndentNo);
						}
						//System.out.println("the resulting value is "+val);

						listOfTermsAndConditions.add(String.valueOf(termsAndCondition));

					}

				}



				String chargesRecordsCount =  request.getParameter("numbeOfChargesRowsToBeProcessed");
				String numOfChargeRec[] = null;







				if((chargesRecordsCount != null) && (!chargesRecordsCount.equals(""))) {
					numOfChargeRec = chargesRecordsCount.split("\\|");
					if(numOfChargeRec != null && numOfChargeRec.length > 0) {
						for(String charNum : numOfChargeRec) {



							TransportChargesDto transportChargesDto = new TransportChargesDto();
							Conveyance = request.getParameter("Conveyance"+charNum);
							ConveyanceId = Conveyance.split("\\$")[0];
							ConveyanceName = Conveyance.split("\\$")[1];
							ConveyanceAmount = request.getParameter("ConveyanceAmount"+charNum);
							GSTTax= request.getParameter("GSTTax"+charNum);
							GSTTaxId = GSTTax.split("\\$")[0];
							GSTTax = GSTTax.split("\\$")[1].substring(0,GSTTax.split("\\$")[1].length()-1);


							GSTAmount = request.getParameter("GSTAmount"+charNum);
							if(isSiteLevelPo.equalsIgnoreCase("true")){
								
								AmountAfterTax = request.getParameter("AmountAfterTaxx"+charNum);
							}else{
								AmountAfterTax = request.getParameter("AmountAfterTax"+charNum);
							}
							//AmountAfterTax = request.getParameter("AmountAfterTax"+charNum);
							TransportInvoice = request.getParameter("TransportInvoice"+charNum);
							transportChargesDto.setTransportId(ConveyanceId);
							transportChargesDto.setTransportAmount(ConveyanceAmount);
							transportChargesDto.setTransportGSTPercentage(GSTTaxId);
							transportChargesDto.setTransportGSTAmount(GSTAmount);
							transportChargesDto.setTotalAmountAfterGSTTax(AmountAfterTax);
							transportChargesDto.setTransportInvoice(TransportInvoice);
							finalamount = request.getParameter("finalAmntDiv");
							transportChargesDto.setTotalamount(finalamount);

							firstLetterChar = strVendorGSTIN.charAt(0);
							secondLetterChar=strVendorGSTIN.charAt(1);

							//System.out.println("the gstn number first letter"+firstLetterChar);
							//System.out.println("the gstn number first letter"+secondLetterChar);


							if(receiverState.equalsIgnoreCase("Telangana")){

								if (firstLetterChar=='3' && secondLetterChar=='6') {


									if (GSTTax.equals("0")) {
										CGST = "0";
										SGST = "0";
									} else {
										percent = Double.parseDouble(GSTTax)/2;
										amt = Double.parseDouble(GSTAmount)/2;
										CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
										SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
										CGST = String.valueOf(percent);
										SGST = String.valueOf(percent);
									}
								} else {
									percent = Double.parseDouble(GSTTax);
									amt = Double.parseDouble(GSTAmount);
									IGST = String.valueOf(percent);
									IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								}



							}else{

								if (firstLetterChar=='2' && secondLetterChar=='9') {


									if (GSTTax.equals("0")) {
										CGST = "0";
										SGST = "0";
									} else {
										percent = Double.parseDouble(GSTTax)/2;
										amt = Double.parseDouble(GSTAmount)/2;
										CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
										SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
										CGST = String.valueOf(percent);
										SGST = String.valueOf(percent);
									}
								} else {
									percent = Double.parseDouble(GSTTax);
									amt = Double.parseDouble(GSTAmount);
									IGST = String.valueOf(percent);
									IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								}

							}
							double doubleConveyanAmt=Double.parseDouble(ConveyanceAmount);
							doubleConveyanAmt=Double.parseDouble(new DecimalFormat("##.##").format(doubleConveyanAmt));

							int poTransChrgsSeqNo = objPurchaseDepartmentIndentProcessDao.getPoTransChrgsEntrySeqNo();
							int result2=0;
							if(approvalEmpId!=null && approvalEmpId.equals("VND")){

								objPurchaseDepartmentIndentProcessDao.insertPOTransportDetails(poTransChrgsSeqNo,productDetails,transportChargesDto);

							}else{
								result2 = objPurchaseDepartmentIndentProcessDao.insertPOTempTransportDetails(poTransChrgsSeqNo,productDetails,transportChargesDto);

							}//System.out.println("the transport query executed"+result2);



							if(receiverState.equalsIgnoreCase("Telangana")){

								if (firstLetterChar=='3' && secondLetterChar=='6') {

									strTableThreeData += ConveyanceName+"@@"+doubleConveyanAmt+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+" "+"@@"+" "+"@@"+"&&";
								}else{
									strTableThreeData += ConveyanceName+"@@"+doubleConveyanAmt+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+IGST+"%"+"@@"+IGSTAMT+"&&";				

								}
							}else{


								if (firstLetterChar=='2' && secondLetterChar=='9') {

									strTableThreeData += ConveyanceName+"@@"+doubleConveyanAmt+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+" "+"@@"+" "+"@@"+"&&";
								}else{
									strTableThreeData += ConveyanceName+"@@"+doubleConveyanAmt+"@@"+GSTTax+"@@"+GSTAmount+"@@"+AmountAfterTax+"@@"+AmountAfterTax+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+" "+"@@"+IGST+"%"+"@@"+IGSTAMT+"&&";				

								}
							}



						}
					}
				}



			}

			productDetails = null;
			String strUserName = session.getAttribute("UserName") == null ? "" : session.getAttribute("UserName").toString();


			String strTableOneData = strPONumber+"@@"+strPoDate+"@@"+strIndentNo+"@@"+strVendorName+"@@"+strVendorAddress+"@@"+vendorState+"@@"+strVendorGSTIN+
			"@@"+strReceiverName+"@@"+strReceiverAddress+"@@"+strReceiverMobileNo+"@@"+strReceiverGSTIN+"@@"+finalamount+"@@"+subject+"@@"+contactPersonName+"@@"+ccEmailId+"@@"+billingAddress+"@@"+" "+"@@"+" "+"@@"+strUserName+"@@"+new java.sql.Date(System.currentTimeMillis())+"@@"+" "+"@@"+" "+"@@"+strIndentCreationDate+"@@"+siteWiseIndentNo+"@@"+
			strBillingAddressGSTIN+"@@"+strReceiveSideContactPerson+"@@"+strReceiverLandLine+"@@"+strEmail+"@@"+strBillingCompanyName+"@@"+strSiteId+"@@"+siteName+"@@"+strVendorId;


			List<ProductDetails> listProductDetails  = new ArrayList<ProductDetails>();
			for(int i=0;i<noofrows;i++){

				String indentCreationDetailsId ="";

				int	num=Integer.parseInt(recordscount[i]);


				if(noofrows!=0)
				{
					sno++;

					String actionValue = request.getParameter("actionValue"+num);
					//	String productId = request.getParameter("productId"+num);

					//	String subProductId = request.getParameter("sub_ProductId"+num);
					//	String childProductId = request.getParameter("child_ProductId"+num);
					//	String setMeasurementId = request.getParameter("measurementId"+num);
					String product = request.getParameter("Product"+num);
					String prodsInfo[] = product.split("\\$");	
					String productId = prodsInfo[0];
					String productName = prodsInfo[1];

					String subProduct = request.getParameter("SubProduct"+num);
					String subProdsInfo[] = subProduct.split("\\$");					
					String subProductId = subProdsInfo[0];
					String subProductName = subProdsInfo[1];				

					String childProduct = request.getParameter("ChildProduct"+num);
					String childProdsInfo[] = childProduct.split("\\$");					
					String childProductId = childProdsInfo[0];
					String childProductName = childProdsInfo[1];

					String mesurement = request.getParameter("UnitsOfMeasurement"+num);
					String measureInfo[] = mesurement.split("\\$");					
					String setMeasurementId = measureInfo[0];
					String setMeasurementName = measureInfo[1];
					String vendorProductDesc=request.getParameter("childProductVendorDesc"+num);
					if(vendorProductDesc.equals("")){
						vendorProductDesc="-";

					}



					String purchaseDepartmentIndentProcessSeqId1 = request.getParameter("purchaseDepartmentIndentProcessSeqId"+num);
					String newProductCreated=request.getParameter("isNewOrOld"+num);
					if(newProductCreated.equalsIgnoreCase("new")){

						int indentCreationDetailsSeqNum = icd.getIndentCreationDetailsSequenceNumber();
						indentCreationDetailsId=String.valueOf(indentCreationDetailsSeqNum);
						indentCreation="true";

					}else{
						indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
					}

					
					if(isSiteLevelPo.equalsIgnoreCase("true")){
						
						 hsnCode = request.getParameter("HSNCode"+num);
						 price = request.getParameter("Price"+num);
						 basicAmount = request.getParameter("BasicAmount"+num);
						
						 taxAmount = request.getParameter("TaxAmount"+num);
						 amountAfterTax = request.getParameter("AmountAfterTax"+num);
						 totalAmount = request.getParameter("TotalAmount"+num);
						 quantity = request.getParameter("Quantity"+num);
						  tax = request.getParameter("Tax"+num);
						
						
					}else{
					 hsnCode = request.getParameter("hsnCode"+num);
					 price = request.getParameter("PriceId"+num);
					 basicAmount = request.getParameter("BasicAmountId"+num);
					
					 taxAmount = request.getParameter("taxAmount"+num);
					 amountAfterTax = request.getParameter("amountAfterTax"+num);
					 totalAmount = request.getParameter("totalAmount"+num);
					 quantity = request.getParameter("quantity"+num);
					  editStrQuantity = request.getParameter("strQuantity"+num);
					   tax = request.getParameter("tax"+num);
					}
					
					if(tax.contains("%")){
						taxId = tax.split("\\$")[0];
						tax = tax.split("\\$")[1].substring(0,tax.split("\\$")[1].length()-1);
					}else{
						taxId = tax.split("\\$")[0];
						tax = tax.split("\\$")[0];


					} 
					
					//String strQuantiry=quantity;
					String indentNo = request.getParameter("indentNumber");
					String poIntiatedQuantity = request.getParameter("poIntiatedQuantity"+num);
					String requestQuantity = request.getParameter("strRequestQuantity"+num);
					/*==========================================this is for edit po get initiatedquan & requestedQuan===============*/
					
					if((poIntiatedQuantity==null || poIntiatedQuantity.equals("")) && (requestQuantity==null || requestQuantity.equals("")) && !newProductCreated.equalsIgnoreCase("new")){
						
						
						double strtpoIntiatedQuantity=(objPurchaseDepartmentIndentProcessDao.getIntiatedQuantityInPurchaseTable(indentCreationDetailsId));
						requestQuantity=String.valueOf(objPurchaseDepartmentIndentProcessDao.getRequestedQuantityInPurchaseTable(indentCreationDetailsId));
						double tempQuan=Double.valueOf(quantity);
						
						
						poIntiatedQuantity=String.valueOf(strtpoIntiatedQuantity);
						if(actionValue.equals("S")){
							action="true";
							//break;
						}else if(actionValue.equals("E")){
							
							int result5=objPurchaseDepartmentIndentProcessDao.updateTempPOQuantityDetails(indentCreationDetailsId,quantity,editStrQuantity);
							 isRevision="true";
						/*double strRequestQuan=Double.parseDouble(requestQuantity);
						strtpoIntiatedQuantity=strtpoIntiatedQuantity-tempQuan;
						if(strtpoIntiatedQuantity<0){
							quantity=String.valueOf(Math.abs(strtpoIntiatedQuantity));
							
						}else if(strtpoIntiatedQuantity>0){
							double tempPoinitiatedQuan=Double.parseDouble(quantity);
							poIntiatedQuantity=quantity;
							strQuantiry="0";
							 isRevision="true";
							 if(strRequestQuan>tempPoinitiatedQuan){
							 objPurchaseDepartmentIndentProcessDao.updatePurchasetblForRevision(indentCreationDetailsId,poIntiatedQuantity,"A");	
							 }else{
								 objPurchaseDepartmentIndentProcessDao.updatePurchasetblForRevision(indentCreationDetailsId,poIntiatedQuantity,"I");
							 }
						}*/
						}
					}

					String Discount=request.getParameter("Discount"+num);
					String amountAfterDiscount=request.getParameter("amtAfterDiscount"+num);
					
					
					String strStatus = "A";


					

					//	String taxArr []  = tax.split("\\$");


					

					

					//		String purchaseDepartmentIndentProcessSeqId = request.getParameter("purchaseDepartmentIndentProcessSeqId"+num);
					//	String strStatus = "";
					//	int pendingQuantity = Integer.parseInt(request.getParameter("pendingQuantity"+num) == null ? "0" : request.getParameter("pendingQuantity"+num).toString());

					//	int intPoQuantity = Integer.parseInt(quantity == null ? "0" : quantity.toString());

					//	if(intPoQuantity >= pendingQuantity){

					//	strStatus = "I";
					//	}

					productDetails = new ProductDetails();
					productDetails.setStrSerialNumber(String.valueOf(sno));
					productDetails.setProductId(productId);
					productDetails.setProductName(productName);
					productDetails.setSub_ProductId(subProductId);
					productDetails.setSub_ProductName(subProductName);
					productDetails.setChild_ProductId(childProductId);
					productDetails.setChild_ProductName(childProductName);
					productDetails.setMeasurementId(setMeasurementId);
					productDetails.setMeasurementName(setMeasurementName);
					productDetails.setChildProductCustDisc(vendorProductDesc);
					productDetails.setQuantity(quantity);

					productDetails.setHsnCode(hsnCode);
					productDetails.setPricePerUnit(price);
					productDetails.setBasicAmt(basicAmount);
					productDetails.setStrDiscount(Discount);
					productDetails.setStrAmtAfterDiscount(amountAfterDiscount);
					productDetails.setTax(taxId);
					productDetails.setTaxAmount(taxAmount);
					productDetails.setAmountAfterTax(amountAfterTax);
					productDetails.setTotalAmount(totalAmount);
					productDetails.setStrPONumber(indentNo);
					productDetails.setIndentCreationDetailsId(indentCreationDetailsId);

					double doubleQuantity = 0;
					if(indentCreationDetailsId != null && !indentCreationDetailsId.equals("") ){

						//double intPoIntiatedQuantity = objPurchaseDepartmentIndentProcessDao.getIntiatedQuantityInPurchaseTable(indentCreationDetailsId);
						double intPoIntiatedQuantity = Double.valueOf(poIntiatedQuantity ==null ? "0" : poIntiatedQuantity.toString());
						double intRequestQuantity = Double.valueOf(requestQuantity ==null ? "0" : requestQuantity.toString());
						doubleQuantity = Double.valueOf(quantity ==null ? "0" : quantity.toString());

						if(intPoIntiatedQuantity+doubleQuantity >= intRequestQuantity){

							strStatus = "I";

						}

					}

					firstLetterChar = strVendorGSTIN.charAt(0);
					secondLetterChar=strVendorGSTIN.charAt(1);

					//System.out.println("the gstn number first letter"+firstLetterChar);
					//System.out.println("the gstn number first letter"+secondLetterChar);


					double totalvalue=Double.valueOf(totalAmount);

					totalAmt=totalAmt+totalvalue;
					totalAmt =Double.parseDouble(new DecimalFormat("##.##").format(totalAmt));
					int val = (int) Math.ceil(totalAmt);
					double roundoff=Math.ceil(totalAmt)-totalAmt;
					double grandtotal=Math.ceil(totalAmt);


					NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
					String strtotal = numberFormat.format(totalAmt);

					//String strtotal=String.valueOf(totalAmt);
					String strroundoff=String.format("%.2f",roundoff);
					String strgrandtotal=numberFormat.format(grandtotal);

					//	String taxArr []  = tax.split("\\$");
					//	tax = taxArr[0];

					if(receiverState.equalsIgnoreCase("Telangana")){

						if (firstLetterChar=='3' && secondLetterChar=='6') {

							request.setAttribute("isCGSTSGST","true");


							if (tax.equals("0")) {
								CGST = "0";
								SGST = "0";
							} else {
								percent = Double.parseDouble(tax)/2;
								amt = Double.parseDouble(taxAmount)/2;
								CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								SGSTAMT =Double.parseDouble(new DecimalFormat("##.##").format(amt));
								CGST = String.valueOf(percent);
								SGST = String.valueOf(percent);
							}
						} else {

							request.setAttribute("isCGSTSGST","false");

							percent = Double.parseDouble(tax);
							amt = Double.parseDouble(taxAmount);
							IGST = String.valueOf(percent);
							IGSTAMT =Double.parseDouble(new DecimalFormat("##.##").format(amt));


						}	
					} else{

						if (firstLetterChar=='2' && secondLetterChar=='9') {

							request.setAttribute("isCGSTSGST","true");

							if (tax.equals("0")) {
								CGST = "0";
								SGST = "0";
							} else {
								percent = Double.parseDouble(tax)/2;
								amt = Double.parseDouble(taxAmount)/2;
								CGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								SGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
								CGST = String.valueOf(percent);
								SGST = String.valueOf(percent);
							}
						} else {

							request.setAttribute("isCGSTSGST","false");
							percent = Double.parseDouble(tax);
							amt = Double.parseDouble(taxAmount);
							IGST = String.valueOf(percent);
							IGSTAMT = Double.parseDouble(new DecimalFormat("##.##").format(amt));
						}
					}

					//	productDetails.setPurchaseDeptIndentProcessSeqId(purchaseDepartmentIndentProcessSeqId);
					double doublePrice=Double.parseDouble(price);
					double doubleBasicAmount=Double.parseDouble(basicAmount);
					double doubleDiscount=Double.parseDouble(Discount);
					doublePrice=Double.parseDouble(new DecimalFormat("##.##").format(doublePrice));
					doubleBasicAmount=Double.parseDouble(new DecimalFormat("##.##").format(doubleBasicAmount));
					doubleDiscount=Double.parseDouble(new DecimalFormat("##.##").format(doubleDiscount));

					if(receiverState.equalsIgnoreCase("Telangana")){

						if (firstLetterChar=='3' && secondLetterChar=='6') {

							strTableTwoDate += sno+"@@"+subProductName+"@@"+childProductName+"@@"+hsnCode+"@@"+setMeasurementName+"@@"+
							quantity+"@@"+doublePrice+"@@"+doubleBasicAmount+"@@"+doubleDiscount+"@@"+amountAfterDiscount+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+""+"@@"+""+"@@"+amountAfterTax+"@@"+amountAfterTax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"
							+productName+"@@"+productId+"@@"+subProductId+"@@"+childProductId+"@@"+setMeasurementId+"@@"+indentCreationDetailsId+"&&";
						}else
						{

							strTableTwoDate += sno+"@@"+subProductName+"@@"+childProductName+"@@"+hsnCode+"@@"+setMeasurementName+"@@"+
							quantity+"@@"+doublePrice+"@@"+doubleBasicAmount+"@@"+doubleDiscount+"@@"+amountAfterDiscount+"@@"+""+"@@"+""+"@@"+""+"@@"+""+"@@"+IGST+"%"+"@@"+IGSTAMT+"@@"+amountAfterTax+"@@"+amountAfterTax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"
							+productName+"@@"+productId+"@@"+subProductId+"@@"+childProductId+"@@"+setMeasurementId+"@@"+indentCreationDetailsId+"&&";

						}
					}else{

						if (firstLetterChar=='2' && secondLetterChar=='9') {

							strTableTwoDate += sno+"@@"+subProductName+"@@"+childProductName+"@@"+hsnCode+"@@"+setMeasurementName+"@@"+
							quantity+"@@"+doublePrice+"@@"+doubleBasicAmount+"@@"+doubleDiscount+"@@"+amountAfterDiscount+"@@"+CGST+"%"+"@@"+CGSTAMT+"@@"+SGST+"%"+"@@"+SGSTAMT+"@@"+""+"@@"+""+"@@"+amountAfterTax+"@@"+amountAfterTax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"
							+productName+"@@"+productId+"@@"+subProductId+"@@"+childProductId+"@@"+setMeasurementId+"@@"+indentCreationDetailsId+"&&";
						}else
						{

							strTableTwoDate += sno+"@@"+subProductName+"@@"+childProductName+"@@"+hsnCode+"@@"+setMeasurementName+"@@"+
							quantity+"@@"+doublePrice+"@@"+doubleBasicAmount+"@@"+doubleDiscount+"@@"+amountAfterDiscount+"@@"+""+"@@"+""+"@@"+""+"@@"+""+"@@"+IGST+"%"+"@@"+IGSTAMT+"@@"+amountAfterTax+"@@"+amountAfterTax+"@@"+strroundoff+"@@"+grandtotal+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+totalAmt+"@@"+vendorProductDesc+"@@"
							+productName+"@@"+productId+"@@"+subProductId+"@@"+childProductId+"@@"+setMeasurementId+"@@"+indentCreationDetailsId+"&&";

						}
					}

					int result=0;
					if(approvalEmpId!=null && approvalEmpId.equals("VND")){

						result=objPurchaseDepartmentIndentProcessDao.insertPOEntryDetails(productDetails,poEntryId);	

					}else
					{
						result=objPurchaseDepartmentIndentProcessDao.insertTempPOEntryDetails(productDetails,strPONumber);

					}

					if(indentCreationDetailsId != null && !indentCreationDetailsId.equals("") ){

						if(result==1){
							//int intQuantity = Integer.parseInt(quantity);
							if(indentCreation.equalsIgnoreCase("true")){
								int purchaseIndentProcessId = cntlIndentrocss.getPurchaseIndentProcessSequenceNumber();
								objPurchaseDepartmentIndentProcessDao.insertIndentCreationtbl(productDetails,strIndentNo);

								objPurchaseDepartmentIndentProcessDao.insertPurchaseDepttbl(purchaseIndentProcessId,sessionSiteId,strUserId,productDetails);


							}else{
								
								if(!isRevision.equals("true") && !action.equals("true")){
								int intIndentCreationDetailsId = Integer.parseInt(indentCreationDetailsId);
								objPurchaseDepartmentIndentProcessDao.updatePurchaseDeptIndentProcesstbl(doubleQuantity, intIndentCreationDetailsId,strStatus);
							}
							}


						}
					}

					//		icd.updatePurchaseDepartmentIndentProcess( productDetails,"");

					//icd.updateIndentCreationDetails(productDetails);

					//icd.inactiveIndent(productDetails);


				}
				
			}//for close
			int intstrIndentNo = Integer.parseInt(strIndentNo);
			objPurchaseDepartmentIndentProcessDao.getupdatePurchaseDeptIndentProcess(intstrIndentNo, strUserId,strSiteId,approvalEmpId,sessionSiteId) ;

			if(approvalEmpId!=null && approvalEmpId.equals("VND")  ){
				if(isSiteLevelPo.equalsIgnoreCase("true")){ //siteLevelPo Page
					
					objPurchaseDepartmentIndentProcessDao.updateSiteLeveltbl(sessionSiteId,total_Records+1,current_Records+1);
				}  else{
				
				if(editPonumber==null || editPonumber.equals("")){
					
				
				int intSiteWise_Number= Integer.parseInt(siteWise_Number)+1;
				int intSiteWise_YearNumber = Integer.parseInt(siteWise_YearNumber)+1;

				if(receiverState.equalsIgnoreCase("Telangana")){

					objPurchaseDepartmentIndentProcessDao.getUpdatePoNumberGeneratorHeadOfficeWise(intHOWiseInfinityNumber+1,intHOWiseYearwiseNumber+1,"PO_SIPL");  //PO_TELANGANA changed to PO_SIPL because requirment is changed they want SIPL level
					objPurchaseDepartmentIndentProcessDao.getUpdateStateWisePoNumber(intSiteWise_Number,intSiteWise_YearNumber,strSiteId);

				}else{


					objPurchaseDepartmentIndentProcessDao.getUpdatePoNumberGeneratorHeadOfficeWise(intHOWiseInfinityNumber+1,intHOWiseYearwiseNumber+1,"PO_SIPL"); //PO_KARNATAKA changed to PO_SIPL because requirment is changed they want SIPL level
					objPurchaseDepartmentIndentProcessDao.getUpdateStateWisePoNumber(intSiteWise_Number,intSiteWise_YearNumber,strSiteId);

				}
				}else{ }
				}
				strResponse="POPrintPage";

				objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls("0",String.valueOf(poEntryId),strUserId, strSiteId, "C","");


			}
			else{

				objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls(String.valueOf(strPONumber),"0",strUserId, strSiteId, "C","");

				strResponse="CreatePOFinalPage";
			}
			final VendorDetails vd = new VendorDetails();


			String nameEmail=objPurchaseDepartmentIndentProcessDao.getPoCreatedEmpName(strUserId);
			vd.setVendor_Id(strVendorId);
			final String poNumber =strPONumber;
			final String ccEmailTo = ccEmailId;
			final String subject1 = subject;
			final String finalSiteId = strSiteId;
			final String poCreatedEmpName=nameEmail;
			final int getLocalPort = request.getLocalPort();

			if(approvalEmpId!=null && approvalEmpId.equals("VND")){
				ExecutorService executorService = Executors.newFixedThreadPool(10);
				try{


					executorService.execute(new Runnable() {
						public void run() {
							sendEmailForPo( "", 0,finalSiteId, "siteName",vd,poNumber,ccEmailTo,subject1,poCreatedEmpName,getLocalPort);
						}
					});
					executorService.shutdown();
				}catch(Exception e){
					e.printStackTrace();
					executorService.shutdown();
				}
			}

			request.setAttribute("listOfTermsAndConditions", listOfTermsAndConditions);

			objviewPOPageDataMap.put("AddressDetails", strTableOneData);
			objviewPOPageDataMap.put("productDetails", strTableTwoDate);
			objviewPOPageDataMap.put("TransportDetails", strTableThreeData);
			request.setAttribute("viewPoPageData", objviewPOPageDataMap);
			request.setAttribute("receiverState", receiverState);
			//	strResponse = "Success";
			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			//if close
		}//try close

		catch(Exception e){
			//	strResponse = "Fail";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			e.printStackTrace();
		}

		return strResponse;
	}

	@Override
	public String SaveEnquiryForm(Model model, HttpServletRequest request,HttpSession session)
	{

		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDIn_saveEF, ");

		ProductDetails productDetails =null;
		String strResponse = "";
		int strPONumber = 0;
		String strVendorId = ""; 
		String vendorName = ""; 
		String strIndentNo = "";
		String strToSite="";
		String SiteName="";
		String siteWiseIndentNo = "";

		try{

			int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
			strVendorId = request.getParameter("vendorId");
			vendorName = request.getParameter("vendorName");
			siteWiseIndentNo = request.getParameter("siteWiseIndentNo");
			SiteName = request.getParameter("SiteName");
			String pass = request.getParameter("pass");
			//	System.out.println("the vendor id is "+strVendorId);
			int sno = 0;
			if(noofrows > 0){
				strIndentNo = request.getParameter("indentNumber");
				strToSite = request.getParameter("toSiteId"); //toSiteId
				WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , IndentNumber:"+strIndentNo+" , Vendor:"+vendorName);


				int acceptTermsAndConditionTotal = Integer.parseInt(request.getParameter("countOftermsandCondsfeilds"));
				String termsAndCondition = "";
				int val=0;
				for(int i=1;i<=acceptTermsAndConditionTotal;i++){

					termsAndCondition =  request.getParameter("termsAndCond"+i);

					val=objPurchaseDepartmentIndentProcessDao.saveVendorTermsconditions(termsAndCondition,strVendorId,strIndentNo);

					//System.out.println("the resulting value is "+val);

				}



				List<ProductDetails> listProductDetails  = new ArrayList<ProductDetails>();
				for(int num=1;num<=noofrows;num++){


					if(noofrows!=0)
					{
						sno++;
						String productId = request.getParameter("productId"+num);
						String subProductId = request.getParameter("subProductId"+num);
						String childProductId = request.getParameter("childProductId"+num);
						String productName = request.getParameter("ProductName"+num);
						String subProductName = request.getParameter("SubProductName"+num);
						String childProductName = request.getParameter("ChildProductName"+num);
						String childProductCustomerDesc = request.getParameter("childProductCustomerDesc"+num);


						String setMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
						String setMeasurementName = request.getParameter("unitsOfMeasurement"+num);
						String purchaseDepartmentIndentProcessSeqId = request.getParameter("purchaseDepartmentIndentProcessSeqId"+num);
						String poIntiatedQuantity = request.getParameter("poIntiatedQuantity"+num);
						String requestQuantity = request.getParameter("requestQantity"+num);
						String pendingQuantity = request.getParameter("pendingQuantity"+num);
						String quantity = request.getParameter("stQantity"+num);
						//String quantity = request.getParameter("stQantity"+num);
						String indentNo = request.getParameter("indentNumber");


						String hsnCode = request.getParameter("hsnCode"+num);
						String price = request.getParameter("price"+num);
						String basicAmount = request.getParameter("basicAmount"+num);
						String Discount=request.getParameter("Discount"+num);
						String amountAfterDiscount=request.getParameter("amtAfterDiscount"+num);
						String tax = request.getParameter("tax"+num);
						String taxAmount = request.getParameter("taxAmount"+num);
						String amountAfterTax = request.getParameter("amountAfterTax"+num);
						String totalAmount = request.getParameter("totalAmount"+num);
						String indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
						String strTaxId = "";
						String taxArr []  = tax.split("\\$");
						tax = taxArr[1];
						strTaxId = taxArr[0];
						String strStatus = "A";


						double otherOrTransportCharges = Double.valueOf(request.getParameter("OtherOrTransportChargesId"+num) == null ? "0" : request.getParameter("OtherOrTransportChargesId"+num).toString());
						double taxOnOtherOrTransportCharges =  Double.valueOf(request.getParameter("TaxOnOtherOrTransportChargesId"+num)== null ? "0" : request.getParameter("TaxOnOtherOrTransportChargesId"+num).toString());
						double otherOrTransportChargesAfterTax =  Double.valueOf(request.getParameter("OtherOrTransportChargesAfterTaxId"+num)== null ? "0" : request.getParameter("OtherOrTransportChargesAfterTaxId"+num).toString());

						String productBatchData = request.getParameter("productBatchData"+num);
						if(productBatchData!=null&&!productBatchData.equals("")){
							String[] icdArray = productBatchData.split("@@");
							int noofsplitproducts = icdArray.length;
							for(int i=0;i<noofsplitproducts;i++)
							{
								String currentProdData = icdArray[i];
								String individualICDId = currentProdData.split("=")[0];
								String individualQuantity = currentProdData.split("=")[1];


								productDetails = new ProductDetails();
								productDetails.setStrSerialNumber(String.valueOf(sno));
								productDetails.setProductId(productId);
								productDetails.setProductName(productName);
								productDetails.setSub_ProductId(subProductId);
								productDetails.setSub_ProductName(subProductName);
								productDetails.setChild_ProductId(childProductId);
								productDetails.setChild_ProductName(childProductName);
								productDetails.setMeasurementId(setMeasurementId);
								productDetails.setMeasurementName(setMeasurementName);
								//productDetails.setPendingQuantity(pendingQuantity);//po quantity

								productDetails.setQuantity(individualQuantity); //customer menioned Quantity
								productDetails.setHsnCode(hsnCode);
								productDetails.setPricePerUnit(price);
								productDetails.setBasicAmt(doCalculation(basicAmount,individualQuantity,quantity));
								productDetails.setStrDiscount(Discount);
								productDetails.setStrAmtAfterDiscount(doCalculation(amountAfterDiscount,individualQuantity,quantity));
								productDetails.setTax(tax);
								productDetails.setTaxId(strTaxId);
								productDetails.setTaxAmount(doCalculation(taxAmount,individualQuantity,quantity));
								productDetails.setAmountAfterTax(doCalculation(amountAfterTax,individualQuantity,quantity));
								productDetails.setTotalAmount(doCalculation(totalAmount,individualQuantity,quantity));
								productDetails.setStrIndentId(indentNo);
								productDetails.setVendorId(strVendorId);
								productDetails.setSite_Id(strToSite);
								productDetails.setChildProductCustDisc(childProductCustomerDesc);

								productDetails.setOtherOrTransportCharges1(0.0);
								productDetails.setTaxOnOtherOrTransportCharges1(0.0);
								productDetails.setOtherOrTransportChargesAfterTax1(0.0);
								productDetails.setIndentCreationDetailsId(individualICDId);


								objPurchaseDepartmentIndentProcessDao.updateEnquiryFormDetails(productDetails);

							} 
						}
						else
						{
							productDetails = new ProductDetails();
							productDetails.setStrSerialNumber(String.valueOf(sno));
							productDetails.setProductId(productId);
							productDetails.setProductName(productName);
							productDetails.setSub_ProductId(subProductId);
							productDetails.setSub_ProductName(subProductName);
							productDetails.setChild_ProductId(childProductId);
							productDetails.setChild_ProductName(childProductName);
							productDetails.setMeasurementId(setMeasurementId);
							productDetails.setMeasurementName(setMeasurementName);
							//productDetails.setPendingQuantity(pendingQuantity);//po quantity
							productDetails.setQuantity(quantity); //customer menioned Quantity

							productDetails.setHsnCode(hsnCode);
							productDetails.setPricePerUnit(price);
							productDetails.setBasicAmt(basicAmount);
							productDetails.setStrDiscount(Discount);
							productDetails.setStrAmtAfterDiscount(amountAfterDiscount);
							productDetails.setTax(tax);
							productDetails.setTaxId(strTaxId);
							productDetails.setTaxAmount(taxAmount);
							productDetails.setAmountAfterTax(amountAfterTax);
							productDetails.setTotalAmount(totalAmount);
							productDetails.setStrIndentId(indentNo);
							productDetails.setVendorId(strVendorId);
							productDetails.setSite_Id(strToSite);
							productDetails.setChildProductCustDisc(childProductCustomerDesc);

							productDetails.setOtherOrTransportCharges1(otherOrTransportCharges);
							productDetails.setTaxOnOtherOrTransportCharges1(taxOnOtherOrTransportCharges);
							productDetails.setOtherOrTransportChargesAfterTax1(otherOrTransportChargesAfterTax);
							productDetails.setIndentCreationDetailsId(indentCreationDetailsId);


							objPurchaseDepartmentIndentProcessDao.updateEnquiryFormDetails(productDetails);
						}



					}

				}
			}//for close
			String newPassword = getNewPasswordAfterRemove(strVendorId,strIndentNo,pass);
			objPurchaseDepartmentIndentProcessDao.setVendorPasswordInDB(newPassword,strVendorId);



			strResponse = "Success";


			if(strResponse.equalsIgnoreCase("success")){


				String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
				List<String> allEmployeeEmailsOfPD = new ArrayList<String>();
				if(!strToSite.equals("112")){

					allEmployeeEmailsOfPD = objPurchaseDepartmentIndentProcessDao.getAllEmployeeEmailsUnderDepartment(purchaseDeptId);

					String ccTo [] = new String[allEmployeeEmailsOfPD.size()];
					allEmployeeEmailsOfPD.toArray(ccTo);

					EmailFunction objEmailFunction = new EmailFunction();



					objEmailFunction.sendEnquiryFormFillMailToPurchaseDept(ccTo,siteWiseIndentNo,vendorName,SiteName);
				}
			}


			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			//if close
		}//try close

		catch(Exception e){
			strResponse = "Fail";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			e.printStackTrace();
		}

		return strResponse;

	}
	public String doCalculation(String strInput,String strIndividualQuantity,String strQuantity)
	{
		if(strQuantity.equals("0")||strQuantity.equals("0.0")){return "0";}
		else{}


		if(strInput == null || strInput.equals("")){

			return "0";
		}
		else{}

		if(strIndividualQuantity == null || strIndividualQuantity.equals("")){

			return "0";
		}
		else{}

		if(strQuantity == null || strQuantity.equals("")){

			return "0";
		}
		else{}


		double input = Double.parseDouble(strInput);
		double individualQuantity = Double.parseDouble(strIndividualQuantity);
		double quantity = Double.parseDouble(strQuantity);
		double output = (input*individualQuantity)/quantity;

		return String.valueOf(output);
	}
	public String getNewPasswordAfterRemove(String strVendorId,String strIndentNo, String pass)
	{
		String newIndentWisePasswords = "";
		String indentWisePasswords= "";
		indentWisePasswords = objPurchaseDepartmentIndentProcessDao.getVendorPasswordInDB(strVendorId);
		if(indentWisePasswords!=null&&indentWisePasswords!="")
		{

			indentWisePasswords = indentWisePasswords.substring(0, indentWisePasswords.length() - 2);
			String[] indentWisePasswordArray = indentWisePasswords.split("@@");
			for(String indentWisePwd : indentWisePasswordArray)
			{
				String[] indentAndPwd = indentWisePwd.split("=");
				String indent = indentAndPwd[0];
				String pwd = indentAndPwd[1];
				if(indent.equals(strIndentNo)){
					if(pass.equals(pwd))
					{

					}
				}
				else{
					newIndentWisePasswords+=indent+"="+pwd+"@@";
				}
			}

		}
		return newIndentWisePasswords;

	}

	@Override
	public void printIndent(Model model, HttpServletRequest request, int site_id, String user_id) {
		int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
		int siteWiseIndentNo= Integer.parseInt(request.getParameter("siteWiseIndentNo"));
		String strCreateDate="";
		int  orderQuantity=0;
		//System.out.println(indentNumber);
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		String siteId=request.getParameter("siteId");

		 String versionNo=request.getParameter("versionNo");
		 String reference_No=request.getParameter("reference_No");
		 String issue_date=request.getParameter("issue_date");
		
		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		int sno = 0;
		for(int num=1;num<=noofrows;num++){

			sno++;
			String product = request.getParameter("product"+num);
			String subProduct = request.getParameter("subProduct"+num);
			//String childProduct = request.getParameter("childProduct"+num);               //actual name
			String childProduct = request.getParameter("childProductPuchaseDeptDisc"+num); 

			if(childProduct == null ){
				childProduct = request.getParameter("childProduct"+num); 
			}


			//changed name 
			String unitsOfMeasurement = request.getParameter("unitsOfMeasurement"+num);

			//what is exactly meaning by requiredQuantity as per JSP it is different(element.pendingQuantity)

			String requiredQuantity = request.getParameter("requiredQuantity1"+num);
			String productAvailability=request.getParameter("productAvailability"+num);
			String remarks=request.getParameter("remarks"+num);
			double strRequiredQty=Double.parseDouble(requiredQuantity);
			double strProductAvail=Double.parseDouble(productAvailability);
			double strrequiredQuantity=0;

			strrequiredQuantity=(strRequiredQty)+(strProductAvail);
			requiredQuantity=String.valueOf(strrequiredQuantity);


			IndentCreationBean indentCreationBean = new IndentCreationBean();
			indentCreationBean.setStrSerialNumber(String.valueOf(sno));
			indentCreationBean.setSubProduct1(subProduct);
			indentCreationBean.setChildProduct1(childProduct);
			indentCreationBean.setUnitsOfMeasurement1(unitsOfMeasurement);
			indentCreationBean.setRequiredQuantity1(requiredQuantity);
			indentCreationBean.setProductAvailability(productAvailability);
			indentCreationBean.setOrderQuantity(strRequiredQty);
			indentCreationBean.setRemarks1(remarks);
			IndentCreationBean icb = new IndentCreationBean();
			icb = cntlIndentrocss.getCreateAndRequiredDates(indentNumber);
			indentCreationBean.setStrRequiredDate(icb.getStrRequiredDate());
			strCreateDate = icb.getStrCreateDate();
			list.add(indentCreationBean);

		}
		request.setAttribute("IndentDetails",list);
		//	System.out.println(list.get(0).getChildProduct1());
		List<IndentCreationBean> list1 = new ArrayList<IndentCreationBean>();
		IndentCreationBean icb1 = new IndentCreationBean();
		icb1.setIndentNumber(indentNumber);
		icb1.setSiteWiseIndentNo(siteWiseIndentNo);
		icb1.setVersionNo(versionNo);
		icb1.setIssue_date(issue_date);
		icb1.setReference_No(reference_No);
		
		icb1.setStrCreateDate(strCreateDate);
		list1.add(icb1);
		request.setAttribute("IndentDtls",list1);
		model.addAttribute("createdSiteName",cntlIndentrocss.getSiteNameWhereIndentCreated(indentNumber));
		model.addAttribute("siteAddress",cntlIndentrocss.getAddressOfSite(site_id));
		model.addAttribute("listCreatedName",objPurchaseDepartmentIndentProcessDao.getApproveCreateEmp(indentNumber,request));
		//	 model.addAttribute("createEmpName",createEmpName);
		objPurchaseDepartmentIndentProcessDao.getVerifiedEmpNames(indentNumber,request,siteId);


	}


	@Override
	public List<ProductDetails> getIndentsProductWise(String product, String subProduct, String childProduct) {
		return objPurchaseDepartmentIndentProcessDao.getIndentsProductWise(product,subProduct,childProduct);

	}

	@Override
	public List<ProductDetails> loadCreatePOPage(Model model, HttpServletRequest request) {
		//int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
		//System.out.println(indentNumber);
		//List<ProductDetails> list = new ArrayList<ProductDetails>();
		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		int sno = 0;
		List<ProductDetails> listProductDetails  = new ArrayList<ProductDetails>();
		for(int num=1;num<=noofrows;num++){
			if(request.getParameter("checkboxname"+num)!=null)
			{




				String productId = request.getParameter("productId"+num);
				String subProductId = request.getParameter("subProductId"+num);
				String childProductId = request.getParameter("childProductId"+num);
				String productName = request.getParameter("productName"+num);
				String subProductName = request.getParameter("subProductName"+num);
				String childProductName = request.getParameter("childProductName"+num);
				String setMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
				String setMeasurementName = request.getParameter("unitsOfMeasurementName"+num);
				String requiredQuantity = request.getParameter("requiredQuantity"+num);
				String indentNo = request.getParameter("indentNo"+num);
				ProductDetails productDetails = new ProductDetails();
				productDetails.setStrSerialNumber(String.valueOf(sno));
				productDetails.setProductId(productId);
				productDetails.setProductName(productName);
				productDetails.setSub_ProductId(subProductId);
				productDetails.setSub_ProductName(subProductName);
				productDetails.setChild_ProductId(childProductId);
				productDetails.setChild_ProductName(childProductName);
				productDetails.setMeasurementId(setMeasurementId);
				productDetails.setMeasurementName(setMeasurementName);
				productDetails.setQuantity(requiredQuantity);
				boolean isAlreadyThere = false;
				for(int i=0;i<listProductDetails.size();i++)
				{
					if(listProductDetails.get(i).getChild_ProductName().equals(childProductName))
					{
						isAlreadyThere = true;
						int temp = Integer.parseInt(listProductDetails.get(i).getQuantity());
						temp+=Integer.parseInt(requiredQuantity);
						listProductDetails.get(i).setQuantity(String.valueOf(temp));
						break;
					}
				}
				if(!isAlreadyThere)
				{
					sno++;
					productDetails.setStrSerialNumber(String.valueOf(sno));
					listProductDetails.add(productDetails);
				}




			}
		}

		return listProductDetails;
		//request.setAttribute("IndentDetails",list);

	}

	@Override
	public List<Map<String, Object>> getAllProducts() {
		String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();

		return objPurchaseDepartmentIndentProcessDao.getAllProducts(purchaseDeptId);
	}


	@Override
	public List<Map<String, Object>> sendenquiry2(Model model, HttpServletRequest request, int site_id, String user_id,String strSiteId) {
		int enquiryFormdetailsId = 0;
		final List<VendorDetails>  listOfVendorDetails =new ArrayList<VendorDetails>();
		int noOfVendors= Integer.parseInt(request.getParameter("noofvendorsproccessed"));
		for(int vnum=1;vnum<=noOfVendors;vnum++){
			String VendorName = request.getParameter("vendorName"+vnum);
			String GSTINNo = request.getParameter("strGSTINNumber"+vnum);
			String VendorAddress = request.getParameter("vendorAddress"+vnum);
			String vendorId= request.getParameter("vendorId"+vnum);
			String vendorPass = CommonUtilities.getStan();
			VendorDetails vendorDetails = new VendorDetails();
			vendorDetails.setVendor_name(VendorName);
			vendorDetails.setGsin_number(GSTINNo);
			vendorDetails.setAddress(VendorAddress);
			vendorDetails.setVendor_Id(vendorId);
			vendorDetails.setVendor_Pass(vendorPass);
			listOfVendorDetails.add(vendorDetails);
		}
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		int sno = 0;
		String indentCreationDetailsIdForenquiry = "";
		for(int num=1;num<=noofrows;num++){
			if(request.getParameter("checkboxname"+num)!=null)
			{

				String productId = request.getParameter("productId"+num);
				String subProductId = request.getParameter("subProductId"+num);
				String childProductId = request.getParameter("childProductId"+num);
				String unitsOfMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
				String product = request.getParameter("productName"+num);
				String subProduct = request.getParameter("subProductName"+num);
				//String childProduct = request.getParameter("childProductName"+num);          //actual name
				String childProduct = request.getParameter("childProductPuchaseDeptDisc"+num); //changed name
				String unitsOfMeasurement = request.getParameter("unitsOfMeasurementName"+num);
				String requiredQuantity = request.getParameter("requiredQuantity"+num);
				int indentCreationDetailsId = Integer.parseInt(request.getParameter("indentCreationDetailsId"+num));
				int indentNumber = Integer.parseInt(request.getParameter("indentNo"+num));
				int reqSiteId = Integer.parseInt(request.getParameter("strSiteId"+num));



				String strChildProductPurchasedisc = request.getParameter("childProductPuchaseDeptDisc"+num); 



				indentCreationDetailsIdForenquiry = indentCreationDetailsIdForenquiry+indentCreationDetailsId+",";

				IndentCreationBean indentCreationBean = new IndentCreationBean();
				indentCreationBean.setProductId1(productId);
				indentCreationBean.setSubProductId1(subProductId);
				indentCreationBean.setChildProductId1(childProductId);
				indentCreationBean.setUnitsOfMeasurementId1(unitsOfMeasurementId);
				indentCreationBean.setSubProduct1(subProduct);
				indentCreationBean.setChildProduct1(childProduct);
				indentCreationBean.setPurchaseDeptChildProdDisc(strChildProductPurchasedisc);
				indentCreationBean.setUnitsOfMeasurement1(unitsOfMeasurement);
				indentCreationBean.setRequiredQuantity1(requiredQuantity);
				indentCreationBean.setIndentCreationDetailsId(indentCreationDetailsId);
				indentCreationBean.setSiteId(reqSiteId);
				indentCreationBean.setIndentNumber(indentNumber);
				sno++;
				indentCreationBean.setStrSerialNumber(String.valueOf(sno));
				for(VendorDetails vendorDetails : listOfVendorDetails){
					indentCreationBean.setVendorId(vendorDetails.getVendor_Id());
					enquiryFormdetailsId = objPurchaseDepartmentIndentProcessDao.getEnquiryFormDetailsId();
					indentCreationBean.setEnquiryFormDetailsId(enquiryFormdetailsId);
					int result = objPurchaseDepartmentIndentProcessDao.insertVendorEnquiryFormDetails(indentCreationBean);
				}
				list.add(indentCreationBean);

			}
		}
		indentCreationDetailsIdForenquiry = indentCreationDetailsIdForenquiry.substring(0,indentCreationDetailsIdForenquiry.length()-1);

		List<Map<String, Object>> listReceiverDtls=objPurchaseDepartmentIndentProcessDao.getVendorOrSiteAddress(strSiteId);
		request.setAttribute("IndentDetails",list);
		final String sendEnquiryEmpDetails=objPurchaseDepartmentIndentProcessDao.getPoCreatedEmpName(user_id);
		final int getLocalPort = request.getLocalPort();
		//
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		try{

			final String finalIndentCreationDetailsIdForenquiry = indentCreationDetailsIdForenquiry;


			executorService.execute(new Runnable() {
				public void run() {
					sendEmailForEnquiry( "", 0, "Sumadhura Purchase Department", "",listOfVendorDetails,finalIndentCreationDetailsIdForenquiry,"-",0,"",sendEnquiryEmpDetails,getLocalPort);
				}
			});
			executorService.shutdown();
		}catch(Exception e){
			e.printStackTrace();
			executorService.shutdown();
		}
		//
		return listReceiverDtls;
	}



	@Override
	public List<Map<String, Object>> sendenquiry(Model model, HttpServletRequest request, int site_id, String user_id,final String siteId) {
		final int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
		final String siteName= request.getParameter("siteName");
		final int siteWiseIndentNo= Integer.parseInt(request.getParameter("siteWiseIndentNo"));
		String strsiteId= request.getParameter("siteId");

		final List<VendorDetails>  listOfVendorDetails =new ArrayList<VendorDetails>();
		int noOfVendors= Integer.parseInt(request.getParameter("noofvendorsproccessed"));
		for(int vnum=1;vnum<=noOfVendors;vnum++){
			String VendorName = request.getParameter("vendorName"+vnum);
			String GSTINNo = request.getParameter("strGSTINNumber"+vnum);
			String VendorAddress = request.getParameter("vendorAddress"+vnum);
			String vendorId= request.getParameter("vendorId"+vnum);
			String vendorPass = CommonUtilities.getStan();
			VendorDetails vendorDetails = new VendorDetails();
			vendorDetails.setVendor_name(VendorName);
			vendorDetails.setGsin_number(GSTINNo);
			vendorDetails.setAddress(VendorAddress);
			vendorDetails.setVendor_Id(vendorId);
			vendorDetails.setVendor_Pass(vendorPass);
			listOfVendorDetails.add(vendorDetails);
		}


		//System.out.println(indentNumber);
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		int sno = 0;
		String productName = "";
		String subProductName = "";
		String childProductName = "";
		String unitsOfMeasurementName = "";
		String productId = "";
		String subProductId = "";
		String childProductId = "";
		String unitsOfMeasurementId = "";
		String requiredQuantity = "";
		String strRequestQuantity = "";
		int indentCreationDetailsId = 0;
		String indentCreationDetailsIdForenquiry = "";
		int enquiryFormdetailsId = 0;
		String strChildProductPurchasedisc = "";

		for(int num=1;num<=noofrows;num++){
			if(request.getParameter("checkboxname"+num)!=null)
			{
				sno++;
				productName = request.getParameter("product"+num);
				subProductName = request.getParameter("subProduct"+num);
				//childProductName = request.getParameter("childProduct"+num);               //actual name
				childProductName = request.getParameter("childProductPuchaseDeptDisc"+num);  //changed name 
				unitsOfMeasurementName = request.getParameter("unitsOfMeasurement"+num);
				productId = request.getParameter("productId"+num);
				subProductId = request.getParameter("subProductId"+num);
				childProductId = request.getParameter("childProductId"+num);
				unitsOfMeasurementId = request.getParameter("unitsOfMeasurementId"+num);

				requiredQuantity = request.getParameter("POPendingQuantity"+num);//requiredQuantity
				//strRequestQuantity = request.getParameter("strRequestQuantity"+num);
				indentCreationDetailsId = Integer.parseInt(request.getParameter("indentCreationDetailsId"+num));



				strChildProductPurchasedisc = request.getParameter("childProductPuchaseDeptDisc"+num); 



				indentCreationDetailsIdForenquiry = indentCreationDetailsIdForenquiry+indentCreationDetailsId+",";

				IndentCreationBean indentCreationBean = new IndentCreationBean();
				indentCreationBean.setStrSerialNumber(String.valueOf(sno));
				indentCreationBean.setSubProduct1(subProductName);
				indentCreationBean.setChildProduct1(childProductName);
				indentCreationBean.setUnitsOfMeasurement1(unitsOfMeasurementName);
				indentCreationBean.setRequiredQuantity1(requiredQuantity);
				indentCreationBean.setProductId1(productId);
				indentCreationBean.setSubProductId1(subProductId);
				indentCreationBean.setChildProductId1(childProductId);
				indentCreationBean.setUnitsOfMeasurementId1(unitsOfMeasurementId);


				indentCreationBean.setSiteId(Integer.parseInt(siteId));
				indentCreationBean.setIndentNumber(indentNumber);

				indentCreationBean.setPurchaseDeptChildProdDisc(strChildProductPurchasedisc);
				indentCreationBean.setIndentCreationDetailsId(indentCreationDetailsId);

				for(VendorDetails vendorDetails : listOfVendorDetails){
					indentCreationBean.setVendorId(vendorDetails.getVendor_Id());
					enquiryFormdetailsId = objPurchaseDepartmentIndentProcessDao.getEnquiryFormDetailsId();
					indentCreationBean.setEnquiryFormDetailsId(enquiryFormdetailsId);
					int result = objPurchaseDepartmentIndentProcessDao.insertVendorEnquiryFormDetails(indentCreationBean);
				}

				list.add(indentCreationBean);
			}
		}
		indentCreationDetailsIdForenquiry = indentCreationDetailsIdForenquiry.substring(0,indentCreationDetailsIdForenquiry.length()-1);


		//String vendorId = request.getParameter("vendorId");

		List<Map<String, Object>> listReceiverDtls=objPurchaseDepartmentIndentProcessDao.getVendorOrSiteAddress(siteId);
		request.setAttribute("IndentDetails",list);
		request.setAttribute("receiverState",objPurchaseDepartmentIndentProcessDao.getStateNameForTermsAndConditions(siteId));
		final String address= objPurchaseDepartmentIndentProcessDao.getSiteAddress(strsiteId);
		final String sendEnquiryEmpDetails=objPurchaseDepartmentIndentProcessDao.getPoCreatedEmpName(user_id);
		final int getLocalPort = request.getLocalPort();




		boolean isFillForm = false;
		if(request.getAttribute("isFillForm")!=null){
			if(request.getAttribute("isFillForm").toString().equals("yes")){isFillForm = true;}
		}
		if(isFillForm){}
		else{
			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{

				final String finalIndentCreationDetailsIdForenquiry = indentCreationDetailsIdForenquiry;


				executorService.execute(new Runnable() {
					public void run() {
						sendEmailForEnquiry( "", indentNumber, "Sumadhura Purchase Department", siteName,listOfVendorDetails,finalIndentCreationDetailsIdForenquiry,address,siteWiseIndentNo,siteId,sendEnquiryEmpDetails,getLocalPort);
					}
				});
				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}



		}
		return listReceiverDtls;
	}
	public void sendEmailForEnquiry(String pendingEmpId,int indentNumber,String indentFrom,String indentTo,List<VendorDetails> listOfVendorDetails,String indentCreationDetailsIdForenquiry,String address, int siteWiseIndentNo,String strIndentSiteId,String sendEnquiryEmpDetails,int getLocalPort){


		try{
			for(VendorDetails vendorDetails : listOfVendorDetails){
				//List<Map<String, Object>> indentCreationDtls = null;
				List<String> toMailListArrayList = new ArrayList<String>();
				String emailto [] = null ;
				/*if(!pendingEmpId.equals("-"))
			{
				indentCreationDtls = icd.getIndentCreationDetails(indentNumber, "approvalToEmployee");
			}else if(pendingEmpId.equals("-"))
			{
				indentCreationDtls = icd.getIndentCreationDetails(indentNumber,"approvalToDept");

				toMailListArrayList = icd.getAllEmployeeEmailsUnderDepartment(999);
			}*/
				String newIndentWisePasswords= "";
				String indentWisePasswords= "";
				indentWisePasswords = objPurchaseDepartmentIndentProcessDao.getVendorPasswordInDB(vendorDetails.getVendor_Id());

				newIndentWisePasswords+=indentWisePasswords+indentNumber+"="+vendorDetails.getVendor_Pass()+"@@";
				/*if(indentWisePasswords!=null&&indentWisePasswords!="")
			{
				boolean isAlreadyThere = false;
				indentWisePasswords = indentWisePasswords.substring(0, indentWisePasswords.length() - 2);
				String[] indentWisePasswordArray = indentWisePasswords.split("@@");
				for(String indentWisePwd : indentWisePasswordArray)
				{
					String[] indentAndPwd = indentWisePwd.split("=");
					String indent = indentAndPwd[0];
					String pwd = indentAndPwd[1];
					if(indent.equals(String.valueOf(indentNumber))){
						pwd = vendorDetails.getVendor_Pass();
						isAlreadyThere = true;
					}
					newIndentWisePasswords+=indent+"="+pwd+"@@";
				}

				if(!isAlreadyThere)
				{
					newIndentWisePasswords+=indentNumber+"="+vendorDetails.getVendor_Pass()+"@@";
				}

			}
			else
			{
				newIndentWisePasswords+=indentNumber+"="+vendorDetails.getVendor_Pass()+"@@";
			}*/

				objPurchaseDepartmentIndentProcessDao.setVendorPasswordInDB(newIndentWisePasswords,vendorDetails.getVendor_Id());
				String strIndentFromSite = "";
				//String strIndentFromDate = "";
				//String strEmailAddress =   "";
				/*for(Map<String, Object> objIndentCreationDtls : indentCreationDtls) {



				strIndentFromSite = objIndentCreationDtls.get("SITE_NAME")==null ? "" :   objIndentCreationDtls.get("SITE_NAME").toString();
				strIndentFromDate = objIndentCreationDtls.get("CREATE_DATE")==null ? "" :   objIndentCreationDtls.get("CREATE_DATE").toString();
				strEmailAddress = objIndentCreationDtls.get("Email_id")==null ? "" :   objIndentCreationDtls.get("Email_id").toString();

			}*/
				String createDate = objPurchaseDepartmentIndentProcessDao.getIndentCreationDate(indentNumber);
				String vendoremail = objPurchaseDepartmentIndentProcessDao.getVendorEmail(vendorDetails.getVendor_Id());

				String[] EmailToArray = vendoremail.split(",");
				for(int i=0;i<EmailToArray.length;i++){
					toMailListArrayList.add(EmailToArray[i]);
				}
				//	toMailListArrayList.add(vendoremail);

				emailto = new String[toMailListArrayList.size()];
				toMailListArrayList.toArray(emailto);

				EmailFunction objEmailFunction = new EmailFunction();



				objEmailFunction.sendMailToVendor( indentTo, indentNumber, indentFrom, 	strIndentFromSite, createDate, emailto , vendorDetails,indentCreationDetailsIdForenquiry,address,siteWiseIndentNo,strIndentSiteId,sendEnquiryEmpDetails,getLocalPort);

			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void sendEmailForPo(String pendingEmpId,int indentNumber,String indentFrom,String indentTo,VendorDetails vendorDetails,String poNumber,String ccEmailTo,String subject,String poCreatedEmpName,int getLocalPort){


		try{
			//List<Map<String, Object>> indentCreationDtls = null;
			List<String> toMailListArrayList = new ArrayList<String>();
			String emailto [] = null ;
			String strIndentFromSite = "";
			String createDate = "now";//objPurchaseDepartmentIndentProcessDao.getIndentCreationDate(indentNumber);
			String vendoremail = objPurchaseDepartmentIndentProcessDao.getVendorEmail(vendorDetails.getVendor_Id());


			if(vendoremail != null &&! vendoremail.equals("")){
				if(vendoremail.contains(",")){
					for(int i=0;i<vendoremail.split(",").length;i++){
						toMailListArrayList.add(vendoremail.split(",")[i]);
					}
				}else{
					toMailListArrayList.add(vendoremail);
				}
			}



			emailto = new String[toMailListArrayList.size()];
			toMailListArrayList.toArray(emailto);

			String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
			List<String> allEmployeeEmailsOfPD = new ArrayList<String>();
			if(!indentFrom.equals("112")){
				allEmployeeEmailsOfPD = objPurchaseDepartmentIndentProcessDao.getAllEmployeeEmailsUnderDepartment( purchaseDeptId);
			}
			//	System.out.println("allEmployeeEmailsOfPD: "+allEmployeeEmailsOfPD);
			if(!ccEmailTo.equals("")&&ccEmailTo!=null){
				String[] ccEmailToArray = ccEmailTo.split(",");
				for(int i=0;i<ccEmailToArray.length;i++){
					allEmployeeEmailsOfPD.add(ccEmailToArray[i]);
				}
			}
			String ccTo [] = new String[allEmployeeEmailsOfPD.size()];
			allEmployeeEmailsOfPD.toArray(ccTo);

			EmailFunction objEmailFunction = new EmailFunction();



			objEmailFunction.sendMailToVendorForPO( indentTo, indentNumber, indentFrom, 	strIndentFromSite, createDate, emailto , vendorDetails,poNumber,ccTo,subject,poCreatedEmpName,getLocalPort);

		}catch(Exception e){
			e.printStackTrace();
		}
	}


	@Override
	public List<IndentCreationDto> getPendingIndents(String user_id,String site_id) {
		List<IndentCreationDto> list = objPurchaseDepartmentIndentProcessDao.getPendingIndents(user_id,site_id);
		return list;
	}


	@Override
	public List<IndentCreationBean> getAllPurchaseIndents() {
		String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
		return cntlIndentrocss.getIndentFromAndToDetails(purchaseDeptId);
	}


	@Override
	public boolean getVendorPasswordInDB(String uname,int indentNumber,String pass) {
		boolean isValidPassword= false;
		String newIndentWisePasswords = "";
		String indentWisePasswords= "";
		indentWisePasswords = objPurchaseDepartmentIndentProcessDao.getVendorPasswordInDB(uname);
		boolean isThere = false;
		if(indentWisePasswords!=null&&indentWisePasswords!="")
		{

			indentWisePasswords = indentWisePasswords.substring(0, indentWisePasswords.length() - 2);
			String[] indentWisePasswordArray = indentWisePasswords.split("@@");
			for(String indentWisePwd : indentWisePasswordArray)
			{
				String[] indentAndPwd = indentWisePwd.split("=");
				String indent = indentAndPwd[0];
				String pwd = indentAndPwd[1];
				if(indent.equals(String.valueOf(indentNumber))){
					if(pass.trim().equals(pwd))
					{
						isValidPassword = true;
					}
				}
			}
		}
		return isValidPassword;
	}


	@Override
	public List<Map<String, Object>> getComparisionDtls(HttpServletRequest request,HttpSession session)
	{
		String strResponse = "failed";

		List<Map<String, Object>>  objproducts= null;
		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		//CHILD_PRODUCT_ID
		List<String> childProductList = new ArrayList<String>();
		String childProductId =  "";
		String strChildProductList = "";
		String siteId=request.getParameter("siteId");
		try{
			String indentNo = request.getParameter("indentNumber");
			String vendorId=request.getParameter("vendorId1");
			for(int num=1;num<=noofrows;num++){
				if(request.getParameter("checkboxname"+num)!=null)
				{

					childProductId = request.getParameter("childProductId"+num);
					strChildProductList = strChildProductList+"'"+childProductId+"',";
					childProductList.add(childProductId);

				}
			}
			request.setAttribute("childProductList", childProductList);

			if(strChildProductList.length() >0){
				strChildProductList =  strChildProductList.substring(0,strChildProductList.length()-1);


				objproducts= objPurchaseDepartmentIndentProcessDao.getComparisionDetails( indentNo, strChildProductList,vendorId);
				objproducts = equalizeQuantityInDifferentVendorsForSameProduct(objproducts);
			}

			request.setAttribute("receiverState",objPurchaseDepartmentIndentProcessDao.getStateNameForTermsAndConditions(siteId));

		}

		catch(Exception e){
			e.printStackTrace();
		}
		return objproducts;	
	}
	public List<Map<String, Object>> equalizeQuantityInDifferentVendorsForSameProduct(List<Map<String, Object>>  objproducts){

		Map<String,String> childProductIdAndIndentQuantityMap = new HashMap<String,String>();
		for(Map<String, Object> prods : objproducts){
			String childProductId = prods.get("CHILD_PRODUCT_ID")==null ? "" :   prods.get("CHILD_PRODUCT_ID").toString();
			String strQuantity = prods.get("INDENT_QTY")==null ? "" :   prods.get("INDENT_QTY").toString();
			if(!childProductIdAndIndentQuantityMap.containsKey(childProductId)){
				childProductIdAndIndentQuantityMap.put(childProductId, strQuantity);
			}
		}
		//
		for(int i=0;i<objproducts.size();i++){
			Map<String, Object> prods = objproducts.get(i);
			String childProductId = prods.get("CHILD_PRODUCT_ID")==null ? "" :   prods.get("CHILD_PRODUCT_ID").toString();
			String vendorQuantity = prods.get("VENDOR_MENTIONED_QTY")==null ? "" :   prods.get("VENDOR_MENTIONED_QTY").toString();
			String indentQuantity = childProductIdAndIndentQuantityMap.get(childProductId);
			prods.put("INDENT_QTY",indentQuantity);
			//doCalculation
			if(!vendorQuantity.equals(indentQuantity)){
				String basicAmount = prods.get("BASIC_AMOUNT")==null ? "" :   prods.get("BASIC_AMOUNT").toString();
				String amountAfterDiscount = prods.get("AMOUNT_AFTER_DISCOUNT")==null ? "" :   prods.get("AMOUNT_AFTER_DISCOUNT").toString();
				String taxAmount = prods.get("TAX_AMOUNT")==null ? "" :   prods.get("TAX_AMOUNT").toString();
				String amountAfterTax = prods.get("AMOUNT_AFTER_TAX")==null ? "" :   prods.get("AMOUNT_AFTER_TAX").toString();
				String totalAmount = prods.get("TOTAL_AMOUNT")==null ? "" :   prods.get("TOTAL_AMOUNT").toString();

				prods.put("VENDOR_MENTIONED_QTY", indentQuantity);
				prods.put("BASIC_AMOUNT", doCalculation(basicAmount,indentQuantity,vendorQuantity));
				prods.put("AMOUNT_AFTER_DISCOUNT", doCalculation(amountAfterDiscount,indentQuantity,vendorQuantity));
				prods.put("TAX_AMOUNT", doCalculation(taxAmount,indentQuantity,vendorQuantity));
				prods.put("AMOUNT_AFTER_TAX", doCalculation(amountAfterTax,indentQuantity,vendorQuantity));
				prods.put("TOTAL_AMOUNT", doCalculation(totalAmount,indentQuantity,vendorQuantity));
			}

		}
		return objproducts;
	}

	@Override
	public List<IndentCreationBean> getAllSitePurchaseIndents(String siteId) {
		String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
		return cntlIndentrocss.getSpecificSiteIndentFromAndToDetails(purchaseDeptId,siteId);
	}

	@Override
	public List<ProductDetails> getTermsAndConditions(String site_id) {
		String state = objPurchaseDepartmentIndentProcessDao.getStateNameForTermsAndConditions(site_id);
		state = state.toUpperCase();
		//	String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
		List<ProductDetails> listTermsAndcondtion = new ArrayList<ProductDetails>();
		ProductDetails objProductDetails = null;

		int count =0;
		while(true) {
			objProductDetails = new ProductDetails();
			count = count+1;

			String condition = validateParams.getProperty(site_id+"_"+state+"_TC"+count);
			if(condition==null){break;}
			else{
				objProductDetails.setStrTermsConditionName(condition);
				listTermsAndcondtion.add(objProductDetails); 
			}

		}
		return listTermsAndcondtion;
	}
	@Override
	public String getDefaultCCEmails(String site_id) {
		String state = objPurchaseDepartmentIndentProcessDao.getStateNameForTermsAndConditions(site_id);
		state = state.toUpperCase();

		String strCCEmails="";
		int count =0;
		while(true) {

			count = count+1;

			String ccEmail = validateParams.getProperty(site_id+"_"+state+"_CCEMAIL"+count);
			if(ccEmail==null){break;}
			else{
				strCCEmails =strCCEmails + ccEmail + ",";
			}

		}
		if(!strCCEmails.equals("")){strCCEmails = strCCEmails.substring(0,strCCEmails.length()-1);}
		return strCCEmails;
	}	

	public List<IndentCreationBean> ViewPoPendingforApproval(String fromDate, String toDate, String strUserId,String tempPoNumber){
		List<IndentCreationBean> list = null;
		try{
			list = objPurchaseDepartmentIndentProcessDao.ViewPoPendingforApproval( fromDate,  toDate,  strUserId,tempPoNumber);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public String getDetailsforPoApproval(String poNumber, String siteId,HttpServletRequest request) {

		Map<String,String> objviewPOPageDataMap = new HashMap<String,String>();
		String result="Success";
		String tblOneData="";
		String tbltwoData="";
		String tblCharges="";
		String gstinumber="";
		String deliverySiteState="";
		String siteName=request.getParameter("siteName");
		//String strIndentNumber = "";
		try {
			//strIndentNumber = request.getParameter("indentNumber") == null ? "" : request.getParameter("indentNumber").toString();
			tblOneData+= objPurchaseDepartmentIndentProcessDao.getPendingVendorDetails(poNumber, siteId,request,siteName);
			deliverySiteState=request.getAttribute("deliverySiteState").toString();
			tbltwoData+= objPurchaseDepartmentIndentProcessDao.getPendingProductDetails(poNumber,siteId,request,deliverySiteState);
			gstinumber=request.getAttribute("gstinumber").toString();
			//terms=request.getAttribute("terms").toString();
			tblCharges+=objPurchaseDepartmentIndentProcessDao.getPendingTransportChargesList(poNumber,siteId,gstinumber,request,deliverySiteState);
			request.setAttribute("receiverState",objPurchaseDepartmentIndentProcessDao.getStateNameForTermsAndConditions(siteId));

			objviewPOPageDataMap.put("AddressDetails", tblOneData);
			objviewPOPageDataMap.put("productDetails", tbltwoData);
			objviewPOPageDataMap.put("TransportDetails", tblCharges);
			request.setAttribute("viewPoPageData", objviewPOPageDataMap);



		} 

		catch (Exception e) {

			request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Receive.");

			result = "Failed";
			AuditLogDetailsBean auditBean = new AuditLogDetailsBean();

			auditBean.setOperationName("update Recive");
			auditBean.setStatus("error");

			e.printStackTrace();
		}

		return result;
	}

	@Override
	public String SavePoApproveDetails(final String tempPONumber, String siteId,String userId,HttpServletRequest request,String isCancelTempPO) {

		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDIn_savPOA, ");

		Map<String,String> objviewPOPageDataMap = new HashMap<String,String>();
		String result="Success";

		String indentnumber="";
		String permPoNumber="";
		int val=0;
		String approvalEmpId = "";
		String state="";
		String sessionSite_id="";
		int intPoEntrySeqId =0;
		String revision_No="";
		String old_Po_Number="";
		String siteLevelPoPreparedBy="";
		String siteName="";
		String ccmailId=request.getParameter("ccEmailId2")== null ? "" : request.getParameter("ccEmailId2").toString();	
		try{


			approvalEmpId = objPurchaseDepartmentIndentProcessDao.getTemproryuser(userId);

			HttpSession session = request.getSession(true);
			String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();				

			if(approvalEmpId!=null && !approvalEmpId.equals("") && !approvalEmpId.equals("VND")){
				WriteTrHistory.write("Site:"+siteId+" , User:"+userId+" , Date:"+new java.util.Date()+" , TempPONumber:"+tempPONumber);


				val=objPurchaseDepartmentIndentProcessDao.updateTempPoEntry(approvalEmpId,tempPONumber,ccmailId);
				if(isCancelTempPO.equals("true")){

					objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls(tempPONumber,"0",strUserId, siteId, "E&S","");

				}else{

					objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls(tempPONumber,"0",strUserId, siteId, "A","");

				}
				if(val>0){
					result="success";
					request.setAttribute("result", "Temp Po approved Successfully");
				}				
				else{
					result="failed";
					request.setAttribute("result", "Temp Po approved Failed");
				}

			}
			else{
				revision_No=request.getParameter("revision_No") == null ? "" : request.getParameter("revision_No").toString();	
				old_Po_Number=request.getParameter("oldPoNumber") == null ? "" : request.getParameter("oldPoNumber").toString();
				siteLevelPoPreparedBy=request.getParameter("siteLevelPoPreparedBy") == null ? "-" : request.getParameter("siteLevelPoPreparedBy").toString();
				siteName=request.getParameter("siteName") == null ? "" : request.getParameter("siteName").toString();
				objPurchaseDepartmentIndentProcessDao.getAndsaveVendorDetails(tempPONumber, siteId,userId,request,revision_No,old_Po_Number,siteLevelPoPreparedBy,siteName);
				request.getAttribute("tempPoNumber").toString();
				permPoNumber=request.getAttribute("permentPoNumber").toString();
				WriteTrHistory.write("Site:"+siteId+" , User:"+userId+" , Date:"+new java.util.Date()+" , TempPONumber:"+tempPONumber+" , PermanentPONumber:"+permPoNumber);

				state=request.getAttribute("State").toString();
				intPoEntrySeqId = Integer.parseInt(request.getAttribute("poEntrySeqID") == null ? "0" : request.getAttribute("poEntrySeqID").toString());
				objPurchaseDepartmentIndentProcessDao.gettermsconditions(tempPONumber,String.valueOf(intPoEntrySeqId));
				objPurchaseDepartmentIndentProcessDao.getAndsavePendingProductDetails(tempPONumber,siteId,request,permPoNumber,intPoEntrySeqId);
				indentnumber=request.getParameter("strIndentNo");
				objPurchaseDepartmentIndentProcessDao.getAndsavePendingTransportChargesList(tempPONumber,siteId,request,intPoEntrySeqId);
				result="success";
				request.setAttribute("result", "Temp Po approved Successfully and PO Number is : "+permPoNumber);
				request.setAttribute("viewPoPageData", objviewPOPageDataMap);

				if(result.equals("success")){

					sessionSite_id=request.getAttribute("sessionSite_id").toString();

					String vendorId = "";

					objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls(tempPONumber,String.valueOf(intPoEntrySeqId),strUserId, siteId, "A","");

					int i=objPurchaseDepartmentIndentProcessDao.updatepoEntrydetails(tempPONumber,indentnumber,siteId,userId,sessionSite_id);

					vendorId = objPurchaseDepartmentIndentProcessDao.getVendorDetails(tempPONumber, siteId,userId,request);
					//String serviceName=request.getAttribute("serviceState").toString();
					/*int infinityNumber=	objPurchaseDepartmentIndentProcessDao.getPoInfinityNumberGenerator(serviceName);
				int YearWiseNumber=objPurchaseDepartmentIndentProcessDao.getPoYearWiseNumberGenerator(serviceName);
				int	site_Wise_Ponumber=objPurchaseDepartmentIndentProcessDao.getStateWisePoNumber(siteId);
				int	site_Wise_Year_Ponumber=objPurchaseDepartmentIndentProcessDao.getStateWiseYearPo_Number(siteId);


				if(state.equalsIgnoreCase("Telangana")){

					objPurchaseDepartmentIndentProcessDao.getUpdatePoNumberGeneratorHeadOfficeWise(infinityNumber,YearWiseNumber,"PO_TELANGANA");
					objPurchaseDepartmentIndentProcessDao.getUpdateStateWisePoNumber(site_Wise_Ponumber,site_Wise_Year_Ponumber,siteId);

				}else{


					objPurchaseDepartmentIndentProcessDao.getUpdatePoNumberGeneratorHeadOfficeWise(infinityNumber,YearWiseNumber,"PO_KARNATAKA");
					objPurchaseDepartmentIndentProcessDao.getUpdateStateWisePoNumber(site_Wise_Ponumber,site_Wise_Year_Ponumber,siteId);

				}*/



					final VendorDetails vd = new VendorDetails();
					vd.setVendor_Id(vendorId);

					String ccEmailId = request.getParameter("ccEmailId2");
					if(!ccEmailId.equals("")){
						if(ccEmailId.charAt(ccEmailId.length() - 1)==','){
							ccEmailId = ccEmailId.substring(0,ccEmailId.length()-1);
						}
						if(ccEmailId.charAt(0)=='-'){
							ccEmailId = ccEmailId.substring(1,ccEmailId.length());
						}
					}

					String empId=objPurchaseDepartmentIndentProcessDao.getPoCreatedEmpId(tempPONumber);
					String nameEmail=objPurchaseDepartmentIndentProcessDao.getPoCreatedEmpName(empId);
					final String ccEmailTo = ccEmailId;
					final String subject = request.getParameter("subject");
					final String finalSiteId = siteId;
					final String finalPermPoNumber = permPoNumber;
					final String poCreatedEmpName=nameEmail;
					final int getLocalPort = request.getLocalPort();
					ExecutorService executorService = Executors.newFixedThreadPool(10);
					executorService.execute(new Runnable() {
						public void run() {
							sendEmailForPo( "", 0, finalSiteId, "",vd,finalPermPoNumber,ccEmailTo,subject,poCreatedEmpName,getLocalPort);
						}
					});
					executorService.shutdown();


				}

			}//else

			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
		}catch (Exception e) {

			request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Receive.");

			result = "failed";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			AuditLogDetailsBean auditBean = new AuditLogDetailsBean();

			auditBean.setOperationName("update Recive");
			auditBean.setStatus("error");

			e.printStackTrace();
		}
		return result;
	}

	public String RejectPoDetails(HttpSession session ,HttpServletRequest request) {

		String user_id ="";
		String ponumber = "";
		String response = "";
		String indentNumber="";
		String quantity="";
		String site_id ="";
		String indentCreationdtlsId="";
		int intTotalNoOfRecords = 0;
		try {



			intTotalNoOfRecords = Integer.parseInt(request.getParameter("totalNoOfRecords") == null ? "0" : request.getParameter("totalNoOfRecords").toString());
			if(intTotalNoOfRecords > 0){
				for(int i =0; i<=intTotalNoOfRecords-1;i++){

					indentNumber=request.getParameter("strIndentNo");
					quantity=request.getParameter("quantity"+i);
					ponumber=request.getParameter("strPONumber");
					indentCreationdtlsId=request.getParameter("indentCreationdtlsId"+i);
					//	session = request.getSession(true);
					site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
					user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();


					objPurchaseDepartmentIndentProcessDao.updatePurchaseDeptIndentProcestbl(indentNumber,quantity,ponumber,indentCreationdtlsId);

				}

				objPurchaseDepartmentIndentProcessDao.updateTablesOnTempPORejection( indentNumber, ponumber, indentCreationdtlsId);


				response = "Success";
			}else{
				response = "failure";
			}
		} catch (Exception e) {
			//System.out.println("temp po number "+ponumber);
			e.printStackTrace();
			response = "failure";
		}	
		SaveAuditLogDetails.auditLog("0",user_id,"PO rejected",response,String.valueOf(site_id));
		return response;
	}




	public List<ProductDetails> getQuatationProductDetails(HttpServletRequest request,HttpSession session){

		List<ProductDetails> listProductDetails  =  new ArrayList<ProductDetails>();

		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
		int sno=0;

		for(int num=1;num<=noofrows;num++){
			if(request.getParameter("checkboxname"+num)!=null)
			{
				++sno;
				String product = request.getParameter("product"+num);
				String subProduct = request.getParameter("subProduct"+num);
				String childProduct = request.getParameter("childProduct"+num);
				String unitsOfMeasurement = request.getParameter("unitsOfMeasurement"+num);
				String requiredQuantity = request.getParameter("requiredQuantity"+num);
				String pendingQuantity = request.getParameter("pendingQuantity"+num);
				String poIntiatedQuantity = request.getParameter("poIntiatedQuantity"+num);

				//	strChildProductList = strChildProductList+"'"+childProductId+"',";
				ProductDetails productDetails = new ProductDetails();

				productDetails.setStrSerialNumber(String.valueOf(sno));
				productDetails.setProductName(product);
				productDetails.setSub_ProductName(subProduct);
				productDetails.setChild_ProductName(childProduct);
				productDetails.setMeasurementName(unitsOfMeasurement);
				//	productDetails.setQuantity(strPending);

				productDetails.setPendingQuantity(pendingQuantity);
				productDetails.setRequiredQuantity(requiredQuantity);
				productDetails.setPoIntiatedQuantity(poIntiatedQuantity);




				listProductDetails.add(productDetails);
			}
		}

		return listProductDetails;

	}

	public List<ProductDetails> getQuatationDetails(HttpServletRequest request){
		Map<String,String> objviewPOPageDataMap = new HashMap<String,String>();

		List<ProductDetails> listProductDetails  =  new ArrayList<ProductDetails>();
		String strTableOneData="";
		String termsconditions="";
		String VendorName=request.getParameter("vendorName1");
		String vendorId=request.getParameter("vendorId1");
		String strGSTINNumber=request.getParameter("strGSTINNumber1");
		String vendorAddress=request.getParameter("vendorAddress1");
		String indentNo = request.getParameter("indentNumber");
		String siteWiseIndentNo = request.getParameter("siteWiseIndentNo");
		String SiteName=request.getParameter("siteName");
		String siteId=request.getParameter("siteId");
		int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));


		ProductDetails productDetails = new ProductDetails();
		productDetails.setVendorName(VendorName);
		productDetails.setStrGSTINNumber(strGSTINNumber);
		productDetails.setVendorAddress(vendorAddress);
		productDetails.setSiteName(SiteName);
		productDetails.setStrIndentId(indentNo);
		/*productDetails.setSiteWiseIndentNo(siteWiseIndentNo);*/

		listProductDetails.add(productDetails);


		strTableOneData +=indentNo+"@@"+new java.sql.Date(System.currentTimeMillis())+"@@"+VendorName+"@@"+vendorAddress+"@@"+strGSTINNumber+"@@"+siteWiseIndentNo+"@@"+SiteName;

		//	 objviewPOPageDataMap.put("AddressDetails",strTableOneData);

		List<String> listOfTermsAndConditions=objPurchaseDepartmentIndentProcessDao.getVendortermsconditions(indentNo,vendorId);
		//System.out.println("the value is "+listOfTermsAndConditions);
		request.setAttribute("listOfTermsAndConditions",listOfTermsAndConditions);

		//String state=;
		//System.out.println("the value is"+state);
		request.setAttribute("receiverState",objPurchaseDepartmentIndentProcessDao.getStateNameForTermsAndConditions(siteId));

		request.setAttribute("AddressDetails",strTableOneData);

		return listProductDetails;
	}

	//check val true for Temp Po
	@Override
	public List<ProductDetails> getProductDetailsLists(String indentNo, String vendorName,HttpServletRequest request,String checkVal) {
		List<ProductDetails> listGetInvoiceDetailsList = null;
		List<ProductDetails> listProductDetails  =  new ArrayList<ProductDetails>();
		int sno=0;
		String productId ="";
		String subProductId ="";
		String childProductId ="";
		String productName ="";
		String subProductName ="";
		String childProductName ="";
		String setMeasurementId ="";
		String setMeasurementName ="";
		String indentCreationDetailsId ="";
		String strQuantity ="";
		String strPOIntiatedQuantity ="";
		String strPurchaseDepatRequstReceivedQuantity ="";


		int noofrows = Integer.parseInt(request.getParameter("numberOfRows") == null ? "0" : request.getParameter("numberOfRows").toString());
		try {

			if(checkVal.equalsIgnoreCase("true")){

				productId = request.getParameter("prodId");
				subProductId = request.getParameter("subProductId");
				childProductId = request.getParameter("childProdId");
				productName = request.getParameter("productName");
				subProductName = request.getParameter("subProductName");
				childProductName = request.getParameter("childProductName");//childProduct
				setMeasurementId = request.getParameter("measurementId");
				setMeasurementName = request.getParameter("measurementName");
				indentCreationDetailsId = request.getParameter("indent_Creation_dtls_Id");
				strQuantity = request.getParameter("pending_Quan");
				strPOIntiatedQuantity = request.getParameter("init_Quan");
				strPurchaseDepatRequstReceivedQuantity = request.getParameter("req_Quan");

				ProductDetails productDetails = new ProductDetails();
				productDetails.setStrSerialNumber(String.valueOf(sno));
				productDetails.setProductId(productId);
				productDetails.setProductName(productName);
				productDetails.setSub_ProductId(subProductId);
				productDetails.setSub_ProductName(subProductName);
				productDetails.setChild_ProductId(childProductId);
				productDetails.setChild_ProductName(childProductName);
				productDetails.setMeasurementId(setMeasurementId);
				productDetails.setMeasurementName(setMeasurementName);
				productDetails.setIndentCreationDetailsId(indentCreationDetailsId);
				productDetails.setQuantity(strQuantity);
				productDetails.setPoIntiatedQuantity(strPOIntiatedQuantity);
				productDetails.setPurchasedeptRequestReceiveQuantity(strPurchaseDepatRequstReceivedQuantity);

				listProductDetails.add(productDetails);




			}else{

				for(int num=1;num<=noofrows;num++){
					if(request.getParameter("checkboxname"+num)!=null)
					{
						sno++;
						productId = request.getParameter("productId"+num);
						subProductId = request.getParameter("subProductId"+num);
						childProductId = request.getParameter("childProductId"+num);
						productName = request.getParameter("product"+num);
						subProductName = request.getParameter("subProduct"+num);
						childProductName = request.getParameter("childProductPuchaseDeptDisc"+num);//childProduct
						setMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
						setMeasurementName = request.getParameter("unitsOfMeasurement"+num);
						indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
						strQuantity = request.getParameter("POPendingQuantity"+num);
						strPOIntiatedQuantity = request.getParameter("poIntiatedQuantity"+num);
						strPurchaseDepatRequstReceivedQuantity = request.getParameter("strRequestQuantity"+num);

						ProductDetails productDetails = new ProductDetails();
						productDetails.setStrSerialNumber(String.valueOf(sno));
						productDetails.setProductId(productId);
						productDetails.setProductName(productName);
						productDetails.setSub_ProductId(subProductId);
						productDetails.setSub_ProductName(subProductName);
						productDetails.setChild_ProductId(childProductId);
						productDetails.setChild_ProductName(childProductName);
						productDetails.setMeasurementId(setMeasurementId);
						productDetails.setMeasurementName(setMeasurementName);
						productDetails.setIndentCreationDetailsId(indentCreationDetailsId);
						productDetails.setQuantity(strQuantity);
						productDetails.setPoIntiatedQuantity(strPOIntiatedQuantity);
						productDetails.setPurchasedeptRequestReceiveQuantity(strPurchaseDepatRequstReceivedQuantity);
						//productDetails.set

						listProductDetails.add(productDetails);
					}
				}
			}//else
			listGetInvoiceDetailsList = objPurchaseDepartmentIndentProcessDao.getProductDetailsLists(indentNo,vendorName,listProductDetails,request);

			//System.out.println("the list of details"+listGetInvoiceDetailsList);		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listGetInvoiceDetailsList;
	}	

	@Override
	public String closeIndent(Model model, HttpServletRequest request, int site_id, String user_id,String siteId/*created site Id*/) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDIn_cloInd, ");
		String response = "";
		int result1=0;
		int sno=0;
		int result3=0;
		String indentCreationDetailsId ="";
		String responseMessage = "";
		try {
			String indentNumber= request.getParameter("indentNumber");
			String siteWiseIndentNo=request.getParameter("siteWiseIndentNo");
			String typeOfPurchase = request.getParameter("typeOfPurchase");
			if(typeOfPurchase.equalsIgnoreCase("others")){

				typeOfPurchase=request.getParameter("typeOfPurchaseOthers");
			}
			//String type=request.getParameter("typeOfPurchaseOthers");
			int noOfRows=Integer.parseInt(request.getParameter("numberOfRows"));

			for(int num=1;num<=noOfRows;num++){
				if(request.getParameter("checkboxname"+num)!=null)
				{
					sno++;
					//indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
					//objPurchaseDepartmentIndentProcessDao.productWiseInactiveInPurchaseTable(indentCreationDetailsId);

				}
			}

			// if all products are closed
			if(sno==noOfRows){

				result1 = objPurchaseDepartmentIndentProcessDao.doInactiveInIndentCreation(indentNumber);
				int indentCreationApprovalSeqNum = objPurchaseDepartmentIndentProcessDao.getIndentCreationApprovalSequenceNumber();
				IndentCreationDto indentCreationDto = new IndentCreationDto();
				indentCreationDto.setSiteId(site_id);
				indentCreationDto.setUserId(user_id);
				indentCreationDto.setPurpose(typeOfPurchase);
				int result2 = objPurchaseDepartmentIndentProcessDao.insertIndentCreationApprovalDtls(indentCreationApprovalSeqNum, indentNumber, indentCreationDto);
				for(int i=1;i<=sno;i++){

					indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+i);
					result3 =objPurchaseDepartmentIndentProcessDao.doInactiveInPurchaseTable(indentCreationDetailsId,typeOfPurchase);

				}


				//result3 = objPurchaseDepartmentIndentProcessDao.doInactiveInPurchaseTable(indentNumber,typeOfPurchase);
				responseMessage = "indent "+siteWiseIndentNo+" closed successfully.";
			}else{// if few products are closed (not all)
				for(int num=1;num<=noOfRows;num++){
					if(request.getParameter("checkboxname"+num)!=null)
					{

						indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
						result3=objPurchaseDepartmentIndentProcessDao.productWiseInactiveInPurchaseTable(indentCreationDetailsId,typeOfPurchase);

					}
				}
				responseMessage ="successfully "+sno +" Products  closed in indent number "+siteWiseIndentNo+" ";
			}

			//	System.out.println("Query results: "+result1+","+result2+","+result3);
			if(result1>0 || result3>0){
				response = "Success";
				System.out.println(indentNumber+" Indent Closed");
				transactionManager.commit(status);
				WriteTrHistory.write("Tr_Completed");
				return responseMessage;
			}
			else{
				responseMessage = "Soory, indent doesnt closed please try again after some time";
				transactionManager.rollback(status);
				WriteTrHistory.write("Tr_Completed");
				return responseMessage;
			}
		} catch (Exception e) {
			response = "Failure";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			e.printStackTrace();
			return responseMessage;
		}	

	}	


	@Override
	public String getSiteIdByPONumber(String poNumber) {
		int siteId = objPurchaseDepartmentIndentProcessDao.getSiteIdByPONumber(poNumber);
		return String.valueOf(siteId);
	}	

	public List<IndentCreationBean> ViewTempPo(String fromDate, String toDate,String tempPoNumber){
		List<IndentCreationBean> list = null;
		try{
			list = objPurchaseDepartmentIndentProcessDao.ViewTempPo( fromDate,  toDate,tempPoNumber);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}


	@Override
	public List<ProductDetails> combinedDetailsChildProductWise(List<ProductDetails> indentDetails) {
		//
		List<ProductDetails> requiredIndentDetails = new ArrayList<ProductDetails>();
		int strSerialNumber = 0;
		ProductDetails objProductDetails = null;

		Iterator itr = indentDetails.iterator();

		while (itr.hasNext()) {
			objProductDetails = (ProductDetails) itr.next();

			String childProductinIndentDetails = objProductDetails.getChild_ProductId() == null ? ""	: objProductDetails.getChild_ProductId().toString();
			int pendingQuantityinIndentDetails = Integer.parseInt(objProductDetails.getPendingQuantity() == null ? "" : objProductDetails.getPendingQuantity().toString());
			String indentCreationDetailsIdinIndentDetails = objProductDetails.getIndentCreationDetailsId() == null ? "" : objProductDetails.getIndentCreationDetailsId().toString();

			boolean isAlreadyThere = false;
			for(ProductDetails one_in_requiredIndentDetails : requiredIndentDetails)
			{	String childproductId = one_in_requiredIndentDetails.getChild_ProductId();
			if(childproductId.equals(childProductinIndentDetails))
			{	
				isAlreadyThere = true;
				int pendingQuantity = Integer.parseInt(one_in_requiredIndentDetails.getPendingQuantity());
				one_in_requiredIndentDetails.setPendingQuantity(String.valueOf((pendingQuantity+pendingQuantityinIndentDetails)));
				String productBatchData = one_in_requiredIndentDetails.getProductBatchData();
				if(productBatchData!=null&&!productBatchData.equals(""))
				{
					one_in_requiredIndentDetails.setProductBatchData(productBatchData+"@@"+indentCreationDetailsIdinIndentDetails+"="+String.valueOf((pendingQuantityinIndentDetails)));
				}
				else
				{
					one_in_requiredIndentDetails.setProductBatchData(indentCreationDetailsIdinIndentDetails+"="+String.valueOf((pendingQuantityinIndentDetails)));
				}
			}
			}
			if(!isAlreadyThere)
			{
				ProductDetails pd = objProductDetails; 
				strSerialNumber++;
				pd.setStrSerialNumber(String.valueOf(strSerialNumber));
				pd.setPendingQuantity(String.valueOf(pendingQuantityinIndentDetails));
				pd.setProductBatchData(indentCreationDetailsIdinIndentDetails+"="+String.valueOf(pendingQuantityinIndentDetails));
				requiredIndentDetails.add(pd);
			}
		}

		//
		return requiredIndentDetails;
	}


	@Override
	public List<Map<String, Object>> getListOfActivePOs() {

		return objPurchaseDepartmentIndentProcessDao.getListOfActivePOs();
	}
/***********************************************************Update Po******************************************/
	@SuppressWarnings("unused")
	@Override
	public String editAndSaveUpdatePO(Model model, HttpServletRequest request,HttpSession session) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDIn_ed&SPO, ");
		String response = "";
		String productRow="";
		String transportRow="";
		String productAndTransport="";
		boolean isAnyUpdateFailed = false;
		String ccEmailId="";
		String subject="";
		String strTotalAmount="";
		try{
			int noofRows = Integer.parseInt(request.getParameter("numberOfRows"));
			String poNumber = request.getParameter("poNo");
			//System.out.println("updating poNumber: "+poNumber);
			String toSite = request.getParameter("toSite");
			String indentNumber = request.getParameter("indentNumber"); 
			String vendorId=request.getParameter("vendorId");
			String strVendorId=request.getParameter("strVendorId");
			String indentCreationDetailsId ="";
			String indentCreation="";
			String	strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();	
			String sessionSiteId=session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			
			WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , PONumber:"+poNumber);
			if(!vendorId.equals(strVendorId) || !ccEmailId.equals("") || !subject.equals("")){

				objPurchaseDepartmentIndentProcessDao.updateTempPOVendorDetails(vendorId,poNumber,ccEmailId,subject,"true");

			}
			int poEntrySeqNumber = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNoByPONumber(poNumber,toSite);
			//updating Product Details
			//	System.out.println("---Product Details---");
			for(int num=1;num<=noofRows;num++){
				String actionValue = request.getParameter("actionValue"+num);

				if(actionValue==null&&request.getParameter("ChildProduct"+num)==null)
				{
					//System.out.println(num+" row newly added & deleted at front end.");
					continue;
				}else{}


				String product = request.getParameter("Product"+num);
				String prodsInfo[] = product.split("\\$");	
				String productId = prodsInfo[0];
				String productName = prodsInfo[1];

				String subProduct = request.getParameter("SubProduct"+num);
				String subProdsInfo[] = subProduct.split("\\$");					
				String subProductId = subProdsInfo[0];
				String subProductName = subProdsInfo[1];				

				String childProduct = request.getParameter("ChildProduct"+num);
				String childProdsInfo[] = childProduct.split("\\$");					
				String childProductId = childProdsInfo[0];
				String childProductName = childProdsInfo[1];

				String mesurement = request.getParameter("UnitsOfMeasurement"+num);
				String measureInfo[] = mesurement.split("\\$");					
				String setMeasurementId = measureInfo[0];
				String setMeasurementName = measureInfo[1];

				String quantity = request.getParameter("quantity"+num);
				String strQuantity=request.getParameter("strQuantity"+num);
				String price = request.getParameter("PriceId"+num);
				String basicAmount = request.getParameter("BasicAmountId"+num);

				String Discount=request.getParameter("Discount"+num);
				String amountAfterDiscount=request.getParameter("amtAfterDiscount"+num);

				String tax = request.getParameter("tax"+num);
				String taxId = tax;
				if(tax.contains ("$")){
					String parts[] = tax.split("\\$");
					taxId=  parts[0];
				}
				String taxAmount = request.getParameter("taxAmount"+num);
				String amountAfterTax = request.getParameter("amountAfterTax"+num);

				String hsnCode = request.getParameter("hsnCode"+num);
				
				String vendorProductDesc=request.getParameter("childProductVendorDesc"+num);
				if(vendorProductDesc.equals("")){
					vendorProductDesc="-";

				}

				String otherOrTransportCharges = request.getParameter("otherOrTransportCharges"+num)==null ? "0.0" : request.getParameter("otherOrTransportCharges"+num);
				String taxOnOtherOrTransportCharges = request.getParameter("taxOnOtherOrTransportCharges"+num)==null ? "0.0" : request.getParameter("taxOnOtherOrTransportCharges"+num);
				String otherOrTransportChargesAfterTax = request.getParameter("otherOrTransportChargesAfterTax"+num)==null ? "0.0" : request.getParameter("otherOrTransportChargesAfterTax"+num);


				String totalAmount = request.getParameter("totalAmount"+num);
				strTotalAmount= request.getParameter("strTotalAmount"+num);
				
				String newProductCreated=request.getParameter("isNewOrOld"+num);
				if(newProductCreated.equalsIgnoreCase("new")){

					int indentCreationDetailsSeqNum = icd.getIndentCreationDetailsSequenceNumber();
					indentCreationDetailsId=String.valueOf(indentCreationDetailsSeqNum);
					indentCreation="true";

				}else{
					indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
				}

				//String indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
				String poEntryDetailsId = request.getParameter("poEntryDetailsId"+num);

				ProductDetails productDetails = new ProductDetails();
				productDetails.setProductId(productId);
				productDetails.setSub_ProductId(subProductId);
				productDetails.setChild_ProductId(childProductId);
				productDetails.setMeasurementId(setMeasurementId);
				productDetails.setQuantity(quantity);
				productDetails.setPricePerUnit(price);
				productDetails.setBasicAmt(basicAmount);
				productDetails.setStrDiscount(Discount);
				productDetails.setStrAmtAfterDiscount(amountAfterDiscount);
				productDetails.setTax(taxId);
				productDetails.setTaxAmount(taxAmount);
				productDetails.setAmountAfterTax(amountAfterTax);
				productDetails.setHsnCode(hsnCode);
				productDetails.setOtherOrTransportCharges1(Double.parseDouble(otherOrTransportCharges));
				productDetails.setTaxOnOtherOrTransportCharges1(Double.parseDouble(taxOnOtherOrTransportCharges));
				productDetails.setOtherOrTransportChargesAfterTax1(Double.parseDouble(otherOrTransportChargesAfterTax));

				productDetails.setTotalAmount(totalAmount);
				productDetails.setIndentCreationDetailsId(indentCreationDetailsId);
				productDetails.setPoEntryDetailsId(poEntryDetailsId);
				productDetails.setChildProductCustDisc(vendorProductDesc);
				
				if(actionValue==null&&request.getParameter("ChildProduct"+num)!=null)
				{
					int result1 = objPurchaseDepartmentIndentProcessDao.insertPOEntryDetails(productDetails,poEntrySeqNumber);
					//System.out.println(num+" row newly added. so inserted into PO_ENTRY_DETAILS: "+result1);
					if(indentCreation.equalsIgnoreCase("true")){
						int purchaseIndentProcessId = cntlIndentrocss.getPurchaseIndentProcessSequenceNumber();
						objPurchaseDepartmentIndentProcessDao.insertIndentCreationtbl(productDetails,indentNumber);
						objPurchaseDepartmentIndentProcessDao.insertPurchaseDepttbl(purchaseIndentProcessId,sessionSiteId,strUserId,productDetails);
					}
					if(result1==0){
						
						isAnyUpdateFailed = true;break;}
					continue;
				}else{}
				/*  S-Same ,  E-Edit ,  R-Remove  */
				if(actionValue.equals("S"))
				{	
					if(!strTotalAmount.equals(totalAmount)){
					int update = objPurchaseDepartmentIndentProcessDao.updatePOEntryDetails(productDetails);
					}
					//System.out.println(num+" row does not changed. so Remains same.");
					continue;
				}else{}
				if(actionValue.equals("E"))
				{
					int result2 = objPurchaseDepartmentIndentProcessDao.updatePOEntryDetails(productDetails);
					int result5=objPurchaseDepartmentIndentProcessDao.updateTempPOQuantityDetails(indentCreationDetailsId,quantity,strQuantity);
					//System.out.println(num+" row Edited. so it is updated in PO_ENTRY_DETALS: "+result2);
					if(result2==0){isAnyUpdateFailed = true;break;}
					continue;
				}else{}
				if(actionValue.equals("R"))
				{
					int result3 = objPurchaseDepartmentIndentProcessDao.deletePOEntryDetails(poEntryDetailsId);
					//	System.out.print(num+" row removed. so it is deleted from PO_ENTRY_DETAILS: "+result3);
					int result4 = objPurchaseDepartmentIndentProcessDao.updatePOIntiatedQuantityInPDTable(indentCreationDetailsId,quantity);
					//	System.out.println("  & updated po_intiated_quantity in SUM_PURCHASE_DEPT_INDENT_PROSS: "+result4);
					if(result3==0||result4==0){isAnyUpdateFailed = true;break;}
					continue;
				}else{}
			}
			//updating Transport Charges
			//System.out.println("---Transport Details---");
			int noofTransRows = Integer.parseInt(request.getParameter("noofTransRows"));
			if(isAnyUpdateFailed==false){
				for(int num=1;num<=noofTransRows;num++){
					String transactionActionValue = request.getParameter("transactionActionValue"+num);
					if(transactionActionValue==null&&request.getParameter("Conveyance"+num)==null)
					{
						//System.out.println(num+" row newly added & deleted at front end.");
						continue;
					}else{}
					String Conveyance = request.getParameter("Conveyance"+num);
					String ConveyanceId = Conveyance.split("\\$")[0];
					String ConveyanceAmount = request.getParameter("ConveyanceAmount"+num);
					String GSTTaxId = request.getParameter("GSTTax"+num).split("\\$")[0];
					String GSTAmount = request.getParameter("GSTAmount"+num);
					String AmountAfterTax = request.getParameter("AmountAfterTax"+num);

					TransportChargesDto transportChargesDto = new TransportChargesDto();
					transportChargesDto.setTransportId(ConveyanceId);
					transportChargesDto.setTransportAmount(ConveyanceAmount);
					transportChargesDto.setTransportGSTPercentage(GSTTaxId);
					transportChargesDto.setTransportGSTAmount(GSTAmount);
					transportChargesDto.setTotalAmountAfterGSTTax(AmountAfterTax);
					if(transactionActionValue==null&&Conveyance!=null)
					{	
						ProductDetails productDetails = new ProductDetails();
						productDetails.setSite_Id(toSite);
						productDetails.setPoEntryId(poEntrySeqNumber);
						productDetails.setIndentNo(indentNumber);
						int poTransChrgsSeqNo = objPurchaseDepartmentIndentProcessDao.getPoTransChrgsEntrySeqNo();
						int result5 = objPurchaseDepartmentIndentProcessDao.insertPOTransportDetails(poTransChrgsSeqNo,productDetails,transportChargesDto);
						System.out.println(num+" row newly added. so inserted in SUMADHURA_PO_TRNS_O_CHRGS_DTLS: "+result5);
						if(result5==0){isAnyUpdateFailed = true;break;}
						continue;
					}else{}
					/*  S-Same ,  E-Edit ,  R-Remove  */
					if(transactionActionValue.equals("S"))
					{
						//System.out.println(num+" row does not changed. so Remains same.");
						continue;
					}else{}
					if(transactionActionValue.equals("E"))
					{
						int poTransChrgsDtlsSeqNo = Integer.parseInt(request.getParameter("poTransChrgsDtlsSeqNo"+num));
						int result6 = objPurchaseDepartmentIndentProcessDao.updatePOTransportChargesDetails(transportChargesDto,poTransChrgsDtlsSeqNo);
						//System.out.println(num+" row edited. so updated in SUMADHURA_PO_TRNS_O_CHRGS_DTLS: "+result6);
						if(result6==0){isAnyUpdateFailed = true;break;}
						continue;
					}else{}
					if(transactionActionValue.equals("R"))
					{
						int poTransChrgsDtlsSeqNo = Integer.parseInt(request.getParameter("poTransChrgsDtlsSeqNo"+num));
						int result7 = objPurchaseDepartmentIndentProcessDao.deletePOTransportChargesDetails(poTransChrgsDtlsSeqNo);
						//System.out.println(num+" row removed. so it is deleted from SUMADHURA_PO_TRNS_O_CHRGS_DTLS: "+result7);
						if(result7==0){isAnyUpdateFailed = true;break;}
						continue;
					}else{}
				}// end of FOR loop
			}// end of IF block
			int j=objPurchaseDepartmentIndentProcessDao.deleteTemppoTermsAdnConditions(String.valueOf(poEntrySeqNumber),"true");//delete old terms and conditions
			int acceptTermsAndConditionTotal = Integer.parseInt(request.getParameter("countOftermsandCondsfeilds"));
			List<String> listOfTermsAndConditions = new ArrayList<String>();
			String termsAndCondition = "";
			int value=0;
			for(int i=1;i<=acceptTermsAndConditionTotal;i++){
				termsAndCondition =  request.getParameter("termsAndCond"+i);

				if(termsAndCondition!=null && !termsAndCondition.equals("")){

					value=objPurchaseDepartmentIndentProcessDao.saveTermsconditions(termsAndCondition,poEntrySeqNumber,vendorId,indentNumber);

					listOfTermsAndConditions.add(String.valueOf(termsAndCondition));
				}
				
				else{continue;}
			}
			

			response="Success";
		}
		catch(Exception e)
		{
			response="Failure";
			e.printStackTrace();
		}
		if(response.equals("Success")&&isAnyUpdateFailed==false)
		{
			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			//System.out.println("Data Committed");
		}
		else
		{
			response="Failure";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			//System.out.println("Data Rollbacked");
		}
		return response;
	}

	@Override
	public List<ProductDetails> getProductDetailsListsForQuatation(String indentNo, String vendorName,HttpServletRequest request) {
		List<ProductDetails> listGetInvoiceDetailsList = null;
		List<ProductDetails> listProductDetails  =  new ArrayList<ProductDetails>();
		//	List<ProductDetails> getPoDetails = new ArrayList<ProductDetails>();
		Map<String,String> objviewPOPageDataMap = new HashMap<String,String>();
		ProductDetails objGetDetails=null;
		int sno=0;
		String strTableTwoDate="";
		String productId =""; 
		String subProductId ="";
		String childProductId ="";
		String setMeasurementId ="";
		String productName ="";		
		String subProductName ="";		
		String setMeasurementName ="";	
		String strChildProductName="";

		String requiredQuantity="";
		String price="";
		String basicAmount="";
		String discount="";
		String amountAfterDiscount="";
		String tax="";
		String taxAmount="";
		String amountAfterTax="";
		String otherCharges="";
		String otherChargesAfterTax="";
		String totalAmount="";
		String hsnCode="";
		String taxOnOtherTransportCharges="";
		//	String finalAmount="";
		String strIndentCreationDetailsId="";
		String ChildProductDescription="";
		int strno=0;
		double totalAmt=0.0;
		double totChargesVal=0.0;
		int val = 0;
		double roundoff = 0;
		double grandtotal = 0;
		double doubletaxAmt=0.0;
		double doubleAmountAfterTax=0.0;
		double doubleTotalAmt=0.0;
		double doubleBasicAmt=0.0;
		double doubleAmtAfterDiscount=0.0;

		int noofrows = 0;
		try {
			noofrows = Integer.parseInt(request.getParameter("numberOfRows"));

			for(int num=1;num<=noofrows;num++){
				if(request.getParameter("checkboxname"+num)!=null)
				{
					sno++;
					productId = request.getParameter("productId"+num);
					subProductId = request.getParameter("subProductId"+num);
					childProductId = request.getParameter("childProductId"+num);
					productName = request.getParameter("product"+num);
					subProductName = request.getParameter("subProduct"+num);
					String childProductName = request.getParameter("childProduct"+num);
					setMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
					setMeasurementName = request.getParameter("unitsOfMeasurement"+num);
					String indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
					String strQuantity = request.getParameter("strRequestQuantity"+num);

					ProductDetails productDetails = new ProductDetails();
					productDetails.setStrSerialNumber(String.valueOf(sno));
					productDetails.setProductId(productId);
					productDetails.setProductName(productName);
					productDetails.setSub_ProductId(subProductId);
					productDetails.setSub_ProductName(subProductName);
					productDetails.setChild_ProductId(childProductId);
					productDetails.setChild_ProductName(childProductName);
					productDetails.setMeasurementId(setMeasurementId);
					productDetails.setMeasurementName(setMeasurementName);
					productDetails.setIndentCreationDetailsId(indentCreationDetailsId);
					productDetails.setQuantity(strQuantity);

					listProductDetails.add(productDetails);
				}
			}


			listGetInvoiceDetailsList = objPurchaseDepartmentIndentProcessDao.getProductDetailsLists(indentNo,vendorName,listProductDetails,request);

			for(int i =0 ; i < listGetInvoiceDetailsList.size() ; i++){

				objGetDetails = listGetInvoiceDetailsList.get(i);


				productName=objGetDetails.getProductName();

				subProductName=objGetDetails.getSub_ProductName();

				strChildProductName=objGetDetails.getChild_ProductName();

				setMeasurementName=objGetDetails.getMeasurementName();
				requiredQuantity=objGetDetails.getRequiredQuantity();
				price=objGetDetails.getPrice();
				basicAmount=objGetDetails.getBasicAmt();
				discount=objGetDetails.getStrDiscount();
				amountAfterDiscount=objGetDetails.getStrAmtAfterDiscount();
				tax=objGetDetails.getTax();
				taxAmount=objGetDetails.getTaxAmount();
				amountAfterTax=objGetDetails.getAmountAfterTax();
				otherChargesAfterTax=objGetDetails.getOtherchargesaftertax1();

				//totalAmount=objGetDetails.getTotalAmount();
				totalAmount=objGetDetails.getAmountAfterTax();
				hsnCode=objGetDetails.getHsnCode();

				strno=objGetDetails.getSerialno();

				double totalvalue=Double.valueOf(totalAmount);
				double strOtherChargesAfterTax=Double.valueOf(otherChargesAfterTax);
				totChargesVal=totChargesVal+strOtherChargesAfterTax;
				doubleBasicAmt=Double.valueOf(basicAmount);
				doubletaxAmt=Double.valueOf(taxAmount);
				doubleAmountAfterTax=Double.valueOf(amountAfterTax);
				doubleTotalAmt=Double.valueOf(totalAmount);
				doubleAmtAfterDiscount=Double.valueOf(amountAfterDiscount);

				doubleBasicAmt=Double.parseDouble(new DecimalFormat("##.##").format(doubleBasicAmt));

				doubletaxAmt=Double.parseDouble(new DecimalFormat("##.##").format(doubletaxAmt));
				doubleAmountAfterTax=Double.parseDouble(new DecimalFormat("##.##").format(doubleAmountAfterTax));
				doubleTotalAmt=Double.parseDouble(new DecimalFormat("##.##").format(doubleTotalAmt));
				doubleAmtAfterDiscount=Double.parseDouble(new DecimalFormat("##.##").format(doubleAmtAfterDiscount));




				totalAmt=totalAmt+totalvalue;

				if(i == listGetInvoiceDetailsList.size()-1){
					totalAmt = totalAmt+totChargesVal;
					totalAmt = Double.parseDouble(new DecimalFormat("##.##").format(totalAmt));
					val = (int) Math.ceil(totalAmt);
					roundoff=Math.ceil(totalAmt)-totalAmt;
					roundoff = Double.parseDouble(new DecimalFormat("##.##").format(roundoff));
					grandtotal=Math.ceil(totalAmt);


				}
				strTableTwoDate+=strno+"@@"+productName+"@@"+subProductName+"@@"+strChildProductName+"@@"+setMeasurementName
				+"@@"+hsnCode+"@@"+requiredQuantity+"@@"+price+"@@"+doubleBasicAmt+"@@"+discount+"@@"+doubleAmtAfterDiscount
				+"@@"+tax+"@@"+doubletaxAmt+"@@"+doubleAmountAfterTax+"@@"+new NumberToWord().convertNumberToWords(val)+" Rupees Only."+"@@"+doubleAmountAfterTax+"@@"+roundoff+"@@"+grandtotal+"@@"+totChargesVal+"@@"+totalAmt+"&&";

			}

			objviewPOPageDataMap.put("productDetails", strTableTwoDate);

			request.setAttribute("viewPoPageData", objviewPOPageDataMap);

			//System.out.println("the list of details"+listGetInvoiceDetailsList.size());		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listGetInvoiceDetailsList;
	}


	@Override
	public int getSiteWiseIndentNo(int indentNumber) {
		return objPurchaseDepartmentIndentProcessDao.getSiteWiseIndentNo(indentNumber);
	}

	public void printIndentForPurchase(Model model, HttpServletRequest request, int site_id, String user_id) {

		int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
		int siteWiseIndentNo= Integer.parseInt(request.getParameter("siteWiseIndentNo"));
		String strCreateDate="";

		//System.out.println(indentNumber);
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		String siteId=request.getParameter("siteId");
		
		 String versionNo=request.getParameter("versionNo");
		 String reference_No=request.getParameter("reference_No");
		 String issue_date=request.getParameter("issue_date");
		
		list=objPurchaseDepartmentIndentProcessDao.purchasePrintIndent(indentNumber);



		request.setAttribute("IndentDetails",list);
		System.out.println(list.get(0).getChildProduct1());
		IndentCreationBean icb = new IndentCreationBean();
		icb = cntlIndentrocss.getCreateAndRequiredDates(indentNumber);
		//indentCreationBean.setStrRequiredDate(icb.getStrRequiredDate());
		strCreateDate = icb.getStrCreateDate();
		List<IndentCreationBean> list1 = new ArrayList<IndentCreationBean>();
		IndentCreationBean icb1 = new IndentCreationBean();
		icb1.setIndentNumber(indentNumber);
		icb1.setSiteWiseIndentNo(siteWiseIndentNo);
		icb1.setStrCreateDate(strCreateDate);
		icb1.setVersionNo(versionNo);
		icb1.setReference_No(reference_No);
		icb1.setIssue_date(issue_date);
		
		list1.add(icb1);
		request.setAttribute("IndentDtls",list1);
		model.addAttribute("createdSiteName",cntlIndentrocss.getSiteNameWhereIndentCreated(indentNumber));
		model.addAttribute("siteAddress",cntlIndentrocss.getAddressOfSite(site_id));
		model.addAttribute("listCreatedName",objPurchaseDepartmentIndentProcessDao.getApproveCreateEmp(indentNumber,request));
		//	 model.addAttribute("createEmpName",createEmpName);
		objPurchaseDepartmentIndentProcessDao.getVerifiedEmpNames(indentNumber,request,siteId);


	}


	@Override
	public String CancelPo(HttpSession session,HttpServletRequest request,String temp_Po_Number,String user_id,String site_id) {

		String pendingEmpId="";
		String response="";
		int result=0;

		String remarks=request.getParameter("Remakrs_cancel")==null ? " " : request.getParameter("Remakrs_cancel");
		pendingEmpId=objPurchaseDepartmentIndentProcessDao.getpendingEmpId(temp_Po_Number,user_id);


		if(pendingEmpId!=null || pendingEmpId.equals("")){

			result=objPurchaseDepartmentIndentProcessDao.updateEmpId(pendingEmpId,temp_Po_Number);
			objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls(temp_Po_Number,"0",user_id, site_id, "CAN",remarks);
			//	int i=objPurchaseDepartmentIndentProcessDao.deleteTemppoTermsAdnConditions(temp_Po_Number);
			response="success";
			//	}
		}

		return response;
	}

	@Override
	public List<ProductDetails> getListOfCancelPo(String userId) {
		return objPurchaseDepartmentIndentProcessDao.getListOfCancelPo(userId);
	}
	@Override
	public List<ProductDetails> getViewCancelPoDetails(String poNumber, String reqSiteId) {
		return objPurchaseDepartmentIndentProcessDao.getViewCancelPoDetails(poNumber, reqSiteId);
	}
	@Override
	public List<ProductDetails> getProductDetailsListsForCancelPo(String poNumber,String reqSiteId) {
		return objPurchaseDepartmentIndentProcessDao.getProductDetailsListsForCancelPo(poNumber,reqSiteId);
	}

	@Override
	public List<ProductDetails> getTransChrgsDtlsForCancelPo(String poNumber,String reqSiteId) {
		return objPurchaseDepartmentIndentProcessDao.getTransChrgsDtlsForCancelPo(poNumber,reqSiteId);
	}


	/*==================================update temp po save================================================*/

	@Override
	public String updateTempPoPage(Model model, HttpServletRequest request,HttpSession session) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDup_tempPo&SPO, ");
		String response = "";
		boolean isAnyUpdateFailed = false;
		String strQuantity="";
		String strProdEdit="";
		String otherOrTransportCharges ="";
		String taxOnOtherOrTransportCharges ="";
		String otherOrTransportChargesAfterTax ="";
		String totalAmount ="";
		String poEntryDetailsId ="";
		String strTotalAmount="";
		int val=0;
		String strStatus="A";
		double intPoIntiatedQuantity =0.0;
		double intRequestQuantity =0.0;
		try{
			int noofRows = Integer.parseInt(request.getParameter("numberOfRows"));
			String strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();	
			String sessionSiteId=session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

			String poNumber = request.getParameter("poNo");
			//System.out.println("updating poNumber: "+poNumber);
			String vendorId=request.getParameter("vendorId");
			String strVendorId=request.getParameter("strVendorId");
			String toSite = request.getParameter("toSite");
			String strSiteId=request.getParameter("siteId");
			String indentNumber = request.getParameter("indentNumber");
			String ccEmailId=request.getParameter("ccEmailId2");
			String subject=request.getParameter("subject")== null ? "-" : request.getParameter("subject").toString();
			WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , PONumber:"+poNumber);

			if(!vendorId.equals(strVendorId) || !ccEmailId.equals("") || !subject.equals("-")){

				objPurchaseDepartmentIndentProcessDao.updateTempPOVendorDetails(vendorId,poNumber,ccEmailId,subject,"false");

			}

			int poEntrySeqNumber = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNoByTempPONumber(poNumber,strSiteId);
			//updating Product Details
			//	System.out.println("---Product Details---");
			for(int num=1;num<=noofRows;num++){
				String actionValue = request.getParameter("actionValue"+num);

				if(actionValue==null&&request.getParameter("ChildProduct"+num)==null)
				{
					//System.out.println(num+" row newly added & deleted at front end.");
					continue;
				}else{}


				String product = request.getParameter("Product"+num);
				String prodsInfo[] = product.split("\\$");	
				String productId = prodsInfo[0];
				String productName = prodsInfo[1];

				String subProduct = request.getParameter("SubProduct"+num);
				String subProdsInfo[] = subProduct.split("\\$");					
				String subProductId = subProdsInfo[0];
				String subProductName = subProdsInfo[1];				

				String childProduct = request.getParameter("ChildProduct"+num);
				String childProdsInfo[] = childProduct.split("\\$");					
				String childProductId = childProdsInfo[0];
				String childProductName = childProdsInfo[1];

				String mesurement = request.getParameter("UnitsOfMeasurement"+num);
				String measureInfo[] = mesurement.split("\\$");					
				String setMeasurementId = measureInfo[0];
				String setMeasurementName = measureInfo[1];

				String quantity = request.getParameter("quantity"+num);
				strQuantity=request.getParameter("strQuantity"+num);
				String price = request.getParameter("PriceId"+num);
				String basicAmount = request.getParameter("BasicAmountId"+num);

				String Discount=request.getParameter("Discount"+num);
				String amountAfterDiscount=request.getParameter("amtAfterDiscount"+num);

				String tax = request.getParameter("tax"+num);
				String taxId = tax;
				if(tax.contains ("$")){
					String parts[] = tax.split("\\$");
					taxId=  parts[0];
				}
				String taxAmount = request.getParameter("taxAmount"+num);
				String amountAfterTax = request.getParameter("amountAfterTax"+num);

				String hsnCode = request.getParameter("hsnCode"+num);
				String vedorDescription = request.getParameter("vendorDescription"+num);

				 otherOrTransportCharges = request.getParameter("otherOrTransportCharges"+num)==null ? "0.0" : request.getParameter("otherOrTransportCharges"+num);
				 taxOnOtherOrTransportCharges = request.getParameter("taxOnOtherOrTransportCharges"+num)==null ? "0.0" : request.getParameter("taxOnOtherOrTransportCharges"+num);
				 otherOrTransportChargesAfterTax = request.getParameter("otherOrTransportChargesAfterTax"+num)==null ? "0.0" : request.getParameter("otherOrTransportChargesAfterTax"+num);


				 totalAmount = request.getParameter("totalAmount"+num);
				 strTotalAmount= request.getParameter("strTotalAmount"+num);
				String indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
				 poEntryDetailsId = request.getParameter("poEntryDetailsId"+num);

				ProductDetails productDetails = new ProductDetails();
				productDetails.setProductId(productId);
				productDetails.setSub_ProductId(subProductId);
				productDetails.setChild_ProductId(childProductId);
				productDetails.setChild_ProductName(childProductName);
				productDetails.setMeasurementId(setMeasurementId);
				productDetails.setQuantity(quantity);
				productDetails.setPricePerUnit(price);
				productDetails.setBasicAmt(basicAmount);
				productDetails.setStrDiscount(Discount);
				productDetails.setStrAmtAfterDiscount(amountAfterDiscount);
				productDetails.setTax(taxId);
				productDetails.setTaxAmount(taxAmount);
				productDetails.setAmountAfterTax(amountAfterTax);
				productDetails.setHsnCode(hsnCode);
				productDetails.setOtherOrTransportCharges1(Double.parseDouble(otherOrTransportCharges));
				productDetails.setTaxOnOtherOrTransportCharges1(Double.parseDouble(taxOnOtherOrTransportCharges));
				productDetails.setOtherOrTransportChargesAfterTax1(Double.parseDouble(otherOrTransportChargesAfterTax));

				productDetails.setTotalAmount(totalAmount);
				productDetails.setIndentCreationDetailsId(indentCreationDetailsId);
				productDetails.setPoEntryDetailsId(poEntryDetailsId);
				productDetails.setChildProductCustDisc(vedorDescription);
				
				
				if(actionValue==null&&request.getParameter("ChildProduct"+num)!=null)
				{
					int result1 = objPurchaseDepartmentIndentProcessDao.insertTempPOEntryDetails(productDetails,poEntrySeqNumber);
					if(indentCreationDetailsId!=null && !indentCreationDetailsId.equals("")){

						String value=objPurchaseDepartmentIndentProcessDao.getPoInitiateQuan(indentCreationDetailsId);
						//double intPoIntiatedQuantity = objPurchaseDepartmentIndentProcessDao.getIntiatedQuantityInPurchaseTable(indentCreationDetailsId);
						if(value.contains("|")){

							String data[]=value.split("\\|");
							intPoIntiatedQuantity =Double.valueOf(data[0]);
							intRequestQuantity =Double.valueOf(data[1]);

						}


						double	doubleQuantity = Double.valueOf(quantity ==null ? "0" : quantity.toString());

						if(intPoIntiatedQuantity+doubleQuantity >= intRequestQuantity){

							strStatus = "I";

						}   if(result1==1){
							int intIndentCreationDetailsId = Integer.parseInt(indentCreationDetailsId);
							objPurchaseDepartmentIndentProcessDao.updatePurchaseDeptIndentProcesstbl(doubleQuantity, intIndentCreationDetailsId,strStatus);
						}

						String approvalEmpId=objPurchaseDepartmentIndentProcessDao.getTemproryuser(strUserId);
						int intstrIndentNo = Integer.parseInt(indentNumber);
						objPurchaseDepartmentIndentProcessDao.getupdatePurchaseDeptIndentProcess(intstrIndentNo, strUserId,strSiteId,approvalEmpId,sessionSiteId) ;



					}
					//System.out.println(num+" row newly added. so inserted into PO_ENTRY_DETAILS: "+result1);
					if(result1==0){isAnyUpdateFailed = true;break;}
					continue;
				}else{}
				/*  S-Same ,  E-Edit ,  R-Remove  */
				if(actionValue.equals("S"))
				{	
					if(!strTotalAmount.equals(totalAmount)){

						int result2 = objPurchaseDepartmentIndentProcessDao.updateTempPOEntryDetails(productDetails);	
					}
					//System.out.println(num+" row does not changed. so Remains same.");
					continue;
				}else{}
				if(actionValue.equals("E"))
				{

					strProdEdit="true";
					int result2 = objPurchaseDepartmentIndentProcessDao.updateTempPOEntryDetails(productDetails);
					int result5=objPurchaseDepartmentIndentProcessDao.updateTempPOQuantityDetails(indentCreationDetailsId,quantity,strQuantity);
					//System.out.println(num+" row Edited. so it is updated in PO_ENTRY_DETALS: "+result2);
					if(result2==0){isAnyUpdateFailed = true;break;}
					continue;
				}else{}
				if(actionValue.equals("R"))
				{
					int result3 = objPurchaseDepartmentIndentProcessDao.deleteTempPOEntryDetails(poEntryDetailsId);
					//	System.out.print(num+" row removed. so it is deleted from PO_ENTRY_DETAILS: "+result3);
					int result4 = objPurchaseDepartmentIndentProcessDao.updatePOIntiatedQuantityInPDTable(indentCreationDetailsId,quantity);
					//	System.out.println("  & updated po_intiated_quantity in SUM_PURCHASE_DEPT_INDENT_PROSS: "+result4);
					if(result3==0||result4==0){isAnyUpdateFailed = true;break;}
					continue;
				}else{}
			}
			//updating Transport Charges
			//System.out.println("---Transport Details---");
			int noofTransRows = Integer.parseInt(request.getParameter("noofTransRows"));
			if(isAnyUpdateFailed==false){
				for(int num=1;num<=noofTransRows;num++){
					String transactionActionValue = request.getParameter("transactionActionValue"+num);
					if(transactionActionValue==null&&request.getParameter("Conveyance"+num)==null)
					{
						//System.out.println(num+" row newly added & deleted at front end.");
						continue;
					}else{}
					String Conveyance = request.getParameter("Conveyance"+num);
					String ConveyanceId = Conveyance.split("\\$")[0];
					String ConveyanceAmount = request.getParameter("ConveyanceAmount"+num);
					String GSTTaxId = request.getParameter("GSTTax"+num).split("\\$")[0];
					String GSTAmount = request.getParameter("GSTAmount"+num);
					String AmountAfterTax = request.getParameter("AmountAfterTax"+num);

					TransportChargesDto transportChargesDto = new TransportChargesDto();
					transportChargesDto.setTransportId(ConveyanceId);
					transportChargesDto.setTransportAmount(ConveyanceAmount);
					transportChargesDto.setTransportGSTPercentage(GSTTaxId);
					transportChargesDto.setTransportGSTAmount(GSTAmount);
					transportChargesDto.setTotalAmountAfterGSTTax(AmountAfterTax);
					if(transactionActionValue==null&&Conveyance!=null)
					{	
						ProductDetails productDetails = new ProductDetails();
						productDetails.setSite_Id(toSite);
						productDetails.setPoEntrySeqNumber(poEntrySeqNumber);
						productDetails.setIndentNo(indentNumber);
						int poTransChrgsSeqNo = objPurchaseDepartmentIndentProcessDao.getPoTransChrgsEntrySeqNo();

						int result5 = objPurchaseDepartmentIndentProcessDao.insertTempPOTransportDetails(poTransChrgsSeqNo,productDetails,transportChargesDto,poNumber);
						System.out.println(num+" row newly added. so inserted in SUMADHURA_PO_TRNS_O_CHRGS_DTLS: "+result5);
						if( result5==0){isAnyUpdateFailed = true;break;}
						continue;
					}else{}
					/*  S-Same ,  E-Edit ,  R-Remove  */
					if(transactionActionValue.equals("S"))
					{
						//System.out.println(num+" row does not changed. so Remains same.");
						continue;
					}else{}
					if(transactionActionValue.equals("E"))
					{
						int poTransChrgsDtlsSeqNo = Integer.parseInt(request.getParameter("poTransChrgsDtlsSeqNo"+num));


						int result6 = objPurchaseDepartmentIndentProcessDao.updateTempPOTransportChargesDetails(transportChargesDto,poTransChrgsDtlsSeqNo);
						//System.out.println(num+" row edited. so updated in SUMADHURA_PO_TRNS_O_CHRGS_DTLS: "+result6);
						if( result6==0){isAnyUpdateFailed = true;break;}
						continue;
					}else{}
					if(transactionActionValue.equals("R"))
					{
						int poTransChrgsDtlsSeqNo = Integer.parseInt(request.getParameter("poTransChrgsDtlsSeqNo"+num));


						int result7 = objPurchaseDepartmentIndentProcessDao.deleteTempPOTransportChargesDetails(poTransChrgsDtlsSeqNo);
						//System.out.println(num+" row removed. so it is deleted from SUMADHURA_PO_TRNS_O_CHRGS_DTLS: "+result7);
						if(result7==0){isAnyUpdateFailed = true;break;}
						continue;
					}else{}
				}// end of FOR loop
			}// end of IF block

			int j=objPurchaseDepartmentIndentProcessDao.deleteTemppoTermsAdnConditions(poNumber,"false");
			int acceptTermsAndConditionTotal = Integer.parseInt(request.getParameter("countOftermsandCondsfeilds"));

			String termsAndCondition = "";
			int value=0;
			for(int i=1;i<=acceptTermsAndConditionTotal;i++){
				termsAndCondition =  request.getParameter("termsAndCond"+i);

				if(termsAndCondition!=null && !termsAndCondition.equals("")){

					value=objPurchaseDepartmentIndentProcessDao.saveTempTermsconditions(termsAndCondition,poNumber,vendorId,indentNumber);

				}else{continue;}
			}
			if(value>0){

				objPurchaseDepartmentIndentProcessDao.updateTempPoVieworCancel(poNumber,strSiteId);	
				//objPurchaseDepartmentIndentProcessDao.insertTempPOorPOCreateApproverDtls(poNumber,"0",strUserId, sessionSiteId, "E"," ");

			}

			response="Success";
		}
		/*if(response.equalsIgnoreCase("success")){



		}
		 */
		catch(Exception e)
		{
			response="Failure";
			e.printStackTrace();
		}
		if(response.equals("Success")&&isAnyUpdateFailed==false)
		{
			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			//System.out.println("Data Committed");
		}
		else
		{
			response="Failure";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			//System.out.println("Data Rollbacked");
		}
		return response;
	}

	@Override
	public String tempPoSubProducts(String prodId,String indentNumber,String reqSiteId) {
		return objPurchaseDepartmentIndentProcessDao.tempPoSubProducts(prodId,indentNumber,reqSiteId);
	}

	@Override
	public String tempPoChildProducts(String subProdId,String indentNumber,String reqSiteId) {
		return objPurchaseDepartmentIndentProcessDao.tempPoChildProducts(subProdId,indentNumber,reqSiteId);
	}

	@Override
	public List<String> getTempTermsAndConditions(String poNumber,String isRevised,String reqSiteId) {


		return objPurchaseDepartmentIndentProcessDao.getTempTermsAndConditions(poNumber,isRevised,reqSiteId);
	}


	/*************************************************get comments for Po****************************************/
	@Override
	public String  getCancelPoComments(String poNumber) {

		List<String> list = null;
		String strPurpose = "";
		try{
			strPurpose = objPurchaseDepartmentIndentProcessDao.getCancelPoComments(poNumber);
		}catch(Exception e){
			e.printStackTrace();
		}
		return strPurpose;
	}

	public String getTempPOSubject(String poNumber) {

		return objPurchaseDepartmentIndentProcessDao.getTempPOSubject(poNumber);
	}
	public String getTempPoCCEmails(String poNumber) {
		
		return objPurchaseDepartmentIndentProcessDao.getTempPoCCEmails(poNumber);
	}
	
	@SuppressWarnings("unused")
	@Override
	public String getNoOfRowsForUpdatePO(Model model, HttpServletRequest request,HttpSession session) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in PDIn_ed&SPO, ");
		String response = "";
		String temp_No="";
		boolean isAnyUpdateFailed = false;
		try{
			int noofRows = Integer.parseInt(request.getParameter("numberOfRows"));
			String poNumber = request.getParameter("poNo");
			String toSite = request.getParameter("toSiteId");
			String indentNumber = request.getParameter("indentNumber"); 
			WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , PONumber:"+poNumber);

			//int poEntrySeqNumber = objPurchaseDepartmentIndentProcessDao.getPoEnterSeqNoByPONumber(poNumber,toSite);
			for(int num=1;num<=noofRows;num++){
				String actionValue = request.getParameter("actionValue"+num);

				if(actionValue==null&&request.getParameter("ChildProduct"+num)==null)
				{
					//System.out.println(num+" row newly added & deleted at front end.");
					continue;
				}else{}

				String indentCreationDetailsId = request.getParameter("indentCreationDetailsId"+num);
				String quantity = request.getParameter("quantity"+num);
				
				
				if(actionValue==null&&request.getParameter("ChildProduct"+num)!=null)
				{
						continue;
				}else{}
				
				if(actionValue.equals("R"))
				{
					
					//	System.out.print(num+" row removed. so it is deleted from PO_ENTRY_DETAILS: "+result3);
					int result4 = objPurchaseDepartmentIndentProcessDao.updatePOIntiatedQuantityInPDTable(indentCreationDetailsId,quantity);
					
					//	System.out.println("  & updated po_intiated_quantity in SUM_PURCHASE_DEPT_INDENT_PROSS: "+result4);
					if(result4==0){isAnyUpdateFailed = true;break;}
					continue;
				}else{ objPurchaseDepartmentIndentProcessDao.checkIOndentCreationtbl(indentNumber);}
			}
		
			response="success";
		}
		catch(Exception e)
		{
			response="Failure";
			e.printStackTrace();
		}
		if(response.equals("Success")&&isAnyUpdateFailed==false)
		{
			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			//System.out.println("Data Committed");
		}
		else
		{
			response="Failure";
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			//System.out.println("Data Rollbacked");
		}
		return response;
	}
	
	public int insertSiteLevelIndentData(int site_Id,String user_Id,int indent_Number,String siteWiseIndent){
		
		return objPurchaseDepartmentIndentProcessDao.insertSiteLevelIndentData(site_Id,user_Id,indent_Number,siteWiseIndent);
	}
	
	
		public static void main(String[] args){


		String thirdTableData = "None@@0@@0@@0@@0&&";
		String [] third = thirdTableData.split("&&");
		double i=-2;
		System.out.println(Math.abs(i));
		
	}
}
