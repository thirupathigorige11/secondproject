package com.sumadhura.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.Model;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.dto.IndentCreationDetailsDto;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.transdao.CentralSiteIndentProcessDao;

import com.sumadhura.transdao.IndentCreationDao;
import com.sumadhura.util.UIProperties;


@Service("cntlIndentprocess")
public class CentralSiteIndentrocessServiceImpl extends UIProperties implements CentralSiteIndentrocessService{

	
	@Autowired
	PlatformTransactionManager transactionManager;
	
	@Autowired
	CentralSiteIndentProcessDao cntlIndentrocss;

	
	@Autowired
	private IndentCreationDao icd;
	
	@Override
	public String sendToPD(Model model, HttpServletRequest request, int site_id, String user_id) {
		boolean isSendMail = true;
		String response = "";
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in CeIn_senTPD, ");
		String pendingEmpId = "";
		int indentNumber = 0;
		String strIndentFrom = "";
		String strIndentTo = "";
		int siteWiseIndentNo = 0;
		int portNo=0;
		final List<IndentCreationDetailsDto> listProductDetails = new ArrayList<IndentCreationDetailsDto>();
		final IndentCreationDto indentCreationDtoForMail = new IndentCreationDto();
		try
		{
			indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
			pendingEmpId = "-";
			String pendingDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
			String reqSiteName = request.getParameter("siteName");
			int indentReqSiteId = cntlIndentrocss.getSiteIdByName(reqSiteName);
			String reqReceiveFrom = user_id;
			strIndentFrom = "Central";
			strIndentTo = "Purchase Department";
			siteWiseIndentNo= Integer.parseInt(request.getParameter("siteWiseIndentNo"));
			indentCreationDtoForMail.setSiteId(indentReqSiteId);
			indentCreationDtoForMail.setPendingEmpId(pendingEmpId);
			portNo=request.getLocalPort();
			WriteTrHistory.write("Site:"+site_id+" , User:"+user_id+" , Date:"+new java.util.Date()+" , IndentNumber:"+indentNumber);
			

			int response1 = icd.updateIndentCreation(indentNumber, pendingEmpId, pendingDeptId);
			IndentCreationDto indentCreationDto = new IndentCreationDto();
			indentCreationDto.setSiteId(site_id);
			indentCreationDto.setUserId(user_id);
			indentCreationDto.setPurpose("");
			int indentCreationApprovalSeqNum = icd.getIndentCreationApprovalSequenceNumber();
			int response2 = icd.insertIndentCreationApprovalAsApprove(indentCreationApprovalSeqNum, indentNumber, indentCreationDto);
			int noofrows = Integer.parseInt(request.getParameter("numberOfRows"));
			for(int num=1;num<=noofrows;num++){
				int IndentCreationDetailsId = Integer.parseInt(request.getParameter("indentCreationDetailsId"+num));
				String productId = request.getParameter("productId"+num);
				String subProductId = request.getParameter("subProductId"+num);
				String childProductId = request.getParameter("childProductId"+num);
				String unitsOfMeasurementId = request.getParameter("unitsOfMeasurementId"+num);
				String requiredQuantity = request.getParameter("requiredQuantity"+num);
				IndentCreationBean purchaseIndentDetails = new IndentCreationBean();
				purchaseIndentDetails.setProductId1(productId);
				purchaseIndentDetails.setSubProductId1(subProductId);
				purchaseIndentDetails.setChildProductId1(childProductId);
				purchaseIndentDetails.setUnitsOfMeasurementId1(unitsOfMeasurementId);
				purchaseIndentDetails.setRequiredQuantity1(requiredQuantity);
				IndentCreationDetailsDto indentCreationDetailsDto = new IndentCreationDetailsDto();
				indentCreationDetailsDto.setProdName(request.getParameter("productName"+num));
				indentCreationDetailsDto.setSubProdName(request.getParameter("subProductName"+num));
				indentCreationDetailsDto.setChildProdName(request.getParameter("childProductName"+num));
				indentCreationDetailsDto.setMeasurementName(request.getParameter("unitsOfMeasurementName"+num));
				indentCreationDetailsDto.setRequiredQuantity(requiredQuantity);
				indentCreationDetailsDto.setRemarks(request.getParameter("remarks"+num));
				listProductDetails.add(indentCreationDetailsDto);
				
				IndentCreationDto centralTableData = cntlIndentrocss.getCentralIndentProcessData(IndentCreationDetailsId);

				int purchaseIndentProcessId = cntlIndentrocss.getPurchaseIndentProcessSequenceNumber();
				/*if(!centralTableData.getIntiatedQuantity().equals("0")){throw new InitiatedNotReturnedException("Purchase Order Cannot be Processed. Because Intiated Quantity NOT Returned");}*/
				cntlIndentrocss.insertPurchaseIndentProcess(purchaseIndentProcessId,purchaseIndentDetails,IndentCreationDetailsId,indentReqSiteId,reqReceiveFrom,centralTableData);
			}
			System.out.println("Indent Sent To Purchase Dept");
			System.out.println("responses: "+response1+","+response2);
			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			response = "Indent Sent To Purchase Dept Successfully";
			request.setAttribute("AuditResponse", "Success");

		}//end of TRY block
		catch(InitiatedNotReturnedException e){
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			e.printStackTrace();
			System.out.println("Indent Sent To Purchase Dept Failed");
			response = "Sent Indent To Purchase Dept failed ";
			System.out.println(e.getMessage());
			request.setAttribute("AuditResponse", "Fail");
		}
		catch(Exception e){
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			System.out.println("Indent Sent To Purchase Dept Failed");
			response = "Failed To Sent Indent To Purchase Dept ";
			isSendMail = false;
			e.printStackTrace();
			request.setAttribute("AuditResponse", "Fail");
		}
		//---------------------
		if(isSendMail){
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		try{

			final String strPendingEmpId = pendingEmpId;
			final int indentNumber_final = indentNumber;
			final String strIndentFrom_final = strIndentFrom;
			final String strIndentTo_final = strIndentTo;
			final int siteWiseIndentNo_final = siteWiseIndentNo;
			final int portNo_final=portNo;

			executorService.execute(new Runnable() {
				public void run() {

					String  purpose = getIndentLevelComments(indentNumber_final);



					List<IndentCreationBean> list =  getndentChangedDetails(indentNumber_final);




					sendEmailDetails( strPendingEmpId, indentNumber_final, strIndentFrom_final, strIndentTo_final,listProductDetails, indentCreationDtoForMail,purpose,list,siteWiseIndentNo_final,portNo_final);



				}


			});




			executorService.shutdown();
		}catch(Exception e){
			e.printStackTrace();
			executorService.shutdown();
		}
		}
		//---------------------
		return response;
	}
	
	public void sendEmailDetails(String pendingEmpId,int indentNumber,String indentFrom,String indentTo,List<IndentCreationDetailsDto> listProductDetails, IndentCreationDto indentCreationDto,String strIndentLevelComments,List<IndentCreationBean> strProductsChangedComments, int siteWiseIndentNo,int portNo){


		try{
			List<Map<String, Object>> indentCreationDtls = null;
			List<String> toMailListArrayList = new ArrayList<String>();

			
			indentCreationDtls = icd.getIndentCreationDetails(indentNumber,"approvalToDept");
			String purchaseDeptId  = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
			toMailListArrayList = icd.getAllEmployeeEmailsUnderDepartment(purchaseDeptId);
			




			String strIndentFromSite = "";
			String strIndentFromDate = "";
			String strEmailAddress =   "";
			String strScheduleDate = "";
			for(Map<String, Object> objIndentCreationDtls : indentCreationDtls) {



				strIndentFromSite = objIndentCreationDtls.get("SITE_NAME")==null ? "" :   objIndentCreationDtls.get("SITE_NAME").toString();
				strIndentFromDate = objIndentCreationDtls.get("CREATE_DATE")==null ? "" :   objIndentCreationDtls.get("CREATE_DATE").toString();
				strEmailAddress = objIndentCreationDtls.get("Email_id")==null ? "" :   objIndentCreationDtls.get("Email_id").toString();
				strScheduleDate = objIndentCreationDtls.get("scheduleDate")==null ? "" :   objIndentCreationDtls.get("scheduleDate").toString();
			}

			if(strEmailAddress.contains(",")){
				for(String strEmailAddress1 : strEmailAddress.split(","))
				{
					toMailListArrayList.add(strEmailAddress1);
				}
			}
			else{
			toMailListArrayList.add(strEmailAddress);
			}
			if(toMailListArrayList.size() > 0){
				String emailto [] = null ;
				emailto = new String[toMailListArrayList.size()];
				toMailListArrayList.toArray(emailto);



				List<IndentCreationBean> list =  getndentChangedDetails(indentNumber);


				EmailFunction objEmailFunction = new EmailFunction();

				objEmailFunction.sendIndentCreationApprovalMailDetails( indentTo, indentNumber, indentFrom,strIndentFromSite, strIndentFromDate, strScheduleDate,emailto,listProductDetails,indentCreationDto,strIndentLevelComments,list,siteWiseIndentNo,portNo);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	public List<IndentCreationBean> getCentralIndentDetailsLists(int indentNumber) {
		return cntlIndentrocss.getCentralIndentDetailsLists(indentNumber);
	}
	@Override
	public List<IndentCreationBean> getPurchaseIndentDetailsLists(int indentNumber,String strReqSiteId) {
		return cntlIndentrocss.getPurchaseIndentDetailsLists(indentNumber,strReqSiteId);
	}
	@Override
	public List<ProductDetails> getPurchaseIndentDtlsLists(String  indentCreationDetailsIdForenquiry,String strVendorId) {
		return cntlIndentrocss.getPurchaseIndentDtlsLists(indentCreationDetailsIdForenquiry,strVendorId);
	}
	@Override
	public String requestToOtherSite(Model model, HttpServletRequest request, int site_id, String user_id) {
		String response = "";
		boolean isSendMail = true;
		int indentNumber = 0;
		int reqSiteId = 0;
		int noofrows = 0;
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in CeIn_reqOth, ");
		try
		{
			indentNumber = Integer.parseInt(request.getParameter("bfIndentNumber")); 
			reqSiteId = Integer.parseInt(request.getParameter("bfSiteId")); 
			noofrows = Integer.parseInt(request.getParameter("bfRows"));
			WriteTrHistory.write("Site:"+site_id+" , User:"+user_id+" , Date:"+new java.util.Date()+" , IndentNumber:"+indentNumber);
			for(int num=1;num<=noofrows;num++)
			{

				String strSenderSite = request.getParameter("sitename"+num);
				int senderSite;
				String aQuantity = request.getParameter("aquantity"+num);
				try {
					Integer.parseInt(aQuantity);
					senderSite = cntlIndentrocss.getSiteIdByName(strSenderSite);
				} catch(Exception e) { return "inputwrong";}

				String bulkdata = request.getParameter("bulkdata"+num);

				//System.out.println("sendersite: >>"+senderSite+"<<");
				//System.out.println("bulkdata: "+bulkdata);
				String[] bulkarray = bulkdata.split("@@");
				IndentCreationBean indentCreationBean = new IndentCreationBean();
				indentCreationBean.setProductId1(bulkarray[0]);
				indentCreationBean.setSubProductId1(bulkarray[1]);
				indentCreationBean.setChildProductId1(bulkarray[2]);
				indentCreationBean.setUnitsOfMeasurementId1(bulkarray[3]);
				int indentProcessId = Integer.parseInt(bulkarray[4]);
				indentCreationBean.setIndentProcessId(indentProcessId);
				indentCreationBean.setIndentNumber(indentNumber);
				indentCreationBean.setSiteId(reqSiteId);
				indentCreationBean.setRequiredQuantity1(aQuantity);
				int centralIndentReqDetailsSeqNum = cntlIndentrocss.getCentralIndentRequestDetailsSequenceNumber();
				if(cntlIndentrocss.getIndentProcessIdCount(indentProcessId,senderSite)>0){
					cntlIndentrocss.updateRequestToOtherSite(indentCreationBean,centralIndentReqDetailsSeqNum,senderSite);
				}
				else
				{
					cntlIndentrocss.requestToOtherSite(indentCreationBean,centralIndentReqDetailsSeqNum,senderSite);
				}
				cntlIndentrocss.updateInitiatedQuantityInCentralTable(aQuantity,indentProcessId);
				/*if(bulkdata1!=null){bulkdata = bulkdata1;}
			if(sendersite1==null){continue;}else{if(sendersite1.equals(""))	{continue;}}*/
			}//end of FOR loop

			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
			System.out.println("Request Sent To Other Site");
			response = "Request Sent To Other Site Sucessfully";



		}//end of TRY block
		catch(Exception e){
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			System.out.println("Request Sending To Other Site Failed");
			response ="Failed To Sent Request To Other Site";
			e.printStackTrace();
			isSendMail = false;
		}
		
		if(isSendMail){

			/*for(int num=1;num<=noofrows;num++)
			{
				String strSenderSite = request.getParameter("sitename"+num);
			sendEmail( "", indentNumber, "CENTRAL", strSenderSite);
			}*/
		}

		return response;

	}
	@Override
	public List<IndentCreationBean> getAllCentralIndents() {
		String centralDeptId = validateParams.getProperty("CENTRAL_DEPT_ID") == null ? "" : validateParams.getProperty("CENTRAL_DEPT_ID").toString();
		return icd.getIndentFromAndToDetails(centralDeptId);
	}



	@Override
	public List<IndentCreationBean> getIndentCreationLists(int indentNumber) {
		List<IndentCreationBean> list = icd.getIndentCreationLists(indentNumber);
		return list;
	}
	
	@Override
	public String  getIndentLevelComments(int indentNo) {

		List<IndentCreationBean> list = null;
		String strPurpose = "";
		try{
			strPurpose = icd.getIndentLevelComments( indentNo);
		}catch(Exception e){
			e.printStackTrace();
		}
		return strPurpose;
	}
	
	public List<IndentCreationBean>   getndentChangedDetails(int indentNo) {

		List<IndentCreationBean> list = null;
		String strPurpose = "";
		try{
			list = icd.getndentChangedDetails( indentNo);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
}
