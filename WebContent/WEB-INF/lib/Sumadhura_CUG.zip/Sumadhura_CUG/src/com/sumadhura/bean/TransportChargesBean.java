package com.sumadhura.bean;

public class TransportChargesBean {
	private String transportId;
	private String transportGstPercentage;
	private String transportGstAmount;
	private String totalAmountAfterGstTax;
	private String transportInvoiceId;
	private String indentEntryInvoiceId;
	private String dateAndTime;
	private String transportAmount;

	public String getTransportId() {
		return transportId;
	}

	public void setTransportId(String transportId) {
		this.transportId = transportId;
	}

	public String getTransportGstPercentage() {
		return transportGstPercentage;
	}

	public void setTransportGstPercentage(String transportGstPercentage) {
		this.transportGstPercentage = transportGstPercentage;
	}

	public String getTransportGstAmount() {
		return transportGstAmount;
	}

	public void setTransportGstAmount(String transportGstAmount) {
		this.transportGstAmount = transportGstAmount;
	}

	public String getTotalAmountAfterGstTax() {
		return totalAmountAfterGstTax;
	}

	public void setTotalAmountAfterGstTax(String totalAmountAfterGstTax) {
		this.totalAmountAfterGstTax = totalAmountAfterGstTax;
	}

	public String getTransportInvoiceId() {
		return transportInvoiceId;
	}

	public void setTransportInvoiceId(String transportInvoiceId) {
		this.transportInvoiceId = transportInvoiceId;
	}

	public String getIndentEntryInvoiceId() {
		return indentEntryInvoiceId;
	}

	public void setIndentEntryInvoiceId(String indentEntryInvoiceId) {
		this.indentEntryInvoiceId = indentEntryInvoiceId;
	}

	public String getDateAndTime() {
		return dateAndTime;
	}

	public void setDateAndTime(String dateAndTime) {
		this.dateAndTime = dateAndTime;
	}

	public String getTransportAmount() {
		return transportAmount;
	}

	public void setTransportAmount(String transportAmount) {
		this.transportAmount = transportAmount;
	}

}
