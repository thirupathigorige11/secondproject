package com.sumadhura.transdao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sumadhura.bean.ProductDetails;
import com.sumadhura.dto.PriceMasterDTO;

public interface ReportsDao {

	String getAllProductsDetail(String siteId);

	Set<PriceMasterDTO> getProductPriceListBySite(String siteId, String childProdName);

	Set<PriceMasterDTO> getLastThreeMonthPriceMasterDetail(String childProductId, String prodName, String priceId,
			String site_id);

	String getRequestedAmountReportBySite(String siteId, String tillDatePaymentReq);
	List<String> loadAllChildProducts(String prodName);
}
