package com.sumadhura.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;



import java.util.Random;
import java.util.TreeMap;


@Repository
public class CommonUtilities  {
	
	static Logger log = Logger.getLogger(CommonUtilities.class);



	@Autowired
	private  JdbcTemplate jdbcTemplate;
	
	public static String getStan()
	{
		String val = "";
		Random random = new Random();
		int randomInt = random.nextInt(8999) + 1000;		
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date today = new Date();
		String todayStr = format.format(today);
		val = todayStr + randomInt;
		return val;
	}
	
	
	
	
	 // pad with " " to the right to the given length (n)
	  public static String padRight(String s, int n) {
	    return String.format("%1$-" + n + "s", s);
	  }

	  // pad with " " to the left to the given length (n)
	  public static String padLeft(String s, int n) {
	    return String.format("%1$" + n + "s", s);
	  }
	  public static String breakString(String param, char specialChar,int afterNoOfspecialChar){
			String result = "";
			//Controlled loop to count characters
			int count =1;
			for (int i = 0; i < param.length(); i++)
			{
				if (param.charAt(i) == specialChar)
				{
					count++;
					if(count == afterNoOfspecialChar){
						result += String.valueOf("&");
						count =1;
					}else{
						result += String.valueOf(param.charAt(i));
					}
				}else{
					result += String.valueOf(param.charAt(i));
				}
			}
			////System.out.println("Count Special Char:"+count);
			return result;
		}

	
	
	  public   Map<String, String> getSiteList() {

			Map<String, String> gst = null;
			List<Map<String, Object>> dbSiteList = null;

			gst = new TreeMap<String, String>();

			String gstSlabsQry = "SELECT SITE_ID, SITE_NAME FROM SITE where STATUS = 'ACTIVE' ";
			log.debug("Query to fetch gst slab = "+gstSlabsQry);

			dbSiteList = jdbcTemplate.queryForList(gstSlabsQry, new Object[]{});

			for(Map<String, Object> gstSlabs : dbSiteList) {
				gst.put(String.valueOf(gstSlabs.get("SITE_ID")).trim(), String.valueOf(gstSlabs.get("SITE_NAME")).trim());
			}
			return gst;
		}
	
}
