package com.sumadhura.transdao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sumadhura.bean.ProductDetails;
import com.sumadhura.util.DBConnection;
import com.sumadhura.util.UIProperties;
@Repository
public class ProductDao extends UIProperties  {

	//JdbcTemplate template=null;
	//SELECT * FROM CHILD_PRODUCT WHERE UPPER(NAME) = UPPER('Ms Elbow �CLASS 65NB - FF72') AND SUB_PRODUCT_ID='SP1020' AND STATUS='A'
	public int checkProductNameAvailableOrNot(String productName) {

		int res = 0;
		String sql = "";
		JdbcTemplate template = null;
		List<Map<String, Object>> TotalProductList = null;
		try {
			logger.info("Inside checkProductAvailableOrNot() Product Name --->  " + productName);
			template = new JdbcTemplate(DBConnection.getDbConnection());
			sql = "SELECT * FROM PRODUCT WHERE UPPER(NAME) =UPPER('"+productName+"') AND STATUS='A'";
			TotalProductList = template.queryForList(sql, new Object[] {});
			
			if (null != TotalProductList && TotalProductList.size() > 0) {
				res = 1;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			template = null;
		}
		return res;
	}
	
	
	
	public int checkSubProductNameAvailableOrNot(String productId, String subProductName) {

		int res = 0;
		String sql = "";
		JdbcTemplate template = null;
		List<Map<String, Object>> TotalProductList = null;
		try {

			logger.info("Inside checkSubProductNameAvailableOrNot() method in ProductDao class--->  Product Id -->"+productId+" Subproduct Name is "+subProductName);
			template = new JdbcTemplate(DBConnection.getDbConnection());
			sql = "SELECT * FROM SUB_PRODUCT WHERE UPPER(NAME) = UPPER('"+subProductName+"') AND PRODUCT_ID='"+productId+"' AND STATUS='A'";
			logger.info("query in Inside checkSubProductNameAvailableOrNot() method "+ sql);
			TotalProductList = template.queryForList(sql, new Object[] {});
			
			if (null != TotalProductList && TotalProductList.size() > 0) {
				res = 1;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			template = null;
		}
		return res;
	}
	
	
	
	public int checkChildProductNameAvailableOrNot(String subProductId, String childProductName) {

		int res = 0;
		String sql = "";
		JdbcTemplate template = null;
		List<Map<String, Object>> TotalProductList = null;
		try {

			logger.info("Inside checkChildProductNameAvailableOrNot() method in ProductDao class---> subProductId -->"+subProductId+" Subproduct Name is "+childProductName);
			template = new JdbcTemplate(DBConnection.getDbConnection());
			sql = "SELECT * FROM CHILD_PRODUCT WHERE UPPER(NAME) = UPPER('"+childProductName+"') AND SUB_PRODUCT_ID='"+subProductId+"' AND STATUS='A'";
			logger.info("query in Inside checkChildProductNameAvailableOrNot() method "+ sql);
			TotalProductList = template.queryForList(sql, new Object[] {});
			
			if (null != TotalProductList && TotalProductList.size() > 0) {
				res = 1;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			template = null;
		}
		return res;
	}
	
	public int saveproduct(String strProductName,String strProductId) throws Exception{

		int res = 0;
		JdbcTemplate template=null;
		try{

			logger.info("save db1 "+strProductName);
			template = new JdbcTemplate(DBConnection.getDbConnection());
			logger.info("db connection");

			String sql="insert into product(name,PRODUCT_ID,STATUS,created_date) values(?,?,?,sysdate)";  
			res  = template.update(sql,new Object[]{strProductName,strProductId,"A"});

		}
		catch(Exception e){
			e.printStackTrace();
		}

		return res;

	}
	public List<ProductDetails> getTotalProducts() {
		JdbcTemplate template=null;
		List<Map<String,Object>> TotalProductList = null;
		ProductDetails objProductDetails = null;
		List<ProductDetails> listProductList =  new ArrayList<ProductDetails>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select name from product where STATUS='A'";

			logger.info(sql);

			TotalProductList = template.queryForList(sql,new Object[]{});

			for(Map productList : TotalProductList){
				objProductDetails = new ProductDetails();

				objProductDetails.setProductName((productList.get("name") == null ? "" : productList.get("name").toString()));
				listProductList.add(objProductDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return listProductList;
	}

	
	public int deleteproduct(String strProductId){
		//int id = 0;
		JdbcTemplate template=null;
		int count = 0;
		try{
			template = new JdbcTemplate(DBConnection.getDbConnection());
			String sql = "UPDATE product SET STATUS = 'I' WHERE PRODUCT_ID = ?";
			count = template.update(sql,new Object[]{strProductId});
		}catch(Exception e){
			e.printStackTrace();
		}
		return count;
	}


	public int savesubproduct(String strProductId,String strSubProductId,String strSubProductName) throws Exception{

		int res = 0;
		JdbcTemplate template=null;
		try{

			logger.info("save subdb "+strSubProductId);

			template = new JdbcTemplate(DBConnection.getDbConnection());
			logger.info("db connection");
			String sql="insert into sub_product(SUB_PRODUCT_ID,PRODUCT_ID,NAME,STATUS) values(?,?,?,?)";  
			res  = template.update(sql,new Object[]{strSubProductId,strProductId,strSubProductName,"A"});

		}
		catch(Exception e){
			e.printStackTrace();
		}

		return res;

	}
	public List<ProductDetails> getTotalSubProducts() {
		JdbcTemplate template=null;
		List<Map<String,Object>> TotalSubProductList = null;
		ProductDetails objProductDetails = null;
		List<ProductDetails> listSubProductList =  new ArrayList<ProductDetails>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select S.NAME as Sub_ProductName ,P.NAME as ProductName from  SUB_PRODUCT S,PRODUCT P WHERE S.PRODUCT_ID = P.PRODUCT_ID  and S.STATUS = 'A'";

			logger.info(sql);

			TotalSubProductList = template.queryForList(sql,new Object[]{});

			for(Map productList : TotalSubProductList){
				objProductDetails = new ProductDetails();
				objProductDetails.setSub_ProductName((productList.get("Sub_ProductName") == null ? "" : productList.get("Sub_ProductName").toString()));
				objProductDetails.setProductName((productList.get("ProductName") == null ? "" : productList.get("ProductName").toString()));
				listSubProductList.add(objProductDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();
			
		}

		return listSubProductList;
	}
	
	public int deletesubproduct(String strProductId,String strSubProductId){
		//int id = 0;
		JdbcTemplate template=null;
		int count = 0;
		try{
			template = new JdbcTemplate(DBConnection.getDbConnection());
			String sql = "UPDATE sub_product SET STATUS = ? WHERE  PRODUCT_ID = ? and SUB_PRODUCT_ID = ?";
			
			count = template.update(sql,new Object[]{"I",strProductId,strSubProductId});
		}catch(Exception e){
			e.printStackTrace();
		}
		return count;
	}


	public int saveChildProduct(String strChildProductName,String strChildProductId,String strSubProductId,String strMeasurementName,String strMeasurementId) throws Exception{
		 
		int res = 0;
		JdbcTemplate template=null;
		String sql= "";
		try{
			template = new JdbcTemplate(DBConnection.getDbConnection());
			
			
			logger.info("db connection for child product");
			sql="insert into child_product(CHILD_PRODUCT_ID,SUB_PRODUCT_ID,name,STATUS) values(?,?,?,?)";  
			res  = template.update(sql,new Object[]{strChildProductId,strSubProductId,strChildProductName,"A"});

			logger.info("db connection for measurement");
			 sql="insert into measurement(MEASUREMENT_ID,NAME,CREATED_DATE,CHILD_PRODUCT_ID, STATUS ) values(?,?,sysdate,?,?)";  
			res  = template.update(sql,new Object[]{strMeasurementId,strMeasurementName,strChildProductId,"A"});

		}
		catch(Exception e){
			e.printStackTrace();
		}

		return res;

	}
	public List<ProductDetails> getAllChildProducts() {
		JdbcTemplate template=null;
		List<Map<String,Object>> AllProductList = null;
		ProductDetails objProductDetails = null;
		List<ProductDetails> listAllProductList =  new ArrayList<ProductDetails>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select C.NAME as CHILD_PRODUCT_NAME,S.NAME as SUB_PRODUCTNAME ,P.NAME as PRODUCT_NAME from CHILD_PRODUCT c,SUB_PRODUCT S,PRODUCT P where C.SUB_PRODUCT_ID = S.SUB_PRODUCT_ID and S.PRODUCT_ID = P.PRODUCT_ID  and C.STATUS = 'A'";

			logger.info(sql);

			AllProductList = template.queryForList(sql,new Object[]{});

			for(Map productList :AllProductList){
				objProductDetails = new ProductDetails();
				objProductDetails.setProductName((productList.get("PRODUCT_NAME") == null ? "" : productList.get("PRODUCT_NAME").toString()));
				objProductDetails.setSub_ProductName((productList.get("SUB_PRODUCTNAME") == null ? "" : productList.get("SUB_PRODUCTNAME").toString()));
				objProductDetails.setChild_ProductName((productList.get("CHILD_PRODUCT_NAME") == null ? "" : productList.get("CHILD_PRODUCT_NAME").toString()));
				listAllProductList.add(objProductDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();
			//throw new MyException("");
		}

		return listAllProductList;
	}

	
	public int deletechildproduct(String strSubProdId,String strChildProdId){
		//	int id = 0;
		JdbcTemplate template=null;
		int count = 0;
		try{
			template = new JdbcTemplate(DBConnection.getDbConnection());
			String sql = "UPDATE child_product SET STATUS = 'I' WHERE CHILD_PRODUCT_ID = ? and SUB_PRODUCT_ID = ?";
		
			count = template.update(sql,new Object[]{strChildProdId,strSubProdId});
		}catch(Exception e){
			e.printStackTrace();
		}
		return count;
	}
	

	public int getSeqNo(String strProductType){
		//	int id = 0;
		JdbcTemplate template=null;
		int count = 0;
		String sql = "";
		try{
			template = new JdbcTemplate(DBConnection.getDbConnection());

			if(strProductType.equals("combobox_Product")){
				sql = "select PRODUCT_ID_SEQ.nextval from dual";
			}
			else if(strProductType.equals("delete_SubProd")){
				sql = "select SUBPRODUCT_ID_SEQ.nextval from dual";
			}
			else if(strProductType.equals("childproduct")){
				sql = "select CHILD_PRODUCT_ID_SEQ.nextval from dual";
			}
			else if(strProductType.equals("measurement")){
				sql = "select MEASUREMENT_ID_SEQ.nextval from dual";
			}

			count = template.queryForInt(sql);

		}catch(Exception e){
			e.printStackTrace();
		}
		return count;
	}

	
}
