package com.sumadhura.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;


import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.Model;

import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.dto.IndentCreationDetailsDto;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.util.CommonUtilities;
import com.sumadhura.util.UIProperties;

public class IndentCreationApprovalEmailFunction extends UIProperties {

	private JdbcTemplate jdbcTemplate;
	public IndentCreationApprovalEmailFunction(JdbcTemplate template) {

		this.jdbcTemplate = template;
	}



	public String approveIndentCreationFromMail( HttpServletRequest request,int site_id, String user_id) {
		String response = "";
		boolean isSendMail = true;
		String strIndentTo = "";
		String strIndentFrom = "";
		int reqSiteId = 0;

		//int indentNumber = 0;
		String pendingEmpId = "";
		String strPurpose = "";
		final List<IndentCreationDetailsDto> listProductDetails = new ArrayList<IndentCreationDetailsDto>();
		final List<IndentCreationBean> editList = new ArrayList<IndentCreationBean>();
		final IndentCreationDto indentCreationDtoForMail = new IndentCreationDto();
		int indentNumber = 0;
		int siteWiseIndentNo = 0;
		int portNo=0;
		try {
			indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			siteWiseIndentNo = getSiteWiseIndentNo(indentNumber);
			System.out.println(request.getParameter("tempPass")+"-"+getTempPasswordOfIndent(indentNumber));
			if(request.getParameter("tempPass").equals(getTempPasswordOfIndent(indentNumber))){}
			else{
				
				return "WrongPassword";
				}

			strIndentFrom= getIndentFrom(indentNumber);
			strIndentTo= getIndentTo(user_id);
			List<IndentCreationBean> indentDetails = getIndentCreationLists(indentNumber);
			List<IndentCreationBean> productslist = getIndentCreationDetailsLists(indentNumber);
			IndentCreationDto indentCreationDto = new IndentCreationDto();
			reqSiteId = indentDetails.get(0).getSiteId();


			String strEditComments = indentDetails.get(0).getMaterialEditComment();

			if(strEditComments.contains("@@@")){
				String strEditCommentsArr [] = strEditComments.split("@@@");
				for(int j = 0; j< strEditCommentsArr.length;j++){
					IndentCreationBean objCommentIndentCreationBean  = new IndentCreationBean();
					objCommentIndentCreationBean.setMaterialEditComment(strEditCommentsArr[j]);
					editList.add(objCommentIndentCreationBean);
				}


			}


			indentCreationDto.setSiteId(reqSiteId);//reqSiteId
			indentCreationDtoForMail.setSiteId(reqSiteId);
			indentCreationDto.setUserId(user_id);
			String comment=request.getParameter("comment");
			indentCreationDto.setPurpose(comment);//purpose
			String temppass = CommonUtilities.getStan();
			indentCreationDto.setTempPass(temppass);
			indentCreationDtoForMail.setTempPass(temppass);
			int indentCreationApprovalSeqNum = getIndentCreationApprovalSequenceNumber();

			portNo=request.getLocalPort();
			int response1 = insertIndentCreationApprovalAsApprove(indentCreationApprovalSeqNum, indentNumber, indentCreationDto);
			pendingEmpId = getPendingEmployeeId(user_id);
			//pendingEmpId = user_id;
			indentCreationDtoForMail.setPendingEmpId(pendingEmpId);
			String pendingDeptId = "-";
			if(pendingEmpId.equals("-"))
			{
				pendingDeptId = getPendingDeptId(user_id);
			}
			int response2 = updateIndentCreation(indentNumber, pendingEmpId, pendingDeptId, indentCreationDto,"approving from Mail");
			int noofrows = Integer.parseInt(request.getParameter("noofRowsTobeProcessed"));

			String centralDeptId = validateParams.getProperty("CENTRAL_DEPT_ID") == null ? "" : validateParams.getProperty("CENTRAL_DEPT_ID").toString();
			String purchaseDeptId = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
			for(int num=1;num<=noofrows;num++)
			{
				IndentCreationDetailsDto indentCreationDetailsDto = new IndentCreationDetailsDto();
				indentCreationDetailsDto.setProdId(productslist.get(num-1).getProductId1());
				indentCreationDetailsDto.setProdName(productslist.get(num-1).getProduct1());
				indentCreationDetailsDto.setSubProdId(productslist.get(num-1).getSubProductId1());
				indentCreationDetailsDto.setSubProdName(productslist.get(num-1).getSubProduct1());
				indentCreationDetailsDto.setChildProdId(productslist.get(num-1).getChildProductId1());
				indentCreationDetailsDto.setChildProdName(productslist.get(num-1).getChildProduct1());
				indentCreationDetailsDto.setMeasurementId(productslist.get(num-1).getUnitsOfMeasurementId1());
				indentCreationDetailsDto.setMeasurementName(productslist.get(num-1).getUnitsOfMeasurement1());

				indentCreationDetailsDto.setRequiredQuantity(productslist.get(num-1).getRequiredQuantity1());
				indentCreationDetailsDto.setRemarks(productslist.get(num-1).getRemarks1());
				listProductDetails.add(indentCreationDetailsDto);




				strPurpose = getIndentLevelComments(indentNumber);
				request.setAttribute("indentLevelComments", "strPurpose");



				// To Give Indent to Central
				if(pendingEmpId.equals("-")&&pendingDeptId.equals(centralDeptId))
				{
					int centralIndentProcessId = getCentralIndentProcessSequenceNumber();
					insertCentralIndentProcess(centralIndentProcessId,productslist.get(num-1),productslist.get(num-1).getIndentCreationDetailsId(),reqSiteId);
				}else if(pendingEmpId.equals("-")&&pendingDeptId.equals(purchaseDeptId))
				{
					int indentProcessId = getCentralIndentProcessSequenceNumber();
					insertPurchaseIndentProcess(indentProcessId,productslist.get(num-1),productslist.get(num-1).getIndentCreationDetailsId(),reqSiteId,user_id);
				}
			}

			System.out.println("Indent Approval Success via EMail");
			response = "Success";
		}
		catch(Exception e){

			System.out.println("Indent Approval Failed via EMail");
			response = "Failed";
			isSendMail = false;
			e.printStackTrace();
		}
		if(isSendMail){
			ExecutorService executorService = Executors.newFixedThreadPool(10);
			try{

				final String finalPendingEmpId = pendingEmpId;
				final String finalStrIndentFrom =strIndentFrom;
				final String finalStrIndentTo = strIndentTo;
				final String finalStrPurpose = strPurpose;
				final int indentNumber_final = indentNumber;
				final int siteWiseIndentNo_final = siteWiseIndentNo;
				final int portNo_final =portNo;
				executorService.execute(new Runnable() {
					public void run() {



						//sendEmail( "", indentNumber, strIndentFrom, strIndentTo);

						IndentCreationServiceImpl objIndentCreationServiceImpl = new IndentCreationServiceImpl();
						sendEmailDetails( finalPendingEmpId, indentNumber_final, finalStrIndentFrom, finalStrIndentTo,listProductDetails, indentCreationDtoForMail,finalStrPurpose,editList,siteWiseIndentNo_final,portNo_final);


					}


				});




				executorService.shutdown();
			}catch(Exception e){
				e.printStackTrace();
				executorService.shutdown();
			}
		}
		/*if(isSendMail){


			//sendEmail( "", indentNumber, strIndentFrom, strIndentTo);
			sendEmailDetails( pendingEmpId, indentNumber, strIndentFrom, strIndentTo,listProductDetails, indentCreationDtoForMail,strPurpose,editList);
		}*/
		return response;
	}	



	public List<IndentCreationBean> getIndentCreationLists(int indentNumber) {
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		List<Map<String, Object>> dbIndentDts = null;
		String strPendingEmployeeName = "";
		String strPendingDeptName = "";


		String query = "SELECT SIC.SITEWISE_INDENT_NO,SIC.SCHEDULE_DATE ,SIC.REQUIRED_DATE, SIC.INDENT_CREATE_EMP_ID ,SIC.PENDING_EMP_ID, S.SITE_NAME,S.SITE_ID,"+
		"( SELECT SED.EMP_NAME FROM SUMADHURA_EMPLOYEE_DETAILS SED WHERE SED.EMP_ID=SIC.INDENT_CREATE_EMP_ID and INDENT_CREATION_ID = ?) as INDENT_CREATE_EMP_NAME, "+
		"( SELECT SED.EMP_NAME FROM SUMADHURA_EMPLOYEE_DETAILS SED WHERE SED.EMP_ID=SIC.PENDING_EMP_ID and INDENT_CREATION_ID = ?) as PENDING_EMP_NAME,METERIAL_EDIT_COMMENT , "+
		"( SELECT SDD.DEPT_NAME FROM SUMADHURA_DEPARTMENT_DETAILS SDD WHERE SDD.DEPT_ID=SIC.PENDIND_DEPT_ID and INDENT_CREATION_ID = ?) as PENDING_DEPT_NAME "+
		" FROM SUMADHURA_INDENT_CREATION SIC, SITE S WHERE SIC.INDENT_CREATION_ID = ? AND S.SITE_ID = SIC.SITE_ID";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {
				indentNumber,indentNumber,indentNumber,indentNumber
		});
		for(Map<String, Object> prods : dbIndentDts) {
			IndentCreationBean indentCreationBean = new IndentCreationBean();
			indentCreationBean.setIndentNumber(indentNumber);
			String strScheduleDate = prods.get("SCHEDULE_DATE")==null ? "0000-00-00 00:00:00.000" : prods.get("SCHEDULE_DATE").toString();
			String strRequiredDate = prods.get("REQUIRED_DATE")==null ? "0000-00-00 00:00:00.000" : prods.get("REQUIRED_DATE").toString();
			Date scheduleDate = null;
			Date requiredDate = null;
			try {
				scheduleDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(strScheduleDate);
				requiredDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(strRequiredDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			strScheduleDate = new SimpleDateFormat("dd-MMM-yy").format(scheduleDate);
			strRequiredDate = new SimpleDateFormat("dd-MMM-yy").format(requiredDate);
			indentCreationBean.setStrScheduleDate(strScheduleDate);
			indentCreationBean.setStrRequiredDate(strRequiredDate);
			indentCreationBean.setSiteWiseIndentNo(Integer.parseInt(prods.get("SITEWISE_INDENT_NO")==null ? "0" :   prods.get("SITEWISE_INDENT_NO").toString()));
			indentCreationBean.setIndentFrom(prods.get("INDENT_CREATE_EMP_NAME")==null ? "" :   prods.get("INDENT_CREATE_EMP_NAME").toString());

			indentCreationBean.setSiteName(prods.get("SITE_NAME")==null ? "" :   prods.get("SITE_NAME").toString());
			indentCreationBean.setSiteId(Integer.parseInt(prods.get("SITE_ID")==null ? "" :   prods.get("SITE_ID").toString()));
			indentCreationBean.setIndentNumber(indentNumber);
			indentCreationBean.setMaterialEditComment(prods.get("METERIAL_EDIT_COMMENT")==null ? "" :   prods.get("METERIAL_EDIT_COMMENT").toString());

			strPendingEmployeeName = prods.get("PENDING_EMP_NAME")==null ? "" :   prods.get("PENDING_EMP_NAME").toString();

			strPendingDeptName = prods.get("PENDING_DEPT_NAME")==null ? "" :   prods.get("PENDING_DEPT_NAME").toString();


			if(strPendingEmployeeName.equals("")){
				indentCreationBean.setIndentTo(strPendingDeptName);
			}else{
				indentCreationBean.setIndentTo(strPendingEmployeeName);
			}






			//indentCreationBean.setPurpose("PO");
			list.add(indentCreationBean);
		}
		List<Map<String, Object>> dbIndentDts2 = null;
		String query2 = "SELECT SED.EMP_NAME,SICAD.PURPOSE from  SUM_INT_CREATION_APPROVAL_DTLS SICAD,SUMADHURA_EMPLOYEE_DETAILS SED "
			+ " where SICAD.INDENT_CREATION_ID = ? AND SED.EMP_ID=SICAD.INDENT_CREATE_APPROVE_EMP_ID";
		dbIndentDts2 = jdbcTemplate.queryForList(query2, new Object[] {
				indentNumber
		});
		String purposeView="";
		for(Map<String, Object> prods2 : dbIndentDts2) {
			String empName = prods2.get("EMP_NAME")==null ? "" : prods2.get("EMP_NAME").toString();
			String purpose = prods2.get("PURPOSE")==null ? "" : prods2.get("PURPOSE").toString();
			purposeView+=empName+" - "+purpose+"<br>";
		}
		list.get(0).setPurpose(purposeView);
		return list;
	}

	public int getSiteWiseIndentNo(int indentNumber) {
		String query = "select SITEWISE_INDENT_NO from SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID = ? ";
		int result = jdbcTemplate.queryForInt(query, new Object[] {indentNumber});
		return result;
	}

	public String getIndentFrom(int indentNumber) {
		String indentFrom = "";
		List<Map<String, Object>> dbIndentDts = null;
		String query = "SELECT  SED.EMP_ID,SED.EMP_NAME FROM SUM_INT_CREATION_APPROVAL_DTLS SICAD,SUMADHURA_EMPLOYEE_DETAILS SED where SICAD.INDENT_CREATE_APPROVE_EMP_ID = SED.EMP_ID  AND SICAD.INT_CREATION_APPROVAL_DTLS_ID in"
			+ "(SELECT max(SICAD.INT_CREATION_APPROVAL_DTLS_ID) FROM SUM_INT_CREATION_APPROVAL_DTLS SICAD where SICAD.INDENT_CREATION_ID = ? GROUP BY SICAD.INDENT_CREATION_ID)";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
		for(Map<String, Object> prods : dbIndentDts) {
			indentFrom = prods.get("EMP_NAME")==null ? "" :   prods.get("EMP_NAME").toString();		
		}
		return indentFrom;
	}

	public String getIndentTo(String user_id) {
		String indentTo = "";
		List<Map<String, Object>> dbIndentDts = null;
		String query = "SELECT  SED.EMP_ID,SED.EMP_NAME FROM SUMADHURA_APPROVER_MAPPING_DTL SAMD,SUMADHURA_EMPLOYEE_DETAILS SED where SAMD.EMP_ID = ? AND SAMD.APPROVER_EMP_ID = SED.EMP_ID AND MODULE_TYPE='INDENT'";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {user_id});
		for(Map<String, Object> prods : dbIndentDts) {
			indentTo = prods.get("EMP_NAME")==null ? "" :   prods.get("EMP_NAME").toString();		
		}
		return indentTo;
	}

	public List<IndentCreationBean> getIndentCreationDetailsLists(int indentNumber) {
		List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
		List<Map<String, Object>> dbIndentDts = null;
		int strSerialNumber = 0;
		String query = "SELECT P.NAME as PRODUCT_NAME,SP.NAME as SUB_PRODUCT_NAME,CP.NAME as CHILD_PRODUCT_NAME,MST.NAME as MEASUREMENT_NAME,"+
		"SICD.PRODUCT_ID,SICD.SUB_PRODUCT_ID,SICD.CHILD_PRODUCT_ID,SICD.MEASUREMENT_ID,"+
		"SICD.REQ_QUANTITY,SICD.REMARKS,SICD.INDENT_CREATION_DETAILS_ID FROM SUMADHURA_INDENT_CREATION_DTLS SICD, PRODUCT P,SUB_PRODUCT SP,CHILD_PRODUCT CP,MEASUREMENT MST "+
		"WHERE SICD.PRODUCT_ID=P.PRODUCT_ID AND SICD.SUB_PRODUCT_ID=SP.SUB_PRODUCT_ID AND SICD.CHILD_PRODUCT_ID=CP.CHILD_PRODUCT_ID "+
		"AND SICD.MEASUREMENT_ID=MST.MEASUREMENT_ID AND SICD.INDENT_CREATION_ID= ? ";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {indentNumber});
		for(Map<String, Object> prods : dbIndentDts) {
			IndentCreationBean indentCreationBean = new IndentCreationBean();

			indentCreationBean.setProductId1(prods.get("PRODUCT_ID")==null ? "" :   prods.get("PRODUCT_ID").toString());
			indentCreationBean.setSubProductId1(prods.get("SUB_PRODUCT_ID")==null ? "" :   prods.get("SUB_PRODUCT_ID").toString());
			indentCreationBean.setChildProductId1(prods.get("CHILD_PRODUCT_ID")==null ? "" :   prods.get("CHILD_PRODUCT_ID").toString());
			indentCreationBean.setUnitsOfMeasurementId1(prods.get("MEASUREMENT_ID")==null ? "" :   prods.get("MEASUREMENT_ID").toString());
			indentCreationBean.setProduct1(prods.get("PRODUCT_NAME")==null ? "" :   prods.get("PRODUCT_NAME").toString());
			indentCreationBean.setSubProduct1(prods.get("SUB_PRODUCT_NAME")==null ? "" :   prods.get("SUB_PRODUCT_NAME").toString());
			indentCreationBean.setChildProduct1(prods.get("CHILD_PRODUCT_NAME")==null ? "" :   prods.get("CHILD_PRODUCT_NAME").toString());
			indentCreationBean.setUnitsOfMeasurement1(prods.get("MEASUREMENT_NAME")==null ? "" :   prods.get("MEASUREMENT_NAME").toString());
			indentCreationBean.setRequiredQuantity1(prods.get("REQ_QUANTITY")==null ? "" :   prods.get("REQ_QUANTITY").toString());
			indentCreationBean.setRemarks1(prods.get("REMARKS")==null ? "" :   prods.get("REMARKS").toString());
			indentCreationBean.setIndentCreationDetailsId(Integer.parseInt(prods.get("INDENT_CREATION_DETAILS_ID")==null ? "" :   prods.get("INDENT_CREATION_DETAILS_ID").toString()));
			strSerialNumber++;
			indentCreationBean.setStrSerialNumber(String.valueOf(strSerialNumber));
			list.add(indentCreationBean);
		}	
		return list;
	}

	public String getTempPasswordOfIndent(int indentNumber) {
		String query = "SELECT TEMPPASS FROM SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID = "+indentNumber;
		String result = jdbcTemplate.queryForObject(query,String.class);  
		return result;

	}

	public int getIndentCreationApprovalSequenceNumber() {
		int indentCreationDetailsSeqNum = jdbcTemplate.queryForInt("SELECT INDENT_CREATION_APPROVAL_SEQ.NEXTVAL FROM DUAL");
		return indentCreationDetailsSeqNum;
	}


	public int insertIndentCreationApprovalAsApprove(int indentCreationApprovalSeqNum, int indentNumber,
			IndentCreationDto indentCreationDto) {
		String query = "INSERT INTO SUM_INT_CREATION_APPROVAL_DTLS(INT_CREATION_APPROVAL_DTLS_ID ,INDENT_CREATION_ID ,"
			+ "INDENT_TYPE ,creation_date ,SITE_ID ,INDENT_CREATE_APPROVE_EMP_ID, PURPOSE  ) "+
			"VALUES(?, ?, ?, sysdate, ?, ?, ?)";
		int result = jdbcTemplate.update(query, new Object[] {
				indentCreationApprovalSeqNum, 	indentNumber,
				"A", indentCreationDto.getSiteId(),indentCreationDto.getUserId(),indentCreationDto.getPurpose()
		});
		return result;
	}


	public int updateIndentCreation(int indentCreationSeqNum, String pendingEmpId, String pendingDeptId,IndentCreationDto indentCreationDto,String strFinalChangedComments) {

		int result = 0;
		if(strFinalChangedComments.equals("approving from Mail")){
			String query = "UPDATE SUMADHURA_INDENT_CREATION set PENDING_EMP_ID = ?, MODIFYDATE= sysdate , PENDIND_DEPT_ID = ? ,TEMPPASS = ?   "+
			"WHERE INDENT_CREATION_ID = ?";
			result = jdbcTemplate.update(query, new Object[] {
					pendingEmpId, pendingDeptId, indentCreationDto.getTempPass(), indentCreationSeqNum
			});
		}else{
			String query = "UPDATE SUMADHURA_INDENT_CREATION set PENDING_EMP_ID = ?, MODIFYDATE= sysdate , PENDIND_DEPT_ID = ? ,TEMPPASS = ? , METERIAL_EDIT_COMMENT = ? "+
			"WHERE INDENT_CREATION_ID = ?";
			result = jdbcTemplate.update(query, new Object[] {
					pendingEmpId, pendingDeptId, indentCreationDto.getTempPass(),strFinalChangedComments,indentCreationSeqNum
			});
		}






		return result;
	}

	public int updateIndentCreation(int indentCreationSeqNum, String pendingEmpId, String pendingDeptId) {
		String query = "UPDATE SUMADHURA_INDENT_CREATION set PENDING_EMP_ID = ? , MODIFYDATE= sysdate , PENDIND_DEPT_ID = ? "+
		"WHERE INDENT_CREATION_ID = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				pendingEmpId, pendingDeptId, indentCreationSeqNum
		});
		return result;
	}

	public String getPendingEmployeeId(String user_id) {

		String strApproverEmpId = "";
		List<Map<String, Object>> dbIndentDts = null;
		String query = "SELECT APPROVER_EMP_ID FROM SUMADHURA_APPROVER_MAPPING_DTL where EMP_ID = ? AND MODULE_TYPE='INDENT'";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {user_id});  



		for(Map<String, Object> prods : dbIndentDts) {
			strApproverEmpId = prods.get("APPROVER_EMP_ID")==null ? "" :   prods.get("APPROVER_EMP_ID").toString();
			//icb.setFromEmpName(prods.get("EMP_NAME")==null ? "" :   prods.get("EMP_NAME").toString());		
		}

		return strApproverEmpId;
	}

	public String getPendingDeptId(String user_id) {



		String strApproverDepId = "";
		List<Map<String, Object>> dbIndentDts = null;
		String query = "SELECT APPROVER_DEPT_ID FROM SUMADHURA_APPROVER_MAPPING_DTL where EMP_ID = ? AND MODULE_TYPE='INDENT'";
		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {user_id});  



		for(Map<String, Object> prods : dbIndentDts) {
			strApproverDepId = prods.get("APPROVER_DEPT_ID")==null ? "" :   prods.get("APPROVER_DEPT_ID").toString();
			//icb.setFromEmpName(prods.get("EMP_NAME")==null ? "" :   prods.get("EMP_NAME").toString());		
		}

		return strApproverDepId;


	}

	public String  getIndentLevelComments(int indentNo) {


		List<Map<String, Object>> getcommentDtls = null;
		String strEmployeName = "";
		String strComments = "";
		String StrIndentLevelComments = "";

		String query = "select PURPOSE,SED.EMP_NAME from SUM_INT_CREATION_APPROVAL_DTLS SICAD , SUMADHURA_EMPLOYEE_DETAILS SED where "+
		" SED.EMP_ID = SICAD.INDENT_CREATE_APPROVE_EMP_ID "+
		" and INDENT_CREATION_ID = ? ";
		getcommentDtls = jdbcTemplate.queryForList(query, new Object[] {indentNo});

		if(getcommentDtls != null && getcommentDtls.size() > 0){
			for(Map<String, Object> prods : getcommentDtls) {

				strEmployeName = prods.get("EMP_NAME")==null ? "" : prods.get("EMP_NAME").toString();
				strComments = prods.get("PURPOSE")==null ? "" : prods.get("PURPOSE").toString();

				if((strEmployeName!=null && strComments!=null) && (!strEmployeName.equals("") && !strComments.equals(""))){

					StrIndentLevelComments +=  strEmployeName + " :  "+strComments +"   ,";
				}

			}
			if(StrIndentLevelComments!=null && !StrIndentLevelComments.equals("")){
				StrIndentLevelComments =  StrIndentLevelComments.substring(0,StrIndentLevelComments.length()-1);
			}

		}


		return StrIndentLevelComments;

	}
	public int getCentralIndentProcessSequenceNumber() {
		int centralIndentProcessSeqNum = jdbcTemplate.queryForInt("SELECT CENTRAL_INDENT_PROCESS_SEQ.NEXTVAL FROM DUAL");
		return centralIndentProcessSeqNum;
	}

	public int insertCentralIndentProcess(int indentProcessId,IndentCreationBean changedIndentDetails,int IndentCreationDetailsId,int site_id)
	{
		String query = "INSERT INTO SUMADHURA_CNTL_INDENT_PROCESS(INDENT_PROCESS_ID,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,CENTRAL_REQ_QUANTITY,ALLOCATED_QUANTITY,PENDING_QUANTIY,INTIATED_QUANTITY,STATUS"+
		",INDENT_REQ_SITE_ID,INDENT_CREATION_DETAILS_ID,CREATION_DATE,MEASUREMENT_ID,INDENT_REQ_QUANTITY) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,sysdate,?,?)";
		int result = jdbcTemplate.update(query, new Object[] {
				indentProcessId,
				changedIndentDetails.getProductId1(),
				changedIndentDetails.getSubProductId1(),
				changedIndentDetails.getChildProductId1(),
				changedIndentDetails.getRequiredQuantity1(),"0",
				changedIndentDetails.getRequiredQuantity1(),"0",
				"A",site_id,IndentCreationDetailsId,
				changedIndentDetails.getUnitsOfMeasurementId1(),
				changedIndentDetails.getRequiredQuantity1()
		});
		return result;
	}

	public int insertPurchaseIndentProcess(int purchaseIndentProcessId,IndentCreationBean purchaseIndentDetails,int IndentCreationDetailsId,int indentReqSiteId,String reqReceiveFrom)
	{
		String query = "INSERT INTO SUM_PURCHASE_DEPT_INDENT_PROSS(PURCHASE_DEPT_INDENT_PROSS_SEQ,PRODUCT_ID,SUB_PRODUCT_ID,CHILD_PRODUCT_ID,MEASUREMENT_ID,"+
		"PURCHASE_DEPT_REQ_QUANTITY, ALLOCATED_QUANTITY, PENDING_QUANTIY, PO_INTIATED_QUANTITY,"+
		"STATUS,INDENT_REQ_SITE_ID,REQ_RECEIVE_FROM,CREATION_DATE,INDENT_CREATION_DETAILS_ID,INDENT_REQ_QUANTITY) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,sysdate,?,?)";
		int result = jdbcTemplate.update(query, new Object[] {
				purchaseIndentProcessId,
				purchaseIndentDetails.getProductId1(),
				purchaseIndentDetails.getSubProductId1(),
				purchaseIndentDetails.getChildProductId1(),
				purchaseIndentDetails.getUnitsOfMeasurementId1(),
				purchaseIndentDetails.getRequiredQuantity1(),"0",
				purchaseIndentDetails.getRequiredQuantity1(),"0",
				"A",indentReqSiteId,reqReceiveFrom,IndentCreationDetailsId,
				purchaseIndentDetails.getRequiredQuantity1()
		});
		return result;
	}
	
	
	public void sendEmailDetails(String pendingEmpId,int indentNumber,String indentFrom,String indentTo,List<IndentCreationDetailsDto> listProductDetails, IndentCreationDto indentCreationDto,String strIndentLevelComments,List<IndentCreationBean> strProductsChangedComments, int siteWiseIndentNo,int portNo){


		try{
			List<Map<String, Object>> indentCreationDtls = null;
			List<String> toMailListArrayList = new ArrayList<String>();

			if(!pendingEmpId.equals("-"))
			{
				indentCreationDtls = getIndentCreationDetails(indentNumber, "approvalToEmployee");
			}else if(pendingEmpId.equals("-"))
			{
				indentCreationDtls = getIndentCreationDetails(indentNumber,"approvalToDept");

				toMailListArrayList = getAllEmployeeEmailsUnderDepartment(indentCreationDto.getPendingDeptId());
			}




			String strIndentFromSite = "";
			String strIndentFromDate = "";
			String strEmailAddress =   "";
			String strScheduleDate = "";
			for(Map<String, Object> objIndentCreationDtls : indentCreationDtls) {



				strIndentFromSite = objIndentCreationDtls.get("SITE_NAME")==null ? "" :   objIndentCreationDtls.get("SITE_NAME").toString();
				strIndentFromDate = objIndentCreationDtls.get("CREATE_DATE")==null ? "" :   objIndentCreationDtls.get("CREATE_DATE").toString();
				strEmailAddress = objIndentCreationDtls.get("Email_id")==null ? "" :   objIndentCreationDtls.get("Email_id").toString();
				strScheduleDate = objIndentCreationDtls.get("scheduleDate")==null ? "" :   objIndentCreationDtls.get("scheduleDate").toString();
			}

			if(strEmailAddress.contains(",")){
				for(String strEmailAddress1 : strEmailAddress.split(","))
				{
					toMailListArrayList.add(strEmailAddress1);
				}
			}
			else{
			toMailListArrayList.add(strEmailAddress);
			}
			if(toMailListArrayList.size() > 0){
				String emailto [] = null ;
				emailto = new String[toMailListArrayList.size()];
				toMailListArrayList.toArray(emailto);



				List<IndentCreationBean> list =  getndentChangedDetails(indentNumber);


				EmailFunction objEmailFunction = new EmailFunction();

				objEmailFunction.sendIndentCreationApprovalMailDetails( indentTo, indentNumber, indentFrom,strIndentFromSite, strIndentFromDate, strScheduleDate,emailto,listProductDetails,indentCreationDto,strIndentLevelComments,list,siteWiseIndentNo,portNo);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public 	List<Map<String, Object>> getIndentCreationDetails( int intIndentNumber,String aprroverTo) {



		List<Map<String, Object>> dbIndentProcessDts = null;
		String query = "";
		if(aprroverTo.equals("approvalToEmployee")){


			query = " select SITE_NAME,CREATE_DATE,EMP_EMAIL as Email_id,SCHEDULE_DATE as scheduleDate from  SITE S, SUMADHURA_INDENT_CREATION SIC,SUMADHURA_EMPLOYEE_DETAILS SED where "+
			"SIC.SITE_ID = S.SITE_ID and SIC.PENDING_EMP_ID = SED.EMP_ID and SIC.INDENT_CREATION_ID = ?";

		}else{
			query = " select SITE_NAME,CREATE_DATE,DEPT_EMAIL as Email_id,SCHEDULE_DATE as scheduleDate from  SITE S, SUMADHURA_INDENT_CREATION SIC,SUMADHURA_DEPARTMENT_DETAILS SDD where "+
			" SIC.SITE_ID = S.SITE_ID and SIC.PENDIND_DEPT_ID = SDD.DEPT_ID and SIC.INDENT_CREATION_ID = ? ";

		}

		dbIndentProcessDts = jdbcTemplate.queryForList(query, new Object[] {intIndentNumber});

		return dbIndentProcessDts;

	}


	
	public List<String>  getAllEmployeeEmailsUnderDepartment(String deptId) {

		List<Map<String, Object>> dbIndentDts = null;
		String strEmailId = "";
		List<String> objList = new ArrayList<String>();
		//thisIsAStringArray[5] = "FFF";
		String query = " select EMP_EMAIL from SUMADHURA_EMPLOYEE_DETAILS SED where DEPT_ID = ? ";


		dbIndentDts = jdbcTemplate.queryForList(query, new Object[] {deptId});

		if(dbIndentDts!= null){



			for(Map<String, Object> prods : dbIndentDts) {



				strEmailId = prods.get("EMP_EMAIL")==null ? "" :   prods.get("EMP_EMAIL").toString();


				if(!strEmailId.equals("")){
					if(strEmailId.contains(",")){
						for(String strEmailId1 : strEmailId.split(","))
						{
							objList.add(strEmailId1);
						}
					}
					else{
					objList.add(strEmailId);
					}
				}

			}	
		}

		return objList;
	}
	
	public List<IndentCreationBean>  getndentChangedDetails(int indentNo) {


		List<Map<String, Object>> getcommentDtls = null;
		String strEmployeName = "";
		String strComments = "";
		String METERIAL_EDIT_COMMENT = "";
		List<IndentCreationBean> editList = new  ArrayList<IndentCreationBean>();
		try{

			String query = "  select METERIAL_EDIT_COMMENT from SUMADHURA_INDENT_CREATION where INDENT_CREATION_ID = ? ";
			getcommentDtls = jdbcTemplate.queryForList(query, new Object[] {indentNo});

			if(getcommentDtls != null && getcommentDtls.size() > 0) {
				for(Map<String, Object> prods : getcommentDtls) {

					strEmployeName = prods.get("METERIAL_EDIT_COMMENT")==null ? "  " : prods.get("METERIAL_EDIT_COMMENT").toString();


				}
				//METERIAL_EDIT_COMMENT =  strEmployeName.substring(0,strEmployeName.length()-1);
			}




			if(strEmployeName.contains("@@@")){
				String strEditCommentsArr [] = strEmployeName.split("@@@");
				for(int j = 0; j< strEditCommentsArr.length;j++){
					IndentCreationBean objCommentIndentCreationBean  = new IndentCreationBean();
					objCommentIndentCreationBean.setMaterialEditComment(strEditCommentsArr[j]);
					editList.add(objCommentIndentCreationBean);
				}


			}

		}catch(Exception e){
			e.printStackTrace();
		}

		return editList;

	}
	
	//================ above is approval function
	
	//================ below is rejection function
	

	public String rejectIndentCreationFromMail( HttpServletRequest request) {
		String response = "";
		
		try
		{
			int indentNumber= Integer.parseInt(request.getParameter("indentNumber"));
			if(request.getParameter("tempPass").equals(getTempPasswordOfIndent(indentNumber))){}else{return "WrongPassword";}

			IndentCreationDto indentCreationDto = new IndentCreationDto();
			indentCreationDto.setTempPass(CommonUtilities.getStan());
			int response2 = rejectIndentCreation(indentNumber,indentCreationDto);
			
			System.out.println("Indent Rejected via EMail");
			response = "Success";
		}
		catch(Exception e)
		{
			
			System.out.println("Indent Rejection Failed via Email");
			response = "Failed";
			e.printStackTrace();
		}
		return response;
	}
	
	public int rejectIndentCreation(int indentCreationSeqNum, IndentCreationDto indentCreationDto) {
		String query = "UPDATE SUMADHURA_INDENT_CREATION set STATUS = 'I', MODIFYDATE= sysdate, TEMPPASS = ?  "+
		"WHERE INDENT_CREATION_ID = ?";
		int result = jdbcTemplate.update(query, new Object[] {
				indentCreationDto.getTempPass(), indentCreationSeqNum
		});
		return result;
	}
}
