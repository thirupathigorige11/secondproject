package com.sumadhura.transdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.userDetails;
import com.sumadhura.util.DBConnection;


@Repository
public class UtilDao {


	public  List<Map<String, Object>> getAllSites() {
		JdbcTemplate template = null;
		List<Map<String, Object>> totalProductList = null;
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select SITE_ID, SITE_NAME  from  SITE";
			System.out.println(sql);

			totalProductList = template.queryForList(sql, new Object[] {});

			/*
			 * for(Map productList : TotalProductList){ objProductDetails = new
			 * ProductDetails();
			 * 
			 * objProductDetails.setProduct_Name((productList.get("name") ==
			 * null ? "" : productList.get("name").toString()));
			 * listProductList.add(objProductDetails); }
			 */

		} catch (Exception e) {
			e.printStackTrace();

		}

		return totalProductList;
	}



	//******************************************

	public List<Map<String,Object>> getTotalProducts() {
		JdbcTemplate template=null;
		List<Map<String,Object>> totalProductList = null;
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "SELECT PRODUCT_ID, NAME FROM PRODUCT WHERE STATUS = 'A'";

			System.out.println(sql);

			totalProductList = template.queryForList(sql,new Object[]{});


		} catch (Exception e) {
			e.printStackTrace();

		}

		return totalProductList;
	}


	public List<ProductDetails> getAllSubProducts(String strProductId) {
		JdbcTemplate template=null;
		List<Map<String,Object>> AllProductList = null;
		ProductDetails objProductDetails = null;
		List<ProductDetails> listAllProductList =  new ArrayList<ProductDetails>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select SUB_PRODUCT_ID,NAME from SUB_PRODUCT where STATUS = ? and PRODUCT_ID = ?";

			System.out.println(sql);

			AllProductList = template.queryForList(sql,new Object[]{"A",strProductId});
			objProductDetails = new ProductDetails();
			objProductDetails.setSub_ProductName("");
			objProductDetails.setSub_ProductId("");
			listAllProductList.add(objProductDetails);
			for(Map productList :AllProductList){
				objProductDetails = new ProductDetails();
				objProductDetails.setSub_ProductName((productList.get("NAME") == null ? "" : productList.get("NAME").toString()));
				objProductDetails.setSub_ProductId((productList.get("SUB_PRODUCT_ID") == null ? "" : productList.get("SUB_PRODUCT_ID").toString()));
				listAllProductList.add(objProductDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return listAllProductList;
	}

	public List<ProductDetails> getAllChildProducts(String strSubProductId) {
		JdbcTemplate template=null;
		List<Map<String,Object>> AllProductList = null;
		ProductDetails objProductDetails = null;
		List<ProductDetails> listAllProductList =  new ArrayList<ProductDetails>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select CHILD_PRODUCT_ID,NAME from CHILD_PRODUCT where SUB_PRODUCT_ID = ? and STATUS = ?";

			System.out.println(sql);

			AllProductList = template.queryForList(sql,new Object[]{strSubProductId,"A"});

			objProductDetails = new ProductDetails();
			objProductDetails.setChild_ProductName("");
			objProductDetails.setChild_ProductId("");
			listAllProductList.add(objProductDetails);
			for(Map productList :AllProductList){
				objProductDetails = new ProductDetails();
				objProductDetails.setChild_ProductName((productList.get("NAME") == null ? "" : productList.get("NAME").toString()));
				objProductDetails.setChild_ProductId((productList.get("CHILD_PRODUCT_ID") == null ? "" : productList.get("CHILD_PRODUCT_ID").toString()));
				listAllProductList.add(objProductDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return listAllProductList;
	}




	public List<String> getProductsBySearch(String product) {
		JdbcTemplate template=null;
		List<Map<String,Object>> TotalProductList = null;
		//ProductDetails objProductDetails = null;
		String strName = "";
		List<String> listProductList =  new ArrayList<String>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select name from product where upper(NAME) like upper(?) and STATUS = 'A'";

			System.out.println(sql);

			TotalProductList = template.queryForList(sql,new Object[]{product+"%"});

			System.out.println("UtilsDao class TotalProductList  "+TotalProductList);
			for(Map productList : TotalProductList){
				//	objProductDetails = new ProductDetails();

				strName = (productList.get("name") == null ? "" : productList.get("name").toString());
				listProductList.add(strName);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return listProductList;
	}

	public List<String> getSubProductsBySearch(String subproduct) {
		JdbcTemplate template=null;
		List<Map<String,Object>> TotalSubProductList = null;
		//ProductDetails objProductDetails = null;
		String strName = "";
		List<String> listSubProductList =  new ArrayList<String>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select name from sub_product where upper(NAME) like upper(?) and STATUS = 'A'";

			System.out.println(sql);

			TotalSubProductList = template.queryForList(sql,new Object[]{subproduct+"%"});

			for(Map productList : TotalSubProductList){
				//	objProductDetails = new ProductDetails();
				strName = (productList.get("name") == null ? "" : productList.get("name").toString());
				//objProductDetails.setProduct_Name((productList.get("product_name") == null ? "" : productList.get("product_name").toString()));
				listSubProductList.add(strName);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return listSubProductList;
	}
	public List<String> getchildProductsBySearch(String strSubProductId,String strSearchingChildProdName) {
		JdbcTemplate template=null;
		List<Map<String,Object>> AllProductList = null;
		//	ProductDetails objProductDetails = null;
		String strName = "";
		List<String> listAllProductList =  new ArrayList<String>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select NAME from CHILD_PRODUCT where upper(NAME) like upper(?) and STATUS = 'A' and SUB_PRODUCT_ID = ?";

			System.out.println(sql);

			AllProductList = template.queryForList(sql,new Object[]{strSearchingChildProdName+"%",strSubProductId});

			for(Map productList :AllProductList){
				//	objProductDetails = new ProductDetails();
				strName = (productList.get("NAME") == null ? "" : productList.get("NAME").toString());
				listAllProductList.add(strName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return listAllProductList;
	}

	public List<String> getVendorsBySearch(String vendor) {
		JdbcTemplate template=null;
		List<Map<String,Object>> AllVendorsList = null;
		//VendorDetails objVendorDetails = null;
		String strName = "";
		List<String> listAllVendorsList =  new ArrayList<String>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select VENDOR_NAME from vendor_details where upper(VENDOR_NAME) like upper(?) and STATUS = 'A'";

			System.out.println(sql);

			AllVendorsList = template.queryForList(sql,new Object[]{vendor+"%"});

			for(Map vendorList :AllVendorsList){
				//objVendorDetails = new VendorDetails();
				strName = (vendorList.get("vendor_name") == null ? "" : vendorList.get("vendor_name").toString());

				listAllVendorsList.add(strName);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return listAllVendorsList;
	}


	public userDetails getUserDetails(String user_id) {
		JdbcTemplate template=null;
		List<Map<String,Object>> userDetailsList = null;
		//VendorDetails objVendorDetails = null;
		String strName = "";
		userDetails objuserDetails = null;
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select EMP_NAME,MOBILE_NUMBER,EMP_EMAIL from SUMADHURA_EMPLOYEE_DETAILS where EMP_ID = ?";

			System.out.println(sql);

			userDetailsList = template.queryForList(sql,new Object[]{user_id});

			for(Map mapuserDetailsList :userDetailsList){
				objuserDetails = new userDetails();
				objuserDetails.setUserName(mapuserDetailsList.get("EMP_NAME") == null ? "" : mapuserDetailsList.get("EMP_NAME").toString());
				objuserDetails.setMobileNo(mapuserDetailsList.get("MOBILE_NUMBER") == null ? "" : mapuserDetailsList.get("MOBILE_NUMBER").toString());
				objuserDetails.setEmailId(mapuserDetailsList.get("EMP_EMAIL") == null ? "" : mapuserDetailsList.get("EMP_EMAIL").toString());


			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return objuserDetails;
	}


	public String []  getEmployeesEmailId(String siteId) {
		JdbcTemplate template=null;
		List<Map<String,Object>> userDetailsList = null;
		//VendorDetails objVendorDetails = null;
		String strName = "";
		String[] emailArr = null;
		String emailId = "";
		ArrayList<String> objArrayList = new ArrayList<String>();
		try {

			template = new JdbcTemplate(DBConnection.getDbConnection());

			String sql = "select EMP_EMAIL from VENDOR_DETAILS WHERE VENDOR_ID=?";

			System.out.println(sql);

			userDetailsList = template.queryForList(sql,new Object[]{siteId});

			for(Map mapuserDetailsList :userDetailsList){

				emailId = mapuserDetailsList.get("EMP_EMAIL") == null ? "-" : mapuserDetailsList.get("EMP_EMAIL").toString();

				if(!emailId.equals("")){

					objArrayList.add(emailId);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		if(objArrayList.size() > 0){
			String[] arr=new String[objArrayList.size()];
			emailArr =  objArrayList.toArray(arr);
		}else{
			emailArr = null;
		}
		
	
		
		return emailArr;
	}


}
