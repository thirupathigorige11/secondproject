package com.sumadhura.service;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.Model;

import com.sumadhura.bean.AuditLogDetailsBean;
import com.sumadhura.dto.IndentIssueDto;
import com.sumadhura.dto.IndentIssueRequesterDto;
import com.sumadhura.dto.IndentReceiveDto;
import com.sumadhura.transdao.IndentIssueDao;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Service("iisClass")
public class IndentIssueServiceImpl extends UIProperties implements IndentIssueService {

	@Autowired
	private IndentIssueDao iid;

	@Autowired
	PlatformTransactionManager transactionManager;

	@Override
	public Map<String, String> loadProds() {
		return iid.loadProds();
	}

	@Override
	public String loadSubProds(String prodId) {
		return iid.loadSubProds(prodId);
	}

	@Override
	public String loadChildProds(String subProductId) {
		return iid.loadChildProds(subProductId);
	}

	@Override
	public String loadIndentIssueMeasurements(String childProdId) {
		return iid.loadIndentIssueMeasurements(childProdId);
	}

	@Override
	public int insertRequesterData(int indentEntryId, String userId, String siteId, IndentIssueRequesterDto iiReqDto) {
		return iid.insertRequesterData(indentEntryId, userId, siteId, iiReqDto);
	}

	@Override
	public int insertIndentIssueData(int indentEntrySeqNum, IndentIssueDto indIssDto) {		
		return iid.insertIndentIssueData(indentEntrySeqNum, indIssDto,"","","", "", "");
	}

	@Override
	public int updateIndentAvalibility(IndentIssueDto indIssDto, String siteId) {
		return iid.updateIndentAvalibility(indIssDto, siteId);
	}

	@Override
	public void updateIndentAvalibilityWithNewIndent(IndentIssueDto indIssDto, String siteId) {
		iid.updateIndentAvalibilityWithNewIndent(indIssDto, siteId);
	}

	@Override
	public int getIndentEntrySequenceNumber() {
		return iid.getIndentEntrySequenceNumber();
	}

	@Override
	public String indentIssueProcess(Model model, HttpServletRequest request, HttpSession session) {

		//String viewToBeSelected = null;
		String result = "";
		IndentIssueRequesterDto iird = null;
		String strUserId = "";
		String strSiteId = "";
		int indentEntrySeqNum = 0;
		IndentIssueDto issueDto = null;

		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		WriteTrHistory.write("Tr_Opened in InIs_indIss, ");

		try {
			String recordsCount = request.getParameter("numbeOfRowsToBeProcessed");
			logger.info("Rows To Be Processed = "+recordsCount);
			//int countOfRecords = Integer.valueOf(recordsCount);
			String numOfRec[] = null;
			if((recordsCount != null) && (!recordsCount.equals(""))) {
				numOfRec = recordsCount.split("\\|");
			}

			if(numOfRec != null && numOfRec.length > 0) {

				String prod = "Product";
				String subProd = "SubProduct";
				String childProd = "ChildProduct";
				//String hsnCode = "HSNCode";
				String qty = "Quantity";
				String measurements = "UnitsOfMeasurement";
				String uOrF = "UOrF";
				String remarks = "Remarks";

				String reqId = request.getParameter("ReqId");
				String reqDate = request.getParameter("ReqDate");
				String requesterName = request.getParameter("RequesterName");
				String contractorName = request.getParameter("ContractorName");
				String requesterId = request.getParameter("RequesterId");
				//String note = request.getParameter("Note");
				String purpose = request.getParameter("Purpose");
				String slipNumber = request.getParameter("SlipNumber");
				WriteTrHistory.write("Site:"+session.getAttribute("SiteName")+" , User:"+session.getAttribute("UserName")+" , Date:"+new java.util.Date()+" , SlipNumber:"+slipNumber);

				double strPriceListQuantity = 0.0;
				if(requesterName != null && !requesterName.equalsIgnoreCase(""))
				{
					requesterName = requesterName.toUpperCase();
				} if(StringUtils.isNotBlank(contractorName)){
					contractorName = contractorName.toUpperCase();

				}

				logger.info(reqId+" <--> "+reqDate+" <--> "+requesterName+" <--> "+requesterId+" <--> "+purpose+" <--> "+slipNumber+contractorName);

				String blk = request.getParameter("Block");

				String blockId = "";
				String blockName = "";

				if((blk != null) && (!blk.equals(""))) {
					String blockInfo[] = blk.split("\\$");				
					blockId = blockInfo[0];
					blockName = blockInfo[1];
				}

				logger.info("Block Id = "+blockId+" and Block Name = "+blockName);	

				String flr = request.getParameter("Floor");

				String floorId = "";
				String floorName = "";

				if((flr != null) && (!flr.equals(""))) {					
					String floorInfo[] = flr.split("\\$");					
					floorId = floorInfo[0];
					floorName = floorInfo[1];
				}

				logger.info("Floor Id = "+floorId+" and Floor Name = "+floorName);

				String flt = request.getParameter("FlatNumber");

				String flatId = "";
				String flatName = "";

				if((flt != null) && (!flt.equals(""))) {					
					String flatInfo[] = flt.split("\\$");					
					flatId = flatInfo[0];
					flatName = flatInfo[1];
				}
				session = request.getSession(true);
				strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
				strUserId = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();				

				String strReqMonthStart = "";
				if(reqDate.contains("-")){
					String arr[] = reqDate.split("-");
					String strMonth = arr[1];
					String strYear = arr[2];
					strReqMonthStart = "01"+"-"+strMonth+"-"+strYear;
					int intIssueCount = iid.getIssuesCount( slipNumber, strSiteId, strReqMonthStart,reqDate);
					if(intIssueCount>0){
						request.setAttribute("exceptionMsg", "Issue slip already entered");
						result = "Failed";
						transactionManager.rollback(status);
						WriteTrHistory.write("Tr_Completed");
						return result;
					}
				}else{
					request.setAttribute("exceptionMsg", "Date Format is wrong");
					result = "Failed";
					transactionManager.rollback(status);
					WriteTrHistory.write("Tr_Completed");
					return result;
				}



				/*else {
					request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Issue.");
					//viewToBeSelected = "indentIssueResponse";
					result = "Failed";
				}	*/


				logger.info("Flat Id = "+flatId+" and Flat Name = "+flatName);

				iird = new IndentIssueRequesterDto();

				iird.setReqId(reqId);
				iird.setReqDate(reqDate);
				iird.setRequesterName(requesterName);
				iird.setContractorName(contractorName);
				iird.setRequesterId(requesterId);
				//iird.setNote(note);
				iird.setPurpose(purpose);
				iird.setSlipNumber(slipNumber);

				//userId = 1013
				//site_id = 021
				//int indentEntrySeqNum = iid.getIndentEntrySequenceNumber();
				indentEntrySeqNum = Integer.valueOf(reqId);
				session.setAttribute("indentEntrySeqNum",indentEntrySeqNum);
				//logger.info("Indent Entry Seq. Num. = "+indentEntrySeqNum);				

				if (StringUtils.isNoneBlank(strSiteId)) {

				} else {
					transactionManager.rollback(status);
					WriteTrHistory.write("Tr_Completed");
					return result = "SessionFailed";
				}
				//int insertRequesterReult = iid.insertRequesterData(indentEntrySeqNum, strUserId, strSiteId, reqId, reqDate, requesterName, requesterId, note);
				int insertRequesterReult = iid.insertRequesterData(indentEntrySeqNum, strUserId, strSiteId, iird);

				if(insertRequesterReult >= 1) {
					Double totalAmt = 0.0;
					for(String num : numOfRec) {

						num = num.trim();

						//PROD101$Cement <--> SUBPROD101$KCP <--> CHLDPROD101$TetraBag <--> tyty <--> 43 <--> 101$KG
						String product = request.getParameter(prod+num);				

						String prodsInfo[] = product.split("\\$");

						String prodId = prodsInfo[0];
						String prodName = prodsInfo[1];
						//logger.info("Product Id = "+prodId+" and Product Name = "+prodName);					

						String subProduct = request.getParameter(subProd+num);

						String subProdsInfo[] = subProduct.split("\\$");

						String subProdId = subProdsInfo[0];
						String subProdName = subProdsInfo[1];					
						//logger.info("Sub Product Id = "+subProdId+" and Sub Product Name = "+subProdName);

						String childProduct = request.getParameter(childProd+num);

						String childProdsInfo[] = childProduct.split("\\$");

						String childProdId = childProdsInfo[0];
						String childProdName = childProdsInfo[1];					
						//logger.info("Child Product Id = "+childProdId+" and Child Product Name = "+childProdName);

						String quantity = request.getParameter(qty+num);

						String unitsOfMeasurement = request.getParameter(measurements+num);

						String measurementsInfo[] = unitsOfMeasurement.split("\\$");

						String measurementId = measurementsInfo[0];
						String measurementName = measurementsInfo[1];
						//logger.info("Measurement Id = "+measurementId+" and Measurement Name = "+measurementName);

						//String hsnCd = request.getParameter(hsnCode+num);
						String hsnCd = "";

						String uf = request.getParameter(uOrF+num);

						String rems = request.getParameter(remarks+num);

						//logger.info(product+" <--> "+subProduct+" <--> "+childProduct+" <--> "+hsnCd+" <--> "+quantity+" <--> "+unitsOfMeasurement);
						logger.info(prodId+" <--> "+prodName+" <--> "+subProdId+" <--> "+subProdName+" <--> "+childProdId+" <--> "+childProdName+" <--> "+quantity+" <--> "+measurementId+" <--> "+measurementName+" <--> "+hsnCd+" <--> "+uf+" <--> "+rems);

						if (StringUtils.isNotBlank(prodId) && StringUtils.isNotBlank(subProdId) &&StringUtils.isNotBlank(childProdId)) {

						} else {
							transactionManager.rollback(status);
							WriteTrHistory.write("Tr_Completed");
							return result = "Failed";
						}
						String methodName = "";
						double doubleQuantity = 0.0;
						methodName  = validateParams.getProperty(childProdId) == null ? "" : validateParams.getProperty(childProdId).toString();

						if(!methodName.equals("")) {	
							Map<String, String> values = null;

							String strMesurmentConversionClassName  = validateParams.getProperty("MesurmentConversionClassName") == null ? "" : validateParams.getProperty("MesurmentConversionClassName").toString();

							//String strMesurmentConversionClassName = "comsumadhura.util.MesurmentConversions";
							Class<?> strMesurmentConversionClass = Class.forName(strMesurmentConversionClassName); // convert string classname to class
							Object mesurment = strMesurmentConversionClass.newInstance(); // invoke empty constructor


							double doubleActualQuantity  =  Double.valueOf(validateParams.getProperty(childProdId+"ActualQuantity") == null ? "0" : validateParams.getProperty(childProdId+"ActualQuantity").toString());
							double doubleInputQuantity =  Double.valueOf(quantity);
							String strConversionMesurmentId  =  validateParams.getProperty(childProdId+"ID") == null ? "" : validateParams.getProperty(childProdId+"ID").toString();
							// with multiple parameters
							//methodName = "convertCHP00536";
							Class<?>[] paramTypes = {String.class,double.class,double.class, String.class};
							Method printDogMethod = mesurment.getClass().getMethod(methodName, paramTypes);
							values=(Map<String, String>) printDogMethod.invoke(mesurment,"0",doubleActualQuantity,doubleInputQuantity,measurementName);	            
							for(Map.Entry<String, String> retVal : values.entrySet()) {
								quantity=retVal.getKey();
								//prc=retVal.getValue(); 
							}	
							//quantity =  String.valueOf(doubleQuantity);
							measurementId = strConversionMesurmentId;
							measurementName = validateParams.getProperty(childProdId+"IDMNAME") == null ? "" : validateParams.getProperty(childProdId+"IDMNAME").toString();
						}




						issueDto = new IndentIssueDto();

						issueDto.setProdId(prodId);
						issueDto.setProdName(prodName);
						issueDto.setSubProdId(subProdId);
						issueDto.setSubProdName(subProdName);
						issueDto.setChildProdId(childProdId);
						issueDto.setChildProdName(childProdName);
						issueDto.setQuantity(quantity);
						issueDto.setMeasurementId(measurementId);
						issueDto.setMeasurementName(measurementName);
						issueDto.setHsnCd(hsnCd);
						issueDto.setuOrF(uf);
						issueDto.setRemarks(rems);						
						issueDto.setBlockId(blockId);
						issueDto.setFloorId(floorId);
						issueDto.setFlatId(flatId);
						issueDto.setDate(reqDate);

						//int indentEntryDetailsSeqNum = IndentIssueDao.getIndentEntryDetailsSeqNum();
						//logger.info("Indent Entry Details Seq. Num. = "+indentEntryDetailsSeqNum);					

						//29-july-2017 written by Madhu start
						List<IndentIssueDto> list = iid.getPriceListDetails(issueDto, strSiteId);
						//16-aug iid.updateIssueDetailsIntoSumadhuraCloseBalance(issueDto, strSiteId);
						if (null != list && list.size() > 0) {
							for (int i = 0; i < list.size(); i++) {
								IndentIssueDto dto = list.get(i);
								Double issuQuantiy = Double.parseDouble(issueDto.getQuantity());
								Double availQty = Double.parseDouble(dto.getQuantity());
								if (Math.abs(availQty) == Math.abs(issuQuantiy)) {
									totalAmt +=  Double.valueOf(dto.getAmount())*issuQuantiy;
									//iid.updateIndentEntryAmountColumn(String.valueOf(Double.valueOf(dto.getAmount())*issuQuantiy), String.valueOf(issuQuantiy), String.valueOf(indentEntrySeqNum));
									int insertIndentIssueResult = iid.insertIndentIssueData(indentEntrySeqNum, issueDto, dto.getAmount(), String.valueOf(issuQuantiy), dto.getPriceId(), strUserId, strSiteId);
									//iid.updateSumadhuraPriceListIndentEntryDetailsId(dto.getPriceId(), String.valueOf(indentEntrySeqNum));
									if (insertIndentIssueResult >= 1) {
										int updateIndentAvalibilityResult = iid.updateIndentAvalibility(issueDto, strSiteId);
										// viewToBeSelected =
										// "indentReceiveResponse";
										result = "Success";
										if (updateIndentAvalibilityResult == 0) {
											// Making a new entry if new
											// product.
											iid.updateIndentAvalibilityWithNewIndent(issueDto, strSiteId);
											// viewToBeSelected =
											// "indentReceiveResponse";
											result = "Success";
										}
										// transactionManager.commit(status);
										iid.updatePriceListDetails("0", "I", dto.getPriceId());
										//iid.updateIssueDetailsIntoSumadhuraCloseBalance(issueDto, strSiteId, dto.getAmount(), issuQuantiy);
										iid.updateIssueDetailsSumadhuClosingBalByProduct(issueDto, strSiteId, dto.getAmount(), issuQuantiy);
									}

									break;
								} else if (Math.abs(availQty) > Math.abs(issuQuantiy)) {
									totalAmt +=  Double.valueOf(dto.getAmount())*issuQuantiy;
									//iid.updateIndentEntryAmountColumn(String.valueOf(Math.abs(Double.valueOf(dto.getAmount().replace(",","").trim())) * Math.abs(issuQuantiy)), String.valueOf(issuQuantiy), String.valueOf(indentEntrySeqNum));
									int insertIndentIssueResult = iid.insertIndentIssueData(indentEntrySeqNum, issueDto, dto.getAmount(), String.valueOf(issuQuantiy), dto.getPriceId(), strUserId, strSiteId);
									//	iid.updateSumadhuraPriceListIndentEntryDetailsId(dto.getPriceId(), String.valueOf(indentEntrySeqNum));
									if (insertIndentIssueResult >= 1) {
										int updateIndentAvalibilityResult = iid.updateIndentAvalibility(issueDto, strSiteId);
										// viewToBeSelected =
										// "indentReceiveResponse";
										result = "Success";
										if (updateIndentAvalibilityResult == 0) {
											// Making a new entry if new
											// product.
											iid.updateIndentAvalibilityWithNewIndent(issueDto, strSiteId);
											// viewToBeSelected =
											// "indentReceiveResponse";
											result = "Success";
										}
										// transactionManager.commit(status);
										Double remaingQty = availQty - issuQuantiy;
										iid.updatePriceListDetails(String.valueOf(remaingQty), "A", dto.getPriceId());
										//iid.updateIssueDetailsIntoSumadhuraCloseBalance(issueDto, strSiteId, dto.getAmount(), issuQuantiy);
										iid.updateIssueDetailsSumadhuClosingBalByProduct(issueDto, strSiteId, dto.getAmount(), issuQuantiy);

									}

									break;

								} else {
									Double remainQty = issuQuantiy;


									List<IndentIssueDto> objList = iid.getPriceListDetails(issueDto, strSiteId, "");
									if (null != objList && objList.size() > 0) {


										for (int j = 0; j < objList.size(); j++) {
											if(remainQty > 0){	

												IndentIssueDto objDTO = objList.get(j);
												Double availQty1 = Double.parseDouble(objDTO.getQuantity());
												if (Math.abs(remainQty) > Math.abs(availQty1)) {
													remainQty = remainQty - availQty1;
													issueDto.setQuantity(String.valueOf(availQty1));
													int insertIndentIssueResult = iid.insertIndentIssueData(indentEntrySeqNum, issueDto, objDTO.getAmount(), String.valueOf(availQty1), objDTO.getPriceId(), strUserId, strSiteId);
													//	iid.updateSumadhuraPriceListIndentEntryDetailsId(dto.getPriceId(), String.valueOf(indentEntrySeqNum));
													if (insertIndentIssueResult >= 1) {
														totalAmt += Double.parseDouble(objDTO.getAmount()) * Double.parseDouble(objDTO.getQuantity()) ;
														issueDto.setQuantity(String.valueOf(availQty1));
														int updateIndentAvalibilityResult = iid.updateIndentAvalibility(issueDto, strSiteId);
														// viewToBeSelected =
														// "indentReceiveResponse";
														result = "Success";
														if (updateIndentAvalibilityResult == 0) {
															// Making a new entry if
															// new product.
															iid.updateIndentAvalibilityWithNewIndent(issueDto, strSiteId);
															// viewToBeSelected =
															// "indentReceiveResponse";
															result = "Success";
														}
														// transactionManager.commit(status);
														iid.updatePriceListDetails("0", "I", objDTO.getPriceId());
														//iid.updateIssueDetailsIntoSumadhuraCloseBalance(issueDto, strSiteId, objDTO.getAmount(), availQty1);
														iid.updateIssueDetailsSumadhuClosingBalByProduct(issueDto, strSiteId, objDTO.getAmount(), availQty1);

													}

												} else {
													Double remin = remainQty;
													totalAmt += Double.valueOf(objDTO.getAmount()) * remainQty ;
													//remainQty = Math.abs(availQty1) - Math.abs(remainQty);
													strPriceListQuantity = Math.abs(availQty1) - Math.abs(remainQty);
													remainQty = Math.abs(remainQty) - Math.abs(availQty1);


													issueDto.setQuantity(String.valueOf(remin));
													//iid.updateIndentEntryAmountColumn(objDTO.getAmount(), String.valueOf(remin), String.valueOf(indentEntrySeqNum));
													int insertIndentIssueResult = iid.insertIndentIssueData(indentEntrySeqNum, issueDto, objDTO.getAmount(), String.valueOf(remin), objDTO.getPriceId(), strUserId, strSiteId);
													//iid.updateSumadhuraPriceListIndentEntryDetailsId(dto.getPriceId(), String.valueOf(indentEntrySeqNum));
													if (insertIndentIssueResult >= 1) {
														issueDto.setQuantity(String.valueOf(remin));
														int updateIndentAvalibilityResult = iid.updateIndentAvalibility(issueDto, strSiteId);
														// viewToBeSelected =
														// "indentReceiveResponse";
														result = "Success";
														if (updateIndentAvalibilityResult == 0) {
															// Making a new entry if
															// new product.
															iid.updateIndentAvalibilityWithNewIndent(issueDto, strSiteId);
															result = "Success";
														}

														if(strPriceListQuantity == 0.0){
															iid.updatePriceListDetails(String.valueOf(strPriceListQuantity), "I", objDTO.getPriceId());
														}else{
															iid.updatePriceListDetails(String.valueOf(strPriceListQuantity), "A", objDTO.getPriceId());
														}
														//	iid.updateIssueDetailsIntoSumadhuraCloseBalance(issueDto, strSiteId, objDTO.getAmount(), remin);
														iid.updateIssueDetailsSumadhuClosingBalByProduct(issueDto, strSiteId, objDTO.getAmount(), remin);
													}

												}

											}else{
												break;
											}
										}
										//iid.updateIndentEntryAmountColumn(String.valueOf(totalAmt), String.valueOf(issuQuantiy), String.valueOf(indentEntrySeqNum));
									}
								}

							}
						} else {
							transactionManager.rollback(status);
							WriteTrHistory.write("Tr_Completed");
							return result = "No Stock";
						}


						//29-july-2017 written by Madhu end
						/*29-july-2017 written by Madhu start int insertIndentIssueResult = iid.insertIndentIssueData(indentEntrySeqNum, issueDto,"","");
						if(insertIndentIssueResult >= 1) {
							int updateIndentAvalibilityResult = iid.updateIndentAvalibility(issueDto, strSiteId);
							//viewToBeSelected = "indentReceiveResponse";
							result = "Success";
							if(updateIndentAvalibilityResult == 0) {
								//Making a new entry if new product.
								iid.updateIndentAvalibilityWithNewIndent(issueDto, strSiteId);
								//viewToBeSelected = "indentReceiveResponse";
								result = "Success";
							}
							//transactionManager.commit(status);
						} 29-july-2017 written by Madhu end */
					}

					iid.updateIndentEntryAmountColumn(String.valueOf(totalAmt), "", String.valueOf(indentEntrySeqNum));
				}
				else {
					request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Issue.");
					//viewToBeSelected = "indentIssueResponse";
					transactionManager.rollback(status);
					WriteTrHistory.write("Tr_Completed");
					return result = "Failed";
				}				
			}
			else {
				request.setAttribute("exceptionMsg", "Sorry!, No Records Were Found To Be Processed.");
				//viewToBeSelected = "indentIssueResponse";
				transactionManager.rollback(status);
				WriteTrHistory.write("Tr_Completed");
				return result = "Failed";
			}
			transactionManager.commit(status);
			WriteTrHistory.write("Tr_Completed");
		}
		catch (Exception e) {
			transactionManager.rollback(status);
			WriteTrHistory.write("Tr_Completed");
			request.setAttribute("exceptionMsg", "Exception occured while processing the Indent Issue.");
			//viewToBeSelected = "indentIssueResponse";
			result = "Failed";
			AuditLogDetailsBean auditBean = new AuditLogDetailsBean();
			auditBean.setEntryDetailsId(String.valueOf(indentEntrySeqNum));
			auditBean.setLoginId(strUserId);
			auditBean.setOperationName("New Issue");
			auditBean.setStatus("error");
			auditBean.setSiteId(strSiteId);
			new SaveAuditLogDetails().saveAuditLogDetails(auditBean);
			e.printStackTrace();
		}
		return result;
	}
	public int getIssueCount1(HttpServletRequest request ){


		String strSlipNumber=request.getParameter("SlipNumber");
		HttpSession session = request.getSession(true);
		String strSiteId = (String) session.getAttribute("SiteId");
		String strReqDate=request.getParameter("ReqDate");
		int indent_entry_id = iid.getIssuesCount1(  strSlipNumber, strSiteId, strReqDate);
		
		logger.info("slip nu "+strSlipNumber+" indent entry id "+indent_entry_id);
		return indent_entry_id;
	}
	public int getIssueCount(String strSlipNumber,String strSiteId,String strMonthStartString,String strReqDate){


		int intIssueCount = iid.getIssuesCount(  strSlipNumber, strSiteId, strMonthStartString,strReqDate);
		return intIssueCount;
	}

	@Override
	public String loadProductAvailability(String prodId, String subProductId, String childProdId, String measurementId,String requesteddate,HttpServletRequest request, HttpSession session) {
		return iid.getProductAvailability(prodId, subProductId, childProdId, measurementId,requesteddate,String.valueOf(request.getSession(true).getAttribute("SiteId").toString()));
	}

	@Override
	public Map<String, String> loadBlockDetails(String strSiteId) {		
		return iid.loadBlockDetails(strSiteId);
	}

	@Override
	public String getProjectName(HttpSession session) {		
		return iid.getProjectName(session);
	}

	@Override
	public String getFloorDetails(String blockId) {
		return iid.getFloorDetails(blockId);
	}

	@Override
	public String getFlatDetails(String floorId) {
		return iid.getFlatDetails(floorId);
	}

	@Override
	public void updateIssueDetailsIntoSumadhuraCloseBalance(
			IndentReceiveDto irdto, String siteId) {

	}

	@Override
	public void updateIssueDetailsSumadhuClosingBalByProduct(IndentIssueDto issueDto, String strSiteId, String priceId, Double IssueQty) {

	}
	
	public static void main(String[] args){
		double d = 0.0;
		
		if(d == 0){
			System.out.println("ok");
		}
	}

	@Override
	public String getContractorInfo(String contractorName) {
		// TODO Auto-generated method stub
		return iid.getContractorInfo(contractorName);
	}
	@Override
	public String getEmployerInfo(String employeeName) {
		// TODO Auto-generated method stub
		return iid.getEmployerInfo(employeeName);
	}
	public String getEmployerid(String employeeName) {
		// TODO Auto-generated method stub
	//	System.out.println("in service "+employeeName);
		return iid.getEmployerid(employeeName);
	}
	
	public String getEmployerName(String employeeid) {
		// TODO Auto-generated method stub
	//	System.out.println("in service id data "+employeeid);
		return iid.getEmployerName(employeeid);
	}
	
	
	
}
