package com.sumadhura.transdao;

import java.sql.Date;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.sumadhura.bean.PaymentBean;
import com.sumadhura.bean.PaymentModesBean;
import com.sumadhura.bean.VendorDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.PaymentDto;

public interface PaymentProcessDao {

	
	public List<PaymentBean> getInvoiceDetails(String fromDate, String toDate, String siteId,String vendorId, String invoiceNumber);
	public int saveOrUpdePaymentTable(PaymentDto objPaymentDto,int PaymentId);
	public int savePaymentProcessDtlsTable(PaymentDto objPaymentDto,int intPaymentId,int paymentEntrySeqId);
	public int savePaymentApproveRejectTable(PaymentDto objPaymentDto,int intPaymentId,int intPaymentDetailsId);
	public int getPaymentId();
	public int getPaymentDetailsId();
	public List<PaymentBean> getPaymentApprovalDetails(String siteId,String user_id);
	public String getPendingEmpId(String strUserId);
	public int saveApprovalDetails(String paymentId,String strUserId,String comments,String pendingDetailsId,String site_id);
	public int  saveRejectDetails(String paymentId,String strUserId,String comments,String pendingDetailsId,String site_id);
	public int saveChangedDetails(PaymentBean objPaymentBean,String paymentChangedType);
	public int UpDatePaymentDetails(String paymentDetailsId,double changedAmount);
	public String getDeptId(String strUserId);
	public int updateRequestedPaymentEmpId(String paymentDetailsId,String pendingEmpId);
	public int updatePaymentDetailsDate(String paymentDetailsId,String  changedRequestedDate);
	public int getSiteWisePaymentNo(String site_id);
	public int saveAccountsDeptTable(PaymentBean objPaymentBean);
	public int updateRequestedPaymentDeptId(String paymentDetailsId, String deptEmpId);
	public List<PaymentBean> getPODetails(String fromDate, String toDate, String siteId,String vendorId, String poNumber);
	public List<PaymentBean> getAccDeptPaymentApprovalDetails(String siteId, String user_id);
	
	public List<PaymentBean> getAccDeptPaymentPendingDetails(String strUserId);
	public int insertTempPaymentTransactionsTbl(PaymentDto objPaymentDto, int tempPaymentId);
	public String getApproverEmpIdInAccounts(String strEmpId);
	public int updateAccDeptPaymentProcsstbl(PaymentDto objPaymentDto);
	public int updateTempPaymentTransactionsTbl(PaymentDto objPaymentDto,String strPendingEmpId);
	public int insertPaymentTransactionsTbl(PaymentDto objPaymentDto, int intPaymentTransactionId);
	public int updatePaymentDetailsAdjustAmount(String paymentDetailsId, double doubleAdjustAmountFromAdvance);
	public String getRemainingAmountInAdvance(String poNo);
	public int updateReqUptoInAccPayment(String paymentId, String actualRequestedAmount,String changedRequestedAmount, double actualDoubleAdjustAmountFromAdvance, double doubleAdjustAmountFromAdvance);
	public int updateIntiateAmountInAdvancePaymentPO(String poNo, double actualDoubleAdjustAmountFromAdvance,double doubleAdjustAmountFromAdvance);
	public int updateAdvancePaymentPoTable(String poNo, double doubleAdjustAmountFromAdvance);
	public int insertPoHistory(PaymentDto objPaymentDto);
	public int insertInvoiceHistory(PaymentDto objPaymentDto, int intPaymentTransactionId);
	public int updatePaymentReqUptoInAccPaymentTable(PaymentDto objPaymentDto);
	public int insertPaidAmountInAdvancePaymentPoTable(PaymentDto objPaymentDto);
	public String getLowerEmpIdInAccounts(String strEmpId);
	//public List<String> getPaymentInitiatorInAccounts();
	public int revertPendingApprovalToLowerEmployee(String strLowerEmpId, int intTempPaymentTransactionId);
	public int removeRowInAccTempPaymentTransactions(int intTempPaymentTransactionId);
	public int updateIntiateAmountInAccDeptPaymentProcesstbl(String requestedAmount, int intAccDeptPaymentProcessId, double actualDoubleAdjustAmountFromAdvance);
	public int getAccTempPaymentTransactionSeqNo();
	public int saveAccountsApproveRejectTable(PaymentDto objPaymentDto, int intAccDeptPaymentProcessId,int intTempPaymentTransactionId);
	public int saveAccountApprovalDetails(int intAccDeptPaymentProcessId, String strUserId, String comments, int intTempPaymentTransactionId,String site_id);
	public int saveAccountRejectDetails(int intAccDeptPaymentProcessId, String strEmpId, String comments,int intTempPaymentTransactionId, String siteId);
	public int saveAccountChangedDetails(PaymentBean objPaymentBean, String string);
	public int updateRequestedPaymentDeptIdOnAccDeptReject(String paymentDetailsId, String pendingEmpId);
	public int removeRowInAccDeptPmtProcessTbl(int intAccDeptPaymentProcessId);
	public int updateRefNoInAccDeptTransaction(String strRefNo, int intPaymentTransactionId, String paymentMode, String paymentDate);
	public List<PaymentBean> getAccDeptPaymentDetailsToUpdate(String siteId, String user_id, String fromDate, String toDate);
	public int UpDatePaymentDetailsRemarks(String paymentDetailsId, String remarks);
	public int updateReqUptoInAccPaymentOnReject(String paymentId, String actualRequestedAmount, double actualDoubleAdjustAmountFromAdvance);
	public int updateIntiateAmountInAdvancePaymentPOOnReject(String poNo, double actualDoubleAdjustAmountFromAdvance);
	public int setInactiveAccPaymentAfterCheck(int intPaymentId);
	public int updateRefNoInInvoiceHistory(String strRefNo, String paymentMode, int intPaymentTransactionId);
	public int getIntPaymentTransactionId();
	public int insertPaymentTransactionsTblAdjust(PaymentDto objPaymentDto, int intPaymentTransactionId);
	public int insertInvoiceHistoryAdjust(PaymentDto objPaymentDto, int intPaymentTransactionId);
	public String[] getPaymentApproverEmailId(String strUserId);
	public List<PaymentModesBean> getPaymentModes();
	public VendorDetails getVendorAccountDetails(String vendorId);
	public List<PaymentBean> getPaymentApprovalDetailsForMail(String siteId, String user_id, String groupOfPaymentDetailsId);
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate);
	public String[] getAllSiteLevelEmails(String siteId);
	public int setInactiveRowInAccDeptPmtProcessTbl(int intAccDeptPaymentProcessId);
}
