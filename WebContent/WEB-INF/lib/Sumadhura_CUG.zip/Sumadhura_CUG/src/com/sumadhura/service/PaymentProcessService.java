package com.sumadhura.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sumadhura.bean.PaymentBean;

public interface PaymentProcessService {

	public List<String> savePaymentIntiateDetails( HttpServletRequest request,HttpSession session);
	public List<PaymentBean> getInvoiceDetails(String fromDate, String toDate,String site_id,String vendorId, String invoiceNumber);
	
	public List<String> savePaymentApprovalAndRejectDetails( HttpServletRequest request,HttpSession session,String strUserId);
	public List<PaymentBean> getPODetails(String fromDate, String toDate, String site_id,String vendorId, String poNumber);
	public List<PaymentBean> getAccDeptPaymentPendingDetails(String strUserId);
	
	public List<String> createAccountDeptTransaction(HttpServletRequest request , String steEmpId);
	public List<PaymentBean> updateAccountDeptTransaction(HttpServletRequest request, HttpServletResponse response, String strUserId);
	public String getPendingEmpId(String user_id);
	public String updateRefNoInAccDeptTransaction(HttpServletRequest request, String strUserId);
}
