package com.sumadhura.in;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sumadhura.bean.IndentIssueBean;
import com.sumadhura.service.IndentIssueService;
import com.sumadhura.util.SaveAuditLogDetails;

@Controller
public class IndentIssueController {

	@Autowired
	@Qualifier("iisClass")
	IndentIssueService iis;

	@RequestMapping(value = "/launchIndIssuePage", method = RequestMethod.GET)
	public String launchLogInPage(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));

		String StrRoleId = String.valueOf(session.getAttribute("Roleid"));
		//System.out.println("the role id of  "+no);

		if(StrRoleId.equals("2"))
			model.addAttribute("noOfDays",5);
		else if(StrRoleId.equals("4")){
			model.addAttribute("noOfDays",30);
		}else if(StrRoleId.equals("5")){
			model.addAttribute("noOfDays",100);
		}else if(StrRoleId.equals("12")){
			model.addAttribute("noOfDays",20);
		}else if(StrRoleId.equals("13")){
			model.addAttribute("noOfDays",20);
		}else if(StrRoleId.equals("1")){
			model.addAttribute("noOfDays",5);
		}
		else{
			model.addAttribute("noOfDays",0);
		}

		String indentEntrySeqNum=String.valueOf(iis.getIndentEntrySequenceNumber());
		
		iib.setReqId(indentEntrySeqNum);
		iib.setProjectName(iis.getProjectName(session));
		
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
			//String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog(indentEntrySeqNum,user_id,"New Issue View","success",site_id1);
			
		
		
		
		return "indentIssuePage";
	}

	/************************************************** PO***************************/
	
	@RequestMapping(value = "/createPurcghaseOrder.spring", method = RequestMethod.GET)
	public String createPurcghaseOrder(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
		iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Create PO Viewed","success",site_id);
			
		
		
		
		return "createPO";
	}
	
/*	***********************END PO************************/
	

	/************************************************** PO***************************/
	
	@RequestMapping(value = "/PODetailsShow.spring", method = RequestMethod.GET)
	public String PODetailsShow(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
		iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Create PO Viewed clicked Submit","success",site_id);
		
		
		
		
		return "PODetailsShow";
	}
		@RequestMapping(value = "/loadAndSetContractorInfo", method = RequestMethod.GET)
	@ResponseBody
	public String loadAndSetContractorInfo(@RequestParam("contractorName") String contractorName) {
		//System.out.println("In controller contractorName is :"+contractorName+"|");
		String contData = iis.getContractorInfo(contractorName);
		//System.out.println("In controller resulted data :"+contData+"|");
		return contData;
	}
	
	@RequestMapping(value = "/loadAndSetEmployerInfo", method = RequestMethod.GET)
	@ResponseBody
	public String loadAndSetEmployerInfo(@RequestParam("employeeName") String employeeName) {
		//System.out.println("In controller employeeName is :"+employeeName+"|");
		String empData = iis.getEmployerInfo(employeeName);
		//System.out.println("In controller resulted data :"+empData+"|");
		return empData;
	}
	
	@RequestMapping(value = "/getEmployerid", method = RequestMethod.GET)
	@ResponseBody
	public String gettEmployerid(@RequestParam("employeeName") String employeeName) {
		//System.out.println("onblur employeeName is :"+employeeName+"|");
		String empData = iis.getEmployerid(employeeName);
		//System.out.println(" resulted empid :"+empData+"|");
		return empData;
	}
	
	@RequestMapping(value = "/getEmployerName", method = RequestMethod.GET)
	@ResponseBody
	public String getEmployerName(@RequestParam("employeeid") String employeeid) {
	//	System.out.println("onblur employeeid is :"+employeeid+"|");
		String empId = iis.getEmployerName(employeeid);
		//System.out.println(" resulted empdata :"+empId+"|");
		return empId;
	}
	
	
	
	
	
	
	
	
	
/*	***********************END PO************************/
/*	********************************** Get PO Dateials****************************/

	@RequestMapping(value = "/PurcghaseOrderDetails.spring", method = RequestMethod.GET)
	public String getPurcghaseOrderDetails(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));



	 String reqid=String.valueOf(iis.getIndentEntrySequenceNumber());	
		iib.setReqId(reqid);
		iib.setProjectName(iis.getProjectName(session));
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog(reqid,user_id,"Get PO Details Viewed","success",site_id);
			
		
		
		
		return "getPODetails";
	}
	
	
	/************************************END PO Details*****************************************/
	
	@RequestMapping(value = "/indentIssueSubProducts", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueSubProducts(@RequestParam("mainProductId") String mainProductId) {
		return iis.loadSubProds(mainProductId);
	}

	@RequestMapping(value = "/indentIssueChildProducts", method = RequestMethod.POST)
	@ResponseBody
	public String indentIssueChildProducts(@RequestParam("subProductId") String subProductId) {
		return iis.loadChildProds(subProductId);
	}

	@RequestMapping(value = "/listUnitsOfSubProducts", method = RequestMethod.POST)
	@ResponseBody
	public String listUnitsOfSubProducts(@RequestParam("childProductId") String childProductId) {
		return iis.loadIndentIssueMeasurements(childProductId);
	}

	@RequestMapping(value = "/getProductAvailability", method = RequestMethod.POST)
	@ResponseBody
	public String getProductAvailability(@RequestParam("prodId") String prodId, @RequestParam("subProductId") String subProductId, @RequestParam("childProdId") String childProdId, @RequestParam("measurementId") String measurementId,@RequestParam("requesteddate") String requesteddate, HttpServletRequest request, HttpSession session) {
		//System.out.println("controller class");
		//System.out.println("requesteddate - "+requesteddate);
		
		return iis.loadProductAvailability(prodId, subProductId, childProdId, measurementId,requesteddate,request, session);
	}
	@RequestMapping(value = "/getProductAvailability2", method = RequestMethod.POST)
	@ResponseBody
	public String getProductAvailability2(@RequestParam("prodId") String prodId, @RequestParam("subProductId") String subProductId, @RequestParam("childProdId") String childProdId, @RequestParam("measurementId") String measurementId, HttpServletRequest request, HttpSession session) {
		//System.out.println("controller class");
		Date myDate = new Date();
		String requesteddate = new SimpleDateFormat("dd-MMM-YY").format(myDate);
		//System.out.println("requesteddate "+requesteddate);
		return iis.loadProductAvailability(prodId, subProductId, childProdId, measurementId,requesteddate,request, session);
	}

	@RequestMapping(value = "/getFloorDetails", method = RequestMethod.POST)
	@ResponseBody
	public String getFloorDetails(@RequestParam("blockId") String blockId) {
		return iis.getFloorDetails(blockId);
	}

	@RequestMapping(value = "/getFlatDetails", method = RequestMethod.POST)
	@ResponseBody
	public String getFlatDetails(@RequestParam("floorId") String floorId) {
		return iis.getFlatDetails(floorId);
	}
	@RequestMapping(value = "/getIssueCount", method = RequestMethod.POST)
	@ResponseBody
	public int getReceiveCount(@RequestParam("slipNumber") String strSlipNumber,
			@RequestParam("receiveDate") String strReceiveDate,HttpServletRequest request
	) {
		HttpSession session = null;
		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		String strReqMonthStart = "";
		if(strReceiveDate.contains("-")){
			String arr[] = strReceiveDate.split("-");
			String strMonth = arr[1];
			String strYear = arr[2];
			strReqMonthStart = "01"+"-"+strMonth+"-"+strYear;
		}
		return iis.getIssueCount(  strSlipNumber,  strSiteId,strReqMonthStart,  strReceiveDate);
	}
	@RequestMapping(value = "/doIndentIssue", method = RequestMethod.POST)
	public String doIndentIssue(@ModelAttribute("indentIssueModelForm") IndentIssueBean issueModel,	BindingResult result, Model model, HttpServletRequest request, HttpSession session) {
		String response = iis.indentIssueProcess(model, request, session);
		String viewToBeSelected = "";

	/*	if(response.equals("Success")){
			int isIssueSaved = iis.getIssueCount1(  request);

			System.out.println("response....."+response);

			if(isIssueSaved==0)
			{
				response="Failed";
				request.setAttribute("exceptionMsg", "Record Not Inserted. Try Again...");
			}
		}
*/
		if(response.equalsIgnoreCase("Success") ) {
			viewToBeSelected = "indentIssueResponse";
		} else if(response.equalsIgnoreCase("Failed")) {
			viewToBeSelected = "indentIssueResponse";
		}else if (response.equalsIgnoreCase("No Stock")  ) {

			session = request.getSession(true);
			String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();

			IndentIssueBean iib = new IndentIssueBean();
			model.addAttribute("indentIssueModelForm", iib);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("noStock", "Sorry issue failed ! Some of the item stock is insufficient on mention date");
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
			iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
			iib.setProjectName(iis.getProjectName(session));
			viewToBeSelected = "indentIssuePage";
		} else if (response.equalsIgnoreCase("SessionFailed")){
			model.addAttribute("Message", "Session Expired, Please Login Again");
			viewToBeSelected = "index";
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
			String indentEntrySeqNum=String.valueOf(session.getAttribute("indentEntrySeqNum"));
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog(indentEntrySeqNum,user_id,"New Issue clicked Submit","success",site_id1);
			
		
		
		
		
		return viewToBeSelected;
	}
}
