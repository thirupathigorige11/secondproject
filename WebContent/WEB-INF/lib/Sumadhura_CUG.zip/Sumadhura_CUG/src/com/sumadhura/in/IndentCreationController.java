package com.sumadhura.in;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.GetInvoiceDetailsBean;
import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.IndentIssueBean;
import com.sumadhura.bean.IndentReceiveBean;
import com.sumadhura.bean.MenuDetails;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.service.IndentIssueService;
import com.sumadhura.service.IndentReceiveService;
import com.sumadhura.service.PurchaseDepartmentIndentrocessService;
import com.sumadhura.transdao.IndentCreationDao;
import com.sumadhura.transdao.IndentSummaryDao;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;
import com.sumadhura.service.IndentCreationService;

@Controller
public class IndentCreationController extends UIProperties{

	@Autowired
	@Qualifier("posClass")
	IndentCreationService ics;

	@Autowired
	private UtilDao utilDao;

	@Autowired
	@Qualifier("iisClass")
	IndentIssueService iis;

	@Autowired
	@Qualifier("irsClass")
	IndentReceiveService objIndentReceiveService;

	@Autowired
	@Qualifier("purchaseDeptIndentrocess")
	PurchaseDepartmentIndentrocessService purchaseDeptIndentrocess;

	/************************************************** PO***************************/



	/*	***********************END PO**3.
	 * 
	 * *********************/
	/*	********************************** Get PO Dateials****************************/


	@RequestMapping(value = "/indentCreation.spring", method = RequestMethod.GET)
	public String indentCreation(Model model, HttpServletRequest request,HttpSession session) {
		IndentCreationBean icb = new IndentCreationBean();
		//IndentCreationBean icb1 = new IndentCreationBean();

		int SiteId = 0;
		String user_id = "";
		try{
			session = request.getSession(true);
			SiteId = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			model.addAttribute("indentCreationModelForm", icb);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			//model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
			icb = ics.getIndentFromAndToDetails(user_id,icb);
			if(icb.getApproverEmpId()==null){
				model.addAttribute("responseMessage","You Cannot Create Indent");
				return "IndentCreation";
			}
			int siteWiseIndentNo = ics.getMaxOfSiteWiseIndentNumber(SiteId);
			icb.setIndentNumber(ics.getIndentCreationSequenceNumber());
			icb.setSiteWiseIndentNo(siteWiseIndentNo);
			/*icb.setIndentFrom(icb1.getIndentFrom());
		icb.setIndentTo(icb1.getIndentTo());
		icb.setApproverEmpId(icb1.getApproverEmpId());*/
			//iib.setProjectName(iis.getProjectName(session))
		}catch(Exception e){e.printStackTrace();}
		SaveAuditLogDetails.auditLog("0",user_id,"Indent Creation Form View","Success",String.valueOf(SiteId));return "IndentCreation";
	}	
	@RequestMapping(value = "/submitIndentCreation.spring", method = RequestMethod.POST)
	public String submitIndentCreation(Model model, HttpServletRequest request,HttpSession session) {
		System.out.println("IndentCreationController.submitIndentCreation()");
		
		IndentCreationBean icb = new IndentCreationBean();
		int site_id = 0;
		String user_id = "";
		String response = "";
		try{
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			/*model.addAttribute("indentCreationModelForm", icb);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			icb = ics.getIndentFromAndToDetails(user_id,icb);
			icb.setIndentNumber(ics.getIndentCreationSequenceNumber());*/
			response = ics.indentCreation(model, request, site_id, user_id);
			if(response.equals("success")){

				//System.out.println("sucessfully updated");
				request.setAttribute("message", "Indent Created successfully.");
			}
			else{
				//System.out.println("not sucessfully updated");
				request.setAttribute("message1", "Indent Not Created.");

			}//model.addAttribute("responseMessage",response);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Indent Created",response,String.valueOf(site_id));
		return "response";

	}
	@RequestMapping(value = "/getIndentCreationDetails.spring", method = RequestMethod.GET)
	public String getIndentCreationDetails(Model model, HttpServletRequest request,HttpSession session) {
		List<IndentCreationDto> pendingIndents = null;
		List<IndentCreationBean> listofCentralIndents = null;
		Map<String, String> siteDetails = null;
		String strSiteId = "";
		String user_id = "";
		String central_dept_id = "";
		String purchase_dept_id = "";
		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			central_dept_id = validateParams.getProperty("CENTRAL_DEPT_ID") == null ? "" : validateParams.getProperty("CENTRAL_DEPT_ID").toString();
			purchase_dept_id = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();

			siteDetails = new IndentSummaryDao().getSiteDetails();
			model.addAttribute("siteDetails", siteDetails);


		} catch (Exception e) {
			e.printStackTrace();
		}
		if(strSiteId.equals(central_dept_id))
		{
			try {
				listofCentralIndents = ics.getAllCentralIndents();
				model.addAttribute("listofCentralIndents",listofCentralIndents);
			} catch (Exception e) {
				e.printStackTrace();
			}
			SaveAuditLogDetails.auditLog("0",user_id,"Getting List of All Pending Central Indents","Success",strSiteId);
			return "ViewAllCentralIndents";
		}

		else if(strSiteId.equals(purchase_dept_id))
		{
			try {
				listofCentralIndents = purchaseDeptIndentrocess.getAllPurchaseIndents();
				model.addAttribute("listofCentralIndents",listofCentralIndents);
				request.setAttribute("totalProductsList",purchaseDeptIndentrocess.getAllProducts());
			} catch (Exception e) {
				e.printStackTrace();
			}
			SaveAuditLogDetails.auditLog("0",user_id,"Getting List of All Pending Purchase Indents","Success",strSiteId);
			return "PendingIndents";
		}
		else
		{
			try {
				pendingIndents = ics.getPendingIndents(user_id,strSiteId);
				model.addAttribute("pendingIndents",pendingIndents);
			} catch (Exception e) {
				e.printStackTrace();
			}
			SaveAuditLogDetails.auditLog("0",user_id,"getting List of All Pending Indents For Approval","Success",strSiteId);
			return "getIndentCreationDetails";
		}

	}
	/*new*/
	@RequestMapping(value = "/IndentCreationDetailsShow.spring", method = RequestMethod.GET)
	public String IndentCreationDetailsShow(Model model, HttpServletRequest request,HttpSession session) {
System.out.println("IndentCreationController.IndentCreationDetailsShow()");
		IndentCreationBean icb = new IndentCreationBean();
		int indentNumber = 0;
		int siteWiseIndentNumber = 0;
		String user_id = "";
		int site_Id = 0;
		// checking whether indentNumber is valid or not
		boolean isValid = false;
		try {
			session = request.getSession(true);
			siteWiseIndentNumber = Integer.parseInt(request.getParameter("siteWiseIndentNo"));
			site_Id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			indentNumber = ics.getIndentNumber(siteWiseIndentNumber,site_Id);
			isValid = ics.checkIndentNumberIsValidForEmployee(indentNumber, user_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(!isValid){
			try {
				model.addAttribute("errorMessage", "Indent Number is Not Valid");
				List<IndentCreationDto> pendingIndents = null;
				pendingIndents = ics.getPendingIndents(user_id,String.valueOf(site_Id));
				model.addAttribute("pendingIndents",pendingIndents);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return "getIndentCreationDetails";
		}
		try {
			model.addAttribute("indentCreationModelForm", icb);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("blocksMap", iis.loadBlockDetails(String.valueOf(site_Id)));
			List<IndentCreationBean> list = ics.getIndentCreationLists(indentNumber);
			ics.getIndentFromDetails(indentNumber,list);
			ics.getIndentToDetails(user_id,list);
			
			List<IndentCreationBean> editList = new ArrayList<IndentCreationBean>();
			String strEditComments = "";
			for(int i =0 ;i< list.size();i++ ){
				
				IndentCreationBean objIndentCreationBean = list.get(i);
				model.addAttribute("materialEditComment", objIndentCreationBean.getMaterialEditComment());
				strEditComments = objIndentCreationBean.getMaterialEditComment();
				
				if(strEditComments.contains("@@@")){
					String strEditCommentsArr [] = strEditComments.split("@@@");
					for(int j = 0; j< strEditCommentsArr.length;j++){
						IndentCreationBean objCommentIndentCreationBean  = new IndentCreationBean();
						objCommentIndentCreationBean.setMaterialEditComment(strEditCommentsArr[j]);
						editList.add(objCommentIndentCreationBean);
					}
					
					model.addAttribute("materialEditCommentList", editList);
				}
				
			}
			
			String strPurpose = ics.getIndentLevelComments(indentNumber);
			
			model.addAttribute("IndentLevelCommentsList",strPurpose);
			model.addAttribute("IndentCreationList",list);
			model.addAttribute("IndentCreationDetailsList",ics.getIndentCreationDetailsLists(indentNumber));
			model.addAttribute("deletedProductDetailsList",ics.getDeletedProductDetailsLists(indentNumber));
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails.auditLog("0",user_id,"Showing Indent Details for Approval","Success",String.valueOf(site_Id));
		return "IndentCreationDetailsShow";
	}
	@RequestMapping(value = "/approveIndentCreation.spring", method = RequestMethod.POST)
	public String approveIndentCreation(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String result="";
		String response = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			response = ics.approveIndentCreation(model, request, site_id, user_id,session);
			if(response=="Indent Approved Successfully"){
				model.addAttribute("responseMessage",response);
				result="success";
			}else{
				model.addAttribute("responseMessage1",response);
			result="failure";
			}
			List<IndentCreationDto> pendingIndents = null;
			pendingIndents = purchaseDeptIndentrocess.getPendingIndents(user_id,String.valueOf(site_id));
			model.addAttribute("pendingIndents",pendingIndents);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Approving Indent",result,String.valueOf(site_id));
		return "getIndentCreationDetails";

	}
	@RequestMapping(value = "/approveIndentCreationFromMail.spring", method = RequestMethod.POST)
	public String approveIndentCreationFromMail(Model model, HttpServletRequest request,HttpSession session) {
		String responseMessage = "";
		int site_id = 0;
		String user_id = "";  
		String response = "";
		try {
			site_id = Integer.parseInt(request.getParameter("siteId"));
			user_id = request.getParameter("userId");  
			//int indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			response = ics.approveIndentCreationFromMail( request, site_id, user_id);
			if(response.equals("WrongPassword"))
			{
				responseMessage = "Already Approved";
			}
			else if(response.equals("Success"))
			{
				responseMessage = "Indent Approved Successfully";
			}
			else{
				responseMessage = "Failed. Indent NOT Approved";
			}
		} catch (Exception e) {
			responseMessage = "Failed. Indent NOT Approved";
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Approving Indent via Mail",response,String.valueOf(site_id));
		List<MenuDetails> list = new ArrayList<MenuDetails>();
		session.setAttribute("menu", list);
		request.setAttribute("message",responseMessage);
		return "response";
	}
	@RequestMapping(value = "/rejectIndentCreationFromMail.spring", method = RequestMethod.POST)
	public String rejectIndentCreationFromMail(Model model, HttpServletRequest request,HttpSession session) {
		String responseMessage = ""; 
		int site_id = 0;
		String user_id = "";  
		String response = "";
		try {
			site_id = Integer.parseInt(request.getParameter("siteId"));
			user_id = request.getParameter("userId");  
			response = ics.rejectIndentCreationFromMail(model,request,site_id, user_id);
			if(response.equals("WrongPassword"))
			{
				responseMessage = "Already Rejected";
			}
			else if(response.equals("Success"))
			{
				responseMessage = "Indent Rejected Successfully";
			}
			else{
				responseMessage = "Failed. Indent NOT Rejected";
			}
		} catch (Exception e) {
			responseMessage = "Failed. Indent NOT Rejected";
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Rejecting Indent via Mail",response,String.valueOf(site_id));
		List<MenuDetails> list = new ArrayList<MenuDetails>();
		session.setAttribute("menu", list);
		request.setAttribute("message",responseMessage);
		return "response";
	}
	@RequestMapping(value = "/rejectIndentCreation.spring", method = RequestMethod.POST)
	public String rejectIndentCreation(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			response = ics.rejectIndentCreation(model, request, site_id, user_id);
			if(response.equals("Success")){
			model.addAttribute("responseMessage","Indent Rejected Successfully");}
			else{
			model.addAttribute("responseMessage","Failed Indent Rejection");
			}

			List<IndentCreationDto> pendingIndents = null;
			pendingIndents = purchaseDeptIndentrocess.getPendingIndents(user_id,String.valueOf(site_id));
			model.addAttribute("pendingIndents",pendingIndents);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Rejecting Indent",response,String.valueOf(site_id));
		return "getIndentCreationDetails";

	}

	/*	***********************END PO************************/
	/* *****************************************************************************/
	/* ********************* NEWLY ADDED CONTROLLERS *******************************/
	/************************************************** CENTRAL ***************************/
	/*@RequestMapping(value = "/centralIndent.spring", method = RequestMethod.GET)
	public String centralIndent(Model model, HttpServletRequest request,HttpSession session) {
		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		List<IndentCreationBean> listofCentralIndents = null;
		/**/
	/*listofCentralIndents = ics.getAllCentralIndents();
		model.addAttribute("listofCentralIndents",listofCentralIndents);
		return "ViewAllCentralIndents";
	}*/




	/*	***************************************************************/
	/************************************************** Purchase Department ***************************/


	/*@RequestMapping(value = "/ViewPurchaseIndents.spring", method = RequestMethod.GET)
	public String purchaseIndent(Model model, HttpServletRequest request,HttpSession session) {
		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		List<IndentCreationBean> listofCentralIndents = null;
		/**/
	/*listofCentralIndents = ics.getAllPurchaseIndents();
		model.addAttribute("listofCentralIndents",listofCentralIndents);

		request.setAttribute("totalProductsList",ics.getAllProducts());

		return "PendingIndents";//ViewAllPurchaseIndents
	}*/



	@RequestMapping("/getSubProductsOfIndents.spring")
	public  @ResponseBody List<ProductDetails> getAllSubProductList(@RequestParam(value = "prodId") String prodId){
		List<ProductDetails> listAllProductsList = new ArrayList<ProductDetails>();
		try{
			if(prodId.contains("@@")){
				String productArr[] = prodId.split("@@");
				if(productArr != null && productArr.length>=1 ){
					prodId = productArr[0].trim();
					//strProductName = productArr[1].trim();
				}
			}
			listAllProductsList = ics.getAllSubProducts(prodId);
		}catch(Exception e){
			e.printStackTrace();
		}
		return listAllProductsList;
	}
	@RequestMapping("/getChildProductsOfIndents.spring")
	public  @ResponseBody List<ProductDetails> getAllChildProductList(@RequestParam(value = "subProdId") String strSubProdId, HttpServletResponse response) throws Exception{
		List<ProductDetails> listAllProductsList = new ArrayList<ProductDetails>();
		try{
			if(strSubProdId.contains("@@")){
				String productArr[] = strSubProdId.split("@@");
				if(productArr != null && productArr.length>=1 ){
					strSubProdId = productArr[0].trim();
					//strProductName = productArr[1].trim();
				}
			}
			listAllProductsList = ics.getAllChildProducts(strSubProdId);
		}catch(Exception e){
			e.printStackTrace();
		}
		return listAllProductsList;
	}


	/*	***************************************************************/
	/*@RequestMapping(value = "/subCentralIndent.spring", method = RequestMethod.GET)
	public String subCentralIndent(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
		iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		return "subCentralIndent";
	}*/
	/************************************************** PO***************************/


	/*****************************Create Central Indent****************************/
	/*@RequestMapping(value = "/createCentralIndent.spring", method = RequestMethod.GET)
	public String createCentralIndent(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
		iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		return "CreateCentralIndent";
	}*/
	/**************************************************************************/

	/*@RequestMapping(value = "/CreateIndents.spring", method = RequestMethod.GET)
	public String CreateIndents(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
		iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		return "CreateIndents";
	}*/


	/******************************************************************************/

	/*@RequestMapping(value = "/sendenquiry.spring", method = RequestMethod.GET)
	public String sendenquiry(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();


		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
		model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
		model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
		iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		return "SendEnquiry";
	}*/
	/**********************************************************************************************/
	/*@RequestMapping(value = "/CreatePO_waste.spring", method = RequestMethod.GET)
	public String CreatePO_waste(Model model, HttpServletRequest request,HttpSession session) {
		IndentIssueBean iib = new IndentIssueBean();
		String indentNumber= request.getParameter("indentNumber");
		model.addAttribute("indentNumber",indentNumber);

		session = request.getSession(true);
		String strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		model.addAttribute("indentIssueModelForm", iib);
		model.addAttribute("productsMap", iis.loadProds());
	//	model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
	//	model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
	//	iib.setReqId(String.valueOf(iis.getIndentEntrySequenceNumber()));		
		iib.setProjectName(iis.getProjectName(session));
		return "CreateIndentPO";
	}*/

	/***************************************************************************************/
	/*	***********************END PO************************/

	@RequestMapping(value = "/ViewMyRequest.spring", method = RequestMethod.GET)
	public String ViewMyRequestIndent(Model model, HttpServletRequest request,HttpSession session) {
		String strSiteId = "";
		String user_id = "";
		Map<String, String> siteDetails = null;

		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			List<IndentCreationBean> listofCentralIndents = null;

			listofCentralIndents = ics.getViewMyRequestIndents(request);
			model.addAttribute("listofCentralIndents",listofCentralIndents);
			
			siteDetails = new IndentSummaryDao().getSiteDetails();
			model.addAttribute("siteDetails", siteDetails);

			//request.setAttribute("totalProductsList",ics.getAllProducts());
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Showing List of All Requests Came","Success",strSiteId);
		return "Viewmyrequest";//ViewAllPurchaseIndents
	}

	@RequestMapping(value = "/ViewIndentissuedDetails.spring", method = RequestMethod.GET)
	public String ViewIndentissuedDetails(Model model, HttpServletRequest request,HttpSession session) {
		IndentCreationBean icb = new IndentCreationBean();
		String strSiteId = "";
		String user_id = "";
		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			int siteWiseIndentNo = Integer.parseInt(request.getParameter("siteWiseIndentNo"));
			int reqSiteName = Integer.parseInt(request.getParameter("siteId"));
			//System.out.println("*@reqSiteName: "+reqSiteName);
			int indentNumber = ics.getIndentNumber(siteWiseIndentNo,reqSiteName);
			model.addAttribute("indentCreationModelForm", icb);
			List<IndentCreationBean> IndentDetails = null;
			List<IndentCreationBean> IndentDtls = null;
			model.addAttribute("IndentDtls",IndentDtls);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));


			DateFormat df = new SimpleDateFormat("dd-MMM-yy");
			String date = df.format(new Date());
			model.addAttribute("IndentEntrySeqNo",objIndentReceiveService.getIndentEntrySequenceNumber());
			model.addAttribute("todayDate",date);
			IndentDtls = ics.getViewAllMyRequestIndents(request,indentNumber);
			model.addAttribute("IndentDtls",IndentDtls);
			IndentDetails = ics.getViewissedIndentDetailsLists(indentNumber,strSiteId);
			model.addAttribute("IndentDetails",IndentDetails);
			String numberOfRows = "";
			if(IndentDetails!=null){
				for(int i=1;i<=IndentDetails.size();i++)
				{
					numberOfRows += i+"|"; 
				}
			}
			model.addAttribute("numberOfRows",numberOfRows);
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails.auditLog("0",user_id,"Showing Request Details","Success",strSiteId);
		return "CreateissueIndent";
	}

	@RequestMapping(value = "/sendissued.spring", method = RequestMethod.POST)
	public String sendIssuedToVendor(Model model, HttpServletRequest request,HttpSession session) {
		String site_Name = "";
		String user_id = "";
		String response = "";
		try {
			session = request.getSession(true);
			int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			site_Name = session.getAttribute("SiteName") == null ? "" : session.getAttribute("SiteName").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			response = ics.sendissued(model, request, session,site_id, user_id,site_Name);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		if(response.equals("success")){

			try {
				//System.out.println("sucessfully updated");
				request.setAttribute("Message", "Success. sending successfully.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return  "DCviewGRN";
		}
		else{
			try {
				//System.out.println("not sucessfully updated");
				request.setAttribute("Message", "Failed. Sending not sucessful.");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Sending Issued Quantity to Requested Site",response,site_Name);
		return "CreateIssuedResponse";
	}



	@RequestMapping(value = "/Reject.spring", method = RequestMethod.POST)
	public String Reject(Model model, HttpServletRequest request,HttpSession session) {
		/*session = request.getSession(true);
		int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		String indentNumber= request.getParameter("indentNumber");
		model.addAttribute("indentNumber",indentNumber);*/
		int site_id = 0;
		String user_id = "";
		String response ="";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			response = ics.RejectQuantity(model, request, site_id, user_id);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

		if(response.equals("success")){

			//System.out.println("sucessfully updated");
			request.setAttribute("Mesage", "Success. Rejected successfully.");
		}
		else{
			//System.out.println("not sucessfully updated");
			request.setAttribute("Mesage", "Failed. not Rejected.");

		}


		SaveAuditLogDetails.auditLog("0",user_id,"Rejected to Issue Quantity to Other Site",response,String.valueOf(site_id));
		return "Viewmyrequest";
	}

	@RequestMapping(value = "/ViewMyReceive.spring", method = RequestMethod.GET)
	public String ViewMyReceiveIndent(Model model, HttpServletRequest request,HttpSession session) {
		String strSiteId = "";
		String user_id = "";
		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			List<IndentCreationBean> listofCentralIndents = null;

			listofCentralIndents = ics.getViewMyReceiveIndents(request);
			model.addAttribute("listofCentralIndents",listofCentralIndents);

			//	request.setAttribute("totalProductsList",ics.getAllProducts());
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails.auditLog("0",user_id,"Showing List of All Receives Came","Success",strSiteId);
		return "ViewMyReceive";//ViewAllPurchaseIndents
	}
	@RequestMapping(value = "/ViewIndentSenderDetails.spring", method = RequestMethod.GET)
	public String ViewIndentSenderDetails(Model model, HttpServletRequest request,HttpSession session) {
		IndentCreationBean icb = new IndentCreationBean();
		String strSiteId = "";
		String user_id = "";
		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			int indentProcessno = Integer.parseInt(request.getParameter("indentNumber"));
			String reqSiteName = request.getParameter("siteName");
			model.addAttribute("indentCreationModelForm", icb);
			List<IndentCreationBean> IndentDetails = null;
			List<IndentCreationBean> IndentDtls = null;
			//model.addAttribute("IndentDtls",IndentDtls);
			//model.addAttribute("productsMap", iis.loadProds());
			//model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			//model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));

			IndentDtls = ics.getViewAllMyRequestedIndent(request,indentProcessno);
			model.addAttribute("IndentDtls",IndentDtls);
			IndentDetails = ics.getViewReceivedIndentDetailsLists(indentProcessno);
			model.addAttribute("IndentDetails",IndentDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}


		SaveAuditLogDetails.auditLog("0",user_id,"Showing Receive Details","Success",strSiteId);
		return "CreateReceiveIndent";
	}

	@RequestMapping(value = "/sendReceived.spring", method = RequestMethod.POST)
	public String senderReceivedQuantity(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			response = ics.sendReceivedQuantity(model, request, site_id, user_id);
			if(response.equals("success")){

				//System.out.println("sucessfully updated");
				request.setAttribute("Message", "Success. sending successfully.");
			}
			else{
				//System.out.println("not sucessfully updated");
				request.setAttribute("Message", "Failed. Sending not sucessful.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Accepted Received Quantity",response,String.valueOf(site_id));
		return "ViewMyReceive";
	}
	@RequestMapping(value = "/RejectQuantity.spring", method = RequestMethod.POST)
	public String RejectQuantity(Model model, HttpServletRequest request,HttpSession session) {

		int site_id = 0;
		String user_id = "";
		String response = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			response = ics.RejectIssueQuantity(model, request, site_id, user_id);

			if(response.equals("success")){

				//System.out.println("sucessfully updated");
				request.setAttribute("Mesage", "Success. Rejected successfully.");
			}
			else{
				//System.out.println("not sucessfully updated");
				request.setAttribute("Mesage", "Failed. not Rejected.");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Rejected Received Quantity",response,String.valueOf(site_id));
		return "ViewMyReceive";
	}

	@RequestMapping(value = "/getAllIndentCreationDetails.spring", method = RequestMethod.GET)
	public String getAllIndentCreationDetails(Model model,HttpServletRequest request,HttpSession session) {
		String site = "";

		List<IndentCreationBean> listofCentralIndents = null;
		Map<String, String> siteDetails = null;

		try {


			site=request.getParameter("site");
			//	System.out.println(site);
			
			listofCentralIndents = purchaseDeptIndentrocess.getAllSitePurchaseIndents(site);
			if(listofCentralIndents.size()>0){
				model.addAttribute("listofCentralIndents",listofCentralIndents);
			}
			else
				model.addAttribute("message","No Indents are Available");	
			//request.setAttribute("totalProductsList",purchaseDeptIndentrocess.getAllProducts());
			//	request.setAttribute("showGrid", "true");

		}catch(Exception e){
			e.printStackTrace();
		}

		return "ProjectWiseIndent";

	}

	@RequestMapping(value ="ViewMyRaisedIndents.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView ViewMyRaisedIndents(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String indentNumber = "";
		String response="";
		ModelAndView model = null;
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			indentNumber=request.getParameter("indentNumber");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate) || StringUtils.isNotBlank(indentNumber)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();				
				//System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					indentIssueData = ics.getRaisedIndentDetails(fromDate, toDate, site_id,indentNumber);
					if(indentIssueData != null && indentIssueData.size() >0){
						request.setAttribute("showGrid", "true");
						response="success";
					} else {
						model.addObject("succMessage","No Data Available");
						response="failure";

					}
					model.addObject("indentIssueData",indentIssueData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.addObject("indentNumber", indentNumber);
					model.setViewName("ViewAllIndentsDetails");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failure";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
				model.addObject("indentIssueData",indentIssueData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.addObject("indentNumber", indentNumber);
				response="success";
				model.setViewName("ViewAllIndentsDetails");
			}
		} catch (Exception ex) {
			response="failure";
			ex.printStackTrace();
		} 

		//	SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		//	String user_id=String.valueOf(session.getAttribute("UserId"));
		//	String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		//	audit.auditLog("0",user_id,"Get Grn Details View",response,site_id1);

		return model;
	}

	@RequestMapping(value = "/ViewMyRaisedIndentsDetails.spring", method = RequestMethod.GET)
	public String ViewMyRaisedIndentsDetails(Model model, HttpServletRequest request,HttpSession session) {
		IndentCreationBean icb = new IndentCreationBean();
		int indentNumber = 0;
		String user_id = "";
		int site_Id = 0;
		String siteId="";
		int strAuditlogSiteId = 0;
		// checking whether indentNumber is valid or not
		boolean isValid = false;
		try {
			session = request.getSession(true);
			site_Id=Integer.parseInt(request.getParameter("siteId"));
			indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			strAuditlogSiteId = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		//	user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			model.addAttribute("indentCreationModelForm", icb);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("blocksMap", iis.loadBlockDetails(String.valueOf(site_Id)));
			List<IndentCreationBean> list = ics.getIndentCreationLists(indentNumber);
			List<IndentCreationBean> editList = new ArrayList<IndentCreationBean>();
			String strEditComments = "";
			for(int i =0 ;i< list.size();i++ ){
				
				IndentCreationBean objIndentCreationBean = list.get(i);
				model.addAttribute("materialEditComment", objIndentCreationBean.getMaterialEditComment());
				strEditComments = objIndentCreationBean.getMaterialEditComment();
				
				if(strEditComments.contains("@@@")){
					String strEditCommentsArr [] = strEditComments.split("@@@");
					for(int j = 0; j< strEditCommentsArr.length;j++){
						IndentCreationBean objCommentIndentCreationBean  = new IndentCreationBean();
						objCommentIndentCreationBean.setMaterialEditComment(strEditCommentsArr[j]);
						editList.add(objCommentIndentCreationBean);
					}
					
					model.addAttribute("materialEditCommentList", editList);
				}
			
			}
			
			String strPurpose = ics.getIndentLevelComments(indentNumber);
			request.setAttribute("print","true");
			model.addAttribute("IndentLevelCommentsList",strPurpose);
			model.addAttribute("print","true");
			model.addAttribute("IndentGetList",list);
			model.addAttribute("IndentCreationDetailsList",ics.getIndentCreationDetailsLists(indentNumber));
			
			model.addAttribute("deletedProductDetailsList",ics.getDeletedProductDetailsLists(indentNumber));
		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails.auditLog("0",user_id,"Showing Indent Details for Approval","Success",String.valueOf(strAuditlogSiteId));
		return "getIndentDetails";
	}

	/**
	 * @description this method is for getting site wise printing the PO details
	 * @param request
	 * @param session
	 */
	@RequestMapping(value = "/getSiteWisePoDetails.spring", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getSiteWisePoDetails(HttpServletRequest request, HttpSession session) {
		System.out.println("IndentCreationController.getSiteWisePoDetails()");
		ModelAndView model = null;
		try {
			model = new ModelAndView();
			String site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();	
			model.addObject("POSite_id", site_id);	
			model.setViewName("ViewPoDetails");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value ="/getPoDetails.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getPoDetails(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String response="";
		String poNumber="";
		ModelAndView model = null;
		List<IndentCreationBean> indentgetData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			poNumber = request.getParameter("poNumber");
			String siteIForPO=request.getParameter("POSite_id");
			
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)
					|| StringUtils.isNotBlank(poNumber)) {
				session = request.getSession(false);
				//site_id = request.getParameter("dropdown_SiteId") == null ? "": request.getParameter("dropdown_SiteId");
					site_id = siteIForPO == null ? "" :siteIForPO.toString();
					System.out.println("Site is is "+site_id+" ..");
					if (StringUtils.isNotBlank(site_id)) {
						model.addObject("POSite_id", site_id);	
					}
	
					
			//	if (StringUtils.isNotBlank(site_id)) {
					indentgetData = ics.getPoDetails(fromDate, toDate, site_id,poNumber);
					if(indentgetData != null && indentgetData.size() >0){
						request.setAttribute("showGrid", "true");
						response="success";
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failure";

					}
					model.addObject("indentgetData",indentgetData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.addObject("poNumber", poNumber);
					model.setViewName("ViewPoDetails");

				/*} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failure";
					return model;
				}*/
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date or PO Number!");
				model.addObject("indentgetData",indentgetData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.addObject("poNumber", poNumber);
				response="success";
				model.setViewName("ViewPoDetails");
			}
		} catch (Exception ex) {
			response="failure";
			ex.printStackTrace();
		} 

		//	SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		//	String user_id=String.valueOf(session.getAttribute("UserId"));
		//	String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		//	audit.auditLog("0",user_id,"Get Grn Details View",response,site_id1);

		return model;
	}

	@RequestMapping(value = "/getPoDetailsList.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String getPoDetailsList(HttpServletRequest request, HttpSession session,Model model){

		String poNumber = "";
		String siteId = "";
		String viewToBeSelected = "";
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		boolean imageClick = false;
		
		String vendorId="";
		Calendar cal = Calendar.getInstance();
		String site_Id="";
		try{
			site_Id=request.getParameter("siteId");
			 
			 
			poNumber = request.getParameter("poNumber") == null ? "" : request.getParameter("poNumber");
			siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			imageClick = request.getParameter("imageClick") == null ? false : Boolean.valueOf(request.getParameter("imageClick"));
			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(poNumber)){




				/*int currentYear = Calendar.getInstance().get(Calendar.YEAR);
				int currentMonth = Calendar.getInstance().get(Calendar.MONTH)+1;*/
				
				/*if(currentMonth <=3){
					strFinacialYear = currentYear-1+"_"+currentYear;
				}else{
					strFinacialYear = currentYear+"_"+currentYear+1;
				}*/
			//	System.out.println(strFinacialYear);
				
				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				String response=ics.getPoDetailsList(poNumber, site_Id,request);

				versionNo=request.getAttribute("versionNo").toString();
				refferenceNo=request.getAttribute("refferenceNo").toString();
				strPoPrintRefdate=request.getAttribute("strPoPrintRefdate").toString();

			

				model.addAttribute("versionNo",versionNo);
			//	DateFormat newDate = new SimpleDateFormat("MM/dd/yyyy");
				//System.out.println("the current year "+newDate.format(cal));
				model.addAttribute("refferenceNo",refferenceNo);
				model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
				request.setAttribute("poPage","true");
				
				
				
				
				
				
				//System.out.println("poNumber "+poNumber);

				if(response.equalsIgnoreCase("Success")) {

					request.setAttribute("imageClick",imageClick);
					viewToBeSelected = "POPrintPage";

				}

			}	
		}catch(Exception ex) {
			ex.printStackTrace();
		} 


		return viewToBeSelected;
	}
	
		@RequestMapping(value ="/ClosedIndentDetails.spring", method = {RequestMethod.GET, RequestMethod.POST})
		public ModelAndView ClosedIndentDetails(HttpServletRequest request,HttpSession session) {
			String deptId = "";
			String toDate = "";
			String fromDate = "";
			String indentNumber = "";
			String response="";
			ModelAndView model = null;
			List<IndentCreationBean> indentClosedData = null;
			Map<String, String> siteDetails = null;
			String siteWiseIndentNo= "";
			String reqSiteId = "";
			try {
				model = new ModelAndView();
				fromDate = request.getParameter("fromDate");
				toDate = request.getParameter("toDate");
				siteWiseIndentNo=request.getParameter("indentNumber");
				reqSiteId=request.getParameter("site");
				if(siteWiseIndentNo!=null&&reqSiteId!=null&&!siteWiseIndentNo.equals("")&&!reqSiteId.equals("")){
					indentNumber = String.valueOf(ics.getIndentNumber(Integer.parseInt(siteWiseIndentNo),Integer.parseInt(reqSiteId)));
				}
				siteDetails = new IndentSummaryDao().getSiteDetails();
				model.addObject("siteDetails", siteDetails);
				if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate) || StringUtils.isNotBlank(indentNumber)) {
					 session = request.getSession(false);
					 deptId = validateParams.getProperty("SUMADHURA_PURCHASE_DEPT_MNGR");			
					//System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+deptId);
					if (StringUtils.isNotBlank(deptId)) {
						indentClosedData = ics.getClosedIndents(fromDate, toDate, deptId,indentNumber);
						if(indentClosedData != null && indentClosedData.size() >0){
							request.setAttribute("showGrid", "true");
							response="success";
						} else {
							model.addObject("succMessage","The above Dates Data Not Available");
							response="failure";
							
						}
						model.addObject("indentClosedData",indentClosedData);
						model.addObject("fromDate",fromDate);
						model.addObject("toDate", toDate);
						model.addObject("indentNumber", indentNumber);
						model.setViewName("ClosedIndents");

					} else {
						model.addObject("Message","Session Expired, Please Login Again");
						model.setViewName("index");
						response="failure";
						return model;
					}
				} else {
					model.addObject("displayErrMsg", "Please Select From Date or To Date or Indent Number!");
					model.addObject("indentClosedData",indentClosedData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.addObject("indentNumber", indentNumber);
					response="success";
					model.setViewName("ClosedIndents");
				}
			} catch (Exception ex) {
				response="failure";
				ex.printStackTrace();
			} 
			
		
			return model;
		}
	
		@RequestMapping(value = "/ClosedIndentsList.spring", method = RequestMethod.GET)
		public String ClosedIndentsList(Model model, HttpServletRequest request,HttpSession session) {
			IndentCreationBean icb = new IndentCreationBean();
			int indentNumber = 0;
			String user_id = "";
			int site_Id = 0;
			// checking whether indentNumber is valid or not
			boolean isValid = false;
			try {
				session = request.getSession(true);
				indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
				site_Id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
				user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			
			} catch (Exception e) {
				e.printStackTrace();
			}
		
			try {
				
				String strPurpose = ics.getIndentLevelComments(indentNumber);
				
				model.addAttribute("IndentLevelCommentsList",strPurpose);
				model.addAttribute("indentCreationModelForm", icb);
				model.addAttribute("productsMap", iis.loadProds());
				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("blocksMap", iis.loadBlockDetails(String.valueOf(site_Id)));
				List<IndentCreationBean> list = ics.getIndentCreationLists(indentNumber);
				model.addAttribute("print","true");
				model.addAttribute("IndentGetList",list);
				model.addAttribute("IndentCreationDetailsList",ics.getIndentCreationDetailsLists(indentNumber));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			SaveAuditLogDetails.auditLog("0",user_id,"Showing Indent Details for Approval","Success",String.valueOf(site_Id));
			return "getIndentDetails";
		}

		/*@RequestMapping("/ViewIndentProductDetails.spring")
		public String ViewIndentProductDetails(HttpServletRequest request,  HttpSession session) throws Exception {
			String StrResponse="";
			String siteId=session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			 List<Map<String,Object>> listAllProductList = new ArrayList<Map<String,Object>>();
			 listAllProductList=ics.viewIndentProductDetails(siteId);
			 request.setAttribute("allProductlist", listAllProductList);
			StrResponse="ViewIndentProductDetails";
			
			return StrResponse;
		}	*/
		
		@RequestMapping("/ViewIndentProductDetails.spring")
		public String ViewIndentProductDetails(HttpServletRequest request,  HttpSession session) throws Exception {

			String purchase_dept_id = "";
			String toDate = "";
			String fromDate = "";
			String response="";
			ModelAndView model = null;
			String central_Dept_Id="";
			List<Map<String,Object>> listAllProductList = new ArrayList<Map<String,Object>>();
			List<IndentCreationBean> list = new ArrayList<IndentCreationBean>();
			Map<String, String> siteDetails = null;
			String reqSiteId = "";
			String siteId=session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			purchase_dept_id = validateParams.getProperty("PURCHASE_DEPT_ID") == null ? "" : validateParams.getProperty("PURCHASE_DEPT_ID").toString();
			central_Dept_Id=validateParams.getProperty("CENTRAL_DEPT_ID") == null ? "" : validateParams.getProperty("CENTRAL_DEPT_ID").toString();
			try {
				model = new ModelAndView();
				fromDate = request.getParameter("fromDate");
				toDate = request.getParameter("toDate");
				reqSiteId=request.getParameter("site");
				siteDetails = new IndentSummaryDao().getSiteDetails();
				request.setAttribute("siteDetails",siteDetails);
			//	model.addObject("siteDetails", siteDetails);
				
				System.out.println("the data is "+siteDetails);
				
				

				if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
					session = request.getSession(false);

					if (siteId.equalsIgnoreCase(purchase_dept_id) || siteId.equalsIgnoreCase(central_Dept_Id)) {

						
						reqSiteId=request.getParameter("site");

						list=ics.viewIndentProductDetails(fromDate,toDate,reqSiteId);
						request.setAttribute("allProductlist", list);


						model.addObject("fromDate",fromDate);
						model.addObject("toDate", toDate);
						model.addObject("site",siteId);
						response="ViewIndentProductDetails";

					} else {
					//	request.setAttribute("purchase","false");
						list=ics.viewIndentProductDetails(fromDate,toDate,siteId);
						request.setAttribute("allProductlist", list);
						response="ViewIndentProductDetails";
					}
				} else {
					
					if(siteId.equalsIgnoreCase(purchase_dept_id) || siteId.equalsIgnoreCase(central_Dept_Id)){
						request.setAttribute("DEPT_ID","true");
					}

					response="ViewIndentDetailsPage";

				}
			} catch (Exception ex) {
				response="failure";
				ex.printStackTrace();
			} 


			return response;
		}
		
		
}
