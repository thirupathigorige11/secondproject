package com.sumadhura.in;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sumadhura.bean.GetInvoiceDetailsBean;
import com.sumadhura.bean.IndentCreationBean;
import com.sumadhura.bean.IndentIssueBean;
import com.sumadhura.bean.IndentReceiveBean;
import com.sumadhura.bean.MenuDetails;
import com.sumadhura.bean.ProductDetails;
import com.sumadhura.bean.userDetails;
import com.sumadhura.dto.IndentCreationDto;
import com.sumadhura.service.CentralSiteIndentrocessService;
import com.sumadhura.service.DCFormService;
import com.sumadhura.service.EmailFunction;
import com.sumadhura.service.IndentCreationService;
import com.sumadhura.service.IndentIssueService;
import com.sumadhura.service.IndentReceiveService;
import com.sumadhura.service.PurchaseDepartmentIndentrocessService;
import com.sumadhura.transdao.IndentCreationDao;
import com.sumadhura.transdao.IndentSummaryDao;
import com.sumadhura.transdao.PurchaseDepartmentIndentProcessDao;
import com.sumadhura.transdao.UtilDao;
import com.sumadhura.util.AESDecrypt;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;

@Controller
public class PurchaseDepartmentIndentrocessController extends UIProperties {

	@Autowired
	@Qualifier("dcFormClass")
	DCFormService dcFormService;


	@Autowired
	@Qualifier("purchaseDeptIndentrocess")
	PurchaseDepartmentIndentrocessService objPurchaseDeptIndentrocess;



	@Autowired
	@Qualifier("cntlIndentprocess")
	CentralSiteIndentrocessService csips;



	@Autowired
	@Qualifier("posClass")
	IndentCreationService ics;

	@Autowired
	private IndentCreationDao icd;

	@Autowired
	@Qualifier("iisClass")
	IndentIssueService iis;

	@Autowired
	@Qualifier("irsClass")
	IndentReceiveService irs;

	@Autowired
	UtilDao objUtilDao;


	@RequestMapping(value = "/vendorlogin.spring", method =  {RequestMethod.POST,RequestMethod.GET})
	public String vendorlogin(Model model, HttpServletRequest request,HttpSession session) throws Exception {


		String StrResponse=request.getParameter("submitButton")==null ? "0":request.getParameter("submitButton");
		if(StrResponse.equalsIgnoreCase("true")){


			request.setAttribute("indentNumber",request.getParameter("indentNumber"));
			request.setAttribute("indentCreationDetailsIdForenquiry",request.getParameter("indentCreationDetailsIdForenquiry"));
			request.setAttribute("vendordata",request.getParameter("vendordata"));


		}
		else{

			AESDecrypt decrypt=new AESDecrypt();
			String strData = request.getParameter("data");

			strData = strData.replace(" ","+");
			String strDecrypt =decrypt.decrypt("AMARAVADHIS12345",strData);

			/*("indentNumber=101&vendordata=pavan@@1234@@nlh@@VND01"+
	                   "&uname=VND01&pass=xyz&indentCreationDetailsIdForenquiry=101");*/
			String indentNum[] = null;
			String indentCreationId[] = null;
			String strVendorData[] = null;
			if(strDecrypt.contains("&")){
				String data[] = strDecrypt.split("&");

				String strIndentNumberbefore = data[0];
				String vendorData=data[1];
				String uName = data[2];
				String password = data[3];
				String indentCreationIdForEnquiry = data[4];
				indentNum = strIndentNumberbefore.split("=");
				indentCreationId=indentCreationIdForEnquiry.split("=");
				strVendorData=vendorData.split("=");			


			}



			request.setAttribute("indentNumber",indentNum[1]);
			request.setAttribute("indentCreationDetailsIdForenquiry",indentCreationId[1]);
			request.setAttribute("vendordata",strVendorData[1]);

		}
		return "vendorlogin";
	}

	@RequestMapping(value = "/vendorloginsubmit.spring", method = {RequestMethod.POST,RequestMethod.GET})
	public String vendorloginsubmit(Model model, HttpServletRequest request,HttpSession session) throws Exception {

		List<ProductDetails> IndentDetails = null;
		List<IndentCreationBean> IndentDtls = null;

		int indentNumber = 0;
		int siteWiseIndentNo = 0;
		String vendordata = "";
		String[] vdata = new String[0];
		String uname = "";
		String pass = "";
		String address = "";
		String indentCreationDetailsIdForenquiry = "";

		String StrResponse=request.getParameter("submitButton")==null ? "0":request.getParameter("submitButton");
		if(StrResponse.equalsIgnoreCase("true")){
			indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			siteWiseIndentNo = objPurchaseDeptIndentrocess.getSiteWiseIndentNo(indentNumber);
			vendordata = request.getParameter("vendordata");
			vdata = vendordata.split("@@");


			uname = request.getParameter("uname");
			pass = request.getParameter("pass");
			address=request.getParameter("address");

			indentCreationDetailsIdForenquiry = request.getParameter("indentCreationDetailsIdForenquiry");
		}
		else{


			AESDecrypt decrypt=new AESDecrypt();
			String strData = request.getParameter("data");

			strData = strData.replace(" ","+");
			String strDecrypt =decrypt.decrypt("AMARAVADHIS12345",strData);

			/*("indentNumber=101&vendordata=pavan@@1234@@nlh@@VND01"+
		                   "&uname=VND01&pass=xyz&indentCreationDetailsIdForenquiry=101");*/
			String indentNum[] = null;
			String indentCreationId[] = null;
			String strVendorData[] = null;

			if(strDecrypt.contains("$$$")){
				String data[] = strDecrypt.split("\\$\\$\\$");
				//System.out.println("strDecrypt  "+strDecrypt);
				String strIndentNumberbefore = data[0];
				String vendorData=data[1];
				uname = data[2].split("=")[1];
				pass = data[3].split("=")[1];
				String indentCreationIdForEnquiry = data[4];
				if(data[5] != null){
					address=data[5].split("=")[1];
				}
				indentNum = strIndentNumberbefore.split("=");
				indentCreationId=indentCreationIdForEnquiry.split("=");
				strVendorData=vendorData.split("=");			


			}


			//System.out.println("after vendor submit"+indentNumber);
			indentNumber = Integer.parseInt(indentNum[1]);
			siteWiseIndentNo = objPurchaseDeptIndentrocess.getSiteWiseIndentNo(indentNumber);
			indentCreationDetailsIdForenquiry = indentCreationId[1];
			vendordata = strVendorData[1];
			vdata = vendordata.split("@@");


		}

		boolean isValidPassword = objPurchaseDeptIndentrocess.getVendorPasswordInDB(uname,indentNumber,pass);

		List<MenuDetails> list = new ArrayList<MenuDetails>();
		session.setAttribute("menu", list);

		if(isValidPassword)
		{

			//int indentNumber = 0;	

			//String indentCreationDetailsIdForenquiry = request.getParameter("indentCreationDetailsIdForenquiry");


			ProductDetails objProductDetails = new ProductDetails();			
			model.addAttribute("CreatePOModelForm", objProductDetails);


			model.addAttribute("indentNo", indentNumber);
			model.addAttribute("siteWiseIndentNo", siteWiseIndentNo);
			model.addAttribute("vendorName", vdata[0]);
			model.addAttribute("strGSTINNumber", vdata[1]);
			model.addAttribute("vendorAddress", vdata[2]);
			model.addAttribute("vendorId", vdata[3]);
			model.addAttribute("address", address);
			model.addAttribute("productsMap", dcFormService.loadProds());
			model.addAttribute("pass",pass);
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());
			IndentDetails = csips.getPurchaseIndentDtlsLists(indentCreationDetailsIdForenquiry,vdata[3]);

			if(indentNumber==0){
				model.addAttribute("SiteName", "");
				model.addAttribute("SiteId", "");
				model.addAttribute("productList",objPurchaseDeptIndentrocess.combinedDetailsChildProductWise(IndentDetails));
			}
			else{
				IndentDtls = ics.getIndentCreationLists(indentNumber);
				model.addAttribute("SiteName", IndentDtls.get(0).getSiteName());
				model.addAttribute("SiteId", IndentDtls.get(0).getSiteId());
				model.addAttribute("productList",IndentDetails);
			}
			return "CreatePO_Vendor";
		}
		model.addAttribute("message","Data Submitted Already");
		return "response";

	}








	/*@RequestMapping(value = "/OLDviewPurchaseIndent.spring", method = RequestMethod.GET)
	public String OLDviewPurchaseIndent(Model model, HttpServletRequest request,HttpSession session) {
		IndentCreationBean icb = new IndentCreationBean();
		String strSiteId = "";
		String user_id = "";
		int indentNumber = 0;
		String reqSiteName = "";
		//iib.setProjectName(iis.getProjectName(session));
		List<IndentCreationBean> IndentDetails = null;
		List<IndentCreationBean> IndentDtls = null;
		try {
			session = request.getSession(true);
			strSiteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			reqSiteName = request.getParameter("siteName");
			System.out.println("the site name "+reqSiteName);
			model.addAttribute("indentCreationModelForm", icb);
			model.addAttribute("productsMap", iis.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			//model.addAttribute("blocksMap", iis.loadBlockDetails(strSiteId));
			icb.setIndentNumber(indentNumber);	
			icb.setSiteName(reqSiteName);	

			IndentDetails = null;
			IndentDtls = null;
			IndentDtls = ics.getIndentCreationLists(indentNumber);// even though it is a list of objects but it has only one Object.
			//IndentDtls.get(0).setSiteName(reqSiteName);	//so that i added like this to the object at 1st index.
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(IndentDtls.size()==0){
			model.addAttribute("responseMessage","Enter Correct Number");
			List<IndentCreationBean> listofCentralIndents = null;
			listofCentralIndents = objPurchaseDeptIndentrocess.getAllPurchaseIndents();
			model.addAttribute("listofCentralIndents",listofCentralIndents);
			request.setAttribute("totalProductsList",objPurchaseDeptIndentrocess.getAllProducts());
			SaveAuditLogDetails.auditLog("0",user_id,"Entered Wrong Purchase Indent Number","Failure",strSiteId);
			return "PendingIndents";
			}
		model.addAttribute("IndentDtls",IndentDtls);
		model.addAttribute("reqSiteName",reqSiteName);
		IndentDetails = csips.getPurchaseIndentDetailsLists(indentNumber);
		model.addAttribute("IndentDetails",IndentDetails);
		SaveAuditLogDetails.auditLog("0",user_id,"Showing Purchase Indent","Success",strSiteId);
		return "AllIndent";
	}*/

	@RequestMapping(value = "/viewPurchaseIndent.spring", method = {RequestMethod.POST,RequestMethod.GET})
	public String viewPurchaseIndent(Model model, HttpServletRequest request,HttpSession session) {
		int indentNumber = 0;
		int site_id = 0;
		String user_id = "";
		List<IndentCreationBean> IndentDtls = null;
		List<IndentCreationBean> IndentDetails = null;
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			indentNumber = Integer.parseInt(request.getParameter("indentNumber"));
			ProductDetails objProductDetails = new ProductDetails();
			model.addAttribute("CreatePOModelForm", objProductDetails);
			String strCreationDate = request.getParameter("creationDate");
			model.addAttribute("strCreationDate",strCreationDate);
			IndentDtls = ics.getIndentCreationLists(indentNumber);
			if(IndentDtls.size()==0){
				model.addAttribute("responseMessage","Enter Correct Number");
				List<IndentCreationBean> listofCentralIndents = null;
				listofCentralIndents = objPurchaseDeptIndentrocess.getAllPurchaseIndents();
				model.addAttribute("listofCentralIndents",listofCentralIndents);
				request.setAttribute("totalProductsList",objPurchaseDeptIndentrocess.getAllProducts());
				SaveAuditLogDetails.auditLog("0",user_id,"Entered Wrong Purchase Indent Number","Failure",String.valueOf(site_id));
				return "PendingIndents";
			}
			String strRequestSiteId = request.getParameter("siteId"); 
			model.addAttribute("IndentDtls",IndentDtls);
			IndentDetails = csips.getPurchaseIndentDetailsLists(indentNumber,strRequestSiteId);
			model.addAttribute("IndentDetails",IndentDetails);


		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Showing Purchase Indent","Success",String.valueOf(site_id));
		return "AllIndent";
	}

	@RequestMapping(value = "/createPODetails.spring", method = RequestMethod.POST)
	public String createPODetails(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			ProductDetails objProductDetails = new ProductDetails();

			//ics.createPO(model, request);
			List<ProductDetails> IndentDetails = null;
			String indentNo = request.getParameter("indentNumber");
			String siteWiseIndentNo = request.getParameter("siteWiseIndentNo");
			String SiteId=request.getParameter("siteId");
			String SiteName=request.getParameter("siteName");
			String VendorName=request.getParameter("vendorName1");
			String strCreationDate = request.getParameter("strCreationDate");

			model.addAttribute("CreatePOModelForm", objProductDetails);
			model.addAttribute("indentNo", indentNo);
			model.addAttribute("siteWiseIndentNo", siteWiseIndentNo);
			model.addAttribute("SiteId", SiteId);
			model.addAttribute("SiteName", SiteName);
			model.addAttribute("strCreationDate", strCreationDate);
			model.addAttribute("listOfGetProductDetails",objPurchaseDeptIndentrocess.getProductDetailsLists(indentNo, VendorName,request,"false"));

			model.addAttribute("productsMap", dcFormService.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());

			//what is the use of this code ?

			IndentDetails= objPurchaseDeptIndentrocess.createPO(model, request,session);	
			model.addAttribute("productList",IndentDetails);	


			List<ProductDetails> listTermsAndCondition = objPurchaseDeptIndentrocess.getTermsAndConditions(SiteId);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());

			String ccEmails = objPurchaseDeptIndentrocess.getDefaultCCEmails(SiteId);
			model.addAttribute("ccEmails",ccEmails);


			//System.out.println(IndentDetails);
			//System.out.println("the site name is "+SiteId);
			objProductDetails.setStrProjectName(iis.getProjectName(session));
		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Entering PO Details","Success",String.valueOf(site_id));
		return "CreatePO";
	}
	@RequestMapping(value = "/printIndent.spring", method = RequestMethod.POST)
	public String printIndent(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			//site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			site_id = Integer.parseInt(request.getParameter("siteId") == null ? "" : request.getParameter("siteId").toString());



			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			objPurchaseDeptIndentrocess.printIndent(model, request, site_id, user_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Printing Indent","Success",String.valueOf(site_id));
		return "PrintIndent";
	}
	/*@RequestMapping(value = "/CreatePO.spring", method = RequestMethod.POST)
	public String createPO(Model model, HttpServletRequest request,HttpSession session) {
		/*session = request.getSession(true);
		int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		String indentNumber= request.getParameter("indentNumber");
		model.addAttribute("indentNumber",indentNumber);*/


	/*	ProductDetails objProductDetails = new ProductDetails();

		//ics.createPO(model, request);

		model.addAttribute("CreatePOModelForm", objProductDetails);
		model.addAttribute("productList", objPurchaseDeptIndentrocess.createPO(model, request,session));	
		objProductDetails.setStrProjectName(iis.getProjectName(session));




		return "CreateIndentPO";
	}*/



	@RequestMapping(value = "/sendenquiry.spring", method = RequestMethod.POST)
	public String sendPurchaseIndentToVendor(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);

			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			String indentNumber= request.getParameter("indentNumber");
			String siteId= request.getParameter("siteId");
			String siteWiseIndentNo= request.getParameter("siteWiseIndentNo");
			String siteName= request.getParameter("siteName");
			model.addAttribute("indentNumber",indentNumber);
			model.addAttribute("siteId",siteId);
			model.addAttribute("siteWiseIndentNo",siteWiseIndentNo);
			model.addAttribute("siteName",siteName);
			List<Map<String, Object>> listReceiverDtls=objPurchaseDeptIndentrocess.sendenquiry(model, request, site_id, user_id,siteId);

			//	List<Map<String, Object>> listReceiverDtls=ics.getVendorOrSiteAddress(siteId);
			model.addAttribute("listReceiverDtls",listReceiverDtls);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Sending Enquiry","Success",String.valueOf(site_id));
		return "SendEnquiry";
	}
	@RequestMapping(value = "/fillForm.spring", method = RequestMethod.POST)
	public String fillForm(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			ProductDetails objProductDetails = new ProductDetails();

			//ics.createPO(model, request);
			List<ProductDetails> IndentDetails = null;
			String indentNo = request.getParameter("indentNumber");
			String SiteId=request.getParameter("siteId");
			String SiteName=request.getParameter("siteName");
			String siteWiseIndentNo = request.getParameter("siteWiseIndentNo");


			model.addAttribute("CreatePOModelForm", objProductDetails);
			model.addAttribute("indentNo", indentNo);
			model.addAttribute("siteWiseIndentNo", siteWiseIndentNo);
			model.addAttribute("SiteId", SiteId);
			model.addAttribute("SiteName", SiteName);
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());

			//what is the use of below code ?


			request.setAttribute("isFillForm","yes");
			objPurchaseDeptIndentrocess.sendenquiry(model, request, site_id, user_id,SiteId);

			IndentDetails= objPurchaseDeptIndentrocess.createPO(model, request,session);	
			model.addAttribute("productList",IndentDetails);	


			/*List<ProductDetails> listTermsAndCondition = objPurchaseDeptIndentrocess.getTermsAndConditions();
				model.addAttribute("listTermsAndCondition",listTermsAndCondition);*/



			//System.out.println(IndentDetails);
			//System.out.println("the site name is "+SiteId);
			objProductDetails.setStrProjectName(iis.getProjectName(session));
		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Filling Enquiry Form","Success",String.valueOf(site_id));
		return "CreatePO_FillForm";
	}
	@RequestMapping(value = "/sendenquiry2.spring", method = RequestMethod.POST)
	public String sendPurchaseIndentToVendor2(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			String indentNumber= request.getParameter("indentNo1");
			String strSiteId= request.getParameter("strSiteId1");
		//	System.out.println("the site name in controller"+strSiteId);
			model.addAttribute("indentNumber",indentNumber);
			List<Map<String, Object>> listReceiverDtls=objPurchaseDeptIndentrocess.sendenquiry2(model, request, site_id, user_id,strSiteId);
			model.addAttribute("listReceiverDtls",listReceiverDtls);
		} catch (NumberFormatException e) {

			e.printStackTrace();//TODO Auto-generated catch block
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Sending Enquiry","Success",String.valueOf(site_id));
		return "SendEnquiry";
	}
	@RequestMapping(value = "/SavePoDetails.spring", method = RequestMethod.POST)
	public String SavePoDetails(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";

		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		String strValue="";

		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			int currentYear = Calendar.getInstance().get(Calendar.YEAR);
			int currentMonth = Calendar.getInstance().get(Calendar.MONTH)+1;
			Calendar cal = Calendar.getInstance();
			String currentYearYY = new SimpleDateFormat("YY").format(cal.getTime());
			String strFinacialYear = "";
			//String FinacialYear = "";

			if(currentMonth <=3){

				strFinacialYear = (currentYear-1)+"-"+Integer.parseInt(currentYearYY);
			}else{
				strFinacialYear = currentYear+"-"+(Integer.parseInt(currentYearYY)+1);
			}
			//	request.setAttribute("strFinacialYear",strFinacialYear);
			versionNo = validateParams.getProperty("PO_versionNo");
			refferenceNo = validateParams.getProperty("PO_Refference");
			strPoPrintRefdate = validateParams.getProperty("PO_issuedate");
			
			request.setAttribute("versionNo", versionNo);
			request.setAttribute("refferenceNo", refferenceNo);
			request.setAttribute("strPoPrintRefdate", strPoPrintRefdate);
			
			model.addAttribute("versionNo",versionNo);
			model.addAttribute("refferenceNo",refferenceNo);
			model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
			request.setAttribute("poPage","true");
			ProductDetails objProductDetails = new ProductDetails();
			//ics.createPO(model, request);
			model.addAttribute("CreatePOModelForm", objProductDetails);
			strValue=objPurchaseDeptIndentrocess.SavePoDetails(model, request,session,strFinacialYear);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		SaveAuditLogDetails.auditLog("0",user_id,"PO Created",response,String.valueOf(site_id));
		//System.out.println("return page name: "+strValue);
		return strValue;

	}



	@RequestMapping(value = "/SaveEnquiryForm.spring", method = RequestMethod.POST)
	public String SaveVendorPODetails(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";

		try {
			session = request.getSession(true);
			//site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			//user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			ProductDetails objProductDetails = new ProductDetails();
			//ics.createPO(model, request);
			model.addAttribute("CreatePOModelForm", objProductDetails);
			response = objPurchaseDeptIndentrocess.SaveEnquiryForm(model, request,session);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		if(response.equals("Success"))
		{
			SaveAuditLogDetails.auditLog("0",user_id,"Save Enquiry Form",response,String.valueOf(site_id));
			request.setAttribute("message", "Data Submitted.");
			return "Vendor_Response";
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Save Enquiry Form",response,String.valueOf(site_id));
		request.setAttribute("message", "Error Occured. Click Link and Try Again...");
		return "Vendor_Response";
	}

	/*@RequestMapping(value = "/loadCreatePOPage.spring", method = RequestMethod.POST)
	public String loadCreatePOPage(Model model, HttpServletRequest request,HttpSession session) {
		/*session = request.getSession(true);
		int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		String indentNumber= request.getParameter("indentNumber");
		model.addAttribute("indentNumber",indentNumber);*/


	/*ProductDetails objProductDetails = new ProductDetails();

		//ics.createPO(model, request);

		model.addAttribute("CreatePOModelForm", objProductDetails);
		model.addAttribute("productList", objPurchaseDeptIndentrocess.loadCreatePOPage(model, request));	
		objProductDetails.setStrProjectName(iis.getProjectName(session));


		//request.setAttribute("productList", productList);

		return "CreatePO";

	}*/

	@RequestMapping(value = "/getIndentsProductWise.spring", method = RequestMethod.POST)
	public String getIndentsProductWise(Model model, HttpServletRequest request,HttpSession session, 
			@RequestParam("combobox_Product") String product, @RequestParam("combobox_SubProduct") String subProduct, @RequestParam("combobox_ChildProduct") String childProduct) 
	{

		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);

			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			model.addAttribute("getIndentsProductWiseModelForm",  new ProductDetails());
			//System.out.println(product+","+subProduct+","+childProduct);

			List<ProductDetails> productList = objPurchaseDeptIndentrocess.getIndentsProductWise(product,subProduct,childProduct);

			request.setAttribute("productList", productList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Sending Enquiry","Success",String.valueOf(site_id));
		return "ProductWiseIndents";
	}


	@RequestMapping(value = "/getComparisionStatement.spring", method = RequestMethod.POST)
	public String getComaprisionStatement(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		List<Map<String, Object>> productList = null;
		try {

			//session = request.getSession(true);
			//site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			//user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			ProductDetails objProductDetails = new ProductDetails();

			//ics.createPO(model, request);
			List<ProductDetails> IndentDetails = null;
			String indentNo = request.getParameter("indentNumber");
			//String SiteId=request.getParameter("siteId");
			String SiteName=request.getParameter("siteName");




			productList = objPurchaseDeptIndentrocess.getComparisionDtls( request,session);	
			//model.addAttribute("productList",productDetails);	
			if(productList.size()>0){



				request.setAttribute("productList", productList);
			}else{
				request.setAttribute("productList1", productList);
			}

			model.addAttribute("indentNo", indentNo);
			model.addAttribute("siteName", SiteName);

			//System.out.println(IndentDetails);


		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails.auditLog("0",user_id,"Entering PO Details","Success",String.valueOf(site_id));
		if(productList != null && productList.size() > 0){
			return "Comparison";
		}else{

			model.addAttribute("message1", "Sorry Comparision not available for this product(s)");

			return "response";
		}




	}

	@RequestMapping(value ="/ViewPoPendingforApproval.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView ViewPoPendingforApproval(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String response="";
		String tempPoNumber = "";
		ModelAndView model = null;
		String user_id="";
		List<IndentCreationBean> indentgetData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			tempPoNumber=request.getParameter("tempPoNumber");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate) || StringUtils.isNotBlank(tempPoNumber)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();	
				user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
				//System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					indentgetData = objPurchaseDeptIndentrocess.ViewPoPendingforApproval(fromDate, toDate, user_id,tempPoNumber);
					if(indentgetData != null && indentgetData.size() >0){
						request.setAttribute("showGrid", "true");
						response="success";
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failure";

					}
					model.addObject("indentgetData",indentgetData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.addObject("tempPoNumber", tempPoNumber);
					model.setViewName("PendingPoApproval");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failure";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date or Temp Po Number!");
				model.addObject("indentgetData",indentgetData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.addObject("tempPoNumber", tempPoNumber);
				response="success";
				model.setViewName("PendingPoApproval");
			}
		} catch (Exception ex) {
			response="failure";
			ex.printStackTrace();
		} 

		//	SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		//	String user_id=String.valueOf(session.getAttribute("UserId"));
		//	String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		//	audit.auditLog("0",user_id,"Get Grn Details View",response,site_id1);

		return model;
	}

	@RequestMapping(value = "/getDetailsforPoApproval.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String getDetailsforPoApproval(HttpServletRequest request, HttpSession session,Model model){

		String poNumber = "";
		String siteId = "";
		String viewToBeSelected = "";
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		String strNewSiteId = "";
		try{


			strNewSiteId = request.getParameter("siteId");

			poNumber = request.getParameter("poNumber") == null ? "" : request.getParameter("poNumber").toString();
			siteId = request.getParameter("siteId") == null ? "" : request.getParameter("siteId").toString();


			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(poNumber)){

				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				String response=objPurchaseDeptIndentrocess.getDetailsforPoApproval(poNumber, siteId,request);
				String ccEmails = objPurchaseDeptIndentrocess.getTempPoCCEmails(poNumber);
				
				model.addAttribute("ccEmails",ccEmails);
				versionNo=request.getAttribute("versionNo").toString();
				refferenceNo=request.getAttribute("refferenceNo").toString();
				strPoPrintRefdate=request.getAttribute("strPoPrintRefdate").toString();
				
				
				/*if(versionNo.equals("-") && refferenceNo.equals("-") && strPoPrintRefdate.equals("-")){
				String strFinacialYear =request.getAttribute("strFinacialYear").toString();
				versionNo = validateParams.getProperty("PO_"+strFinacialYear+"_versionNo");
				refferenceNo = validateParams.getProperty("PO_"+strFinacialYear+"_Refference");
				strPoPrintRefdate = validateParams.getProperty("PO_"+strFinacialYear+"_issuedate");
				}*/
				model.addAttribute("versionNo",versionNo);
				model.addAttribute("refferenceNo",refferenceNo);
				model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
				model.addAttribute("response",true);
				//System.out.println("poNumber "+poNumber);

				if(response.equalsIgnoreCase("Success")) {

					viewToBeSelected = "Appoval_PO";
				}

			}	
		}catch(Exception ex) {
			ex.printStackTrace();
		} 


		return viewToBeSelected;
	}

	@RequestMapping(value = "/showPODetailsToVendor.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String showPODetailsToVendor(HttpServletRequest request, HttpSession session,Model model){




		String poNumber = "";
		String siteId = "";
		String viewToBeSelected = "";
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		String strResponse="";
		String vendorId="";
		String siteName="";
	//	string strvendorId="";
		Calendar cal = Calendar.getInstance();
		//String site_Id="";
		try{
			//	site_Id=request.getParameter("siteId");

			strResponse=request.getParameter("submitButton")== null ? "0" : request.getParameter("submitButton");
			if(strResponse.equalsIgnoreCase("true")){

				poNumber = request.getParameter("poNumber") == null ? "" : request.getParameter("poNumber");
				siteId = request.getParameter("indentSiteId") == null ? "" : request.getParameter("indentSiteId").toString();
			//	vendorId=request.getParameter("vendorId") == null ? "" : request.getParameter("vendorId").toString();
			}
			else{

				AESDecrypt decrypt=new AESDecrypt();
				String strData = request.getParameter("data");

				strData = strData.replace(" ","+");
				String strDecrypt =decrypt.decrypt("AMARAVADHIS12345",strData);

				String strPoNumber[] = null;
				String strSiteId[] = null;
				String strVendorId[]=null;
				String strSiteName[]=null;
				
				//	String indentCreationId[] = null;
				//	String strVendorData[] = null;
				if(strDecrypt.contains("&")){
					String data[] = strDecrypt.split("&");

					poNumber = data[0];
					siteId=data[1];
					/*siteName=data[2];
					if(data.length > 3){
						vendorId=data[3];
					}*/
					strPoNumber = poNumber.split("=");
					strSiteId=siteId.split("=");

					strSiteName=siteName.split("=");
					poNumber=strPoNumber[1];
					siteId=strSiteId[1];

					/*if(vendorId != null && !vendorId.equals("")){
						strVendorId=vendorId.split("=");
						vendorId=strVendorId[1];
						//	siteName=strSiteName[1];
					}*/

				}

			}

			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(poNumber)){


				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				String response=ics.getPoDetailsList(poNumber, siteId,request);

				String strFinacialYear =request.getAttribute("strFinacialYear").toString();
				versionNo = validateParams.getProperty("PO_"+strFinacialYear+"_versionNo");
				refferenceNo = validateParams.getProperty("PO_"+strFinacialYear+"_Refference");
				strPoPrintRefdate = validateParams.getProperty("PO_"+strFinacialYear+"_issuedate");

				request.setAttribute("poPage","false");
				model.addAttribute("versionNo",versionNo);
				//	DateFormat newDate = new SimpleDateFormat("MM/dd/yyyy");
				//System.out.println("the current year "+newDate.format(cal));
				model.addAttribute("refferenceNo",refferenceNo);
				model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);






				System.out.println("poNumber "+poNumber);

				if(response.equalsIgnoreCase("Success")) {

					viewToBeSelected = "POPrintPage";
				}

			}	
		}catch(Exception ex) {
			ex.printStackTrace();
		} 


		return viewToBeSelected;


		/*

		String poNumber = "";
		String siteId = "";
		String viewToBeSelected = "";
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		String strNewSiteId = "";
		request.setAttribute("showPODetailsToVendor", "yes");


		try{

			poNumber = request.getParameter("poNumber") == null ? "" : request.getParameter("poNumber").toString();
			siteId = objPurchaseDeptIndentrocess.getSiteIdByPONumber(poNumber);

			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(poNumber)){

				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				String response=objPurchaseDeptIndentrocess.getDetailsforPoApproval(poNumber, siteId,request);
				String strFinacialYear =request.getAttribute("strFinacialYear").toString();
				versionNo = validateParams.getProperty("PO_"+strFinacialYear+"_versionNo");
				refferenceNo = validateParams.getProperty("PO_"+strFinacialYear+"_Refference");
				strPoPrintRefdate = validateParams.getProperty("PO_"+strFinacialYear+"_issuedate");
				model.addAttribute("versionNo",versionNo);
				model.addAttribute("refferenceNo",refferenceNo);
				model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
				System.out.println("poNumber "+poNumber);

				if(response.equalsIgnoreCase("Success")) {

					viewToBeSelected = "PoApproval";
				}

			}	
		}catch(Exception ex) {
			ex.printStackTrace();
		} 


		return viewToBeSelected;
		 */}


	@RequestMapping(value = "/SavePoApproveDetails.spring", method = RequestMethod.POST)
	public String SavePoApproveDetails(Model model, HttpServletRequest request,HttpSession session) {
		String sessionSite_id ="";
		String user_id = "";
		String response = "";
		String ponumber="";
		String siteId="";
		String permPoNumber = "";
		String strMessage = "";
		try {
			ponumber=request.getParameter("strPONumber");
			siteId=request.getParameter("siteId");
			//String old_Po_Number=request.getParameter("oldPoNumber") == null ? "#" : request.getParameter("oldPoNumber");
			session = request.getSession(true);

			sessionSite_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			ProductDetails objProductDetails = new ProductDetails();

			model.addAttribute("CreatePOModelForm", objProductDetails);
			request.setAttribute("sessionSite_id",sessionSite_id);
			response=objPurchaseDeptIndentrocess.SavePoApproveDetails(ponumber,siteId,user_id,request,"false");
			// permPoNumber=request.getAttribute("permentPoNumber").toString();
			strMessage = request.getAttribute("result") == null ? "" : request.getAttribute("result").toString();
			if(response=="success"){

				model.addAttribute("response",strMessage);

			}
			else{
				model.addAttribute("response1",strMessage);

			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		SaveAuditLogDetails.auditLog("0",user_id,"save PO Approval ",response,String.valueOf(sessionSite_id));
		return "response";

	}


	@RequestMapping(value = "/RejectPoDetails.spring", method = RequestMethod.POST)
	public String RejectPoDetails(Model model, HttpServletRequest request,HttpSession session) {
		String user_id ="";
		String response = "";
		String site_id ="";
		try {



			response=objPurchaseDeptIndentrocess.RejectPoDetails(session,request);

			if(response=="Success"){ 

				model.addAttribute("response","successfully rejected ");

			}
			else{
				model.addAttribute("response1"," not successfully rejected ");

			}


		} catch (Exception e) {

			e.printStackTrace();
		}	
		SaveAuditLogDetails.auditLog("0",user_id,"PO rejected",response,String.valueOf(site_id));
		return "response";

	}

	@RequestMapping(value = "/getQuatationDetails.spring", method = RequestMethod.POST)
	public String getQuatationDetails(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String vendorName="";
		String indentnumber="";
		String strResponse="";
		String retValue="";

		try {

			vendorName=request.getParameter("vendorName1");
			indentnumber=request.getParameter("indentNumber");
			String poNumber=request.getParameter("poNumber");

			ProductDetails objProductDetails = new ProductDetails();
			List<ProductDetails> IndentDetails = null;
			model.addAttribute("productsMap", dcFormService.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("listIssueToOtherSiteInwardLists",objPurchaseDeptIndentrocess.getQuatationDetails(request));
			model.addAttribute("listOfGetProductDetails",objPurchaseDeptIndentrocess.getProductDetailsListsForQuatation(indentnumber, vendorName,request));	
			strResponse=request.getAttribute("falg").toString();
		//	System.out.println(strResponse);
			if(poNumber!=null && !poNumber.equals("")){
				
				if(strResponse.equalsIgnoreCase("false")){
					retValue="ViewQuatation";
					}	else{
						
						model.addAttribute("message1","sorry ! Quatation is not available to this Po");
						
						retValue="response";
						
					}
				
			}
			
			else{
				retValue="ViewQuatation";
				}
			
			
			//	List<String> listOfTermsAndConditions =(List<String>)request.getAttribute("listOfTermsAndConditions");
			//	System.out.println("the value of list"+listOfTermsAndConditions);
			//	model.addAttribute("listOfTermsAndConditions",listOfTermsAndConditions);



		} catch (Exception e) {
			e.printStackTrace();
		}

		SaveAuditLogDetails.auditLog("0",user_id,"View Quatation Details","Success",String.valueOf(site_id));
		return retValue;
	}

	@RequestMapping(value = "/closeIndent.spring", method = RequestMethod.POST)
	public String closeIndent(Model model, HttpServletRequest request,HttpSession session) {

		List<IndentCreationBean> listofCentralIndents = null;
		int site_id = 0;
		String user_id = "";
		String responseMessage = "";
		userDetails  objuserDetails = new userDetails();
		String[] ccTo = null;
		String strResponse="";
		try {
			session = request.getSession(true);
			//	String typeOfPurchase = request.getParameter("typeOfPurchase");

			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			String siteId= request.getParameter("siteId");
			responseMessage=objPurchaseDeptIndentrocess.closeIndent(model, request, site_id, user_id,siteId);
			if(responseMessage.contains("successfully")){					 

				EmailFunction objEmailFunction = new EmailFunction();



				objuserDetails = objUtilDao.getUserDetails(user_id);
				objuserDetails.setStrMesage(responseMessage);

				ccTo =   objUtilDao.getEmployeesEmailId(siteId);

				objEmailFunction.sendMailToClosedIndents(  ccTo, objuserDetails );

				model.addAttribute("response",responseMessage);
				strResponse="success";
			}
			else{
				model.addAttribute("response1",responseMessage);
				strResponse="failed";
			}


			listofCentralIndents = objPurchaseDeptIndentrocess.getAllPurchaseIndents();
			model.addAttribute("listofCentralIndents",listofCentralIndents);
			request.setAttribute("totalProductsList",objPurchaseDeptIndentrocess.getAllProducts());


		} catch (Exception e) {
			strResponse="failed";
			e.printStackTrace();
			
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Closing Indent",strResponse,String.valueOf(site_id));
		return "PendingIndents";
	}

	@RequestMapping(value ="/ViewTempPoPage.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView ViewTempPo(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String response="";
		String tempPONumber="";
		ModelAndView model = null;
		String user_id="";
		List<IndentCreationBean> indentgetData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			tempPONumber = request.getParameter("tempPoNumber");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate) || StringUtils.isNotBlank(tempPONumber)) {
				session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();	
				user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			//	System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					indentgetData = objPurchaseDeptIndentrocess.ViewTempPo(fromDate, toDate,tempPONumber);
					if(indentgetData != null && indentgetData.size() >0){
						request.setAttribute("showGrid", "true");
						response="success";
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failure";

					}
					model.addObject("indentgetData",indentgetData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.addObject("tempPONumber", tempPONumber);
					model.setViewName("ViewTempPoPage_Dates");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failure";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date or Temp po Number!");
				model.addObject("indentgetData",indentgetData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				model.addObject("tempPONumber", tempPONumber);
				response="success";
				model.setViewName("ViewTempPoPage_Dates");
			}
		} catch (Exception ex) {
			response="failure";
			ex.printStackTrace();
		} 

		//	SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
		//	String user_id=String.valueOf(session.getAttribute("UserId"));
		//	String site_id1 = String.valueOf(session.getAttribute("SiteId"));
		//	audit.auditLog("0",user_id,"Get Grn Details View",response,site_id1);

		return model;
	}

	@RequestMapping(value = "/ViewTempPoPageShow.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String ViewTempPoPageShow(HttpServletRequest request, HttpSession session,Model model){

		String poNumber = "";
		String siteId = "";
		String viewToBeSelected = "";
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		Calendar cal = Calendar.getInstance();
		String site_Id="";
		try{
			site_Id=request.getParameter("siteId");
			poNumber = request.getParameter("poNumber") == null ? "" : request.getParameter("poNumber");
			siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(poNumber)){




				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				//	String response=ics.getTempPoDetailsList(poNumber, site_Id,request);
				String response=objPurchaseDeptIndentrocess.getDetailsforPoApproval(poNumber, site_Id,request);
				String strFinacialYear =request.getAttribute("strFinacialYear").toString();
				versionNo = validateParams.getProperty("PO_"+strFinacialYear+"_versionNo");
				refferenceNo = validateParams.getProperty("PO_"+strFinacialYear+"_Refference");
				strPoPrintRefdate = validateParams.getProperty("PO_"+strFinacialYear+"_issuedate");


				model.addAttribute("versionNo",versionNo);
				model.addAttribute("refferenceNo",refferenceNo);
				model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
				model.addAttribute("response",false);

				System.out.println("poNumber "+poNumber);

				if(response.equalsIgnoreCase("Success")) {

					viewToBeSelected = "ViewTempPo";
				}

			}	
		}catch(Exception ex) {
			ex.printStackTrace();
		} 


		return viewToBeSelected;
	}


	@RequestMapping(value = "/RevisedPO.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String RevisedPO(HttpServletRequest request, HttpSession session,Model model){

		String  site_id ="";
		String user_id = "";
		String result="";
		Map<String, String> siteDetails = null;
		try {
			//site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			site_id=request.getParameter("site")== null ? "" : request.getParameter("site").toString();
			request.setAttribute("isPoUpdated","false");
			siteDetails = new IndentSummaryDao().getSiteDetails();
			request.setAttribute("siteDetails",siteDetails);
			if(StringUtils.isNotBlank(String.valueOf(site_id))){
				
				List<Map<String, Object>> listOfPOs=objPurchaseDeptIndentrocess.getListOfActivePOs(site_id);
					if(listOfPOs.size()>0){
						model.addAttribute("listOfPOs",listOfPOs);
						result="ShowPOListToRevised";
					}else{
						
						model.addAttribute("displayErrMsg","Po not Available With this Site");
						result="RevisedOrUpdatePOPages";
					}
					
			}else{
				
				result="RevisedOrUpdatePOPages";
			}
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Revised PO","Success",String.valueOf(site_id));
		return result;
	}

	@RequestMapping(value = "/showPODetailsToRevised.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String showPODetailsToRevised(HttpServletRequest request, HttpSession session,Model model){

		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("productsMap", dcFormService.loadProds());
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());

			ProductDetails objProductDetails = new ProductDetails();
			model.addAttribute("CreatePOModelForm", objProductDetails);
			//ics.createPO(model, request);
			List<ProductDetails> IndentDetails = null;
			String poNumber = request.getParameter("poNumber");
			model.addAttribute("poNumber",poNumber);
			String reqSiteId = request.getParameter("reqSiteId");
			model.addAttribute("poDetails",irs.getPODetails(poNumber,reqSiteId ));
			model.addAttribute("listOfGetProductDetails",irs.getProductDetailsLists(poNumber,reqSiteId));
			model.addAttribute("listOfTransChrgsDtls",irs.getTransChrgsDtls(poNumber,reqSiteId));
			request.setAttribute("isPoUpdated","false");
			
			List<String> listTermsAndCondition  = objPurchaseDeptIndentrocess.getTempTermsAndConditions(poNumber,"true",reqSiteId);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());
			
			/*List<ProductDetails> listTermsAndCondition = objPurchaseDeptIndentrocess.getTermsAndConditions(reqSiteId);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());*/

			String ccEmails = objPurchaseDeptIndentrocess.getDefaultCCEmails(reqSiteId);
			model.addAttribute("ccEmails",ccEmails);

		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Showing Revised PO Details for Update","Success",String.valueOf(site_id));
		return "ShowPODetailsToRevised";
	}

	@RequestMapping(value = "/editAndSaveRevisedPO.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String editAndSavePO(HttpServletRequest request, HttpSession session,Model model){
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate="";
		
		int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH)+1;
		Calendar cal = Calendar.getInstance();
		String currentYearYY = new SimpleDateFormat("YY").format(cal.getTime());
		String strFinacialYear = "";
		//String FinacialYear = "";

		if(currentMonth <=3){

			strFinacialYear = (currentYear-1)+"-"+Integer.parseInt(currentYearYY);
		}else{
			strFinacialYear = currentYear+"-"+(Integer.parseInt(currentYearYY)+1);
		}
		//	request.setAttribute("strFinacialYear",strFinacialYear);
		versionNo = validateParams.getProperty("PO_versionNo");
		refferenceNo = validateParams.getProperty("PO_Refference");
		strPoPrintRefdate = validateParams.getProperty("PO_issuedate");
		
		request.setAttribute("versionNo", versionNo);
		request.setAttribute("refferenceNo", refferenceNo);
		request.setAttribute("strPoPrintRefdate", strPoPrintRefdate);
		
		model.addAttribute("versionNo",versionNo);
		model.addAttribute("refferenceNo",refferenceNo);
		model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
		request.setAttribute("poPage","true");
		ProductDetails objProductDetails = new ProductDetails();
		//ics.createPO(model, request);
		model.addAttribute("CreatePOModelForm", objProductDetails);
		String response1 = objPurchaseDeptIndentrocess.getNoOfRowsForUpdatePO(model, request, session);

		String response = objPurchaseDeptIndentrocess.SavePoDetails(model, request, session,strFinacialYear);

		/*if(response=="Success"){

			model.addAttribute("response","Successfully Updated ");

		}
		else{
			model.addAttribute("response1"," not successfully updated ");

		}*/
		SaveAuditLogDetails.auditLog("0",user_id,"Showing Revised PO Details",response,String.valueOf(site_id));
		return response;
	}
	
	@RequestMapping(value = "/printIndentForPurchase.spring", method = RequestMethod.POST)
	public String printIndentForPurchase(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(request.getParameter("siteId") == null ? "" : request.getParameter("siteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			objPurchaseDeptIndentrocess.printIndentForPurchase(model, request, site_id, user_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Printing Indent","Success",String.valueOf(site_id));
		return "PrintIndent";
	}
	
	@RequestMapping(value = "/cancelPO.spring", method = RequestMethod.POST)
	public String viewOrCancelPO(Model model, HttpServletRequest request,HttpSession session) {
		String  site_id = "";
		String user_id = "";
		String value="";
		String strResponse="";
		try {
			
			String temp_Po_Number=request.getParameter("strPONumber");
			session = request.getSession(true);
			site_id =(request.getParameter("siteId") == null ? "" : request.getParameter("siteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			value=objPurchaseDeptIndentrocess.CancelPo(session,request,temp_Po_Number,user_id,site_id);
			if(value.equalsIgnoreCase("success")){
				model.addAttribute("message","Temp Po cancel");
				}else{
					
					model.addAttribute("message1","Temp Po Not cancel");
					
				}
			
			strResponse="response";
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"ViewOrCancelPo","Success",site_id);
		return strResponse;
	}
	
	@RequestMapping("/getCanceledPoList.spring")
	public String  viewCancelPoList(HttpServletRequest request,HttpSession session,Model model) {

		List<ProductDetails> list = new ArrayList<ProductDetails>();
		String user_id="";
		String site_id="";
		String retValue="";
		try {
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			site_id =(request.getParameter("siteId") == null ? "" : request.getParameter("siteId").toString());
			List<ProductDetails> getListOfCancelPo=objPurchaseDeptIndentrocess.getListOfCancelPo(user_id);
			
			if(getListOfCancelPo.size()>0){
				
				model.addAttribute("listOfPOs",getListOfCancelPo);
				retValue="ViewCancelPo";
				
			}else{
				
				model.addAttribute("response1","Pending Temp Po's Not Available");
				retValue="response";
				
			}
			
			
		
		
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"ViewOrCancelPoList","Success",site_id);
		
		return retValue;
		
	}
	@RequestMapping(value = "/getCanceledPo.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String ViewOrCancelPo(HttpServletRequest request, HttpSession session,Model model){

		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			String poNumber = request.getParameter("poNumber");
			model.addAttribute("poNumber",poNumber);
			String reqSiteId = request.getParameter("reqSiteId");
			String indentNumber = request.getParameter("indentNumber");
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			
			model.addAttribute("tempPoProd",dcFormService.TempPoloadProds(indentNumber,reqSiteId));
			
			model.addAttribute("productsMap", dcFormService.loadProds());
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());

			ProductDetails objProductDetails = new ProductDetails();
			model.addAttribute("CreatePOModelForm", objProductDetails);
			//ics.createPO(model, request);
			List<ProductDetails> IndentDetails = null;
			
		//	model.addAttribute("productsMapForCancel", dcFormService.loadProdsByPONumber(poNumber,reqSiteId));
			model.addAttribute("poDetails",objPurchaseDeptIndentrocess.getViewCancelPoDetails(poNumber,reqSiteId ));
			model.addAttribute("listOfGetProductDetails",objPurchaseDeptIndentrocess.getProductDetailsListsForCancelPo(poNumber,reqSiteId));
			model.addAttribute("listOfTransChrgsDtls",objPurchaseDeptIndentrocess.getTransChrgsDtlsForCancelPo(poNumber,reqSiteId));
			String strPurpose = objPurchaseDeptIndentrocess.getCancelPoComments(poNumber);
			model.addAttribute("IndentLevelCommentsList",strPurpose);
			
			List<String> listTermsAndCondition  = objPurchaseDeptIndentrocess.getTempTermsAndConditions(poNumber,"false",reqSiteId);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());
			String ccEmails = objPurchaseDeptIndentrocess.getTempPoCCEmails(poNumber);
			String subject = objPurchaseDeptIndentrocess.getTempPOSubject(poNumber);
			model.addAttribute("ccEmails",ccEmails);
			model.addAttribute("subject",subject);
			

		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Showing PO cancle details ","Success",String.valueOf(site_id));
		return "ViewCancelTempPo";
	}
	
	@RequestMapping(value = "/updateTempPoPage.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String updateTempPoPage(HttpServletRequest request, HttpSession session,Model model){
		
		String strResponse="";
		String strSiteId=request.getParameter("siteId");
		int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		String poNumber = request.getParameter("poNo");
		String response = objPurchaseDeptIndentrocess.updateTempPoPage(model, request, session);
		if(response.equalsIgnoreCase("Success")){
			
			strResponse=objPurchaseDeptIndentrocess.SavePoApproveDetails(poNumber,strSiteId,user_id,request,"true");
			
			 if(strResponse.equalsIgnoreCase("Success")){

					model.addAttribute("response","Temp Po Approved Successfully");

				}
				else{
					model.addAttribute("response1","Temp Po Not Approved ");

				}
			 
		}
		
		
		else{
			model.addAttribute("response1"," not successfully updated ");

		}
		
		SaveAuditLogDetails.auditLog("0",user_id,"updateTempPoPage ","Success",String.valueOf(site_id));
	return "response";
	}
	
	@RequestMapping(value = "/tempPoSubProducts.spring", method = RequestMethod.POST)
	@ResponseBody
	public String tempPoSubProducts(@RequestParam("mainProductId") String mainProductId,
			@RequestParam("indentNumber") String indentNumber,@RequestParam("reqSiteId") String reqSiteId) {
		
		System.out.println("indent number"+indentNumber);
		
		return objPurchaseDeptIndentrocess.tempPoSubProducts(mainProductId,indentNumber,reqSiteId);
	}
	
	@RequestMapping(value = "/tempPoChildProducts.spring", method = RequestMethod.POST)
	@ResponseBody
	public String tempPoChildProducts(@RequestParam("subProductId") String subProductId,
			@RequestParam("indentNumber") String indentNumber,@RequestParam("reqSiteId") String reqSiteId) {
		
		return objPurchaseDeptIndentrocess.tempPoChildProducts(subProductId,indentNumber,reqSiteId);
	}
	
	@RequestMapping(value = "/listTempPoUnitsOfChildProducts", method = RequestMethod.POST)
	@ResponseBody
	public String listUnitsOfSubProducts(@RequestParam("prodId") String productId)
			 {
		String measurement="";
		
	
		measurement=irs.loadIndentReceiveMeasurements(productId);
		
		return measurement;
	}
	
	@RequestMapping(value = "/getTempPoProductAvailability.spring", method = RequestMethod.POST)
	@ResponseBody
	public String getTempPoProductAvailability(@RequestParam("prodId") String productId,
			@RequestParam("indentNumber") String indentNumber,@RequestParam("VendorName") String VendorName,
			@RequestParam("subProductId") String subProductId,@RequestParam("childProdId") String childProdId,
			@RequestParam("measurementId") String measurementId,@RequestParam("productName") String productName,
			@RequestParam("subProductName") String subProductName,@RequestParam("childProductName") String childProductName,
			@RequestParam("measurementName") String measurementName,@RequestParam("req_Quan") String req_Quan,
			@RequestParam("init_Quan") String init_Quan,@RequestParam("indent_Creation_dtls_Id") String indent_Creation_dtls_Id,
			@RequestParam("pending_Quan") String pending_Quan,HttpServletRequest request) {
		String measurement="";
		
		request.getParameter("productId");
		
		//tester=ravi
		
		request.setAttribute("listOfGetProductDetails",objPurchaseDeptIndentrocess.getProductDetailsLists(indentNumber,VendorName,request,"true"));
		String value=request.getAttribute("productvalues").toString();
	
	
		
		return value;
	}
	
	@RequestMapping(value = "/UpdatePO.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String UpdatePO(HttpServletRequest request, HttpSession session,Model model){

		String site_id ="";
		String user_id = "";
		String result="";
		Map<String, String> siteDetails = null;
		try {
			//site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			site_id=request.getParameter("site")== null ? "" : request.getParameter("site").toString();
			request.setAttribute("isPoUpdated","true");
			siteDetails = new IndentSummaryDao().getSiteDetails();
			request.setAttribute("siteDetails",siteDetails);
			if(StringUtils.isNotBlank(String.valueOf(site_id))){
				List<Map<String, Object>> listOfPOs=objPurchaseDeptIndentrocess.getListOfActivePOs(site_id);
				if(listOfPOs.size()>0){
					model.addAttribute("listOfPOs",listOfPOs);
					result="ShowPOListToRevised";
				}else{
					
					model.addAttribute("displayErrMsg","Po not Available With this Site");
					result="RevisedOrUpdatePOPages";
				}
				
				
			}else{
				
				result="RevisedOrUpdatePOPages";

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"Update PO List","Success",String.valueOf(site_id));
		return "ShowPOListToRevised";
	}
	@RequestMapping(value = "/showPODetailsToUpdate.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String showPODetailsToUpdate(HttpServletRequest request, HttpSession session,Model model){

		int site_id = 0;
		String user_id = "";
		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();

			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("productsMap", dcFormService.loadProds());
			model.addAttribute("gstMap", dcFormService.getGSTSlabs());
			model.addAttribute("chargesMap", dcFormService.getOtherCharges());

			ProductDetails objProductDetails = new ProductDetails();
			model.addAttribute("CreatePOModelForm", objProductDetails);
			//ics.createPO(model, request);
			List<ProductDetails> IndentDetails = null;
			String poNumber = request.getParameter("poNumber");
			model.addAttribute("poNumber",poNumber);
			String reqSiteId = request.getParameter("reqSiteId");
			model.addAttribute("poDetails",irs.getPODetails(poNumber,reqSiteId ));
			model.addAttribute("listOfGetProductDetails",irs.getProductDetailsLists(poNumber,reqSiteId));
			model.addAttribute("listOfTransChrgsDtls",irs.getTransChrgsDtls(poNumber,reqSiteId));
			request.setAttribute("isPoUpdated","true");
			
			List<String> listTermsAndCondition  = objPurchaseDeptIndentrocess.getTempTermsAndConditions(poNumber,"true",reqSiteId);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());
			
			/*List<ProductDetails> listTermsAndCondition = objPurchaseDeptIndentrocess.getTermsAndConditions(reqSiteId);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());*/

			String ccEmails = objPurchaseDeptIndentrocess.getDefaultCCEmails(reqSiteId);
			model.addAttribute("ccEmails",ccEmails);

		} catch (Exception e) {
			e.printStackTrace();
		}



		SaveAuditLogDetails.auditLog("0",user_id,"Showing updated PO Details for Update","Success",String.valueOf(site_id));
		return "ShowPODetailsToRevised";
	}

	@RequestMapping(value = "/editAndSaveUpdatePO.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String editAndSaveUpdatedPO(HttpServletRequest request, HttpSession session,Model model){
		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate="";
		
		int site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		
	
		request.setAttribute("poPage","true");
		ProductDetails objProductDetails = new ProductDetails();
		//ics.createPO(model, request);
		model.addAttribute("CreatePOModelForm", objProductDetails);
		String response = objPurchaseDeptIndentrocess.editAndSaveUpdatePO(model, request, session);

		//String response = objPurchaseDeptIndentrocess.SavePoDetails(model, request, session);

		if(response=="Success"){

			model.addAttribute("response","Successfully Updated ");

		}
		else{
			model.addAttribute("response1"," not successfully updated ");

		}
		SaveAuditLogDetails.auditLog("0",user_id,"Save updated PO Details",response,String.valueOf(site_id));
		return "response";
	}

	
	/************************************************************************siteLevelPo*****************************/
	
	
	@RequestMapping(value = "/createPoPage.spring", method ={RequestMethod.POST,RequestMethod.GET})
	public String createPoPage(Model model, HttpServletRequest request,HttpSession session) {
		  
		
		String response = "";
		String user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
		String site_id =session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
		List<ProductDetails> IndentDetails = null;
		try {
			
			//int siteWiseIndentNo = 
			model.addAttribute("indentReceiveModelForm", new IndentReceiveBean());
			model.addAttribute("productsMap", irs.loadProds());
			model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
			model.addAttribute("gstMap", irs.getGSTSlabs());
			model.addAttribute("chargesMap", irs.getOtherCharges());
			model.addAttribute("siteName",iis.getProjectName(session));
			
			model.addAttribute("siteWiseIndentNo",ics.getMaxOfSiteWiseIndentNumber(Integer.parseInt(site_id)));
			model.addAttribute("indentNumber",ics.getIndentCreationSequenceNumber());
			model.addAttribute("productList",IndentDetails);
			List<ProductDetails> listTermsAndCondition = objPurchaseDeptIndentrocess.getTermsAndConditions(site_id);
			model.addAttribute("listTermsAndCondition",listTermsAndCondition);
			model.addAttribute("TC_listSize", listTermsAndCondition.size());

			String ccEmails = objPurchaseDeptIndentrocess.getDefaultCCEmails(site_id);
			model.addAttribute("ccEmails",ccEmails);

			
		}catch(Exception e){
			e.printStackTrace();
		}
		SaveAuditLogDetails.auditLog("0",user_id,"create PO SitelevelPage",response,String.valueOf(site_id));
		
		return "CreatePoSiteLevel";
		}
	
	
	@RequestMapping(value = "/SaveSiteLevelPoDetails.spring", method = RequestMethod.POST)
	public String SaveSiteLevelPoDetails(Model model, HttpServletRequest request,HttpSession session) {
		int site_id = 0;
		String user_id = "";
		String response = "";

		String versionNo="";
		String refferenceNo="";
		String strPoPrintRefdate = "";
		String strValue="";

		try {
			session = request.getSession(true);
			site_id = Integer.parseInt(session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString());
			user_id = session.getAttribute("UserId") == null ? "" : session.getAttribute("UserId").toString();
			int indent_Number =Integer.parseInt(request.getParameter("indentNumber").toString());
			String siteWiseIndent=request.getParameter("siteWiseIndentNo");
			int currentYear = Calendar.getInstance().get(Calendar.YEAR);
			int currentMonth = Calendar.getInstance().get(Calendar.MONTH)+1;
			Calendar cal = Calendar.getInstance();
			String currentYearYY = new SimpleDateFormat("YY").format(cal.getTime());
			String strFinacialYear = "";
			//String FinacialYear = "";

			if(currentMonth <=3){

				strFinacialYear = (currentYear-1)+"-"+Integer.parseInt(currentYearYY);
			}else{
				strFinacialYear = currentYear+"-"+(Integer.parseInt(currentYearYY)+1);
			}
			//	request.setAttribute("strFinacialYear",strFinacialYear);
			versionNo = validateParams.getProperty("PO_versionNo");
			refferenceNo = validateParams.getProperty("PO_Refference");
			strPoPrintRefdate = validateParams.getProperty("PO_issuedate");
			
			request.setAttribute("versionNo", versionNo);
			request.setAttribute("refferenceNo", refferenceNo);
			request.setAttribute("strPoPrintRefdate", strPoPrintRefdate);
			
			model.addAttribute("versionNo",versionNo);
			model.addAttribute("refferenceNo",refferenceNo);
			model.addAttribute("strPoPrintRefdate",strPoPrintRefdate);
			request.setAttribute("poPage","true");
			ProductDetails objProductDetails = new ProductDetails();
			//ics.createPO(model, request);
			model.addAttribute("CreatePOModelForm", objProductDetails);
			int val=objPurchaseDeptIndentrocess.insertSiteLevelIndentData(site_id,user_id,indent_Number,siteWiseIndent);
			if(val>0){
			strValue=objPurchaseDeptIndentrocess.SavePoDetails(model,request,session,strFinacialYear);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		SaveAuditLogDetails.auditLog("0",user_id,"SiteLevel PO Created",response,String.valueOf(site_id));
		//System.out.println("return page name: "+strValue);
		return strValue;

	}
	/************************************************************************************sample page******************************************************/
	
	

	
}
