package com.sumadhura.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;

import com.sumadhura.dto.PriceMasterDTO;
import com.sumadhura.transdao.ReportsDao;

/**
 * 
 * @author Aniket Chavan
 * @since 5/31/2018 4:24
 * @category Generatring Reports
 *
 */
@Service(value = "guiReportService")

public class ReportsServiceImpl implements ReportsService {
	@Autowired
	PlatformTransactionManager transactionManager;

	@Autowired
	@Qualifier("guireportdao")
	ReportsDao dao;

	@Override
	public String getProdcutsDetail(String siteId) {
		String allProductData = dao.getAllProductsDetail(siteId);
		return allProductData;
	}

	@Override
	public Set<PriceMasterDTO> getProductPriceListBySite(String siteId, String childProdName) {
		Set<PriceMasterDTO> latestChildProdPriceData = dao.getProductPriceListBySite(siteId,childProdName);
		return latestChildProdPriceData;
	}

	@Override
	/**
	 * @author Aniket
	 * @since 07/06/2018 7:00
	 */
	public Map<String, Collection<PriceMasterDTO>> getLastThreeMonthPriceMasterDetail(String childProductId,
			String prodName, String priceId, String site_id) {
		Set<PriceMasterDTO> threeMonthData = dao.getLastThreeMonthPriceMasterDetail(childProductId, prodName, priceId,
				site_id);
		List<PriceMasterDTO> firstMonth = new ArrayList<PriceMasterDTO>();
		List<PriceMasterDTO> secondMonth = new ArrayList<PriceMasterDTO>();
		List<PriceMasterDTO> thirdMonth = new ArrayList<PriceMasterDTO>();

		Map<String, Collection<PriceMasterDTO>> monthWiseData = new HashMap<String, Collection<PriceMasterDTO>>();

		Calendar now = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MMMyy");
		String currentMonthDateAndYear = dateFormat.format(Calendar.getInstance().getTime()).toUpperCase();
		String currentMonthDate = currentMonthDateAndYear.substring(0, 3);
		now = Calendar.getInstance();
		now.add(Calendar.MONTH, -1);
		String previousMonthDateAndYear = dateFormat.format(now.getTime()).toUpperCase();
		String previousMonthDate = previousMonthDateAndYear.substring(0, 3);
		now = Calendar.getInstance();
		now.add(Calendar.MONTH, -2);
		String twoMonthBeforeDateYear = dateFormat.format(now.getTime()).toUpperCase();
		String twoMonthBeforeDate = twoMonthBeforeDateYear.substring(0, 3);
		monthWiseData = extractMonthData(threeMonthData, site_id, twoMonthBeforeDateYear, twoMonthBeforeDate,
				previousMonthDateAndYear, previousMonthDate, currentMonthDateAndYear, currentMonthDate);

		firstMonth = (List<PriceMasterDTO>) monthWiseData.get("firstMonth");
		secondMonth = (List<PriceMasterDTO>) monthWiseData.get("secondMonth");
		thirdMonth = (List<PriceMasterDTO>) monthWiseData.get("thirdMonth");
		if (firstMonth.size() == 0 && secondMonth.size() == 0 && thirdMonth.size() == 0) {
			System.out.println("last three months data is empty...");
			threeMonthData = dao.getLastThreeMonthPriceMasterDetail(childProductId, null, priceId, site_id);
			System.out.println(threeMonthData);
			now = Calendar.getInstance();
			dateFormat = new SimpleDateFormat("MMMyy");
			now = Calendar.getInstance();
			now.add(Calendar.MONTH, -3);
			currentMonthDateAndYear = dateFormat.format(now.getTime()).toUpperCase();
			currentMonthDate = currentMonthDateAndYear.substring(0, 3);
			now = Calendar.getInstance();
			now.add(Calendar.MONTH, -4);
			previousMonthDateAndYear = dateFormat.format(now.getTime()).toUpperCase();
			previousMonthDate = previousMonthDateAndYear.substring(0, 3);
			now = Calendar.getInstance();
			now.add(Calendar.MONTH, -5);
			twoMonthBeforeDateYear = dateFormat.format(now.getTime()).toUpperCase();
			twoMonthBeforeDate = twoMonthBeforeDateYear.substring(0, 3);

			monthWiseData = extractMonthData(threeMonthData, site_id, twoMonthBeforeDateYear, twoMonthBeforeDate,
					previousMonthDateAndYear, previousMonthDate, currentMonthDateAndYear, currentMonthDate);
			return monthWiseData;
		}

		return monthWiseData;
	}

	private Map<String, Collection<PriceMasterDTO>> extractMonthData(Set<PriceMasterDTO> allData, String site_id,
			String twoMonthBeforeDateYear, String twoMonthBeforeDate, String previousMonthDateAndYear,
			String previousMonthDate, String currentMonthDateAndYear, String currentMonthDate) {

		Map<String, Collection<PriceMasterDTO>> monthWiseData = new HashMap<String, Collection<PriceMasterDTO>>();

		List<PriceMasterDTO> firstMonth = new ArrayList<PriceMasterDTO>();
		List<PriceMasterDTO> secondMonth = new ArrayList<PriceMasterDTO>();
		List<PriceMasterDTO> thirdMonth = new ArrayList<PriceMasterDTO>();
		for (PriceMasterDTO object : allData) {
		
			if (twoMonthBeforeDateYear.equals(object.getCreated_date())) {
			
				thirdMonth.add(new PriceMasterDTO(object.getPrice_id() == null ? "" : object.getPrice_id().toString(),
						object.getChild_product_id() == null ? "" : object.getChild_product_id().toString(),
						object.getChild_product_name() == null ? "" : object.getChild_product_name().toString(),
						object.getMeasurement_name() == null ? "" : object.getMeasurement_name().toString(),
						object.getAmount_per_unit_before_taxes() == null ? ""
								: object.getAmount_per_unit_before_taxes().toString(),
						object.getAmount_per_unit_after_taxes() == null ? ""
								: object.getAmount_per_unit_after_taxes().toString(),
						object.getAvailable_quantity() == null ? "" : object.getAvailable_quantity().toString(),
						object.getBasic_amount() == null ? "" : object.getBasic_amount().toString(),
						object.getTotal_amount() == null ? "" : object.getTotal_amount().toString(),
						object.getAmount_after_tax() == null ? "" : object.getAmount_after_tax().toString(),
						object.getCreated_date() == null ? "" : object.getCreated_date().toString(),
						site_id == null ? "" : site_id.toString(),
						twoMonthBeforeDate == null ? "" : twoMonthBeforeDate.toString()));
			}
			if (previousMonthDateAndYear.equals(object.getCreated_date())) {

				secondMonth.add(new PriceMasterDTO(object.getPrice_id() == null ? "" : object.getPrice_id().toString(),
						object.getChild_product_id() == null ? "" : object.getChild_product_id().toString(),
						object.getChild_product_name() == null ? "" : object.getChild_product_name().toString(),
						object.getMeasurement_name() == null ? "" : object.getMeasurement_name().toString(),
						object.getAmount_per_unit_before_taxes() == null ? ""
								: object.getAmount_per_unit_before_taxes().toString(),
						object.getAmount_per_unit_after_taxes() == null ? ""
								: object.getAmount_per_unit_after_taxes().toString(),
						object.getAvailable_quantity() == null ? "" : object.getAvailable_quantity().toString(),
						object.getBasic_amount() == null ? "" : object.getBasic_amount().toString(),
						object.getTotal_amount() == null ? "" : object.getTotal_amount().toString(),
						object.getAmount_after_tax() == null ? "" : object.getAmount_after_tax().toString(),
						object.getCreated_date() == null ? "" : object.getCreated_date().toString(),
						site_id == null ? "" : site_id.toString(),
						previousMonthDate == null ? "" : previousMonthDate.toString()));
			}
			if (currentMonthDateAndYear.equals(object.getCreated_date())) {

				firstMonth.add(new PriceMasterDTO(object.getPrice_id() == null ? "" : object.getPrice_id().toString(),
						object.getChild_product_id() == null ? "" : object.getChild_product_id().toString(),
						object.getChild_product_name() == null ? "" : object.getChild_product_name().toString(),
						object.getMeasurement_name() == null ? "" : object.getMeasurement_name().toString(),
						object.getAmount_per_unit_before_taxes() == null ? ""
								: object.getAmount_per_unit_before_taxes().toString(),
						object.getAmount_per_unit_after_taxes() == null ? ""
								: object.getAmount_per_unit_after_taxes().toString(),
						object.getAvailable_quantity() == null ? "" : object.getAvailable_quantity().toString(),
						object.getBasic_amount() == null ? "" : object.getBasic_amount().toString(),
						object.getTotal_amount() == null ? "" : object.getTotal_amount().toString(),
						object.getAmount_after_tax() == null ? "" : object.getAmount_after_tax().toString(),
						object.getCreated_date() == null ? "" : object.getCreated_date().toString(),
						site_id == null ? "" : site_id.toString(),
						currentMonthDate == null ? "" : currentMonthDate.toString()));
			}
		}
		monthWiseData.put("firstMonth", firstMonth);
		monthWiseData.put("secondMonth", secondMonth);
		monthWiseData.put("thirdMonth", thirdMonth);

		System.out.println("firstMonth " + firstMonth.size());
		System.out.println(("secondMonth " + secondMonth.size()));
		System.out.println(("thirdMonth " + thirdMonth.size()));

		return monthWiseData;
	}

	@Override
	public String getRequestedAmountReportBySite(String siteId, String tillDatePaymentReq) {
		return dao.getRequestedAmountReportBySite(siteId,tillDatePaymentReq);
	}

	@Override
	public List<String> loadAllChildProducts(String prodName) {
		// TODO Auto-generated method stub
		return dao.loadAllChildProducts(prodName);
	}
}
