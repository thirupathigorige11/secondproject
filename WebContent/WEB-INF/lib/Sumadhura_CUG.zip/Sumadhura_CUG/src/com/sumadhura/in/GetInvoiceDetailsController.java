package com.sumadhura.in;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sumadhura.bean.GetInvoiceDetailsBean;
import com.sumadhura.bean.IndentReceiveBean;
import com.sumadhura.bean.ViewIndentIssueDetailsBean;
import com.sumadhura.service.GetTransportChargesListService;
import com.sumadhura.service.IndentReceiveService;
import com.sumadhura.service.InwardToGetInvoiceDetailsService;
import com.sumadhura.transdao.IndentIssueDaoImpl;
import com.sumadhura.util.SaveAuditLogDetails;
import com.sumadhura.util.UIProperties;
@Controller
public class GetInvoiceDetailsController extends UIProperties{

	@Autowired
	@Qualifier("irsClass")
	IndentReceiveService irs;
	@Autowired
	InwardToGetInvoiceDetailsService inwardToGetInvoiceDetails;
	GetTransportChargesListService transportChargesList;



	@RequestMapping(value = "/inwardGetInvoiceDetails.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView doInwardGetInvoiceDetails(HttpSession session){

		ModelAndView model = null;

		try {
			model = new ModelAndView();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("indentGetInvoiceDetails");
		}
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Update Invoice Details View","success",site_id1);
		
		
		return model;

	}
//this method is loading all venor Names
	@RequestMapping(value = "/loadVendorNames.spring", method = RequestMethod.GET)
	public @ResponseBody String loadVendorNames(HttpServletResponse response, HttpServletRequest request, HttpSession session) {
	System.out.println("GetInvoiceDetailsController.loadVendorNames()");
		String resp = "";
		try {
			String vendorName=request.getParameter("vendorName")==null?"":request.getParameter("vendorName");
			System.out.println(vendorName);
			List<String> childProductList = inwardToGetInvoiceDetails.loadAllVendorNames(vendorName);
			Gson gson=new Gson();
			resp =gson.toJson(childProductList);
			System.out.println(resp);
			return resp;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resp;
	}

	@RequestMapping(value = "/doGetInvoiceDetails.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String doIndentIssueToOtherSiteInwards(HttpServletRequest request, HttpSession session,Model model){

		String invoiceNumber = "";
		String siteId = "";
		String response="";
		String vendorName1="";
		try {

			invoiceNumber = request.getParameter("invoiceNumber") == null ? "" : request.getParameter("invoiceNumber");
			vendorName1=request.getParameter("vendorName") == null ? "" : request.getParameter("vendorName");
			System.out.println(vendorName1+" controller "+invoiceNumber);
			siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			
			//dnt knw
			String response1=inwardToGetInvoiceDetails.getVendorNameAndIndentEntryId(invoiceNumber,vendorName1);
			String data[]=response1.split("\\|");
			String indentEntryId=data[0];
			String  vendorName=data[1];
			
			
			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(invoiceNumber)){

				List<GetInvoiceDetailsBean> list=inwardToGetInvoiceDetails.getIssuesToOtherLists(invoiceNumber, siteId,vendorName1);
				if(list.size() > 0){

					model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
					model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
					model.addAttribute("listIssueToOtherSiteInwardLists",list);
					model.addAttribute("listOfGetProductDetails",inwardToGetInvoiceDetails.getGetInvoiceDetailsLists(invoiceNumber, siteId,vendorName1));
					model.addAttribute("listOfTransportChargesDetails",inwardToGetInvoiceDetails.getTransportChargesList(invoiceNumber, siteId));
					model.addAttribute("gstMap", irs.getGSTSlabs());
					model.addAttribute("chargesMap", irs.getOtherCharges());
					System.out.println("InvoiceNumber "+invoiceNumber);
					response="success";
					int count=0;
					for(int i=0;i<4;i++){
						String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
						String imgname = vendorName1+"_"+invoiceNumber+"_"+indentEntryId;
						imgname = imgname.replace("/","$$");
						File f = new File(rootFilePath+siteId+"/"+imgname+"_Part"+i+".jpg");

						if(f.exists()){
							count++;
							DataInputStream dis;
							try {
								dis = new DataInputStream(new FileInputStream(f));
								byte[] barray = new byte[(int) f.length()];
								dis.readFully(barray); 
								byte[] encodeBase64 = Base64.encodeBase64(barray);
								String base64Encoded = new String(encodeBase64, "UTF-8");
								model.addAttribute("image"+i,base64Encoded);
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							
						}
					}
					model.addAttribute("count",count );
					
				}
				else{
					request.setAttribute("Message", "Invoice number doesn't available in our record");
                	response="failed";
					return "indentGetInvoiceDetails";
				}

			} 
		} catch(Exception ex) {
			response="failed";
			ex.printStackTrace();
		} 
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Update Invoice Details click submit",response,site_id1);
		
		return "getInvoiceDetailsInwards";
	}

	@RequestMapping(value = "/getInvoiceDetails.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String getInvoiceDetails(HttpServletRequest request, HttpSession session,Model model){




		String invoiceNumber = "";
		String vendorName = "";
		String vendorId = "";
		String siteId = "";
		String strIndentEntryId  = ""; 
		String invoiceDate = "";
		boolean imageClick = false;
		try {

			invoiceNumber = request.getParameter("invoiceNumber") == null ? "" : request.getParameter("invoiceNumber");
			invoiceDate = request.getParameter("invoiceDate") == null ? "" : request.getParameter("invoiceDate");
			vendorName = request.getParameter("vendorName") == null ? "" : request.getParameter("vendorName");
			vendorId = request.getParameter("vendorId") == null ? "" : request.getParameter("vendorId");
			strIndentEntryId = request.getParameter("IndentEntryId") == null ? "" : request.getParameter("IndentEntryId");
			siteId = request.getParameter("SiteId") == null ? "" : request.getParameter("SiteId");
			//siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			imageClick = request.getParameter("imageClick") == null ? false : Boolean.valueOf(request.getParameter("imageClick"));
			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(invoiceNumber)){
				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				model.addAttribute("listIssueToOtherSiteInwardLists",inwardToGetInvoiceDetails.getInvoiceDetails(invoiceNumber, siteId,vendorId,invoiceDate));
				model.addAttribute("listOfGetProductDetails",inwardToGetInvoiceDetails.getGetInvoiceDetailsLists2(invoiceNumber, siteId,vendorId,invoiceDate));
				model.addAttribute("listOfTransportChargesDetails",inwardToGetInvoiceDetails.getTransportChargesList2(invoiceNumber, siteId,vendorId,invoiceDate));
				model.addAttribute("gstMap", irs.getGSTSlabs());
				model.addAttribute("chargesMap", irs.getOtherCharges());
				System.out.println("InvoiceNumber "+invoiceNumber);
				//--------------------
				int count=0;
				//String vendorNameAndIndentId = inwardToGetInvoiceDetails.getVendorNameAndIndentId(invoiceNumber,  siteId, vendorName);
				//String[] arr = vendorNameAndIndentId.split("@@");
				//String vendorName = arr[0];
				//String indentId = arr[1];
				for(int i=0;i<8;i++){
					String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
					String imgname = vendorName+"_"+invoiceNumber+"_"+strIndentEntryId;
					imgname = imgname.replace("/","$$");
					File f = new File(rootFilePath+siteId+"/"+imgname+"_Part"+i+".jpg");

					if(f.exists()){
						count++;
						DataInputStream dis = new DataInputStream(new FileInputStream(f));
						byte[] barray = new byte[(int) f.length()];
						dis.readFully(barray); 
						byte[] encodeBase64 = Base64.encodeBase64(barray);
						String base64Encoded = new String(encodeBase64, "UTF-8");
						model.addAttribute("image"+i,base64Encoded);
					}
				}
				model.addAttribute("count",count );
				//-----------------------------
			} 
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		if(imageClick){
			return "GetInvoiceDetailsOnImageClick";
		}
		else{
			return "GetInvoiceDetails";
		}
		
	}

	@RequestMapping(value = "/inwardViewInvoiceDetails.spring", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView doInwardVIewInvoiceDetails(){

		ModelAndView model = null;

		try {
			model = new ModelAndView();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			model.setViewName("ViewAllInvoices");
		}
		return model;
	}

	@RequestMapping(value = "/doInvoiceDetails.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public ModelAndView updateInvoiceDetails() {

		ModelAndView model = null;
		try {

			model = new ModelAndView();
		} catch (Exception ex) {

		}
		return model;
	}



	@RequestMapping(value = "/getGrnDetails.spring", method ={ RequestMethod.POST,RequestMethod.GET})
	public String getGrnDetails(HttpServletRequest request, HttpSession session,Model model){

		String invoiceNumber = "";
		String siteId = "";
		String viewToBeSelected = "";
		String strVendorId = "";
		try{
			invoiceNumber = request.getParameter("invoiceNumber") == null ? "" : request.getParameter("invoiceNumber");
			//strVendorId = request.getParameter("vendorId") == null ? "" : request.getParameter("vendorId");
			siteId = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();
			if (StringUtils.isNotBlank(siteId) && StringUtils.isNotBlank(invoiceNumber)){

				model.addAttribute("columnHeadersMap", ResourceBundle.getBundle("validationproperties"));
				model.addAttribute("invoiceDetailsModelForm", new GetInvoiceDetailsBean());
				String response=inwardToGetInvoiceDetails.getGrnDetails(invoiceNumber, siteId,request);
				//System.out.println("InvoiceNumber "+invoiceNumber);

				if(response.equalsIgnoreCase("Success")) {

					viewToBeSelected = "viewGRN";
				}

			}	
		}catch(Exception ex) {
			ex.printStackTrace();
		} 


		return viewToBeSelected;
	}



	@RequestMapping(value = "/updateInvoice", method = RequestMethod.POST)
	public String updateInvoice(@ModelAttribute("invoiceDetailsModelForm")IndentReceiveBean indentRecModel, BindingResult result, Model model, HttpServletRequest request, HttpSession session,@RequestParam("file") MultipartFile[] files) throws IOException  {
		String response = inwardToGetInvoiceDetails.updateInvoice(model, request, session);
		String invoiceNumber = request.getParameter("invoiceNumber");
		String vendorName = request.getParameter("vendorName");
		String indentEntryId=request.getParameter("indentEntryId");
		String site_id = String.valueOf(session.getAttribute("SiteId"));
		String imgname=vendorName+"_"+invoiceNumber+"_"+indentEntryId;
		String viewToBeSelected = "";
		int  numberOfImages=Integer.parseInt(request.getParameter("numberOfImages"));
		int images=(4)-numberOfImages;
		//String[] response_array = response1.split("@@");
		
		//String response2 = response_array [0];
		

		//imgname = "vname_invoiceno_entryid";
		imgname = imgname.replace("/","$$");
		for (int i=0; i < images; i++) {
			MultipartFile multipartFile = files[i];



			if (response.equalsIgnoreCase("Success")&&!multipartFile.isEmpty()) {
				
				
				try {

					String rootFilePath = validateParams.getProperty("INVOICE_IMAGE_PATH") == null ? "" : validateParams.getProperty("INVOICE_IMAGE_PATH").toString();
					File dir = new File(rootFilePath+site_id);
					if (!dir.exists())
						dir.mkdirs();

					
					String filePath = dir.getAbsolutePath()
					+ File.separator + imgname+"_Part"+numberOfImages+".jpg"; 
					numberOfImages++;

					multipartFile.transferTo(new File(filePath));


					//System.out.println("Image Uploaded");
					//return "You successfully uploaded file" ;
				} catch (Exception e) {
					//System.out.println("Image NOT Uploaded");
					//return "You failed to upload " ;
				}
			} else {
				//return "You failed to upload " + " because the file was empty.";
			}

		}

		
		if(response.equalsIgnoreCase("Success")) {

			viewToBeSelected = "viewGRN";
		}
		else if(response.equalsIgnoreCase("Failed")){
			viewToBeSelected = "indentReceiveResponse";
		} else if (response.equalsIgnoreCase("SessionFailed")){
			request.setAttribute("Message", "Session Expired, Please Login Again");
			viewToBeSelected = "index";
		}


		return viewToBeSelected;
	}


	@RequestMapping(value ="getGrnViewDts.spring", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getGrnViewDts(HttpServletRequest request,HttpSession session) {

		String site_id = "";
		String toDate = "";
		String fromDate = "";
		String response="";
		ModelAndView model = null;
		List<ViewIndentIssueDetailsBean> indentIssueData = null;
		try {
			model = new ModelAndView();
			fromDate = request.getParameter("fromDate");
			toDate = request.getParameter("toDate");
			if (StringUtils.isNotBlank(fromDate) || StringUtils.isNotBlank(toDate)) {
				 session = request.getSession(false);
				site_id = session.getAttribute("SiteId") == null ? "" : session.getAttribute("SiteId").toString();				
				System.out.println("From Date "+fromDate +"To Date "+toDate +"Site Id "+site_id);
				if (StringUtils.isNotBlank(site_id)) {
					indentIssueData = inwardToGetInvoiceDetails.getGrnViewDetails(fromDate, toDate, site_id);
					if(indentIssueData != null && indentIssueData.size() >0){
						request.setAttribute("showGrid", "true");
						response="success";
					} else {
						model.addObject("succMessage","The above Dates Data Not Available");
						response="failure";
						
					}
					model.addObject("indentIssueData",indentIssueData);
					model.addObject("fromDate",fromDate);
					model.addObject("toDate", toDate);
					model.setViewName("reports/ViewAllGRN");

				} else {
					model.addObject("Message","Session Expired, Please Login Again");
					model.setViewName("index");
					response="failure";
					return model;
				}
			} else {
				model.addObject("displayErrMsg", "Please Select From Date or To Date!");
				model.addObject("indentIssueData",indentIssueData);
				model.addObject("fromDate",fromDate);
				model.addObject("toDate", toDate);
				response="success";
				model.setViewName("reports/ViewAllGRN");
			}
		} catch (Exception ex) {
			response="failure";
			ex.printStackTrace();
		} 
		
		SaveAuditLogDetails audit=new SaveAuditLogDetails();
		//	String indentEntrySeqNum=session.getAttribute("indentEntrySeqNum").toString();
			String user_id=String.valueOf(session.getAttribute("UserId"));
			String site_id1 = String.valueOf(session.getAttribute("SiteId"));
			audit.auditLog("0",user_id,"Get Grn Details View",response,site_id1);
			
		return model;
	}
}
