package com.sumadhura.bean;

public class PaymentBean {

	private String strInvoiceNo ;
	private double doublePaymentIntiateAmount ;
	private String strPaymentIntiateType ;
	private String strVendorId ;
	private String strPaymentReqDate ;
	private double doubleAmountToBeReleased ;
	private  String strRemarks ;
	private String strInvoiceDate;
	/*private int intPaymentNo;
	private int intPaymentSeqNo;*/
	private int intPaymentId;
	private double doubleInvoiceAmount;
	private String strSiteId;
	private double doublePaymentDoneUpto;
	private double doublePaymentRequestedUpto;
	private String strDCNo;
	private String strPONo;
	private String strApproverEmpId;
	private String strPendingEmpId;
	private String strEmployeeId;
	private int intSerialNo;
	private String strVendorName;
	private String strReceiveDate;
	private String strPODate;
	private String strSiteName;
	//private int strIndentEntryId;
	private int intIndentEntryId;
	private String requestedAmount;
	private String requestedDate;
	private String actualRequestedAmount;
	private String actualRequestedDate;
	private String strComments;
	private int intTempTransactionId;
	//private int intAccDeptPaymentProcessSeqNo;
	private int intAccDeptPaymentProcessId;
	private String strRefrenceNo;
	private int intSiteWisePaymentId;
	private double doublePOTotalAmount;
	private String paymentType;
	private String paymentMode;
	private String paymentModeName;
	private String utrChequeNo;
	private int intPaymentDetailsId;
	//private String paymentId;
	//private String paymentDetailsId;
	private String strDCDate;
	private String strInvoiceReceivedDate;
	private String strInvoiceNoInAP;
	private String paymentModeDisplayName;
	private int intTempPaymentTransactionId;
	private double actualDoubleAdjustAmountFromAdvance;
	private double doublePaidAmount;
	private String strCreatedDate;
	private String strPendingDeptName;
	private String strPendingEmpName;
	private double doubleTransactionAmount;
	private double doubleCreditTotalAmount;
	private double doubleSecurityDeposit;//doubleAdvancePayment
	private String strPaymentRequestReceivedDate;
	private String strCreditNoteNumber;
	private String groupOfPaymentDetailsId;
	private String reqAmountAsGroup;
	private double doublePOAdvancePayment;
	private double doubleAdjustAmountFromAdvance;
	private boolean vendorHeader;
	private String strPaymentDate ;
	private String actualPaymentMode;
	private String actualUtrChequeNo;
	private int vendorGroupSerialNo;
	private String requestReceiveFrom;
	private int intPaymentTransactionId;
	private String status;
	private double doubleBalanceAmount;
	private String strRemarksForView;
	private int intNoofPaymentsVendorWise;
	private String invoiceImage0;
	private String invoiceImage1;
	private String invoiceImage2;
	private String invoiceImage3;
	private boolean hasImage;
	
	
	public boolean isHasImage() {
		return hasImage;
	}
	public void setHasImage(boolean hasImage) {
		this.hasImage = hasImage;
	}
	public String getInvoiceImage1() {
		return invoiceImage1;
	}
	public void setInvoiceImage1(String invoiceImage1) {
		this.invoiceImage1 = invoiceImage1;
	}
	public String getInvoiceImage2() {
		return invoiceImage2;
	}
	public void setInvoiceImage2(String invoiceImage2) {
		this.invoiceImage2 = invoiceImage2;
	}
	public String getInvoiceImage3() {
		return invoiceImage3;
	}
	public void setInvoiceImage3(String invoiceImage3) {
		this.invoiceImage3 = invoiceImage3;
	}
	public String getInvoiceImage0() {
		return invoiceImage0;
	}
	public void setInvoiceImage0(String invoiceImage0) {
		this.invoiceImage0 = invoiceImage0;
	}
	public String getPaymentModeName() {
		return paymentModeName;
	}
	public void setPaymentModeName(String paymentModeName) {
		this.paymentModeName = paymentModeName;
	}
	public int getIntNoofPaymentsVendorWise() {
		return intNoofPaymentsVendorWise;
	}
	public void setIntNoofPaymentsVendorWise(int intNoofPaymentsVendorWise) {
		this.intNoofPaymentsVendorWise = intNoofPaymentsVendorWise;
	}
	public String getStrRemarksForView() {
		return strRemarksForView;
	}
	public void setStrRemarksForView(String strRemarksForView) {
		this.strRemarksForView = strRemarksForView;
	}
	public double getDoubleBalanceAmount() {
		return doubleBalanceAmount;
	}
	public void setDoubleBalanceAmount(double doubleBalanceAmount) {
		this.doubleBalanceAmount = doubleBalanceAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getIntPaymentTransactionId() {
		return intPaymentTransactionId;
	}
	public void setIntPaymentTransactionId(int intPaymentTransactionId) {
		this.intPaymentTransactionId = intPaymentTransactionId;
	}
	public String getRequestReceiveFrom() {
		return requestReceiveFrom;
	}
	public void setRequestReceiveFrom(String requestReceiveFrom) {
		this.requestReceiveFrom = requestReceiveFrom;
	}
	public int getVendorGroupSerialNo() {
		return vendorGroupSerialNo;
	}
	public void setVendorGroupSerialNo(int vendorGroupSerialNo) {
		this.vendorGroupSerialNo = vendorGroupSerialNo;
	}
	public String getActualUtrChequeNo() {
		return actualUtrChequeNo;
	}
	public void setActualUtrChequeNo(String actualUtrChequeNo) {
		this.actualUtrChequeNo = actualUtrChequeNo;
	}
	public String getActualPaymentMode() {
		return actualPaymentMode;
	}
	public void setActualPaymentMode(String actualPaymentMode) {
		this.actualPaymentMode = actualPaymentMode;
	}
	public String getStrPaymentDate() {
		return strPaymentDate;
	}
	public void setStrPaymentDate(String strPaymentDate) {
		this.strPaymentDate = strPaymentDate;
	}
	public boolean isVendorHeader() {
		return vendorHeader;
	}
	public void setVendorHeader(boolean vendorHeader) {
		this.vendorHeader = vendorHeader;
	}
	public double getActualDoubleAdjustAmountFromAdvance() {
		return actualDoubleAdjustAmountFromAdvance;
	}
	public void setActualDoubleAdjustAmountFromAdvance(double actualDoubleAdjustAmountFromAdvance) {
		this.actualDoubleAdjustAmountFromAdvance = actualDoubleAdjustAmountFromAdvance;
	}
	public double getDoublePOAdvancePayment() {
		return doublePOAdvancePayment;
	}
	public void setDoublePOAdvancePayment(double doublePOAdvancePayment) {
		this.doublePOAdvancePayment = doublePOAdvancePayment;
	}
	public double getDoubleAdjustAmountFromAdvance() {
		return doubleAdjustAmountFromAdvance;
	}
	public void setDoubleAdjustAmountFromAdvance(double doubleAdjustAmountFromAdvance) {
		this.doubleAdjustAmountFromAdvance = doubleAdjustAmountFromAdvance;
	}
	public String getReqAmountAsGroup() {
		return reqAmountAsGroup;
	}
	public void setReqAmountAsGroup(String reqAmountAsGroup) {
		this.reqAmountAsGroup = reqAmountAsGroup;
	}
	public String getGroupOfPaymentDetailsId() {
		return groupOfPaymentDetailsId;
	}
	public void setGroupOfPaymentDetailsId(String groupOfPaymentDetailsId) {
		this.groupOfPaymentDetailsId = groupOfPaymentDetailsId;
	}
	public String getStrCreditNoteNumber() {
		return strCreditNoteNumber;
	}
	public void setStrCreditNoteNumber(String strCreditNoteNumber) {
		this.strCreditNoteNumber = strCreditNoteNumber;
	}
	public String getStrPaymentRequestReceivedDate() {
		return strPaymentRequestReceivedDate;
	}
	public void setStrPaymentRequestReceivedDate(String strPaymentRequestReceivedDate) {
		this.strPaymentRequestReceivedDate = strPaymentRequestReceivedDate;
	}
	public double getDoubleSecurityDeposit() {
		return doubleSecurityDeposit;
	}
	public void setDoubleSecurityDeposit(double doubleSecurityDeposit) {
		this.doubleSecurityDeposit = doubleSecurityDeposit;
	}
	public int getIntIndentEntryId() {
		return intIndentEntryId;
	}
	public void setIntIndentEntryId(int intIndentEntryId) {
		this.intIndentEntryId = intIndentEntryId;
	}
	
	public double getDoubleCreditTotalAmount() {
		return doubleCreditTotalAmount;
	}
	public void setDoubleCreditTotalAmount(double doubleCreditTotalAmount) {
		this.doubleCreditTotalAmount = doubleCreditTotalAmount;
	}
	public String getStrPendingDeptName() {
		return strPendingDeptName;
	}
	public void setStrPendingDeptName(String strPendingDeptName) {
		this.strPendingDeptName = strPendingDeptName;
	}
	public String getStrPendingEmpName() {
		return strPendingEmpName;
	}
	public void setStrPendingEmpName(String strPendingEmpName) {
		this.strPendingEmpName = strPendingEmpName;
	}
	
	public double getDoubleTransactionAmount() {
		return doubleTransactionAmount;
	}
	public void setDoubleTransactionAmount(double doubleTransactionAmount) {
		this.doubleTransactionAmount = doubleTransactionAmount;
	}
	
	public String getStrCreatedDate() {
		return strCreatedDate;
	}
	public void setStrCreatedDate(String strCreatedDate) {
		this.strCreatedDate = strCreatedDate;
	}
	public double getDoublePaidAmount() {
		return doublePaidAmount;
	}
	public void setDoublePaidAmount(double doublePaidAmount) {
		this.doublePaidAmount = doublePaidAmount;
	}
	public int getIntSiteWisePaymentId() {
		return intSiteWisePaymentId;
	}
	public void setIntSiteWisePaymentId(int intSiteWisePaymentId) {
		this.intSiteWisePaymentId = intSiteWisePaymentId;
	}
	public int getIntTempPaymentTransactionId() {
		return intTempPaymentTransactionId;
	}
	public void setIntTempPaymentTransactionId(int intTempPaymentTransactionId) {
		this.intTempPaymentTransactionId = intTempPaymentTransactionId;
	}
	public String getPaymentModeDisplayName() {
		return paymentModeDisplayName;
	}
	public void setPaymentModeDisplayName(String paymentModeDisplayName) {
		this.paymentModeDisplayName = paymentModeDisplayName;
	}
	public String getStrInvoiceNoInAP() {
		return strInvoiceNoInAP;
	}
	public void setStrInvoiceNoInAP(String strInvoiceNoInAP) {
		this.strInvoiceNoInAP = strInvoiceNoInAP;
	}
	public String getStrDCDate() {
		return strDCDate;
	}
	public void setStrDCDate(String strDCDate) {
		this.strDCDate = strDCDate;
	}
	public String getStrInvoiceReceivedDate() {
		return strInvoiceReceivedDate;
	}
	public void setStrInvoiceReceivedDate(String strInvoiceReceivedDate) {
		this.strInvoiceReceivedDate = strInvoiceReceivedDate;
	}
	public int getIntPaymentId() {
		return intPaymentId;
	}
	public void setIntPaymentId(int intPaymentId) {
		this.intPaymentId = intPaymentId;
	}
	public int getIntAccDeptPaymentProcessId() {
		return intAccDeptPaymentProcessId;
	}
	public void setIntAccDeptPaymentProcessId(int intAccDeptPaymentProcessId) {
		this.intAccDeptPaymentProcessId = intAccDeptPaymentProcessId;
	}
	public int getIntPaymentDetailsId() {
		return intPaymentDetailsId;
	}
	public void setIntPaymentDetailsId(int intPaymentDetailsId) {
		this.intPaymentDetailsId = intPaymentDetailsId;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getUtrChequeNo() {
		return utrChequeNo;
	}
	public void setUtrChequeNo(String utrChequeNo) {
		this.utrChequeNo = utrChequeNo;
	}
	public double getDoublePOTotalAmount() {
		return doublePOTotalAmount;
	}
	public void setDoublePOTotalAmount(double doublePOTotalAmount) {
		this.doublePOTotalAmount = doublePOTotalAmount;
	}
	public String getStrComments() {
		return strComments;
	}
	public void setStrComments(String strComments) {
		this.strComments = strComments;
	}
	public int getIntTempTransactionId() {
		return intTempTransactionId;
	}
	public void setIntTempTransactionId(int intTempTransactionId) {
		this.intTempTransactionId = intTempTransactionId;
	}
	
	public String getStrRefrenceNo() {
		return strRefrenceNo;
	}
	public void setStrRefrenceNo(String strRefrenceNo) {
		this.strRefrenceNo = strRefrenceNo;
	}
	
	
	public double getDoublePaymentRequestedUpto() {
		return doublePaymentRequestedUpto;
	}
	public void setDoublePaymentRequestedUpto(double doublePaymentRequestedUpto) {
		this.doublePaymentRequestedUpto = doublePaymentRequestedUpto;
	}
	public String getActualRequestedAmount() {
		return actualRequestedAmount;
	}
	public void setActualRequestedAmount(String actualRequestedAmount) {
		this.actualRequestedAmount = actualRequestedAmount;
	}
	public String getActualRequestedDate() {
		return actualRequestedDate;
	}
	public void setActualRequestedDate(String actualRequestedDate) {
		this.actualRequestedDate = actualRequestedDate;
	}
	public String getRequestedDate() {
		return requestedDate;
	}
	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}

	
	
	
	
	
	public String getRequestedAmount() {
		return requestedAmount;
	}
	public void setRequestedAmount(String requestedAmount) {
		this.requestedAmount = requestedAmount;
	}
	
	public String getStrSiteName() {
		return strSiteName;
	}
	public void setStrSiteName(String strSiteName) {
		this.strSiteName = strSiteName;
	}
	public String getStrPODate() {
		return strPODate;
	}
	public void setStrPODate(String strPODate) {
		this.strPODate = strPODate;
	}
	public String getStrReceiveDate() {
		return strReceiveDate;
	}
	public void setStrReceiveDate(String strReceiveDate) {
		this.strReceiveDate = strReceiveDate;
	}
	public String getStrVendorName() {
		return strVendorName;
	}
	public void setStrVendorName(String strVendorName) {
		this.strVendorName = strVendorName;
	}
	public int getIntSerialNo() {
		return intSerialNo;
	}
	public void setIntSerialNo(int intSerialNo) {
		this.intSerialNo = intSerialNo;
	}
	public String getStrEmployeeId() {
		return strEmployeeId;
	}
	public void setStrEmployeeId(String strEmployeeId) {
		this.strEmployeeId = strEmployeeId;
	}
	public String getStrPendingEmpId() {
		return strPendingEmpId;
	}
	public void setStrPendingEmpId(String strPendingEmpId) {
		this.strPendingEmpId = strPendingEmpId;
	}
	public String getStrDCNo() {
		return strDCNo;
	}
	public void setStrDCNo(String strDCNo) {
		this.strDCNo = strDCNo;
	}
	public String getStrPONo() {
		return strPONo;
	}
	public void setStrPONo(String strPONo) {
		this.strPONo = strPONo;
	}
	public String getStrApproverEmpId() {
		return strApproverEmpId;
	}
	public void setStrApproverEmpId(String strApproverEmpId) {
		this.strApproverEmpId = strApproverEmpId;
	}
	public double getDoublePaymentDoneUpto() {
		return doublePaymentDoneUpto;
	}
	public void setDoublePaymentDoneUpto(double doublePaymentDoneUpto) {
		this.doublePaymentDoneUpto = doublePaymentDoneUpto;
	}
	public double getDoublePaymentIntiateAmount() {
		return doublePaymentIntiateAmount;
	}
	public void setDoublePaymentIntiateAmount(double doublePaymentIntiateAmount) {
		this.doublePaymentIntiateAmount = doublePaymentIntiateAmount;
	}
	public double getDoubleAmountToBeReleased() {
		return doubleAmountToBeReleased;
	}
	public void setDoubleAmountToBeReleased(double doubleAmountToBeReleased) {
		this.doubleAmountToBeReleased = doubleAmountToBeReleased;
	}
	public String getStrSiteId() {
		return strSiteId;
	}
	public void setStrSiteId(String strSiteId) {
		this.strSiteId = strSiteId;
	}
	public double getDoubleInvoiceAmount() {
		return doubleInvoiceAmount;
	}
	public void setDoubleInvoiceAmount(double doubleInvoiceAmount) {
		this.doubleInvoiceAmount = doubleInvoiceAmount;
	}
	
	public String getStrInvoiceDate() {
		return strInvoiceDate;
	}
	public void setStrInvoiceDate(String strInvoiceDate) {
		this.strInvoiceDate = strInvoiceDate;
	}
	public String getStrInvoiceNo() {
		return strInvoiceNo;
	}
	public void setStrInvoiceNo(String strInvoiceNo) {
		this.strInvoiceNo = strInvoiceNo;
	}
	
	public String getStrPaymentIntiateType() {
		return strPaymentIntiateType;
	}
	public void setStrPaymentIntiateType(String strPaymentIntiateType) {
		this.strPaymentIntiateType = strPaymentIntiateType;
	}
	public String getStrVendorId() {
		return strVendorId;
	}
	public void setStrVendorId(String strVendorId) {
		this.strVendorId = strVendorId;
	}
	public String getStrPaymentReqDate() {
		return strPaymentReqDate;
	}
	public void setStrPaymentReqDate(String strPaymentReqDate) {
		this.strPaymentReqDate = strPaymentReqDate;
	}
	
	
	public String getStrRemarks() {
		return strRemarks;
	}
	public void setStrRemarks(String strRemarks) {
		this.strRemarks = strRemarks;
	}
	
	
}
