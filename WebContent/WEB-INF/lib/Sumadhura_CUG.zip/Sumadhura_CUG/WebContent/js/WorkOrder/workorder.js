/**
 * work order js
 */
	//this function is used to load the childProducts of main products
		function myFunction(id, name, row) {
			$.ajax({
				url : "./loadChildProductList.spring",
				type : "GET",
				data : {
					prodId : id,
					prodName : name
				},
				dataType : "json",
				success : function(resp) {
				var str="";
					debugger;
						
					$.each(resp, function(index, value) {
				//		alert(value.CHILD_PRODUCT_ID + " " + value.NAME);
						str+="	<tr><td><input type='checkbox' name='check' value='"+value.CHILD_PRODUCT_ID+"'> </td><td>1<sup>st</sup> Floor</td><td>"+value.CHILD_PRODUCT_ID+"</td><td><label id='"+value.CHILD_PRODUCT_ID+"amount'>500</label>"+
						"</td></tr>";
					});
					str=str+"<tr><td colspan='4' align='center'>"+
					"<input type='button'	id='submitData' value='Submit' onclick=\"updateRecord('"+id+"')\"  name='submit'></td></tr>";
					$("#tab2").show();
					$("#tab2Tblbody").html(str);
				},
				error : function(data, status, er) {
					//  alert(data+"_"+status+"_"+er);
				}
			});
		}
		
		//this code is for appending the values the main record
		function updateRecord(id) {
		
		var total = "";
			var len = $("input[name='check']:checked").length;
			var i = 0;

			var favorite = [];
            $.each($("input[name='check']:checked"), function(){            
                var childProdId=$(this).val();
           
                var c=childProdId+"amount";
		       var amt=$("#"+childProdId+"amount").text();   
                    i++;
    				if (i < len)
    					total += amt + ",";
    				else
    					total += amt;
            });
            
			$("#" + id + "appendHere").html(total);
			$("#tab2").hide();
		}

		$(document).ready(function() {
			//this code is for checking all the checkboxes
			$("#checkAll").click(function() {
				if ($(this).is(":checked")) {
					var checkboxgroup = "input:checkbox[name='check']";
					$(checkboxgroup).prop("checked", true);
				} else {
					var checkboxgroup = "input:checkbox[name='check']";
					$(checkboxgroup).prop("checked", false);
				}
			});

		});